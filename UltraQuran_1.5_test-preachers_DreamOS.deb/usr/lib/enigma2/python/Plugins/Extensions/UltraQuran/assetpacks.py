# -*- coding: utf-8 -*-
"""Optional versioned artwork for the Lite install."""
import hashlib
import json
import os
import re
import shutil
import tarfile
import tempfile
import threading
import time

from . import support

_RELEASE = "https://github.com/K3bOra/UltraQuran/releases/download/"
_PACKS_FILE = os.path.join(support.ROOT, "asset-packs.json")
_PREFIXES = {
    "photos": ("portraits_src/", "posters_src/", "posters_ready/"),
    "art-1440p": ("art/2560/",),
}
_ASSET_NAME = re.compile(r"^[A-Za-z0-9_-]+\.(jpg|png)\Z")
_CHUNK = 128 * 1024
_RETRY_SECONDS = 90


def _manifest():
    try:
        with open(_PACKS_FILE, "r") as handle:
            return json.load(handle)
    except (IOError, ValueError):
        return {}


PACKS = _manifest()
_paths = {}
_lock = threading.Lock()
_worker = None
_next_check = 0.0


def enabled():
    return bool(PACKS)


def directory(key):
    """A previously verified asset pack. Opening a card never probes the network."""
    path = _paths.get(key)
    return path if path and os.path.isdir(path) else None


def load_installed(width):
    """Find completed packs immediately on reopening, before choosing the skin size."""
    if not enabled():
        return
    try:
        root = _mounted_root()
        if root is None:
            return
        _mount_token(root)
        for key, spec in PACKS.items():
            if key == "art-1440p" and width <= 1920:
                continue
            candidate = _entry_dir(root, key, spec)
            if _ready(candidate, spec["sha256"]):
                _paths[key] = candidate
    except (IOError, OSError):
        pass


def _mounted_root():
    path = support.mounted_storage_root()
    if not path and os.path.ismount("/data") and os.access("/data", os.W_OK):
        path = "/data/UltraQuran"
        if not os.path.isdir(path):
            os.mkdir(path)
    return path


def _mount_token(root):
    """The mount and device must stay the same through download and extraction."""
    parts = os.path.abspath(root).split(os.sep)
    if parts[1:2] == ["media"] and len(parts) >= 4:
        mount = "/media/" + parts[2]
    elif parts[1:2] == ["data"] and len(parts) >= 3:
        mount = "/data"
    else:
        raise IOError("assets require a mounted disk or USB")
    real_mount = os.path.realpath(mount)
    if not os.path.ismount(real_mount) or not os.path.realpath(root).startswith(real_mount + os.sep):
        raise IOError("asset disk is not mounted")
    return mount, real_mount, os.stat(root).st_dev


def _same_disk(root, token):
    if _mount_token(root) != token:
        raise IOError("asset disk changed")


def _entry_dir(root, key, spec):
    return os.path.join(root, "assets", key + "-" + spec["sha256"][:16])


def _ready(path, digest):
    try:
        with open(os.path.join(path, ".complete"), "r") as handle:
            return handle.read(64) == digest
    except (IOError, OSError):
        return False


def _copy(source, target, limit):
    digest = hashlib.sha256()
    size = 0
    while True:
        chunk = source.read(_CHUNK)
        if not chunk:
            break
        size += len(chunk)
        if size > limit:
            raise IOError("asset exceeds its expected size")
        digest.update(chunk)
        target.write(chunk)
    return size, digest.hexdigest()


def _download(spec, target, local_path):
    from .updater import _open

    if local_path and os.path.isfile(local_path):
        reader = open(local_path, "rb")
    else:
        url = spec["url"]
        if not url.startswith(_RELEASE) or url.rsplit("/", 1)[-1] != spec["filename"]:
            raise IOError("invalid artwork release URL")
        reader = _open(url, timeout=12)
    try:
        with open(target, "wb") as handle:
            size, digest = _copy(reader, handle, spec["size"])
        if size != spec["size"] or digest != spec["sha256"]:
            raise IOError("artwork download is incomplete or has the wrong checksum")
    finally:
        reader.close()


def _unpack(archive, dest, key, spec, root, token):
    seen = set()
    total = 0
    with tarfile.open(archive, "r:gz") as package:
        for member in package:
            name = member.name
            prefix = next((p for p in _PREFIXES[key] if name.startswith(p)), None)
            if (not member.isfile() or prefix is None or not _ASSET_NAME.match(name[len(prefix):])
                    or name in seen or member.size <= 0):
                raise IOError("invalid file in artwork archive")
            seen.add(name)
            total += member.size
            if len(seen) > spec["files"] or total > spec["unpacked"]:
                raise IOError("artwork archive exceeded its expected size")
            _same_disk(root, token)
            target = os.path.join(dest, name)
            parent = os.path.dirname(target)
            if not os.path.isdir(parent):
                os.makedirs(parent)
            source = package.extractfile(member)
            try:
                with open(target, "wb") as handle:
                    size, _ = _copy(source, handle, member.size)
                if size != member.size:
                    raise IOError("artwork file is incomplete")
            finally:
                source.close()
    if len(seen) != spec["files"] or total != spec["unpacked"]:
        raise IOError("artwork archive is incomplete")


def _install(root, token, key, spec, final):
    _same_disk(root, token)
    parent = os.path.dirname(final)
    if not os.path.isdir(parent):
        os.mkdir(parent)
    if not os.path.realpath(parent).startswith(os.path.realpath(root) + os.sep):
        raise IOError("artwork folder is outside the mounted disk")
    required = spec["size"] + spec["unpacked"] + 5 * 1024 * 1024
    free = support.free_bytes(parent)
    if free < required + support.HDD_RESERVE:
        raise IOError("not enough space on the asset disk")
    staging = tempfile.mkdtemp(prefix=".uq-art-", dir=parent)
    try:
        local = os.path.join(parent, "inbox", spec["filename"])
        archive = os.path.join(staging, "download.tar.gz")
        dest = os.path.join(staging, "extracted")
        _download(spec, archive, local)
        _same_disk(root, token)
        os.mkdir(dest)
        _unpack(archive, dest, key, spec, root, token)
        _same_disk(root, token)
        with open(os.path.join(dest, ".complete"), "w") as handle:
            handle.write(spec["sha256"])
        if not _ready(final, spec["sha256"]):
            os.rename(dest, final)
    finally:
        shutil.rmtree(staging, ignore_errors=True)


def _sync(width):
    global _paths
    try:
        root = _mounted_root()
        if not root:
            _paths = {}
            return
        token = _mount_token(root)
        for key in ("photos", "art-1440p"):
            if key not in PACKS or (key == "art-1440p" and width <= 1920):
                continue
            spec = PACKS[key]
            final = _entry_dir(root, key, spec)
            if _paths.get(key) != final:
                _paths.pop(key, None)
            try:
                _same_disk(root, token)
                if not _ready(final, spec["sha256"]):
                    _install(root, token, key, spec, final)
                if _ready(final, spec["sha256"]):
                    _paths[key] = final
            except Exception as exc:
                support.log("Artwork %s: %s" % (key, exc))
    except Exception as exc:
        support.log("Artwork storage: %s" % exc)


def schedule(width, now=False):
    """Check installed packs or start a bounded background retry after the screen opens."""
    global _worker, _next_check
    if not enabled():
        return
    with _lock:
        clock = getattr(time, "monotonic", time.time)()
        if (_worker is not None and _worker.is_alive()) or (not now and clock < _next_check):
            return
        _next_check = clock + _RETRY_SECONDS
        _worker = threading.Thread(target=_sync, args=(width,))
        _worker.daemon = True
        _worker.start()
