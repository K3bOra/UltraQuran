# -*- coding: utf-8 -*-
import datetime
import io
import json
import os
import re

from .support import is_mubtahil, ROOT, data_json, data_names, log_exception

RECITER_YOUTUBE_LIBRARY = 19

HIJRI_MONTHS = (
    u"المحرّم", u"صفر", u"ربيع الأول", u"ربيع الآخر",
    u"جمادى الأولى", u"جمادى الآخرة", u"رجب", u"شعبان",
    u"رمضان", u"شوّال", u"ذو القعدة", u"ذو الحجة"
)

# Exact verse counts for all 114 Surahs of the Holy Quran (1..114)
SURA_VERSES = (
    7, 286, 200, 176, 120, 165, 206, 75, 129, 109,
    123, 111, 43, 52, 99, 128, 111, 110, 98, 135,
    112, 78, 118, 64, 77, 227, 93, 88, 69, 60,
    34, 30, 73, 54, 45, 83, 182, 88, 75, 85,
    54, 53, 89, 59, 37, 35, 38, 29, 18, 45,
    60, 49, 62, 55, 78, 96, 29, 22, 24, 13,
    14, 11, 11, 18, 12, 12, 30, 52, 52, 44,
    28, 28, 20, 56, 40, 31, 50, 40, 46, 42,
    29, 19, 36, 25, 22, 17, 19, 26, 30, 20,
    15, 21, 11, 8, 8, 19, 5, 8, 8, 11,
    11, 8, 3, 9, 5, 4, 7, 3, 6, 3,
    5, 4, 5, 6
)

# Set of Madani Surah numbers (all others are Makki)
MADANI_SURAS = {
    2, 3, 4, 5, 8, 9, 22, 24, 33, 47, 48, 49, 55, 57,
    58, 59, 60, 61, 62, 63, 64, 65, 66, 76, 98, 99, 110
}


# Julian day number for Gregorian ordinal zero, and for the tabular Hijri epoch.
GREGORIAN_ORDINAL_OFFSET = 1721425
HIJRI_EPOCH_JDN = 1948440


def _hijri_date(date):
    """Return (day, month, year) in the plugin's tabular Hijri calendar."""
    jd = date.toordinal() + GREGORIAN_ORDINAL_OFFSET
    elapsed = jd - HIJRI_EPOCH_JDN + 10632
    cycles = (elapsed - 1) // 10631
    elapsed = elapsed - 10631 * cycles + 354
    cycle_year = ((10985 - elapsed) // 5316) * ((50 * elapsed) // 17719) + \
                 (elapsed // 5670) * ((43 * elapsed) // 15238)
    elapsed = elapsed - ((30 - cycle_year) // 15) * ((17719 * cycle_year) // 50) - \
              (cycle_year // 16) * ((15238 * cycle_year) // 43) + 29
    month = (24 * elapsed) // 709
    day = elapsed - (709 * month) // 24
    return day, month, 30 * cycles + cycle_year - 30


def hijri_today(date=None):
    day, month, year = _hijri_date(date or datetime.date.today())
    month_name = HIJRI_MONTHS[month - 1]
    return u"%d %s %d هـ" % (day, month_name, year)


def ramadan_countdown(date):
    """Return (days until the next Ramadan, day in Ramadan). Exactly one value is set."""
    day, month, year = _hijri_date(date)
    if month == 9:
        return None, day
    if month > 9:
        year += 1
    # Ramadan starts 236 days into a tabular Hijri year. Leap days fall at the end of the year.
    start = HIJRI_EPOCH_JDN - GREGORIAN_ORDINAL_OFFSET + 354 * (year - 1) + (3 + 11 * year) // 30 + 236
    return start - date.toordinal(), None


def zina_season(date, before=90):
    """Ramadan decoration on the home screen: from `before` days ahead of Ramadan to the third day of Eid."""
    days, ramadan_day = ramadan_countdown(date)
    if ramadan_day is not None:
        return True
    day, month, year = _hijri_date(date)
    if month == 10 and day <= 3:
        return True
    return days is not None and 0 <= days <= before


def format_seconds(seconds):
    seconds = max(1, int(seconds))
    hours, rem = divmod(seconds, 3600)
    minutes, secs = divmod(rem, 60)
    if hours:
        return u"%d:%02d:%02d" % (hours, minutes, secs)
    return u"%02d:%02d" % (minutes, secs)


_DURATION_TAIL = re.compile(u"\\s*[·•\\-–|]\\s*\\d{1,2}:\\d{2}(?::\\d{2})?\\s*$")


def strip_duration(title):
    """"ماتيسر من سورة البقرة · 57:17" -> "ماتيسر من سورة البقرة" (the time is shown under the name)."""
    cleaned = _DURATION_TAIL.sub(u"", title or u"").strip()
    return cleaned or title


LIVE_LIBRARIES = (16,)       # libraries with a show still on air (see liveseries.py)


class LazyLibraries(object):
    """Encyclopedia sections live in data/lib/<n>.json and are read only when a section is opened."""

    def __init__(self, directory):
        self.directory = directory
        self._cache = {}
        try:
            self._keys = sorted(int(name) for name in data_names(directory) if name.isdigit())
        except OSError:
            self._keys = []

    def __contains__(self, key):
        return key in self._keys

    def __iter__(self):
        return iter(self._keys)

    def keys(self):
        return list(self._keys)

    def __len__(self):
        return len(self._keys)

    def __getitem__(self, key):
        if key not in self._keys:
            raise KeyError(key)
        if key not in self._cache:
            self._cache[key] = data_json(self.directory, "%d.json" % key)
        if key in LIVE_LIBRARIES:
            try:
                from . import liveseries
                liveseries.apply(key, self._cache[key])     # new episodes found on the official channel
            except Exception:
                log_exception("live series: cannot add new episodes")
        return self._cache[key]

    def get(self, key, default=None):
        try:
            return self[key]
        except KeyError:
            return default


class Catalog(object):
    def __init__(self):
        data = data_json("catalog.json")
        self.chapters = data["chapters"]
        self.durations = data.get("durations", [60] * 114)
        self.reciters = data["reciters"]
        self.mubtahileen = data.get("mubtahileen", [])
        self.kishk = data.get("kishk")
        self.radios = data["radios"]
        all_figures = list(self.reciters) + list(self.mubtahileen)
        if self.kishk:
            all_figures.append(self.kishk)
        self.all_figures = all_figures
        self.reciter = {entry[0]: entry for entry in all_figures}
        self.edition = {edition[0]: (entry, edition)
                        for entry in all_figures for edition in entry[2]}
        self.radio = {entry[0]: entry for entry in self.radios}
        self.bios = {int(key): value for key, value in data_json("bios.json").items()}
        self.libraries = LazyLibraries(os.path.join(ROOT, "data", "lib"))
        try:
            from . import liveseries
            liveseries.refresh_async()                       # background look for new episodes (on-air shows)
        except Exception:
            log_exception("live series: cannot start the refresh")

    def contains(self, track):
        if not isinstance(track, (tuple, list)) or len(track) != 2:
            return False
        edition, chapter = track
        return edition in self.edition and chapter in self.edition[edition][1][3]

    def chapter(self, number):
        if 1 <= number <= len(self.chapters):
            return self.chapters[number - 1]
        return u"%d" % number

    def is_custom_edition(self, edition_id):
        if edition_id not in self.edition:
            return False
        recording = self.edition[edition_id][1]
        return len(recording) >= 5 and isinstance(recording[4], dict)

    def track_title(self, edition_id, chapter):
        if self.is_custom_edition(edition_id):
            titles = self.edition[edition_id][1][4]
            custom = titles.get(str(chapter)) or titles.get(chapter)
            if custom:
                return strip_duration(custom)
        return u"سورة " + self.chapter(chapter)

    def surah_meta_str(self, chapter, edition_id=None):
        if edition_id is not None and self.is_custom_edition(edition_id):
            rec_id = self.edition[edition_id][0][0]
            numbers = self.edition[edition_id][1][3]
            total = len(numbers)
            try:                       # archive bundles keep the file number as the track key
                chapter = numbers.index(chapter) + 1
            except ValueError:
                pass
            if rec_id == 950:
                return u"خطبة رقم %d من %d  ·  موسوعة فارس المنابر الشيخ كشك" % (chapter, total)
            if is_mubtahil(rec_id):
                return u"ابتهال رقم %d من %d  ·  موسوعة الابتهالات والتواشيح الدينية" % (chapter, total)
            return u"تلاوة رقم %d من %d  ·  تسجيلات نادرة من أرشيف الإنترنت" % (chapter, total)
        if not isinstance(chapter, int) or not (1 <= chapter <= 114):
            return u""
        verses = SURA_VERSES[chapter - 1]
        revelation = u"مدنية" if chapter in MADANI_SURAS else u"مكية"
        return u"سورة رقم %d  ·  %s  ·  %d آية" % (chapter, revelation, verses)

    def surah_duration_seconds(self, edition_id, chapter):
        if edition_id in self.edition:
            recording = self.edition[edition_id][1]
            if len(recording) >= 6 and isinstance(recording[5], dict):
                real = recording[5].get(str(chapter)) or recording[5].get(chapter)
                if real:
                    return int(real)
        if self.is_custom_edition(edition_id):
            rec_id = self.edition[edition_id][0][0]
            return 2400 if rec_id == 950 else (480 if is_mubtahil(rec_id) else 900)
        base = self.durations[chapter - 1] if 1 <= chapter <= len(self.durations) else 60
        if edition_id in self.edition:
            ed_name = self.edition[edition_id][1][1]
            if u"مجود" in ed_name:
                return int(base * 1.45)
            if u"المعلم" in ed_name:
                return int(base * 1.60)
        return base

    def surah_duration_str(self, edition_id, chapter):
        return format_seconds(self.surah_duration_seconds(edition_id, chapter))

    def tracks(self, edition):
        return [(edition, number) for number in self.edition[edition][1][3]]

    @staticmethod
    def format_audio_url(server_or_pattern, chapter):
        if isinstance(server_or_pattern, dict):
            return server_or_pattern.get(str(chapter)) or server_or_pattern.get(chapter) or u""
        if "%03d" in server_or_pattern:
            return server_or_pattern.replace("%%20", "%20").replace("%03d", "%03d" % chapter)
        if "%d" in server_or_pattern:
            return server_or_pattern.replace("%%20", "%20").replace("%d", "%d" % chapter)
        return server_or_pattern.rstrip("/") + ("/%03d.mp3" % chapter)

    def track(self, entry):
        edition, chapter = entry
        if edition is None:
            radio = self.radio[chapter]
            section, schedule = ((u"إذاعة إسلامية", radio[3]) if len(radio) > 3
                                 else (u"إذاعة القرآن الكريم", u"بث مباشر على مدار الساعة"))
            return (radio[1], section, schedule, radio[2], None)
        if edition == "lib":
            title, sub, detail, url = chapter
            return (title, sub, detail, url, None)
        reciter, recording = self.edition[edition]
        return (self.track_title(edition, chapter), reciter[1], recording[1],
                self.format_audio_url(recording[2], chapter), reciter[0])

    video_finder = None  # set by the screen (videos.VideoFinder)

    def reciter_videos(self, reciter_id):
        """Real videos discovered for this sheikh (cached on the HDD); [] while unknown."""
        finder = self.video_finder
        if finder is None:
            return []
        return finder.cached(reciter_id) or []

    def request_reciter_videos(self, reciter_id, retry=False):
        finder = self.video_finder
        if finder is not None and reciter_id in self.reciter:
            finder.request(reciter_id, self.reciter[reciter_id][1], retry=retry)

    def reciter_videos_state(self, reciter_id):
        """'ready' | 'searching' | 'offline' | 'empty'"""
        finder = self.video_finder
        if finder is None:
            return "empty"
        cached = finder.cached(reciter_id)
        if cached is not None:
            return "ready" if cached else "empty"
        if finder.failed(reciter_id):
            return "offline"
        return "searching"

    def reciter_youtube(self, reciter_id):
        section = self.libraries.get(RECITER_YOUTUBE_LIBRARY, {})
        if str(reciter_id) in section.get("counts", {}):
            return data_json("lib", "yt-%d.json" % reciter_id)
        return section.get("people", {}).get(str(reciter_id), [])

    def reciter_youtube_folders(self, reciter_id):
        items = self.reciter_youtube(reciter_id)
        groups = {}
        order = []
        for item in items:
            title = item.get("group") or u"تسجيلات مختارة"
            if title not in groups:
                groups[title] = []
                order.append(title)
            groups[title].append(item)
        if len(order) <= 1:
            return items

        def folder(title, children):
            return {"title": title, "badge": u"%d فيديو" % len(children), "children": children}

        return [folder(u"كل الفيديوهات", items)] + [folder(title, groups[title]) for title in order]

    def reciter_hub_folders(self, reciter_id):
        rec = self.reciter.get(reciter_id)
        ed_count = len(rec[2]) if rec else 1
        total_tracks = sum(len(ed[3]) for ed in rec[2]) if rec else 0
        state = self.reciter_videos_state(reciter_id)
        vid_count = len(self.reciter_videos(reciter_id))
        if state == "ready":
            video_badge = u"%d فيديو موثّق" % vid_count
            if reciter_id == 950:
                video_summary = u"خطب ومقاطع مرئية مصورة نادرة لفارس المنابر الشيخ عبد الحميد كشك رحمه الله، تعمل بالعرض الكامل مع إمكانية حفظها على الهارد بدون نت."
            elif is_mubtahil(reciter_id):
                video_summary = u"حفلات وابتهالات وتلاوات مرئية نادرة للمبتهل من التلفزيون المصري والمساجد الكبرى، مع المشاهدة والتحميل على الهارد بدون نت."
            else:
                video_summary = u"فيديوهات حقيقية للشيخ من أرشيف الإنترنت: تلاوات مصورة وحفلات وختمات، كلها متحقَّق من نسبتها للشيخ ومن صحة روابطها، وتُشغَّل مباشرة على مشغل Ultra Quran."
        elif state == "searching":
            video_badge = u"جارٍ البحث عن الفيديوهات…"
            video_summary = u"يبحث البلجن الآن في أرشيف الإنترنت عن فيديوهات الشيخ، وتُحفَظ النتيجة على الهارد لتفتح فوراً في المرات القادمة."
        elif state == "offline":
            video_badge = u"تعذّر الاتصال · أعد المحاولة"
            video_summary = u"لم يتم الاتصال بأرشيف الإنترنت. تأكد من اتصال الجهاز بالشبكة ثم افتح هذه المكتبة مرة أخرى."
        else:
            video_badge = u"لا توجد فيديوهات موثّقة بعد"
            video_summary = u"لا توجد حالياً فيديوهات موثّقة ومتحقَّق من نسبتها لهذا الشيخ، وتُضاف أولاً بأول مع تحديثات البلجن. المكتبة الصوتية متاحة بالكامل."

        if reciter_id == 950:
            audio_title = u"موسوعة الخطب الصوتية الشاملة (MP3)"
            audio_badge = u"%d مصنفات · %d خطبة صوتية" % (ed_count, total_tracks)
            audio_summary = u"جميع خطب ودروس فارس المنابر الشيخ عبد الحميد كشك رحمه الله مقسمة في 6 فولدرات مع الاستماع وتحميل الخطب أو الفولدر بالكامل على الهارد بدون نت."
            video_title = u"مكتبة الخطب المصورة والمرئية (فيديو MP4)"
        elif is_mubtahil(reciter_id):
            audio_title = u"مكتبة الابتهالات والتواشيح الصوتية (MP3)"
            audio_badge = u"%d مصنفات · %d ابتهال وتوشيح" % (ed_count, total_tracks)
            audio_summary = u"روائع الابتهالات والتواشيح الدينية النادرة وأدعية الفجر والليالي الرمضانية مع الاستماع وتحميل الفولدر بالكامل على الهارد بدون نت."
            video_title = u"مكتبة الابتهالات والحفلات المرئية (فيديو)"
        else:
            audio_title = u"المكتبة الصوتية الشاملة (MP3)"
            audio_badge = u"%d تسجيلات ومصاحف كاملة" % ed_count
            audio_summary = u"جميع المصاحف المرتلة والمجودة والروايات المتواترة عالية النقاء مع إمكانية الاستماع وتحميل السور والفولدرات بالكامل على الهارد."
            video_title = u"المكتبة المرئية والتلاوات المصورة (فيديو)"

        folders = [
            {
                "id": "audio",
                "title": audio_title,
                "badge": audio_badge,
                "summary": audio_summary,
                "icon": "book",
            },
            {
                "id": "video",
                "title": video_title,
                "badge": video_badge,
                "summary": video_summary,
                "icon": "video",
            },
        ]
        youtube_section = self.libraries.get(RECITER_YOUTUBE_LIBRARY, {})
        youtube_count = youtube_section.get("counts", {}).get(str(reciter_id), 0)
        if not youtube_count and "people" in youtube_section:
            youtube_count = len(self.reciter_youtube(reciter_id))
        if youtube_count:
            folders.append({
                "id": "youtube",
                "title": u"يوتيوب",
                "badge": u"%d فيديو" % youtube_count,
            })
        return folders

    def main_portal_folders(self):
        """4 Grand Luxury Folders shown when opening the main Quran & Audio Portal."""
        rec_count = len(self.reciters)
        mub_count = len(self.mubtahileen)
        mub_tracks = sum(len(ed[3]) for m in self.mubtahileen for ed in m[2])
        kishk_tracks = sum(len(ed[3]) for ed in self.kishk[2]) if self.kishk else 254
        return [
            {
                "action": "reciters_gallery",
                "poster_id": 51,
                "poster_name": u"قراء القرآن الكريم",
                "title": u"قراء القرآن الكريم والمصاحف الكاملة",
                "badge": u"%d قارئاً  ·  المصاحف المرتلة والمجودة والتلاوات المرئية" % rec_count,
                "count_label": u"%d قارئاً" % rec_count,
                "riwayas_label": u"صوت وفيديو",
                "born": u"قراء القرآن الكريم\nمصر والعالم الإسلامي",
                "died": u"المصاحف والروايات\nحفص وورش وقالون والمجود",
                "subtitle": u"موسوعة قراء القرآن الكريم",
                "summary": u"تصفح معرض بوسترات %d قارئاً من كبار قراء مصر والعالم الإسلامي، مع السيرة الذاتية لكل قارئ وجميع مصاحفه الصوتية وتلاواته المرئية وإمكانية التحميل للاستماع بدون إنترنت." % rec_count,
            },
            {
                "action": "mubtahileen_gallery",
                "poster_id": 951,
                "poster_name": u"كبار المبتهلين",
                "title": u"فولدر الابتهالات والتواشيح الدينية (معرض كبار المبتهلين)",
                "badge": u"%d مبتهلاً  ·  %d تسجيلًا صوتيًا بالبوسترات" % (mub_count, mub_tracks),
                "count_label": u"%d مبتهلاً" % mub_count,
                "riwayas_label": u"%d ابتهال" % mub_tracks,
                "born": u"مدرسة الابتهال المصري\nالنقشبندي · طوبار · الفشني",
                "died": u"التواشيح والأسحار\nعمران · الطوخي · الفيومي · البهتيمي",
                "subtitle": u"موسوعة الابتهالات وكبار المبتهلين",
                "summary": u"معرض بوسترات كبار المبتهلين على غرار صفحة القرآن الكريم: الشيخ سيد النقشبندي، نصر الدين طوبار، طه الفشني، محمد عمران، محمد الطوخي، محمد الفيومي، كامل البهتيمي، إسماعيل السمكري، محمد الهلباوي، سعيد حافظ، علي محمود، عبد الرحيم دويدار، إبراهيم الإسكندراني، ممدوح عبد الجليل، عبد السميع بيومي، عبد التواب البساتيني، علي الحسيني، حسن عبد العال قاسم، ومحمد عبد القادر أبو سريع.",
            },
            {
                "action": "kishk_hub",
                "poster_id": 950,
                "poster_name": u"الشيخ عبد الحميد كشك",
                "title": u"فولدر الشيخ عبد الحميد كشك «فارس المنابر» (الخطب الصوتية والمصورة)",
                "badge": u"%d خطبة صوتية  ·  1295 خطبة ومقطع مرئي  ·  السيرة الذاتية" % kishk_tracks,
                "count_label": u"%d خطبة" % kishk_tracks,
                "riwayas_label": u"صوت وفيديو",
                "born": u"الميلاد والنشأة\n10 مارس 1933م · شبراخيت",
                "died": u"الوفاة واللقب\n6 ديسمبر 1996م · فارس المنابر",
                "subtitle": u"موسوعة الشيخ عبد الحميد كشك",
                "summary": u"الموسوعة الكاملة لفارس المنابر الشيخ عبد الحميد كشك رحمه الله، تضم %d خطبة ومحاضرة صوتية مقسمة في فولدرات موضوعية، بالإضافة إلى مكتبة الخطب المصورة والمرئية النادرة مع التشغيل والتحميل الكامل على الهارد بدون إنترنت." % kishk_tracks,
            },
            {
                "action": "mushaf_viewer",
                "poster_id": 118,
                "poster_name": u"المصحف الشريف",
                "title": u"فولدر المصحف الشريف المكتوب والمصوّر (604 صفحات بدون إنترنت)",
                "badge": u"604 صفحات كاملة  ·  يُحفظ تلقائياً في فولدر البلجن على الهارد",
                "count_label": u"604 صفحات",
                "riwayas_label": u"مكتوب ومصوّر",
                "born": u"الرسم العثماني\nمصحف المدينة المنورة",
                "died": u"التصفح الدائم\nيعمل على الهارد بدون فلاشة",
                "subtitle": u"المصحف الشريف المكتوب والمصوّر",
                "summary": u"تصفح المصحف الشريف كاملاً (604 صفحات، 30 جزءاً، 114 سورة) بالرسم العثماني الواضح وصور مصحف المدينة المنورة، يُحفظ تلقائياً وبشكل دائم داخل فولدر البلجن على الهارد ليعمل في أي وقت بدون إنترنت.",
            },
        ]

    @staticmethod
    def riwayas(recordings):
        return len({edition[1].split(u" - ", 1)[0] for edition in recordings})

    @staticmethod
    def source_label(url):
        if isinstance(url, dict):
            return u"أرشيف التراث الإسلامي"
        if not isinstance(url, (str, bytes)) and not hasattr(url, "lower"):
            return u"شبكة القرآن"
        if "archive.org" in url:
            return u"أرشيف التلاوات النادرة"
        if "quranicaudio.com" in url:
            return u"مكتبة التلاوات"
        if "islamic.network" in url:
            return u"الشبكة الإسلامية"
        return u"شبكة القرآن"
