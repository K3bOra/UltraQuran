# -*- coding: utf-8 -*-
"""YouTube video and audio selection adapted from Ultra Stalker V9.3.7."""
from __future__ import absolute_import, division, print_function, unicode_literals
import os
import ssl
import time
import zlib
from contextlib import closing

import json
import re
import threading
try:
    from urllib.parse import urlsplit, urljoin
    from urllib.request import Request, urlopen
except ImportError:
    from urlparse import urlsplit, urljoin
    from urllib2 import Request, urlopen

from .support import IS_DREAMOS


_SUBURI = "&suburi="
_ANDROID_VERSION = "21.08.266"
_ANDROID_UA = "com.google.android.youtube/%s (Linux; U; Android 11) gzip" % _ANDROID_VERSION
_ANDROID_NEW_VERSION = "21.26.364"
_ANDROID_NEW_UA = "com.google.android.youtube/%s (Linux; U; Android 11) gzip" % _ANDROID_NEW_VERSION
_VISIONOS_VERSION = "1.02"
_VISIONOS_UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 15_7_3) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Safari/605.1.15"
_IOS_VERSION = "21.26.4"
_IOS_UA = "com.google.ios.youtube/%s (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)" % _IOS_VERSION
_PLAYER_ENDPOINT = "https://www.youtube.com/youtubei/v1/player?prettyPrint=false"

_SSL_CONTEXT = ssl.create_default_context()

_CACHE_LOCK = threading.Lock()
_CANDIDATE_CACHE = {}
_CANDIDATE_CACHE_TTL = 900.0


# Primary target resolution is 1080p Full HD (1920x1080, tier 0) with immediate
# fallback to 720p HD (1280x720, tier 1) -> 480p -> 360p -> lower.
_ITAG_TIER = {
    # 1080p Full HD (tier 0)
    "37": (0, 0),   # 1080p progressive muxed MP4
    "96": (0, 1),   # 1080p HLS muxed TS
    "301": (0, 2),  # 1080p60 HLS muxed TS
    "137": (0, 3),  # 1080p DASH H.264 MP4 video
    "299": (0, 4),  # 1080p60 DASH H.264 MP4 video
    "270": (0, 5),  # 1080p DASH/HLS H.264 video
    # 720p HD (tier 1 - immediate fallback)
    "22": (1, 0),   # 720p progressive muxed MP4
    "95": (1, 1),   # 720p HLS muxed TS
    "300": (1, 2),  # 720p60 HLS muxed TS
    "136": (1, 3),  # 720p DASH H.264 MP4 video
    "298": (1, 4),  # 720p60 DASH H.264 MP4 video
    "232": (1, 5),  # 720p HLS H.264 video
    # 480p (tier 2)
    "35": (2, 0),
    "59": (2, 1),
    "78": (2, 2),
    "94": (2, 3),   # 480p HLS
    "135": (2, 4),  # 480p DASH H.264 MP4 video
    "212": (2, 5),  # 480p DASH H.264 MP4 video
    "231": (2, 6),  # 480p HLS H.264 video
    # 360p (tier 3)
    "18": (3, 0),   # 360p progressive muxed MP4
    "93": (3, 1),   # 360p HLS
    "34": (3, 2),
    "6": (3, 3),
    "134": (3, 4),  # 360p DASH H.264 MP4 video
    "230": (3, 5),  # 360p HLS H.264 video
    # 240p (tier 4)
    "5": (4, 0),
    "36": (4, 1),
    "92": (4, 2),
    "132": (4, 3),
    "133": (4, 4),  # 240p DASH H.264 MP4 video
    "229": (4, 5),
    # 144p (tier 5)
    "17": (5, 0),
    "91": (5, 1),
    "13": (5, 2),
    "151": (5, 3),
    "160": (5, 4),  # 144p DASH H.264 MP4 video
    "269": (5, 5),
}

_VIDEO_ORDER = (
    "37", "96", "301", "137", "299", "270",
    "22", "95", "300", "136", "298", "232",
    "35", "59", "78", "94", "135", "212", "231",
    "18", "93", "34", "6", "134", "230",
    "5", "36", "92", "132", "133", "229",
    "17", "91", "13", "151", "160", "269",
)
_AUDIO_ORDER = ("141", "140", "139", "258", "265", "325", "328", "233", "234")
_SPLIT_VIDEO = {
    "133", "134", "135", "136", "137", "138", "160", "212", "229", "230",
    "231", "232", "248", "264", "271", "272", "266", "269", "270", "298",
    "299", "303", "313", "315", "308",
}
_BLOCKED = {
    # Block >1080p (1440p/4K) and VP8/VP9/AV1/WebM/3D formats
    "38", "138", "264", "266",
    "43", "44", "45", "46",
    "82", "83", "84", "85",
    "100", "101", "102",
    "167", "168", "169", "170", "171", "172",
    "218", "219",
    "242", "243", "244", "245", "246", "247", "248",
    "249", "250", "251",
    "271", "272", "302", "303", "308", "313", "315",
    "394", "395", "396", "397", "398", "399", "400", "401", "402",
    "571", "694", "695", "696", "697", "698", "699", "700", "701",
}


_VIDEO_ID = re.compile(r"^[A-Za-z0-9_-]{11}$")


def watch_url(video_id):
    return "https://www.youtube.com/watch?v=" + video_id


def watch_audio_id(url):
    prefix = "https://www.youtube.com/watch?v="
    if url and url.startswith(prefix):
        video_id = url[len(prefix):]
        if _VIDEO_ID.match(video_id):
            return video_id
    return ""


def media_url(url):
    try:
        url = (url or "").strip()
        parts = urlsplit(url)
        host = parts.hostname or ""
        if (_SUBURI not in url and parts.scheme == "https" and parts.username is None
                and parts.port in (None, 443)
                and (host == "googlevideo.com" or host.endswith(".googlevideo.com"))):
            return url
    except (AttributeError, TypeError, ValueError):
        pass
    return ""


def _http_text(url, data=None, headers=None, timeout=5, limit=6 * 1024 * 1024):
    if data is not None and not isinstance(data, (bytes, bytearray)):
        data = json.dumps(data, separators=(",", ":")).encode("utf-8")
    req_timeout = max(2.5, min(6.0, float(timeout or 5)))
    req_headers = dict(headers or {})
    req_headers.setdefault("Accept-Encoding", "gzip")
    req = Request(url, data=data, headers=req_headers)
    with closing(urlopen(req, timeout=req_timeout, context=_SSL_CONTEXT)) as response:
        raw = response.read(limit + 1)
    if len(raw) > limit:
        raise RuntimeError("response too large")
    if raw[:2] == b"\x1f\x8b":
        raw = zlib.decompressobj(16 + zlib.MAX_WBITS).decompress(raw, limit + 1)
        if len(raw) > limit:
            raise RuntimeError("response too large")
    return raw.decode("utf-8", "replace")


def _http_json(url, payload, headers, timeout):
    text = _http_text(url, payload, headers, timeout=timeout)
    value = json.loads(text)
    return value if isinstance(value, dict) else {}


def _skip_format(row, itag):
    if not isinstance(row, dict):
        return True
    if row.get("targetDurationSec") or row.get("drmFamilies"):
        return True
    if str(row.get("type") or "") == "FORMAT_STREAM_TYPE_OTF":
        return True
    if str(itag or "") in _BLOCKED:
        return True
    mime = str(row.get("mimeType") or "").lower()
    if any(bad in mime for bad in ("vp9", "vp09", "vp8", "av01", "av1", "webm", "opus", "vorbis")):
        return True
    height = int(row.get("height") or 0)
    if height > 1080:
        return True
    return False


def _tier_for_row(row, itag):
    itag_s = str(itag or "")
    if itag_s in _ITAG_TIER:
        return _ITAG_TIER[itag_s]
    height = int((row or {}).get("height") or 0)
    if 720 < height <= 1080:
        return (0, 9)
    if 480 < height <= 720:
        return (1, 9)
    if 360 < height <= 480:
        return (2, 9)
    if 240 < height <= 360:
        return (3, 9)
    if 144 < height <= 240:
        return (4, 9)
    if 0 < height <= 144:
        return (5, 9)
    return (9, 9)


class UltraYouTubeResolver(object):
    def __init__(self):
        self._visitor_id = ""

    def _build_client_request(self, client_id, video_id, visitor_id=""):
        content_ctx = {"html5Preference": "HTML5_PREF_WANTS"}

        real_client_id = 3 if client_id in (3, 30, 3003) else (101 if client_id == 101 else client_id)
        body = {
            "videoId": video_id,
            "playbackContext": {"contentPlaybackContext": content_ctx},
            "context": {"client": {"hl": "en", "gl": "US"}},
        }
        headers = {
            "Content-Type": "application/json",
            "Origin": "https://www.youtube.com",
            "X-YouTube-Client-Name": str(real_client_id),
        }

        if client_id in (3, 3003):
            # Primary fast path matching Taapat/fairbird enigma2-plugin-youtube:
            # ANDROID 21.08.266 with params="2AMB" returns direct unencrypted 1080p (itag 137/299)
            # + 720p (itag 136/298) + M4A audio (itag 140) + progressive MP4 in one ~200ms request.
            ua = _ANDROID_UA
            body["params"] = "2AMB"
            body["context"]["client"].update({
                "clientName": "ANDROID",
                "clientVersion": _ANDROID_VERSION,
                "androidSdkVersion": 30,
                "osName": "Android",
                "osVersion": "11",
                "userAgent": ua,
            })
            headers["X-YouTube-Client-Version"] = _ANDROID_VERSION
            headers["User-Agent"] = ua
            if visitor_id:
                headers["X-Goog-Visitor-Id"] = visitor_id
        elif client_id == 30:
            # ANDROID without "2AMB" to ensure full adaptiveFormats (1080p itag 137 / 720p itag 136)
            ua = _ANDROID_NEW_UA
            body["context"]["client"].update({
                "clientName": "ANDROID",
                "clientVersion": _ANDROID_NEW_VERSION,
                "androidSdkVersion": 30,
                "osName": "Android",
                "osVersion": "11",
                "userAgent": ua,
            })
            headers["X-YouTube-Client-Version"] = _ANDROID_NEW_VERSION
            headers["User-Agent"] = ua
            if visitor_id:
                headers["X-Goog-Visitor-Id"] = visitor_id
        elif client_id == 101:
            # VISIONOS (yt-dlp #17184 / youtube-dl #33293): returns unencrypted 1080p/720p DASH + HLS m3u8 without PO token
            ua = _VISIONOS_UA
            body["context"]["client"].update({
                "clientName": "VISIONOS",
                "clientVersion": _VISIONOS_VERSION,
                "deviceMake": "Apple",
                "deviceModel": "RealityDevice17,1",
                "osName": "visionOS",
                "osVersion": "26.5.230471",
                "userAgent": ua,
            })
            headers["X-YouTube-Client-Name"] = "101"
            headers["X-YouTube-Client-Version"] = _VISIONOS_VERSION
            headers["User-Agent"] = ua
            if visitor_id:
                headers["X-Goog-Visitor-Id"] = visitor_id
        elif client_id == 5:
            ua = _IOS_UA
            body["context"]["client"].update({
                "clientName": "IOS",
                "clientVersion": _IOS_VERSION,
                "deviceMake": "Apple",
                "deviceModel": "iPhone16,2",
                "osName": "iPhone",
                "osVersion": "18.3.2.22D82",
                "userAgent": ua,
            })
            headers["X-YouTube-Client-Version"] = _IOS_VERSION
            headers["User-Agent"] = ua
            if visitor_id:
                headers["X-Goog-Visitor-Id"] = visitor_id
        return ua, body, headers

    @staticmethod
    def _stream_url(row):
        return media_url(row.get("url")) if isinstance(row, dict) else ""

    @staticmethod
    def _rank(itag, order):
        try:
            return order.index(str(itag))
        except ValueError:
            return 100

    def _video_candidates(self, rows):
        choices = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            itag = str(row.get("itag") or "")
            if _skip_format(row, itag):
                continue
            tier, subrank = _tier_for_row(row, itag)
            if tier > 5:
                mime = str(row.get("mimeType") or "").lower()
                height = int(row.get("height") or 0)
                if "video/mp4" in mime and 0 < height <= 1080:
                    tier = 0 if height > 720 else (1 if height > 480 else (2 if height > 360 else (3 if height > 240 else 4)))
                    subrank = 8
                else:
                    continue
            url = self._stream_url(row)
            if url:
                is_split = (itag in _SPLIT_VIDEO) or (
                    "audio" not in str(row.get("mimeType") or "").lower()
                    and itag not in ("18", "22", "37", "34", "35", "36", "17", "5", "6", "59", "78", "91", "92", "93", "94", "95", "96", "300", "301")
                )
                choices.append((tier, subrank, is_split, row, url))
        choices.sort(key=lambda item: (item[0], item[1]))
        return choices

    def _audio_candidates(self, rows):
        choices = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            itag = str(row.get("itag") or "")
            if _skip_format(row, itag):
                continue
            rank = self._rank(itag, _AUDIO_ORDER)
            audio_track = row.get("audioTrack") if isinstance(row.get("audioTrack"), dict) else {}
            disp = str(audio_track.get("displayName") or "").lower()
            if "original" in disp:
                rank -= 40
            if audio_track.get("audioIsDefault"):
                rank -= 20
            if rank == 100:
                mime = str(row.get("mimeType") or "").lower()
                rank = 20 if "audio/mp4" in mime else 200
            if rank >= 200:
                continue
            url = self._stream_url(row)
            if url:
                choices.append((rank, url))
        choices.sort(key=lambda item: item[0])
        return [item[1] for item in choices]

    def extract_audio_candidates(self, video_id, cancel_event=None):
        """Resolve audio-only streams for a public recording when the listener selects it."""
        if not _VIDEO_ID.match(video_id or ""):
            return []
        for client in (3, 30, 101, 5):
            if cancel_event is not None and cancel_event.is_set():
                break
            _, body, headers = self._build_client_request(client, video_id)
            try:
                response = _http_json(_PLAYER_ENDPOINT, body, headers, timeout=4)
            except Exception:
                continue
            formats = (response.get("streamingData") or {}).get("adaptiveFormats") or []
            voices = [row for row in formats if isinstance(row, dict)
                      and str(row.get("mimeType", "")).startswith("audio/mp4")]
            streams = [url for url in self._audio_candidates(voices) if media_url(url)]
            if streams:
                return streams[:3]
        return []

    def _hls_tiered_candidates(self, manifest_url, timeout, ua=None):
        """Return list of (tier, subrank, is_split, url) from HLS master manifest (<=1080p only)."""
        if not media_url(manifest_url):
            return []
        text = _http_text(manifest_url, headers={"User-Agent": str(ua or _VISIONOS_UA)}, timeout=min(4, timeout), limit=2 * 1024 * 1024)
        audio_by_group = {}
        pending_audio = ""
        pending_height = 0
        candidates = []
        for line in text.splitlines():
            line = line.strip()
            if line.startswith("#EXT-X-MEDIA:") and "TYPE=AUDIO" in line.upper():
                group = re.search(r'GROUP-ID="([^"]+)"', line)
                uri = re.search(r'URI="([^"]+)"', line)
                if group and uri:
                    abs_audio = urljoin(manifest_url, uri.group(1))
                    if group.group(1) not in audio_by_group or 'DEFAULT=YES' in line.upper():
                        audio_by_group[group.group(1)] = abs_audio
                continue
            if line.startswith("#EXT-X-STREAM-INF:"):
                if any(bad in line.lower() for bad in ("vp09", "vp9", "av01")):
                    pending_height = 9999
                else:
                    res = re.search(r"RESOLUTION=\d+x(\d+)", line)
                    pending_height = int(res.group(1)) if res else 0
                group = re.search(r'AUDIO="([^"]+)"', line)
                pending_audio = audio_by_group.get(group.group(1), "") if group else ""
                if group and not pending_audio:
                    pending_height = 9999
                candidates.append((line, pending_audio, pending_height, ""))
                continue
            if candidates and line and not line.startswith("#") and not candidates[-1][3]:
                tag = re.search(r"(?:/sgovp/[^/]+itag%3D|/itag/|itag%3D)(\d+)", line)
                itag = tag.group(1) if tag else ""
                info, audio, h_val, _ = candidates[-1]
                candidates[-1] = (info, audio, h_val, urljoin(manifest_url, line) + ("|" + itag if itag else ""))
        out = []
        for _info, audio, h_val, packed in candidates:
            if not packed or h_val > 1080:
                continue
            if "|" in packed:
                url, itag = packed.rsplit("|", 1)
            else:
                url, itag = packed, ""
            if itag in _BLOCKED:
                continue
            tier, subrank = _tier_for_row({"height": h_val}, itag)
            if tier > 5:
                continue
            if not audio:
                out.append((tier, subrank, False, url))
            else:
                out.append((tier, subrank + 3, True, url + _SUBURI + audio))
        out.sort(key=lambda item: (item[0], item[1]))
        return out

    def _collect_from_payload(self, key, payload, client_ua, timeout, stopped, seen, tier_buckets, muxed_buckets, split_buckets):
        if not isinstance(payload, dict):
            return False
        vis = str(((payload.get("responseContext") or {}).get("visitorData") if isinstance(payload.get("responseContext"), dict) else "") or "").strip()
        if vis and not self._visitor_id:
            self._visitor_id = vis
        play_status = str(((payload.get("playabilityStatus") if isinstance(payload.get("playabilityStatus"), dict) else {}) or {}).get("status") or "")
        if play_status != "OK":
            return False
        vdetails = payload.get("videoDetails") if isinstance(payload.get("videoDetails"), dict) else {}
        ret_id = str(vdetails.get("videoId") or "").strip()
        if ret_id != key or vdetails.get("isPrivate") or vdetails.get("isLive"):
            return False
        streaming = payload.get("streamingData") if isinstance(payload.get("streamingData"), dict) else {}
        if not streaming:
            return False
        is_live = bool(vdetails.get("isLive"))
        rows = [row for row in (streaming.get("formats") or []) if isinstance(row, dict)]
        if not is_live:
            rows.extend([row for row in (streaming.get("adaptiveFormats") or []) if isinstance(row, dict)])

        video_choices = self._video_candidates(rows)
        audio_choices = self._audio_candidates(rows) if not is_live else []
        best_audio = audio_choices[0] if audio_choices else ""

        added_any = False

        for tier, subrank, is_split, _row, video_url in video_choices:
            if is_split:
                if not best_audio or tier in split_buckets:
                    continue
                full_url = video_url + _SUBURI + best_audio
                split_buckets[tier] = (subrank, full_url)
            else:
                if tier in muxed_buckets:
                    continue
                full_url = video_url
                muxed_buckets[tier] = (subrank, full_url)
            if full_url not in seen:
                seen.add(full_url)
                tier_buckets.setdefault(tier, []).append((subrank, is_split, full_url))
                added_any = True

        hls = str(streaming.get("hlsManifestUrl") or "").strip()
        if hls and not stopped() and (0 not in tier_buckets or 0 not in muxed_buckets):
            try:
                for tier, subrank, is_split, hls_url in self._hls_tiered_candidates(hls, timeout=min(4, timeout), ua=client_ua):
                    if is_split:
                        if tier in split_buckets:
                            continue
                        split_buckets[tier] = (subrank, hls_url)
                    else:
                        if tier in muxed_buckets:
                            continue
                        muxed_buckets[tier] = (subrank, hls_url)
                if all(media_url(part) for part in hls_url.split(_SUBURI, 1)) and hls_url not in seen:
                        seen.add(hls_url)
                        tier_buckets.setdefault(tier, []).append((subrank, is_split, hls_url))
                        added_any = True
            except Exception:
                pass
        return added_any

    def extract_candidates(self, video_id, timeout=8, cancel_event=None):
        """Return ordered 1080p-first (with 720p fallback) playable stream URLs."""
        key = str(video_id or "").strip()
        if not _VIDEO_ID.match(key):
            return []

        is_dreamos = IS_DREAMOS
        has_exteplayer3 = os.path.exists("/usr/bin/exteplayer3")
        cache_key = (key, is_dreamos, has_exteplayer3, "1080p")
        now = time.time()
        with _CACHE_LOCK:
            cached_entry = _CANDIDATE_CACHE.get(cache_key)
            if cached_entry and (now - cached_entry[0]) < _CANDIDATE_CACHE_TTL and cached_entry[1]:
                return list(cached_entry[1])

        seen = set()
        tier_buckets = {}
        muxed_buckets = {}
        split_buckets = {}

        def stopped():
            if cancel_event is not None:
                try:
                    return bool(cancel_event.is_set())
                except Exception:
                    return False
            return False

        req_timeout = max(3, min(5, int(timeout or 6)))

        # Phase 1: Fast direct non-cipher JSON clients (zero HTML fetch, zero 12MB base.js download)
        # 1. Client 3 (ANDROID 21.08.266 + params="2AMB") — exact Taapat/fairbird client:
        #    returns 1080p (itag 137/299) + 720p (itag 136/298) + M4A audio (itag 140) in one ~200ms request.
        # 2. Client 30 (ANDROID without 2AMB) & Client 101 (VISIONOS) — if HD adaptiveFormats weren't in cid 3.
        # 3. Client 5 (IOS) — fast fallback.
        fast_clients = (3, 30, 101, 5)
        for cid in fast_clients:
            if stopped():
                break
            ua, body, headers = self._build_client_request(cid, key, self._visitor_id)
            try:
                cand_payload = _http_json(_PLAYER_ENDPOINT, body, headers, timeout=req_timeout)
            except Exception:
                continue
            self._collect_from_payload(
                key, cand_payload, ua, req_timeout, stopped,
                seen, tier_buckets, muxed_buckets, split_buckets
            )
            # Stop immediately once we have 1080p (tier 0) or adaptive HD (720p tier 1 when video maxes at 720p)!
            if 0 in tier_buckets or (1 in tier_buckets and split_buckets):
                break
            if tier_buckets and cid in (101, 5):
                break

        results = []
        # Strict 1080p-first -> 720p-second ordering:
        # 1. Tier 0: 1080p Full HD (itag 37/96/301 muxed or itag 137/299 + &suburi= + itag 140)
        # 2. Tier 1: 720p HD immediate fallback (itag 22/95/300 muxed or itag 136/298 + &suburi= + itag 140)
        # 3. Tier 2: 480p
        # 4. Tier 3: 360p muxed (itag 18)
        for tier in sorted(tier_buckets.keys()):
            items = sorted(tier_buckets[tier], key=lambda x: x[0])
            for _subrank, _is_split, url in items:
                if url not in results:
                    results.append(url)

        candidates = results[:4]
        if candidates and all(_SUBURI in url for url in candidates):
            combined = next((url for url in results[4:] if _SUBURI not in url), None)
            if combined:
                candidates[-1] = combined
        results = candidates
        if results:
            with _CACHE_LOCK:
                if len(_CANDIDATE_CACHE) > 128:
                    _CANDIDATE_CACHE.clear()
                _CANDIDATE_CACHE[cache_key] = (now, list(results))
        return results

