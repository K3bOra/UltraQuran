# -*- coding: utf-8 -*-
"""Poster cards for the encyclopedia's galleries (series, programmes, preachers, munshids).

A folder in data/lib/<n>.json that carries "poster": "<name>" has its picture bundled as
posters_src/<name>.jpg (the series' poster, or the preacher's / programme's photo). The card is drawn
once per screen size in the same style as the sheikhs' gallery cards (picture on top, gold-edged
emerald name plate at the bottom, rounded corners) and kept in the portrait cache. Wide pictures are
shown whole over a soft blurred copy of themselves, so a title written on them is never cut.
The bundled cards are available immediately, including on receivers without PIL.
"""
import os
import threading

from . import assetpacks, layout
from .support import ROOT, has_room, log, log_exception

try:
    from PIL import Image, ImageFilter, ImageOps
except ImportError:
    Image = None

SOURCE_DIR = os.path.join(ROOT, "posters_src")
READY_DIR = os.path.join(ROOT, "posters_ready")
VERSION = "lp1"


def available():
    return Image is not None


def folder_items(item):
    return item.get("children") or item.get("folders") or item.get("items")


def gallery_items(items):
    """True when every entry is a folder and the list has poster artwork."""
    return bool(items) and all(isinstance(item, dict) and folder_items(item) for item in items) \
        and any(item.get("poster") for item in items)


class LibraryPosters(object):
    def __init__(self, width, on_ready=None):
        self.width = width
        self.on_ready = on_ready
        self._queue = []
        self._lock = threading.Lock()
        self._busy = False
        self._ready = False
        self._dir = None

    def _cache_dir(self):
        if self._dir is None:
            try:
                from .portraits import get_cache_dir
                self._dir = os.path.join(get_cache_dir(), "lposters")
            except Exception:
                self._dir = "/tmp/ultra-quran-lposters"
        return self._dir

    def _target(self, name):
        return os.path.join(self._cache_dir(), "%s-%s-%d.png" % (VERSION, name, self.width))

    def card_path(self, name):
        if not name:
            return None
        bundled = os.path.join(READY_DIR, name + ".png")
        pack = assetpacks.directory("photos")
        if pack:
            original = os.path.join(pack, "posters_ready", name + ".png")
            if os.path.isfile(original):
                if self.width <= layout.MASTER[0]:
                    return original
                bundled = original
        if self.width <= layout.MASTER[0] and os.path.isfile(bundled):
            return bundled
        target = self._target(name)
        if os.path.isfile(target):
            return target
        return bundled if os.path.isfile(bundled) else None

    def pop_ready(self):
        with self._lock:
            ready, self._ready = self._ready, False
        return ready

    def request(self, names):
        if Image is None:
            return
        if self.width <= layout.MASTER[0]:
            todo = [name for name in names if name and not self.card_path(name)]
        else:
            todo = [name for name in names if name and not os.path.isfile(self._target(name))]
        if not todo:
            return
        with self._lock:
            for name in todo:
                if name not in self._queue:
                    self._queue.append(name)
            if self._busy:
                return
            self._busy = True
        worker = threading.Thread(target=self._loop)
        worker.daemon = True
        worker.start()

    def _loop(self):
        try:
            while True:
                with self._lock:
                    if not self._queue:
                        self._busy = False
                        return
                    name = self._queue.pop(0)
                try:
                    ok = self._render(name)
                except Exception:
                    log_exception("library poster %s failed" % name)
                    ok = False
                if ok:
                    with self._lock:
                        self._ready = True
                    if self.on_ready is not None:
                        try:
                            self.on_ready()
                        except Exception:
                            pass
        finally:
            with self._lock:
                self._busy = False

    def _render(self, name):
        from . import premium
        from .portraits import _atomic_save_png
        pack = assetpacks.directory("photos")
        source_dir = os.path.join(pack, "posters_src") if pack else SOURCE_DIR
        source = os.path.join(source_dir, name + ".jpg")
        if not os.path.isfile(source):
            # posters added after the artwork pack (the new preachers' covers) are bundled with the plugin
            source = os.path.join(SOURCE_DIR, name + ".jpg")
        if not os.path.isfile(source):
            return False
        src = Image.open(source)
        src.load()
        card = compose(src.convert("RGB"))
        target_size = layout.scaled((0, 0, premium.CARD_W, premium.CARD_H), self.width)[2:]
        if card.size != target_size:
            card = card.resize(target_size, premium._lanczos())
        directory = self._cache_dir()
        if not os.path.isdir(directory):
            os.makedirs(directory)
        if not has_room(directory, 2 * 1024 * 1024):
            log("library posters: no room in %s" % directory)
            return False
        _atomic_save_png(card, self._target(name))
        return True


def compose(src, scale=1):
    """Gallery card from a poster / photo, drawn on the 1080p grid (CARD_W x CARD_H) times `scale`."""
    from . import premium
    w, h, photo_h = premium.CARD_W * scale, premium.CARD_H * scale, premium.PHOTO_H * scale
    lanczos = premium._lanczos()
    ratio = src.width / float(src.height)
    card = Image.new("RGBA", (w, h), premium.BASE + (255,))
    if ratio <= 0.85:
        # a real (portrait) poster or photo: full bleed, keep the top where titles and faces are
        picture = ImageOps.fit(src, (w, photo_h), lanczos, centering=(0.5, 0.3))
        if max(w / float(src.width), photo_h / float(src.height)) > 1.25:
            picture = picture.filter(ImageFilter.UnsharpMask(radius=1.6, percent=60, threshold=2))
        card.paste(picture, (0, 0))
    else:
        # wide or square picture: shown whole over a darkened blurred copy of itself
        back = ImageOps.fit(src, (w, photo_h), lanczos).filter(ImageFilter.GaussianBlur(14 * scale))
        back = Image.blend(back, Image.new("RGB", back.size, premium.BASE), 0.45)
        card.paste(back, (0, 0))
        fit_w = w - 12 * scale
        fit_h = int(round(fit_w / ratio))
        if fit_h > photo_h - 12 * scale:
            fit_h = photo_h - 12 * scale
            fit_w = int(round(fit_h * ratio))
        front = src.resize((fit_w, fit_h), lanczos)
        if fit_w > src.width * 1.2:
            front = front.filter(ImageFilter.UnsharpMask(radius=1.4, percent=50, threshold=2))
        mask = premium.rounded_mask(fit_w, fit_h, 10 * scale)
        card.paste(front, ((w - fit_w) // 2, (photo_h - fit_h) // 2), mask)
    premium._plate(card, photo_h)
    return premium._finish(card)
