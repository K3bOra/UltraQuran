# -*- coding: utf-8 -*-
"""Offline translations keyed to the ayahs in the original Mushaf page images."""

import io
import os
import re
import tempfile
import textwrap

try:
    from PIL import ImageFont
except ImportError:
    ImageFont = None

from .support import ROOT, data_json, log_exception

LANGUAGES = (("en", u"English"), ("fr", u"Français"))
SOURCE_VERSE_NUMBER = re.compile(r"^\s*\([0-9]+\)\s*")
FOOTNOTE_MARKER = re.compile(r"\[[0-9]+\]")
ARABIC_DIGITS = u"٠١٢٣٤٥٦٧٨٩"


def _verse_label(verses):
    return u"، ".join(u"".join(ARABIC_DIGITS[int(digit)] for digit in str(verse))
                      for verse in verses if verse)


class MushafTranslation(object):
    def __init__(self, directory):
        self.path = os.path.join(directory, "translation-language.txt")
        self._editions = {}
        self._pages = {}
        self.language = "en"
        try:
            with io.open(self.path, encoding="ascii") as handle:
                language = handle.read().strip()
            if language in dict(LANGUAGES):
                self.language = language
        except (IOError, OSError, UnicodeError):
            pass

    def select(self, language):
        self.language = language
        temporary = None
        try:
            fd, temporary = tempfile.mkstemp(prefix=".translation-", dir=os.path.dirname(self.path))
            with os.fdopen(fd, "wb") as handle:
                handle.write(language.encode("ascii"))
            os.rename(temporary, self.path)
            temporary = None
        except (IOError, OSError):
            log_exception("Could not remember Mushaf translation language")
        finally:
            if temporary and os.path.exists(temporary):
                os.unlink(temporary)

    def _references(self, reading, page):
        if reading not in self._pages:
            if reading == "warsh":
                pages = data_json("translations", "warsh-pages.json")["pages"]
            else:
                pages = [[] for _ in range(604)]
                for surah, numbers in enumerate(data_json("pack-tafsir-index.json"), 1):
                    for verse, number in enumerate(numbers, 1):
                        pages[number - 1].append((surah, [verse], [verse]))
            self._pages[reading] = pages
        return self._pages[reading][page - 1]

    def page(self, reading, page):
        if self.language not in self._editions:
            self._editions[self.language] = data_json("translations", self.language + ".json")
        edition = self._editions[self.language]
        rows = []
        for surah, hafs_verses, display_verses in self._references(reading, page):
            verses = []
            for ayah in hafs_verses:
                body = edition["surahs"][surah - 1][ayah - 1][0]
                body = SOURCE_VERSE_NUMBER.sub(u"", body, count=1)
                verses.append(FOOTNOTE_MARKER.sub(u"", body))
            rows.append((_verse_label(display_verses), verses))
        return rows, edition["source"]


def translation_lines(rows, pixel_width, font_size):
    """Build display lines with the verse numbers of the open Mushaf."""
    paragraphs = []
    for label, verses in rows:
        body = u" ".join(verses)
        if label:
            body = u"(%s) %s" % (label, body)
        paragraphs.extend(body.splitlines())

    if ImageFont is not None:
        try:
            font = ImageFont.truetype(os.path.join(ROOT, "fonts", "Cairo-SemiBold.ttf"), font_size)
            width_of = font.getlength if hasattr(font, "getlength") else lambda text: font.getsize(text)[0]
            return _wrap_by_pixels(paragraphs, pixel_width, width_of)
        except (IOError, OSError, UnicodeError):
            pass
    lines = []
    chars = max(1, 2 * pixel_width // max(1, font_size))
    for paragraph in paragraphs:
        lines.extend(textwrap.wrap(paragraph, chars, break_on_hyphens=False) or [u""])
    return lines


def _wrap_by_pixels(paragraphs, limit, width_of):
    lines = []
    for paragraph in paragraphs:
        line = u""
        for word in paragraph.split():
            candidate = line + u" " + word if line else word
            if width_of(candidate) <= limit:
                line = candidate
                continue
            if line:
                lines.append(line)
            if width_of(word) <= limit:
                line = word
                continue
            line = u""
            for char in word:
                if line and width_of(line + char) > limit:
                    lines.append(line)
                    line = u""
                line += char
        lines.append(line)
    return lines
