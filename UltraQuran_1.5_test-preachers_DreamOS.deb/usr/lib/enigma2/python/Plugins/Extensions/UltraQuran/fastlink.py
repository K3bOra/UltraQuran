# -*- coding: utf-8 -*-
"""Faster starts & rock-solid video/audio streaming proxy for Enigma2 & DreamOS.

Why:
1. archive.org (and most mirrors) answer catalogue links with HTTP 302 redirects to data servers (`ia*.us.archive.org`).
2. Many archive.org media filenames contain Arabic characters, spaces (`%20`), or consecutive spaces (`%20%20`).
   Enigma2's C++ players (`eServiceMP3` 4097, `eServiceUri` 8193, `exteplayer3` 5002) often unescape `%20` into
   literal spaces before handing the URI to GStreamer `souphttpsrc`, or fail SSL/TLS certificate validation on
   `https://*.archive.org`, causing immediate `evTuneFailed` / `evStreamError` on video playback.
3. By running a lightweight multi-threaded local HTTP stream proxy on `127.0.0.1:<port>/stream/<token>.mp4`,
   Enigma2's C++ video engines connect to a clean, pure-ASCII local `http://127.0.0.1` URL with zero redirects,
   zero SSL handshake failures, and full `Range: bytes=...` support for instant playback and seeking.
"""
from __future__ import absolute_import

import hashlib
import os
import socket
import ssl
import threading
import time

try:
    from urllib.parse import quote, unquote, urlsplit, urlunsplit
    from urllib.request import HTTPRedirectHandler, HTTPSHandler, ProxyHandler, Request, build_opener, urlopen
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from socketserver import ThreadingMixIn
except ImportError:  # Python 2 (DreamOS)
    from urllib import quote, unquote
    from urlparse import urljoin, urlsplit, urlunsplit
    from urllib2 import HTTPRedirectHandler, HTTPSHandler, ProxyHandler, Request, build_opener, urlopen
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
    from SocketServer import ThreadingMixIn

try:
    from urllib.parse import urljoin
except ImportError:
    pass

from .support import ROOT, log, native

KEEP = 20 * 60          # data-server links stay valid for hours; keep them 20 minutes
MAX_JOBS = 4
USER_AGENT = "Mozilla/5.0 (X11; Linux armv7l) UltraQuran/1.2"
PROXY_CHUNK = 65536

_cache = {}             # url -> (final url, time)
_running = set()
_lock = threading.Lock()

_proxy_lock = threading.Lock()
_proxy_port = None
_proxy_urls = {}        # token -> original_url


def safe_url(url):
    """Ensure URL path and query are properly percent-encoded pure ASCII for urllib and C++ players."""
    if not url:
        return ""
    try:
        if not isinstance(url, str):
            url = url.encode("utf-8") if str is bytes else url.decode("utf-8", "replace")
    except Exception:
        pass
    if str is not bytes:
        try:
            if any(0x80 <= ord(c) <= 0xFF for c in url):
                url = url.encode("latin-1").decode("utf-8")
        except Exception:
            pass
    try:
        parts = urlsplit(url)
        raw_path = unquote(parts.path)
        if str is bytes:
            if isinstance(raw_path, unicode):
                raw_path = raw_path.encode("utf-8")
        else:
            if isinstance(raw_path, bytes):
                raw_path = raw_path.decode("utf-8", "replace")
            else:
                try:
                    if any(0x80 <= ord(c) <= 0xFF for c in raw_path):
                        raw_path = raw_path.encode("latin-1").decode("utf-8")
                except Exception:
                    pass
        safe_path = quote(raw_path, safe="/-._~")
        raw_query = parts.query
        if str is bytes and isinstance(raw_query, unicode):
            raw_query = raw_query.encode("utf-8")
        return native(urlunsplit((parts.scheme, parts.netloc, safe_path, raw_query, parts.fragment)))
    except Exception:
        return native(url)


def _ssl_contexts():
    contexts = []
    cafile = os.path.join(ROOT, "certs", "cacert.pem")
    if hasattr(ssl, "create_default_context"):
        try:
            if os.path.isfile(cafile):
                contexts.append(ssl.create_default_context(cafile=cafile))
            else:
                contexts.append(ssl.create_default_context())
        except Exception:
            pass
    if hasattr(ssl, "_create_unverified_context"):
        try:
            contexts.append(ssl._create_unverified_context())
        except Exception:
            pass
    return contexts or [None]


class _SafeRedirectHandler(HTTPRedirectHandler):
    """Follows 301/302/303/307/308 redirects while sanitizing Arabic/space Location headers."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        try:
            base = req.get_full_url()
            target = safe_url(urljoin(base, newurl))
        except Exception:
            target = safe_url(newurl)
        new_headers = dict((k, v) for k, v in req.headers.items()
                           if k.lower() not in ("content-length", "content-type", "host"))
        return Request(target, headers=new_headers)


def open_upstream(url, range_header=None, timeout=12):
    """Open `url` (following redirects safely and trying bundled + unverified SSL contexts).
    Returns (response, final_url)."""
    clean_url = safe_url(url)
    # Check if we already have a cached direct CDN URL for faster connection
    cached = None
    with _lock:
        hit = _cache.get(url) or _cache.get(clean_url)
        if hit and time.time() - hit[1] < KEEP and hit[0]:
            cached = hit[0]

    candidates = [cached, clean_url] if (cached and cached != clean_url) else [clean_url]
    last_exc = None

    for target in candidates:
        for ctx in _ssl_contexts():
            try:
                handlers = [_SafeRedirectHandler()]
                if ctx is not None:
                    try:
                        handlers.append(HTTPSHandler(context=ctx))
                    except TypeError:
                        pass
                opener = build_opener(*handlers)
                headers = {
                    "User-Agent": USER_AGENT,
                    "Accept": "*/*",
                    "Connection": "close",
                }
                if range_header:
                    headers["Range"] = native(range_header)
                req = Request(native(target), headers=headers)
                resp = opener.open(req, timeout=timeout)
                final_u = safe_url(resp.geturl() or target)
                if final_u:
                    with _lock:
                        _cache[url] = (final_u, time.time())
                        _cache[clean_url] = (final_u, time.time())
                return resp, final_u
            except Exception as exc:
                last_exc = exc
                text = str(exc).lower()
                if not any(word in text for word in ("ssl", "certificate", "tls", "handshake")):
                    break
        # If cached CDN link expired or failed, forget it and try clean_url next
        if target == cached:
            with _lock:
                _cache.pop(url, None)
                _cache.pop(clean_url, None)

    if last_exc is not None:
        raise last_exc
    raise IOError("Cannot open upstream URL")


def _resolve(url):
    final_u = None
    try:
        resp, final_u = open_upstream(url, range_header="bytes=0-0", timeout=8)
        try:
            status = getattr(resp, "status", None) or resp.getcode()
            if status not in (200, 206):
                final_u = None
        finally:
            resp.close()
    except Exception:
        final_u = None
    return final_u


def prefetch(url):
    """Find the final address of `url` in the background (no-op for local files and known links)."""
    if not url or not url.startswith("http"):
        return
    clean = safe_url(url)
    now = time.time()
    with _lock:
        hit = _cache.get(url) or _cache.get(clean)
        if (hit and now - hit[1] < KEEP) or clean in _running or len(_running) >= MAX_JOBS:
            return
        _running.add(clean)

    def work():
        try:
            final_u = _resolve(clean)
            with _lock:
                if final_u:
                    _cache[url] = (final_u, time.time())
                    _cache[clean] = (final_u, time.time())
                if len(_cache) > 400:
                    for key, _ in sorted(_cache.items(), key=lambda kv: kv[1][1])[:120]:
                        _cache.pop(key, None)
        except Exception:
            pass
        finally:
            with _lock:
                _running.discard(clean)

    thread = threading.Thread(target=work)
    thread.daemon = True
    thread.start()


def final(url, wait=0.0):
    """The data-server address of `url` when known (optionally waiting up to `wait` seconds), else `safe_url(url)`."""
    if not url or not url.startswith("http"):
        return url
    clean = safe_url(url)
    with _lock:
        hit = _cache.get(url) or _cache.get(clean)
    if hit and time.time() - hit[1] < KEEP and hit[0]:
        return hit[0]
    if wait and wait > 0:
        prefetch(clean)
        deadline = time.time() + float(wait)
        while time.time() < deadline:
            time.sleep(0.08)
            with _lock:
                hit = _cache.get(url) or _cache.get(clean)
                still_running = clean in _running
            if hit and time.time() - hit[1] < KEEP and hit[0]:
                return hit[0]
            if not still_running:
                break
    return clean


def forget(url):
    clean = safe_url(url) if url else ""
    with _lock:
        _cache.pop(url, None)
        if clean:
            _cache.pop(clean, None)


# --------------------------------------------------------------------------- Local HTTP Stream Proxy
class _ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class _StreamProxyHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        return

    def do_HEAD(self):
        self._serve(send_body=False)

    def do_GET(self):
        self._serve(send_body=True)

    def _serve(self, send_body=True):
        self.close_connection = True
        path = (self.path or "").split("?", 1)[0]
        parts = [p for p in path.split("/") if p]
        if len(parts) < 2 or parts[0] != "stream":
            self.send_error(404, "Not Found")
            return
        token = parts[1].split(".", 1)[0]
        with _proxy_lock:
            target_url = _proxy_urls.get(token)
        if not target_url:
            self.send_error(404, "Unknown stream token")
            return

        range_hdr = self.headers.get("Range") or self.headers.get("range")
        resp = None
        try:
            resp, _ = open_upstream(target_url, range_header=range_hdr, timeout=15)
            status = getattr(resp, "status", None) or resp.getcode() or 200
            info = resp.info()

            self.send_response(int(status))
            ctype = info.get("Content-Type") or ""
            if not ctype or "octet-stream" in ctype.lower():
                ctype = "video/mp4" if path.endswith(".mp4") else "audio/mpeg"
            self.send_header("Content-Type", ctype)

            clen = info.get("Content-Length")
            if clen:
                self.send_header("Content-Length", clen)

            crange = info.get("Content-Range")
            if crange:
                self.send_header("Content-Range", crange)

            accept_ranges = info.get("Accept-Ranges") or "bytes"
            self.send_header("Accept-Ranges", accept_ranges)
            self.send_header("Connection", "close")
            self.end_headers()

            if send_body:
                while True:
                    chunk = resp.read(PROXY_CHUNK)
                    if not chunk:
                        break
                    self.wfile.write(chunk)
        except (socket.error, IOError):
            # Client (GStreamer / ExtePlayer3 / ServiceApp) closed connection during seek or stop
            pass
        except Exception as exc:
            try:
                log(u"Stream proxy error: %s" % exc)
                self.send_error(502, "Bad Gateway")
            except Exception:
                pass
        finally:
            if resp is not None:
                try:
                    resp.close()
                except Exception:
                    pass


def _ensure_proxy_server():
    global _proxy_port
    with _proxy_lock:
        if _proxy_port is not None:
            return _proxy_port
        try:
            server = _ThreadingHTTPServer(("127.0.0.1", 0), _StreamProxyHandler)
            _proxy_port = server.server_address[1]
            thread = threading.Thread(target=server.serve_forever)
            thread.daemon = True
            thread.start()
            log(u"Local stream proxy listening on 127.0.0.1:%d" % _proxy_port)
        except Exception as exc:
            log(u"Could not start stream proxy: %s" % exc)
            _proxy_port = None
        return _proxy_port


def proxy_url(url, ext=".mp4"):
    """Register `url` in the local HTTP proxy and return `http://127.0.0.1:<port>/stream/<token><ext>`.
    Falls back to `final(url)` if the proxy cannot bind."""
    if not url or not url.startswith("http"):
        return url
    clean = safe_url(url)
    prefetch(clean)
    port = _ensure_proxy_server()
    if not port:
        return final(clean, wait=1.5)
    raw = clean.encode("utf-8") if not isinstance(clean, bytes) else clean
    token = hashlib.md5(raw).hexdigest()[:20]
    lower = clean.lower().split("?", 1)[0]
    for candidate in (".mp4", ".mkv", ".mp3", ".ogg", ".m4a", ".aac", ".ts"):
        if lower.endswith(candidate):
            ext = candidate
            break
    with _proxy_lock:
        _proxy_urls[token] = clean
        if len(_proxy_urls) > 500:
            _proxy_urls.clear()
            _proxy_urls[token] = clean
    return native("http://127.0.0.1:%d/stream/%s%s" % (port, token, ext))
