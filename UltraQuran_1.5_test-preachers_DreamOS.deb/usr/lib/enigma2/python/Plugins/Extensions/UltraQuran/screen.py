# -*- coding: utf-8 -*-
import io
import json
import os
import re
import threading
import textwrap
import time

from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
from Screens.Screen import Screen
from enigma import addFont, ePoint, eSize, getDesktop
try:
    from enigma import gFont
except ImportError:
    gFont = None

from . import VERSION, assetpacks, layout
from .catalog import Catalog, RECITER_YOUTUBE_LIBRARY, format_seconds, hijri_today, ramadan_countdown, strip_duration, zina_season
from .downloader import DownloadManager
from .mushaf import MushafManager, find_mushaf_dir
from .mushaf_translation import LANGUAGES, MushafTranslation, translation_lines
from .player import Audio, PTS, RESUME
from .portraits import PortraitManager
from .posters import LibraryPosters, folder_items, gallery_items
from .scroller import BioScroller
from . import fastlink
from . import homeorder
from .wikibio import WikiBios, SOURCE as WIKI_SOURCE
from .videos import VideoFinder
from .support import ROOT, is_mubtahil, Timer, text_width_pad, art_ready, data_json, ensure_art_for_width, load_favorites, log, log_exception, native, save_favorites

MUSHAF_MENU_ROW_IMAGES = tuple("mushaf_menu_row%d" % i for i in range(layout.MUSHAF_MENU_ROW_COUNT))
MUSHAF_MENU_OPTIONS = tuple(("mushaf_menu_opt%d" % i, "mushaf_menu_detail%d" % i)
                            for i in range(layout.MUSHAF_MENU_ROW_COUNT))
MUSHAF_MENU_LABELS = ("mushaf_menu_title", "mushaf_menu_sub", "mushaf_menu_status", "mushaf_menu_hint")
COUNT_BADGES = tuple("count_badge%d" % i for i in range(len(layout.HOME_COUNT_SECTIONS)))

IMAGES = (
    ("backdrop", "background", "focus", "home_pick", "portrait", "page", "mframe", "pmark_r", "pmark_l",
     "dlg", "dlg_row0", "dlg_row1", "dlg_row2", "dlg_focus", "upd", "upd_fill",
     "rdig0", "rdig1", "rdig2", "rcap", "runit", "rchip", "rnav")
    + ("zina_rope",) + tuple("zina_l%d" % i for i in range(4))
    + tuple("poster%d" % i for i in range(layout.POSTER_PAGE_SIZE))
    + tuple("ecard%d" % i for i in range(layout.ECARD_PAGE_SIZE))
    + tuple("scard%d" % i for i in range(layout.SURA_PAGE_SIZE))
    + tuple("lcard%d" % i for i in range(layout.LIB_PAGE_SIZE))
    + COUNT_BADGES + MUSHAF_MENU_ROW_IMAGES + ("mushaf_menu_panel",)
)

IMAGE_SET = frozenset(IMAGES)

LABELS = {
    "title": (40, "right"), "sub": (18, "right"),
    "panel": (24, "center"), "p_meta": (16, "center"),
    "p_source": (16, "center"), "p_mode": (16, "center"),
    "p_reciter": (19, "center"), "info": (16, "center"),
    "status": (16, "center"), "elapsed": (16, "right"), "duration": (16, "left"),
    "control": (18, "center"), "queue": (16, "center"), "p_info": (15, "center"),
    "dl_status": (15, "center"), "count": (17, "center"),
    "bio_name": (22, "center"), "bio_born": (15, "center"), "bio_died": (15, "center"),
    "bio_heading": (17, "center"), "bio_text": (16, "center"), "bio_source": (15, "center"),
    "bio_recordings": (16, "center"), "bio_riwayas": (16, "center"),
    "gallery_page": (18, "center"), "notice": (22, "center"),
    "jump": (24, "center"), "mushaf_hint": (26, "center"),
    "mushaf_translation_title": (20, "center"), "mushaf_translation_language": (30, "center"),
    "mushaf_translation_page": (19, "center"),
    "mushaf_translation_hint": (16, "center"), "mushaf_translation_credit": (16, "center"),
    "mushaf_translation_fill": (8, "center"),
    "lib_badge": (17, "center"), "lib_heading": (19, "center"),
    "lib_body": (22, "right"), "lib_action": (17, "center"),
    "v_title": (32, "center"), "v_queue": (16, "right"),
    "mushaf_surah": (30, "center"), "mushaf_juz": (19, "center"), "mushaf_page": (84, "center"), "mushaf_state": (16, "center"), "mushaf_tafsir": (20, "right"),
}
# Information texts (left panels, player lines, hints) were too small on a TV: they get a bigger font and the
# plugin shrinks one back step by step only when its text would not fit its box (never below FIT_FLOOR).
BIGGER = {"status": 20, "elapsed": 20, "duration": 20, "p_meta": 19, "p_source": 19, "p_mode": 19, "queue": 19,
          "p_info": 19, "dl_status": 18, "info": 19, "control": 20, "count": 19,
          "bio_born": 18, "bio_died": 18, "bio_heading": 20, "bio_text": 19, "bio_source": 18,
          "bio_recordings": 19, "bio_riwayas": 19, "lib_badge": 19, "lib_heading": 21, "lib_action": 20,
          "mushaf_state": 18, "mushaf_juz": 21}
BIGGER.update({"lib_body": 24, "sub": 20, "v_queue": 18, "mushaf_tafsir": 21})
FIT_FLOOR = dict((name, LABELS[name][0]) for name in BIGGER)
FIT_FLOOR.update({"title": 26, "sub": 15, "count": 15, "v_title": 22, "panel": 19, "lib_heading": 17})
SHANQITI_BIO = (
    u"عالم ومدرّس للفقه والحديث. تلقّى العلم على والده محمد المختار الشنقيطي، "
    u"وكان يحضر دروسه في المسجد النبوي منذ صغره. وفي سن الخامسة عشرة "
    u"بدأ يقرأ عليه سنن الترمذي في مجالس المسجد النبوي.\n\n"
    u"تضم هذه المكتبة تسجيلات من شرحه لعمدة الأحكام وعمدة الفقه وسنن الترمذي."
)
BIO_CHARS = 33      # biography line length in the 416-wide box
LINE_HEIGHT = 1.88  # Cairo's line (ascender + descender) in font sizes
TEXT_PAGE_SECONDS = 5
TEXT_SIZES = ((100, u"عادي"), (115, u"الافتراضي"), (130, u"كبير"))   # 1.4: 115% is the default (clearer)
DEFAULT_TEXT_SIZE = 115
TEXT_SIZE_PATH = "/etc/enigma2/ultra-quran-text-size"
text_clock = getattr(time, "monotonic", time.time)
BIO_VIEWS = ("reciter_hub", "editions", "reciter_videos", "shaarawy", "shaarawy_folders", "mahmoud_hub")
# long texts with their own paging / scrolling: never cut
NO_FIT = frozenset(("mushaf_tafsir", "mushaf_page", "bio_text", "home_ayah2", "upd_notes"))
MUSHAF_TRANSLATION_ROWS = tuple("mushaf_translation_line%d" % i for i in range(layout.MUSHAF_TRANS_LINES))
LABELS.update(dict((name, (22, "left")) for name in MUSHAF_TRANSLATION_ROWS))
NO_FIT = NO_FIT.union(MUSHAF_TRANSLATION_ROWS)
LABELS.update(dict(zip(MUSHAF_MENU_LABELS, ((27, "center"), (20, "center"), (20, "center"), (18, "center")))))
for _option, _detail in MUSHAF_MENU_OPTIONS:
    LABELS[_option] = (23, "right")
    LABELS[_detail] = (19, "right")
    NO_FIT = NO_FIT.union((_option, _detail))
for _name, _size in BIGGER.items():
    LABELS[_name] = (_size, LABELS[_name][1])
LABELS.update({"top_elapsed": (20, "right"), "top_remain": (20, "left")})
LABELS.update({"home_clock": (54, "right"), "home_ayah": (34, "center"), "home_ayah2": (30, "center"), "home_ayah_ref": (18, "center"), "home_resume_cap": (18, "center"),
               "home_resume_title": (25, "center"), "home_resume_sub": (21, "center"), "home_resume_hint": (17, "center"),
               "home_date": (28, "right"), "home_desc": (21, "right"), "home_page_hint": (18, "center"),
               "home_text_size_hint": (17, "center")})
for _name, _floor in (("gallery_page", 16), ("home_ayah", 19), ("home_resume_title", 19), ("home_desc", 17), ("home_date", 22), ("home_resume_sub", 17), ("home_resume_hint", 15)):
    FIT_FLOOR[_name] = _floor
LABELS.update({"ramadan_caption": (21, "center"), "ramadan_number": (35 if gFont is not None else 31, "center"),
               "ramadan_unit": (19, "center")})
FIT_FLOOR.update({"ramadan_caption": 20, "ramadan_number": 25, "ramadan_unit": 17})
LABELS.update({"dlg_title": (28, "center"), "dlg_sub": (19, "center"),
               "dlg_opt0": (22, "center"), "dlg_opt1": (22, "center"), "dlg_opt2": (22, "center")})
LABELS.update({"footer_version": (18, "left")})
FIT_FLOOR.update({"footer_version": 14})
LABELS.update({"upd_status": (24, "center"), "upd_notes": (20, "right"), "upd_page": (17, "left"),
               "upd_green": (22, "left"), "upd_red": (22, "left")})
FIT_FLOOR.update({"upd_status": 18, "upd_page": 15, "upd_green": 17, "upd_red": 17})
LABELS.update({"card%d" % i: (17, "center") for i in range(layout.POSTER_PAGE_SIZE)})
LABELS.update({"ecard_title%d" % i: (22, "center") for i in range(layout.ECARD_PAGE_SIZE)})
LABELS.update({"ecard_meta%d" % i: (17, "center") for i in range(layout.ECARD_PAGE_SIZE)})
LABELS.update({"ecard_num%d" % i: (27, "center") for i in range(layout.ECARD_PAGE_SIZE)})
LABELS.update({"ecard_badge%d" % i: (21, "center") for i in range(layout.ECARD_PAGE_SIZE)})
LABELS.update({"deck_badge%d" % i: (27, "center") for i in range(3)})
LABELS.update({"row%d" % i: (23, "center") for i in range(layout.SURA_PAGE_SIZE)})
LABELS.update({"radio_row%d" % i: (19, "center") for i in range(layout.SURA_PAGE_SIZE)})
LABELS.update({"number%d" % i: (25, "center") for i in range(layout.SURA_PAGE_SIZE)})
LABELS.update({"detail%d" % i: (17, "center") for i in range(layout.SURA_PAGE_SIZE)})
# card names: big, shrunk only as far as needed for the whole name to fit (two lines)
for _prefix, _count, _floor in (("row", layout.SURA_PAGE_SIZE, 18), ("radio_row", layout.SURA_PAGE_SIZE, 16),
                                ("ecard_title", layout.ECARD_PAGE_SIZE, 17)):
    for _i in range(_count):
        FIT_FLOOR["%s%d" % (_prefix, _i)] = _floor
LABELS.update({"radio_row%d" % i: (21, "center") for i in range(layout.SURA_PAGE_SIZE)})
# small card captions one step bigger (shrunk back only when a caption would not fit its capsule)
for _prefix, _count, _big in (("detail", layout.SURA_PAGE_SIZE, 19), ("ecard_meta", layout.ECARD_PAGE_SIZE, 19),
                              ("card", layout.POSTER_PAGE_SIZE, 19)):
    for _i in range(_count):
        _key = "%s%d" % (_prefix, _i)
        FIT_FLOOR[_key] = LABELS[_key][0]
        LABELS[_key] = (_big, LABELS[_key][1])

REGISTERED = False
# calm palette (kept in sync with devtools/gen_art.py)
COLOR_TEXT = "#eee8d6"
COLOR_SOFT = "#9ec6b8"
COLOR_GOLD = "#f4d896"
COLOR_MINT = "#76c4a4"
COLOR_TRACK = "#14302d"
PHOTO_IDS = set()
LIB_PAGE_MS = 16000
SHAARAWY_NAME = u"الشيخ محمد متولي الشعراوي"
MAHMOUD_LIBRARY = 15
YOUTUBE_LIBRARIES = (16, 17, 18, RECITER_YOUTUBE_LIBRARY)
MAHMOUD_VIDEO_OWNER = "mostafa_mahmoud"
MAHMOUD_NAME = u"الدكتور مصطفى محمود"


TASHKEEL = re.compile(u"[\u0610-\u061a\u064b-\u065f\u0670\u06d6-\u06ed]")


AYAH_ONE_LINE = 42   # up to here one line is bigger (31-34) than two lines would be (26-30)
AYAH_TWO_MAX = 30    # biggest size of a two-line ayah
AYAH_PITCH = 1.42    # distance between the two ayah lines, in font sizes (the font's own 1.88 leaves a hole)


def ayah_lines(text):
    """Ayah of the day: a short ayah stays one line; a longer one is split by us into two balanced, centred lines
    (the first a little longer), because the receiver's own wrapping can leave a single word on the first line."""
    words = (text or u"").split()
    if len(text or u"") <= AYAH_ONE_LINE or len(words) < 2:
        return text
    best = None
    for i in range(1, len(words)):
        first, second = u" ".join(words[:i]), u" ".join(words[i:])
        score = max(len(first), len(second)) + (0.5 if len(first) < len(second) else 0)
        if best is None or score < best[0]:
            best = (score, first, second)
    return best[1] + u"\n" + best[2]


def plain(text):
    """Arabic without harakat: Enigma2 cannot position combining marks (they come out as loose
    glyphs between the letters), so labels it draws itself get clean undecorated text."""
    return TASHKEEL.sub(u"", text or u"")


def load_text_size():
    try:
        with io.open(TEXT_SIZE_PATH, encoding="ascii") as handle:
            parts = handle.read().split()
        size = int(parts[0])
        # a bare "100" was written before 1.4, when 100% was the default and not a choice: it gets the new default
        if size == 100 and parts[1:] != ["chosen"]:
            return DEFAULT_TEXT_SIZE
        if size in dict(TEXT_SIZES):
            return size
    except (IOError, OSError, ValueError, IndexError):
        pass
    return DEFAULT_TEXT_SIZE


def collect_media(node):
    """Every downloadable (non-live) audio/video item inside a folder, at any depth."""
    out = []
    stack = [node]
    while stack:
        cur = stack.pop()
        kids = list(cur.get("children") or []) + list(cur.get("folders") or []) + list(cur.get("items") or [])
        if kids:
            stack.extend(reversed(kids))
        elif cur.get("audio") and not cur.get("live") and "qurango.net/radio" not in cur.get("audio", u""):
            out.append(cur)
    return out


def skin(width, height, art_dir=None):
    widgets = []
    for name in IMAGES:
        # background at -4; cards and portraits at 1; the single focus pointer at 2
        z = -5 if name == "backdrop" else -4 if name == "background" else 2 if name == "focus" else 3 if name.startswith("pmark") else 4 if name == "mframe" else 1
        if name in ("rchip", "rnav"):
            z = 8
        elif name.startswith("zina_"):
            z = 5                      # over the home hero's frame, under every text
        elif name in ("rdig0", "rdig1", "rdig2", "rcap", "runit"):
            z = 9
        if name.startswith("dlg"):
            z = 28 if name == "dlg_focus" else 27 if name.startswith("dlg_row") else 26
        if name.startswith("upd"):
            z = 34 if name == "upd_fill" else 32      # above the notice line, the choice dialog and every card
        if name == "mushaf_menu_panel":
            z = 6
        elif name in MUSHAF_MENU_ROW_IMAGES:
            z = 7
        widgets.append('<widget name="%s" position="0,0" size="1,1" alphatest="blend" zPosition="%d" />' % (name, z))
    for name, (size, alignment) in LABELS.items():
        props = 'transparent="1" foregroundColor="%s"' % COLOR_TEXT
        z = 10
        if name in ("count", "info", "sub", "bio_born", "bio_died", "bio_source", "p_info"):
            props = 'transparent="1" foregroundColor="%s"' % COLOR_SOFT
        if name.startswith(("number", "ecard_num")) or name == "ramadan_number":
            props = 'transparent="1" foregroundColor="%s"' % COLOR_GOLD
        if name.startswith(("ecard_badge", "deck_badge")) or name in ("lib_heading", "lib_action", "status", "p_reciter", "p_mode"):
            props = 'transparent="1" foregroundColor="%s"' % COLOR_GOLD
        if name.startswith(("detail", "ecard_meta")) or name in ("bio_heading", "dl_status", "p_meta", "p_source", "lib_badge"):
            props = 'transparent="1" foregroundColor="%s"' % COLOR_MINT
        if name in ("notice", "jump"):
            props = 'transparent="0" backgroundColor="#0c2a28" foregroundColor="%s"' % COLOR_GOLD
            z = 30
        if name in ("home_ayah", "home_ayah2", "home_resume_cap", "home_clock", "home_date", "gallery_page", "home_page_hint"):
            props = 'transparent="1" foregroundColor="%s"' % COLOR_GOLD
        if name in ("home_ayah_ref", "home_resume_sub", "home_desc"):
            props = 'transparent="1" foregroundColor="%s"' % COLOR_MINT
        if name == "home_resume_hint":
            props = 'transparent="1" foregroundColor="%s"' % COLOR_SOFT
        if name.startswith("dlg_"):
            z = 31
            color = COLOR_GOLD if name == "dlg_title" else COLOR_SOFT if name == "dlg_sub" else COLOR_TEXT
            props = 'transparent="1" foregroundColor="%s"' % color
        if name == "footer_version":
            props = 'transparent="1" foregroundColor="%s"' % COLOR_SOFT
        if name.startswith("upd_"):
            z = 35
            color = COLOR_GOLD if name == "upd_status" else COLOR_SOFT if name == "upd_page" else COLOR_TEXT
            props = 'transparent="1" foregroundColor="%s"' % color
        if name == "mushaf_surah":
            props = 'transparent="1" foregroundColor="%s"' % COLOR_GOLD
        if name == "mushaf_juz":
            props = 'transparent="1" foregroundColor="%s"' % COLOR_MINT
        if name == "mushaf_state":
            props = 'transparent="1" foregroundColor="%s"' % COLOR_SOFT
        if name == "mushaf_tafsir":
            props = 'transparent="1" foregroundColor="#e8e2cc"'
        if name == "mushaf_hint":
            props = 'transparent="1" foregroundColor="#3a5a52"'
            z = 12
        if name in ("mushaf_translation_title", "mushaf_translation_language", "mushaf_menu_title"):
            props = 'transparent="1" foregroundColor="%s"' % COLOR_GOLD
        if name == "mushaf_translation_page":
            props = 'transparent="1" foregroundColor="%s"' % COLOR_MINT
        if name in ("mushaf_translation_hint", "mushaf_translation_credit"):
            props = 'transparent="1" foregroundColor="%s"' % COLOR_SOFT
        if name.startswith("mushaf_menu_detail") or name in MUSHAF_MENU_LABELS[1:]:
            props = 'transparent="1" foregroundColor="%s"' % COLOR_SOFT
        if name == "mushaf_translation_fill":
            props = 'transparent="0" backgroundColor="%s"' % COLOR_MINT
        if name in MUSHAF_TRANSLATION_ROWS:
            props = 'transparent="1" foregroundColor="#e8e2cc"'
        vertical = "top" if name in MUSHAF_TRANSLATION_ROWS or name in ("mushaf_tafsir", "upd_notes") else "center"
        widgets.append('<widget name="%s" position="0,0" size="1,1" font="UltraQuranUI;%d" '
                       'halign="%s" valign="%s" zPosition="%d" %s />' %
                       (name, max(6, layout.pixel(size, width)), alignment, vertical, z, props))
    # one flat bar: the track colour equals the rail baked into the artwork, so only ONE bar is ever visible
    # The bar is drawn by the plugin itself: a dark track label and a gold fill label whose WIDTH is set from the
    # position. Receivers' own progress widgets ignored the 0..1000 range on some images (bar full at 14 %).
    widgets.append('<widget name="progress" position="0,0" size="1,1" zPosition="15" font="UltraQuranUI;8" '
                   'transparent="0" backgroundColor="%s" foregroundColor="%s" />' % (COLOR_TRACK, COLOR_TRACK))
    # 'laser' fill (Ultra Stalker New 2 style): an image of the whole track, NOT scaled - the widget is only
    # made as wide as the played part, so the left part of the colour run shows
    widgets.append('<widget name="progress_fill" position="0,0" size="1,1" zPosition="16" alphatest="blend" transparent="1" />')
    # now-playing strip in the top bar (other screens): its own track + fill, so it never fights a screen's bar
    widgets.append('<widget name="top_track" position="0,0" size="1,1" zPosition="15" font="UltraQuranUI;8" '
                   'transparent="0" backgroundColor="#2c4c45" foregroundColor="#2c4c45" />')
    widgets.append('<widget name="top_fill" position="0,0" size="1,1" zPosition="16" alphatest="blend" transparent="1" />')
    # #ff000000 is transparent in Enigma2 ARGB so full-screen video plane is visible in 'video' view,
    # while all other views cover (0,0,1920,1080) with the opaque 'background' pixmap.
    return ('<screen name="UltraQuran" position="center,center" size="%d,%d" flags="wfNoBorder" '
            'backgroundColor="#ff000000" title="Ultra Quran">%s</screen>' %
            (width, height, "".join(widgets)))


def find_mushaf(media_root="/media"):
    return find_mushaf_dir(media_root)


def wrap(text, limit):
    lines = []
    for paragraph in (text or u"").splitlines():
        if not paragraph.strip():
            if lines and lines[-1] != u"":
                lines.append(u"")
        else:
            lines.extend(textwrap.wrap(paragraph, limit, break_long_words=False, break_on_hyphens=False))
    return u"\n".join(lines)


def flat_text(text):
    return u" ".join((text or u"").split())


def card_title(text):
    """Use the caption for a long card's qualifier, leaving two lines available for the title."""
    text = flat_text(text)
    extra = u""
    if len(text) > 30 and u" · " in text:
        text, extra = [part.strip() for part in text.split(u" · ", 1)]
    if len(text) <= 30:
        return "row", text, extra
    return "radio_row", text, extra


def balanced_wrap(text, per_line=52):
    """Wrap a short paragraph into evenly filled lines (no lonely last word)."""
    text = u" ".join((text or u"").split())
    count = max(1, -(-len(text) // per_line))
    limit = -(-len(text) // count) + 4
    return textwrap.wrap(text, limit, break_long_words=False, break_on_hyphens=False) or [u""]


def grid_step(index, count, cols, direction):
    """Circular cursor movement for RTL grids (left = next, right = previous, down = next row).

    * left on the last item wraps to the first, right on the first wraps to the last;
    * down from the last row goes back to the first row (the last item goes straight to the first);
    * up from the first row goes to the last row / last item;
    * when the last row is incomplete, down from the row above lands on the last item.
    """
    if count <= 0:
        return 0
    last = count - 1
    if direction == "left":
        return 0 if index >= last else index + 1
    if direction == "right":
        return last if index <= 0 else index - 1
    if direction == "down":
        target = index + cols
        if target <= last:
            return target
        if index == last or index // cols == last // cols:
            return 0 if index == last else index % cols
        return last
    if direction == "up":
        target = index - cols
        if target >= 0:
            return target
        wrapped = (last // cols) * cols + index % cols
        return wrapped if wrapped <= last else last
    return index


class Route(object):
    def __init__(self, name, items=(), key=None, index=0, folder_title=None):
        self.name, self.items, self.key, self.index = name, items, key, index
        self.folder_title = folder_title
        self.scroll = 0
        self.question_index = 0
        self.score = 0
        self.answered = None
        self.filter_mode = "all"
        self.owner_name = None
        self.all_items = list(items) if name == "shaarawy" else None


class UltraQuran(Screen):
    def createSummary(self):
        from .frontpanel import UltraQuranFrontSummary
        return UltraQuranFrontSummary

    def __init__(self, session):
        global REGISTERED
        desktop = getDesktop(0).size()
        self.width, self.height = next(
            ((w, h) for w, h in layout.SIZES if desktop.width() >= w and desktop.height() >= h),
            layout.SIZES[-1])
        if not REGISTERED:
            path = os.path.join(ROOT, "fonts", "Cairo-SemiBold.ttf")
            try:
                addFont(native(path), "UltraQuranUI", 100, 0, 0)
            except TypeError:
                addFont(native(path), "UltraQuranUI", 100, 0)
            REGISTERED = True
        wanted_width = self.width
        if assetpacks.enabled():
            assetpacks.load_installed(wanted_width)
            self.width, self.height = next(
                ((w, h) for w, h in layout.SIZES if w <= min(wanted_width, 2560) and art_ready(w)),
                (1920, 1080))
        elif art_ready(self.width) is None:
            # e.g. a 4K (3840) skin: prepare its artwork in the background and open now at the
            # nearest shipped size, so the receiver never freezes on first launch
            wanted = self.width
            worker = threading.Thread(target=ensure_art_for_width, args=(wanted,))
            worker.daemon = True
            worker.start()
            self.width, self.height = next(((w, h) for w, h in layout.SIZES if w <= wanted and art_ready(w)), (1920, 1080))
        self.art = ensure_art_for_width(self.width)
        self.asset_width = wanted_width
        self.asset_paths = (assetpacks.directory("photos"), assetpacks.directory("art-1440p"))
        try:
            from .portraits import remember_width
            remember_width(wanted_width)
        except Exception:
            pass
        self.skin = skin(self.width, self.height, self.art)
        Screen.__init__(self, session)
        self.text_size = load_text_size()
        self.home_order = homeorder.load()       # the user's own card order (MENU > ترتيب الكروت)
        self.home_shown = homeorder.DEFAULT      # the order actually drawn on screen right now
        self.home_art = {}
        self.arrange = None                      # {"from": slot or None} while rearranging the cards
        self.scale_art = False
        self.catalog = Catalog()
        self.favorites = load_favorites(self.catalog)
        self.stack = [Route("home")]
        self.mushaf_page = 1
        self.mushaf_mode = "image"
        self.mushaf_half = 0
        self.tafsir_sub = 0
        self.translation_sub = 0
        self.translation_subs = 1
        self.translation_layout = None
        self.repeat = False
        self.jump_buffer = None
        self.tasbih_counts = {}
        self.measured_durations = {}
        self.playing_items = None
        self.playing_index = None
        self.video_osd_visible = True
        self.youtube_lookup = None
        self._shown_widgets = set()
        self._widget_cache = {}
        self._text_pages = {}
        self.notice = Timer(self.hide_notice)
        self.jump_timer = Timer(self.commit_jump)
        self.portrait_timer = Timer(self.refresh_portraits)
        self.warm_timer = Timer(self.warm_portraits)
        self.download_timer = Timer(self.refresh_downloads)
        self.sync_timer = Timer(self.periodic_sync)
        self.video_osd_timer = Timer(self.auto_hide_video_osd)
        self.lib_timer = Timer(lambda: self.lib_turn(1, True))
        self.zina_timer = Timer(self.zina_tick)
        self.zina_frame = 1
        self.zina_on = None
        self.lib_page = 0
        self.lib_pages = 1
        self.lib_page_key = None
        self.portraits = PortraitManager(self.width, on_ready=self.schedule_portrait_refresh)
        self.lposters = LibraryPosters(self.width, on_ready=self.schedule_portrait_refresh)
        names = dict((entry[0], entry[1]) for entry in self.catalog.all_figures)
        names[999] = SHAARAWY_NAME
        self.portraits.names = names
        self.video_timer = Timer(self.refresh_videos)
        self.catalog.video_finder = VideoFinder(on_ready=self.schedule_video_refresh)
        self.downloader = DownloadManager(self.catalog, on_update=self.schedule_download_refresh)
        self.mushaf_timer = Timer(self.refresh_mushaf)
        self.update_timer = Timer(self.poll_update)
        self.mushaf = MushafManager(on_update=self.schedule_mushaf_refresh)
        self.mushaf.display_width = self.width
        self.mushaf_translation = MushafTranslation(self.mushaf.base_dir)
        self._init_mushaf_audio_prefs()
        self.audio = None
        self.dialog = None
        self.upd = None
        self._mini_hint_owner = False
        self.lib_durations = {}
        self.lib_route = None
        self.lib_indices = []
        self.bio_scroll = BioScroller(self, "bio_text")
        self.bio_open = False
        self.bio_timer = Timer(self.refresh_bio)
        self.wiki_bios = WikiBios(on_ready=self.schedule_bio_refresh)

        for name in IMAGES:
            self[name] = Pixmap()
        for name in LABELS:
            self[name] = Label()
        self["progress"] = Label("")
        self["progress_fill"] = Pixmap()
        self["top_track"] = Label("")
        self["top_fill"] = Pixmap()
        self._progress_value = 0.0
        self._progress_box = None

        actions = {
            "left": lambda: self.move("left"), "right": lambda: self.move("right"),
            "up": lambda: self.move("up"), "down": lambda: self.move("down"),
            "ok": self.accept, "cancel": self.back, "menu": self.translation_menu,
            "red": self.red, "yellow": self.yellow, "green": self.green, "blue": self.blue,
            "chplus": lambda: self.page_step(1), "chminus": lambda: self.page_step(-1),
            "nextBouquet": lambda: self.page_step(1), "prevBouquet": lambda: self.page_step(-1),
            "bouquet_up": lambda: self.page_step(1), "bouquet_down": lambda: self.page_step(-1),
            "pageUp": lambda: self.page_step(-1), "pageDown": lambda: self.page_step(1),
            "moveDown": lambda: self.page_step(1), "moveUp": lambda: self.page_step(-1),
        }
        for digit in range(10):
            actions[str(digit)] = lambda digit=digit: self.number(digit)
        self["navigation"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions", "NumberActions", "ChannelSelectBaseActions", "MenuActions"],
            {key: self.guard(fn, key) for key, fn in actions.items()}, -3)
        self["media"] = ActionMap(["InfobarSeekActions"], {
            "playpauseService": self.guard(self.play_control),
            "pauseService": self.guard(self.play_control),
        }, -2)
        self["media"].setEnabled(False)
        self["bio_keys"] = ActionMap(["EPGSelectActions", "InfobarEPGActions", "InfobarActions"], {
            "info": self.guard(self.toggle_bio), "showEventInfo": self.guard(self.toggle_bio),
            "showEventInfoPlugin": self.guard(self.toggle_bio), "epg": self.guard(self.toggle_bio),
        }, -2)
        self.onLayoutFinish.append(self.layout_finished)
        self.onClose.append(self.cleanup)

    @property
    def route(self):
        return self.stack[-1]

    @property
    def is_playing_view(self):
        return self.route.name in ("surahs", "radios", "favorites", "library", "shaarawy", "shaarawy_folders", "video", "mushaf")

    def guard(self, function, key=None):
        def call():
            try:
                if key is not None and getattr(self, "upd", None):
                    self.update_key(key)
                    return
                if key is not None and getattr(self, "dialog", None):
                    self.dialog_key(key)
                    return
                function()
            except Exception:
                log_exception("Interface action failed")
                self.flash(u"تعذّر تنفيذ الأمر")
            self._prefetch_focus()
        return call

    def _prefetch_focus(self):
        """Resolve, in the background, the link of the focused recording / video and of the next track, so
        OK (or the automatic next track) starts without waiting for the server's redirect."""
        try:
            route = self.route
            urls = []
            item = None
            items = route.items or []
            if items and 0 <= route.index < len(items):
                item = items[route.index]
                if route.name in ("surahs", "favorites") and isinstance(item, tuple) and item[0] is not None:
                    urls.append(self.catalog.track(item)[3])
                elif route.name in ("shaarawy", "library", "reciter_videos") and isinstance(item, dict):
                    if item.get("audio"):
                        urls.append(item.get("audio"))
                elif route.name == "video" and route.index + 1 < len(items):
                    urls.append(items[route.index + 1].get("audio"))
            playing = self.playing_items
            if playing and self.playing_index is not None and self.playing_index + 1 < len(playing):
                following = playing[self.playing_index + 1]
                if following[0] is not None:
                    urls.append(self.catalog.track(following)[3])
            for url in urls:
                if (url and not url.startswith("https://www.youtube.com/watch?v=")
                        and not (isinstance(item, dict) and item.get("live"))):
                    fastlink.prefetch(url)
        except Exception:
            pass

    def schedule_portrait_refresh(self):
        try:
            self.portrait_timer.start(150, True)
        except Exception:
            pass

    def refresh_portraits(self):
        if self.lposters.pop_ready() and self.route.name == "lgallery":
            self.render()
        ready = self.portraits.pop_ready()
        if ready and self.route.name in ("gallery", "editions", "shaarawy", "shaarawy_folders", "video", "surahs", "favorites",
                                          "reciter_hub", "reciter_videos"):
            self.render()

    def schedule_bio_refresh(self):
        try:
            self.bio_timer.start(200, True)
        except Exception:
            pass

    def refresh_bio(self):
        if self.route.name in BIO_VIEWS:
            self.render()

    def reciter_bio(self, reciter_id, name=None, shipped=None):
        """The shipped biography, replaced by the full Arabic Wikipedia one once the receiver has fetched it."""
        if shipped is None:
            shipped = self.catalog.bios.get(reciter_id)
        wiki = self.wiki_bios
        if wiki is None:
            return shipped
        if shipped and (shipped.get("nowiki") or len(shipped.get("summary") or u"") >= 300):
            return shipped      # verified full biography: a look-alike Wikipedia article must never replace it
        if name is None:
            name = self.catalog.reciter[reciter_id][1] if reciter_id in self.catalog.reciter else u""
        cached = wiki.get(reciter_id)
        if cached is None:
            wiki.request(reciter_id, name, shipped)
            return shipped
        merged = dict(shipped or {})
        for key in ("summary", "source", "url", "born"):
            if cached.get(key):
                merged[key] = cached[key]
        died, known = cached.get("died"), merged.get("died", u"")
        generic = (not known) or known.startswith((u"معتمد", u"حفظه"))
        if died and (died != u"حفظه الله" or generic):
            merged["died"] = died           # Wikidata has no death date: never overwrite a known one with "alive"
        return merged

    def schedule_video_refresh(self):
        try:
            self.video_timer.start(200, True)
        except Exception:
            pass

    def refresh_videos(self):
        """Background video discovery finished: refresh the hub / video list if the sheikh is on screen."""
        finder = self.catalog.video_finder
        ready = finder.pop_ready() if finder is not None else []
        route = self.route
        if not ready or route.name not in ("reciter_hub", "reciter_videos") or route.key not in ready:
            return
        if route.name == "reciter_hub":
            route.items = self.catalog.reciter_hub_folders(route.key)
        else:
            route.items = self.catalog.reciter_videos(route.key)
            route.index = max(0, min(route.index, len(route.items) - 1))
        self.render()

    def schedule_download_refresh(self):
        try:
            self.download_timer.start(150, True)
        except Exception:
            pass

    def refresh_downloads(self):
        self.downloader.pop_updated()
        if self.route.name == "favorites":
            self.route.items = self.offline_and_favorites_list()
            self.route.index = max(0, min(self.route.index, max(0, len(self.route.items) - 1)))
        if self.route.name in ("editions", "surahs", "favorites", "shaarawy", "library", "reciter_videos", "reciter_hub", "gallery"):
            self.render()

    def schedule_mushaf_refresh(self):
        try:
            self.mushaf_timer.start(180, True)
        except Exception:
            pass

    def refresh_mushaf(self):
        self.mushaf.pop_updated()
        if self.route.name == "mushaf":
            self.render()

    def offline_and_favorites_list(self):
        combined = list(self.favorites)
        seen = set(combined)
        for item in self.downloader.all_downloaded_entries():
            if item not in seen:
                seen.add(item)
                combined.append(item)
        return combined

    def periodic_sync(self):
        """Main-thread periodic check so background portrait/MP3/Mushaf downloads always update the OSD."""
        try:
            self.sync_asset_packs()
            self._finish_youtube_lookup()
            self.refresh_videos()
            ready = self.portraits.pop_ready()
            dl_updated = self.downloader.pop_updated()
            mushaf_updated = self.mushaf.pop_updated()
            if dl_updated and self.route.name == "favorites":
                self.route.items = self.offline_and_favorites_list()
                self.route.index = max(0, min(self.route.index, max(0, len(self.route.items) - 1)))
            if (ready and self.route.name in ("gallery", "editions", "shaarawy", "shaarawy_folders", "video", "surahs", "favorites",
                                              "reciter_hub", "reciter_videos")) or (
                dl_updated and self.route.name in ("editions", "surahs", "favorites", "shaarawy", "library", "reciter_videos", "reciter_hub", "gallery")
            ) or (mushaf_updated and self.route.name == "mushaf"):
                self.render()
            elif self.route.name == "home" and getattr(self, "dialog", None) is None:
                self.render_home_hero()            # the clock in the date capsule
            self._advance_text_pages()
        except Exception:
            pass
        finally:
            try:
                self.sync_timer.start(1200, True)
            except Exception:
                pass

    def sync_asset_packs(self):
        if not assetpacks.enabled():
            return
        assetpacks.schedule(self.asset_width)
        paths = (assetpacks.directory("photos"), assetpacks.directory("art-1440p"))
        if paths == self.asset_paths:
            return
        previous = self.asset_paths
        self.asset_paths = paths
        if paths[0] != previous[0]:
            names = self.portraits.names
            self.portraits = PortraitManager(self.width, on_ready=self.schedule_portrait_refresh)
            self.portraits.names = names
            self.lposters = LibraryPosters(self.width, on_ready=self.schedule_portrait_refresh)
        if not paths[1] and self.width == 2560:
            self.art = os.path.join(ROOT, "art", "1920")
            self.home_art.clear()
        elif paths[1] and self.width == 2560:
            self.art = os.path.join(paths[1], "art", "2560")
            self.home_art.clear()
        self.render()
        if paths[1] and not previous[1] and self.width < 2560 and self.route.name == "home":
            self.flash(u"واجهة الدقة العالية جاهزة · افتح البلجن من جديد لاستخدامها")

    WARM_IDS = [999, 950, 951, 952, 953, 954, 955, 956, 957, 958, 959, 960, 961, 962, 963, 964, 971, 972, 973, 974, 975, 976, 977, 978, 979, 980, 981, 982, 983, 984, 985, 986, 83, 245, 21203, 51, 112, 118, 241, 125, 121, 106, 9, 901, 902, 903, 904, 905, 906, 907, 908, 909, 910, 911, 912, 913, 914, 915, 916, 74, 54, 31, 102, 123, 30]

    def warm_portraits(self):
        """Prepare the first posters a moment after the screen is up (all disk / image work runs in a thread)."""
        try:
            self.portraits.request(self.WARM_IDS, background=True)
        except Exception:
            log_exception("Cannot warm the poster cache")

    def layout_finished(self):
        try:
            self._widget_cache.clear()
            self._shown_widgets.clear()
            self.warm_timer.start(2500, True)
            self.render()
            assetpacks.schedule(self.asset_width, now=True)
            if self.audio is None:
                self.audio = Audio(self.session.nav, self.update_player, self.track_ended)
            self.sync_timer.start(1200, True)
            from .updater import UPDATER, configured
            if configured() and UPDATER.state == "idle":
                UPDATER.check(manual=False)            # quiet check once per session
                self.update_timer.start(1000, False)
        except Exception:
            log_exception("Cannot initialize the Ultra Quran screen")
            self.close()

    def place(self, name, box):
        position = layout.scaled(box, self.width)
        if name in IMAGE_SET:
            # artwork is pre-scaled from its own size, so the widget must match it pixel for pixel
            position = position[:2] + layout.scaled((0, 0, box[2], box[3]), self.width)[2:]
        if self._widget_cache.get((name, "box")) != position:
            x, y, w, h = position
            self[name].instance.move(ePoint(x, y))
            self[name].instance.resize(eSize(w, h))
            self._widget_cache[(name, "box")] = position
        if name not in self._shown_widgets:
            self[name].show()
            self._shown_widgets.add(name)
        if name == "progress":
            self._progress_box = box
            self._place_fill()

    def hide_widget(self, name):
        if name in self._shown_widgets:
            self[name].hide()
            self._shown_widgets.remove(name)
        if name == "progress":
            self.hide_widget("progress_fill")

    def hide(self, name=None):
        """Enigma2 Screen.doClose() calls self.hide() with 0 args; widget hiding passes name."""
        if name is None:
            return Screen.hide(self)
        self.hide_widget(name)

    def text(self, name, value, box):
        # Enigma2 cannot place Arabic combining marks (harakat come out loose between the letters):
        # every label it draws gets the plain letters
        value = plain(value) if name not in MUSHAF_TRANSLATION_ROWS else value
        changed = self._widget_cache.get((name, "value")) != value
        if changed:
            self[name].setText(native(value))
            self._widget_cache[(name, "value")] = value
        if name in LABELS and name not in NO_FIT:
            box = self._tall_enough(name, box)
        self.place(name, box)
        if name in LABELS and name not in NO_FIT:
            self._fit(name, value, box)

    @staticmethod
    def _tall_enough(name, box):
        """A label lower than one line of its font is grown evenly up and down: the receiver draws a line that
        is taller than its label from the label's top (so it sat low and lost its bottom), not centred."""
        x, y, w, h = box
        line = int(LABELS[name][0] * LINE_HEIGHT + 0.999) + 2
        if h >= line:
            return box
        grow = line - h
        return (x, y - grow // 2, w, h + grow)

    def scaled_font(self, name):
        if name.startswith("ramadan_") or name == "footer_version":
            return LABELS[name][0]
        return (LABELS[name][0] * self.text_size + 50) // 100

    def _set_label_font(self, name, pixels):
        key = (name, "font_pixels")
        if gFont is not None and self._widget_cache.get(key) != pixels:
            self[name].instance.setFont(gFont("UltraQuranUI", pixels))
            self._widget_cache[key] = pixels

    def _fit(self, name, value, box):
        """Measure text in its real box. Page overflow when it would require an unreadably small font."""
        key = (value, tuple(box), self.text_size)
        if self._widget_cache.get((name, "fit")) == key:
            return
        self._widget_cache[(name, "fit")] = key
        self._text_pages.pop(name, None)
        try:
            instance = self[name].instance
            if instance is None or not value:
                return
            w, h = layout.scaled(box, self.width)[2:]
            base = LABELS[name][0]
            big = max(base, min(self.scaled_font(name), int((box[3] - 2) / LINE_HEIGHT)))
            normal_floor = FIT_FLOOR.get(name, base)
            floor = min(big, (normal_floor * self.text_size + 50) // 100) if gFont is not None else base
            for size in range(big, floor - 1, -1):
                pixels = max(6, layout.pixel(size, self.width))
                self._set_label_font(name, pixels)
                if self._fits_box(name, value, w, h, pixels):
                    return
            pages = self._paginate_label(name, value, w, h, pixels)
            self[name].setText(native(pages[0]))
            if len(pages) > 1:
                self._text_pages[name] = (pages, 0, text_clock() + TEXT_PAGE_SECONDS)
        except Exception:
            pass

    def _advance_text_pages(self):
        now = text_clock()
        for name in self._shown_widgets.intersection(self._text_pages):
            pages, index, next_at = self._text_pages[name]
            if now >= next_at:
                index = (index + 1) % len(pages)
                self[name].setText(native(pages[index]))
                self._text_pages[name] = (pages, index, now + TEXT_PAGE_SECONDS)

    def bio_text(self, value, box):
        """Sheikh biography box: the whole text, wrapped to the box; when it is longer than the box it rolls
        up slowly by itself (hold at the top, roll, hold at the end, back to the top), like Poster Grid 3."""
        source = plain(value or u"")
        key = (source, tuple(box), self.text_size)
        if self._widget_cache.get(("bio_text", "wrapped_for")) != key:
            self._set_label_font("bio_text", max(6, layout.pixel(self.scaled_font("bio_text"), self.width)))
            self._widget_cache[("bio_text", "wrapped")] = self.bio_scroll.wrap(source, box, BIO_CHARS * 100 // self.text_size)
            self._widget_cache[("bio_text", "wrapped_for")] = key
            self._widget_cache.pop(("bio_text", "value"), None)     # measuring changed the label's text
        lines = self._widget_cache[("bio_text", "wrapped")]
        self.text("bio_text", lines, box)
        self.bio_scroll.show(lines, box)

    def _fits_box(self, name, value, w, h, pixels):
        """True when the label's current text (value) wraps inside w x h with its current font."""
        widget = self[name]
        instance = widget.instance
        height_key = (name, "line_height", pixels)
        line = self._widget_cache.get(height_key)
        if line is None:
            widget.setText(native(u"ا"))
            line = self._widget_cache[height_key] = instance.calculateSize().height()
        widget.setText(native(value))
        need = instance.calculateSize()
        wide = need.width() + (text_width_pad(pixels) if need.width() else 0)
        return wide <= w + 1 and need.height() <= max(h, line) + 1

    def _paginate_label(self, name, value, w, h, pixels):
        """Fit successive parts at word boundaries, using a character split only for a very long word."""
        pages = []
        remainder = value.strip()
        while remainder:
            if self._fits_box(name, remainder, w, h, pixels):
                pages.append(remainder)
                break
            lo, hi = 1, len(remainder)
            while lo < hi:
                mid = (lo + hi + 1) // 2
                if self._fits_box(name, remainder[:mid].rstrip(), w, h, pixels):
                    lo = mid
                else:
                    hi = mid - 1
            if not remainder[lo:lo + 1].isspace():
                boundary = max(remainder.rfind(u" ", 0, lo + 1), remainder.rfind(u"\n", 0, lo + 1))
                if boundary > 0:
                    lo = boundary
            pages.append(remainder[:lo].rstrip())
            remainder = remainder[lo:].lstrip()
        return pages or [value]

    def play_marks(self, label, rect):
        """Two big gold chevrons on the card's bottom bar, hugging its text, for the item that is playing."""
        x, y, w, h = rect
        text_w = 90.0
        try:
            size = self[label].instance.calculateSize()
            measured = size.width() * 1920.0 / self.width
            if 4 < measured:
                text_w = min(w - 160, measured)
        except Exception:
            pass
        mw, mh, gap = layout.PMARK
        cx = x + w / 2.0
        right = int(min(cx + text_w / 2.0 + gap, x + w - mw - 34))
        left = int(max(cx - text_w / 2.0 - gap - mw, x + 34))
        top = int(y + (h - mh) / 2.0)
        self.image("pmark_r", "pmark-r", (right, top, mw, mh))
        self.image("pmark_l", "pmark-l", (left, top, mw, mh))
        self._pmark_owner = label

    def align_label(self, name, mode):
        """Runtime horizontal alignment of a label: 0 left, 1 centre, 2 right (ignored on images without setHAlign)."""
        if self._widget_cache.get((name, "halign")) == mode:
            return
        try:
            self[name].instance.setHAlign(mode)
            self._widget_cache[(name, "halign")] = mode
        except Exception:
            pass

    def image(self, name, key, box, external=False):
        path = key if external else os.path.join(self.art, key + ".png")
        self.place(name, box)
        if self._widget_cache.get((name, "value")) != path:
            instance = self[name].instance
            for method in ("setPixmapScale", "setScale"):
                scale = getattr(instance, method, None)
                if scale is not None:
                    try:
                        scale(1)
                        break
                    except Exception:
                        pass
            instance.setPixmapFromFile(native(path))
            self._widget_cache[(name, "value")] = path

    def reciter_card_image(self, widget_name, reciter_id, box):
        cached = self.portraits.cached_card_path(reciter_id)
        if cached:
            self.image(widget_name, cached, box, external=True)
            return
        self.portraits.request([reciter_id])
        fallback = self.portraits.fallback_card_path(reciter_id)
        if fallback:
            self.image(widget_name, fallback, box, external=True)
        else:
            self.image(widget_name, "grid3-reciter-default", box)

    def reciter_portrait_image(self, widget_name, reciter_id, box):
        cached = self.portraits.cached_portrait_path(reciter_id)
        if cached:
            self.image(widget_name, cached, box, external=True)
            return
        self.portraits.request([reciter_id])
        fallback = self.portraits.fallback_portrait_path(reciter_id)
        if fallback:
            self.image(widget_name, fallback, box, external=True)
        else:
            self.image(widget_name, "poster-default", box)

    def highlight(self, box, style, reciter_id=None):
        """The ONE focus pointer used everywhere: a thin warm-gold rounded outline (no glow, no colour changes)."""
        x, y, w, h = box
        m = layout.FOCUS_MARGIN
        self.image("focus", "focus-" + style, (x - m, y - m, w + 2 * m, h + 2 * m))

    def flash(self, value):
        self.text("notice", value, (480, 932, 960, 62))
        self.notice.start(3200)

    def hide_notice(self):
        self.hide_widget("notice")

    def open(self, route):
        self.cancel_jump()
        self.arrange = None
        self.bio_open = False
        self.stack.append(route)
        self.render()

    def render(self):
        route = self.route
        if not self._shown_widgets:
            for key in IMAGES + tuple(LABELS) + ("progress", "progress_fill", "top_track", "top_fill"):
                self[key].hide()
        previous = self._shown_widgets.copy()
        self._shown_widgets.clear()
        view = route.name
        self["media"].setEnabled(self.is_playing_view or self.mini_player_active())

        if view == "video":
            self.render_video()
            for key in previous - self._shown_widgets:
                self[key].hide()
            self.bio_scroll.stop()
            if self.video_osd_visible:
                Screen.show(self)
            else:
                Screen.hide(self)
            return
        Screen.show(self)

        background_file = None
        if view == "home":
            sections_page = route.index >= layout.HOME_PAGE_SIZE
            suffix = "-%d" % self.text_size if self.text_size != 100 else ""
            background = ("home-sections" if sections_page else "home-gallery") + suffix
            custom = self.home_pages(suffix)
            if custom:
                background_file = custom[1 if sections_page else 0]
        elif view in ("gallery", "editions", "shaarawy", "mushaf"):
            background = view
        elif view == "lgallery":
            background = "gallery-lib-folders" if self.gallery_has_downloads() else "gallery-lib"
        elif view == "main_folders":
            background = "portal"
        elif view == "reciter_hub":
            background = "hub"
        elif view == "mahmoud_hub":
            background = "hub-mahmoud"
        elif view == "reciter_videos":
            background = "reciter"
        elif view == "shaarawy_folders":
            background = "hub-sh" if (self.shaarawy_root() or self.shaarawy_audio_root()) else "shaarawy"
        elif view == "library":
            background = "library-youtube" if route.key in YOUTUBE_LIBRARIES else "library"
        elif view == "quiz":
            background = "quiz"
        else:
            background = "list"
        self.image("backdrop", "bg", (0, 0, 1920, 1080))      # one shared page backdrop under every screen
        if background_file:
            self.image("background", background_file, (0, 0, 1920, 1080), external=True)
        else:
            self.image("background", background, (0, 0, 1920, 1080))
        if view == "home":
            self.render_home_selection()
            self.render_zina()
        elif view == "main_folders":
            self.render_main_folders()
        elif view == "gallery":
            self.gallery()
        elif view == "lgallery":
            self.library_gallery()
        elif view == "reciter_hub":
            self.render_reciter_hub()
        elif view == "mahmoud_hub":
            self.render_mahmoud_hub()
        elif view == "editions":
            self.render_editions()
        elif view == "reciter_videos":
            self.render_reciter_videos()
        elif view == "shaarawy_folders":
            self.render_shaarawy_folders()
        elif view == "shaarawy":
            self.render_shaarawy()
        elif view in ("library", "quiz"):
            self.render_library()
        elif view == "mushaf":
            self.render_mushaf()
        else:
            self.render_list()
        if self.jump_buffer is not None:
            self.jump_label()
        if getattr(self, "dialog", None):
            self.draw_dialog()
        if getattr(self, "upd", None):
            self.draw_update()
        self.text("footer_version", u"V" + VERSION.replace("-test", "t"), layout.FOOTER_VERSION)
        self.render_ramadan_countdown()
        self.top_strip()
        if view != "home":
            self.zina_timer.stop()
        for key in previous - self._shown_widgets:
            self[key].hide()
        if "bio_text" not in self._shown_widgets:
            self.bio_scroll.stop()

    # ------------------------------------------------------------------ choice dialog
    DLG_WIDGETS = ("dlg", "dlg_row0", "dlg_row1", "dlg_row2", "dlg_focus", "dlg_title", "dlg_sub",
                   "dlg_opt0", "dlg_opt1", "dlg_opt2")
    MUSHAF_MENU_WIDGETS = (MUSHAF_MENU_ROW_IMAGES + ("mushaf_menu_panel",) + MUSHAF_MENU_LABELS
                           + tuple(name for pair in MUSHAF_MENU_OPTIONS for name in pair))

    def open_choice(self, title, sub, options, index=0, mushaf_panel=None):
        """Open a choice list, with a dedicated left panel for Mushaf controls."""
        options = list(options)
        if not mushaf_panel:
            options.append((u"إلغاء", None))
        index = max(0, min(int(index or 0), len(options) - 1))
        was_mushaf_panel = bool(self.dialog and self.dialog.get("mushaf_panel"))
        self.dialog = {"title": title, "sub": sub, "options": options, "index": index,
                       "start": 0, "mushaf_panel": mushaf_panel}
        if was_mushaf_panel != bool(mushaf_panel):
            self.render()
        else:
            self.draw_dialog()

    def draw_dialog(self):
        d = self.dialog
        if not d:
            return
        opts = d["options"]
        total = len(opts)
        vis = min(layout.MUSHAF_MENU_ROW_COUNT if d.get("mushaf_panel") else 3, total)
        start = d.get("start", 0)
        if d["index"] < start:
            start = d["index"]
        elif d["index"] >= start + vis:
            start = d["index"] - vis + 1
        start = max(0, min(start, max(0, total - vis)))
        d["start"] = start
        if d.get("mushaf_panel"):
            self.draw_mushaf_dialog(d, vis)
            return
        g = layout.dlg_geometry(vis)
        self.image("dlg", "dlg-%d" % vis, g["panel"])
        self.text("dlg_title", flat_text(plain(d["title"])), g["title"])
        sub_txt = d["sub"] or u""
        if total > 3:
            nav_txt = u"خيار %d من %d  ·  أعلى / أسفل للتنقل" % (d["index"] + 1, total)
            sub_txt = (sub_txt + u"  ·  " + nav_txt) if sub_txt else nav_txt
        if sub_txt:
            self.text("dlg_sub", flat_text(plain(sub_txt)), g["sub"])
        else:
            self.hide_widget("dlg_sub")
        for i in range(3):
            if i < vis:
                opt_idx = start + i
                self.image("dlg_row%d" % i, "dlg-row", g["rows"][i])
                self.text("dlg_opt%d" % i, flat_text(plain(opts[opt_idx][0])), g["rows"][i])
            else:
                self.hide_widget("dlg_row%d" % i)
                self.hide_widget("dlg_opt%d" % i)
        x, y, w, h = g["rows"][d["index"] - start]
        m = layout.FOCUS_MARGIN
        self.image("dlg_focus", "focus-dlg", (x - m, y - m, w + 2 * m, h + 2 * m))

    def draw_mushaf_dialog(self, dialog, visible):
        start = dialog["start"]
        options = dialog["options"]
        panel = dialog["mushaf_panel"]
        self.image("mushaf_menu_panel", "mushaf-menu-panel", layout.MUSHAF_PANEL_L)
        self.text("mushaf_menu_title", dialog["title"], layout.MUSHAF_MENU_TITLE)
        if dialog["sub"]:
            self.text("mushaf_menu_sub", dialog["sub"], layout.MUSHAF_MENU_SUB)
        else:
            self.hide_widget("mushaf_menu_sub")
        for slot, (row, names, box) in enumerate(zip(MUSHAF_MENU_ROW_IMAGES, MUSHAF_MENU_OPTIONS,
                                                      layout.MUSHAF_MENU_ROWS)):
            option, detail = names
            if slot >= visible:
                for name in (row, option, detail):
                    self.hide_widget(name)
                continue
            x, y, w, h = box
            title, _, secondary = options[start + slot][0].partition(u"\n")
            selected = start + slot == dialog["index"]
            asset = "mushaf-menu-selected" if selected else "mushaf-menu-row"
            self.image(row, asset, box)
            self.text(option, title, (x + 18, y + 1, w - 36, 43) if secondary else (x + 18, y, w - 36, h))
            if secondary:
                self.text(detail, secondary, (x + 18, y + 35, w - 36, 36))
            else:
                self.hide_widget(detail)
        menu_hint = u"رجوع للإغلاق"
        if panel != "main":
            menu_hint = u"MENU للقائمة  ·  " + menu_hint
        elif self.mushaf_audio_active():
            menu_hint = u"MENU للقرّاء  ·  " + menu_hint
        position = u"%d من %d  ·  " % (dialog["index"] + 1, len(options)) if len(options) > visible else u""
        self.text("mushaf_menu_status", position + u"أعلى وأسفل  ·  OK للاختيار", layout.MUSHAF_MENU_STATUS)
        self.text("mushaf_menu_hint", menu_hint, layout.MUSHAF_MENU_HINT)

    def close_dialog(self):
        was_mushaf_panel = self.dialog and self.dialog.get("mushaf_panel")
        self.dialog = None
        for name in self.MUSHAF_MENU_WIDGETS if was_mushaf_panel else self.DLG_WIDGETS:
            self.hide_widget(name)
        if was_mushaf_panel:
            self.render()

    def dialog_key(self, key):
        d = self.dialog
        total = len(d["options"])
        if key == "menu" and d.get("mushaf_panel"):
            self.translation_menu()
        elif key in ("up", "left", "chminus", "pageUp", "prevBouquet", "bouquet_down", "moveUp"):
            d["index"] = (d["index"] - 1) % total
            self.draw_dialog()
        elif key in ("down", "right", "chplus", "pageDown", "nextBouquet", "bouquet_up", "moveDown"):
            d["index"] = (d["index"] + 1) % total
            self.draw_dialog()
        elif key in ("ok", "green", "1", "2", "3"):
            if key in ("ok", "green"):
                index = d["index"]
            else:
                index = d.get("start", 0) + (int(key) - 1)
            if index >= total:
                return
            callback = d["options"][index][1]
            self.close_dialog()
            if callback is not None:
                callback()
        elif key in ("cancel", "red", "0", "exit"):
            self.close_dialog()

    def render_home_selection(self):
        index = self.route.index
        if index < layout.HOME_PAGE_SIZE:
            box = layout.HOME[index]
            hint = u"أسفل للصفحة التالية"
        else:
            box = layout.HOME_MORE[index - layout.HOME_PAGE_SIZE]
            hint = u"أعلى للصفحة الأولى" if index < layout.HOME_PAGE_SIZE + layout.HOME_COLUMNS else u"أعلى للصف السابق"
        self.highlight(box, "home")
        self.render_home_count_badges()
        self.text("home_page_hint", hint, layout.HOME_PAGE_HINT)
        self.text("home_text_size_hint", u"MENU · القائمة", layout.HOME_TEXT_SIZE_HINT)
        self.render_home_hero()
        picked = self.arrange.get("from") if self.arrange is not None else None
        if picked is not None and (picked < layout.HOME_PAGE_SIZE) == (index < layout.HOME_PAGE_SIZE):
            x, y, w, h = layout.HOME[picked] if picked < layout.HOME_PAGE_SIZE else layout.HOME_MORE[picked - layout.HOME_PAGE_SIZE]
            self.image("home_pick", "laser-364x10", (x - 7, y + h + 2, w + 14, 10))   # gold bar under the lifted card
        else:
            self.hide_widget("home_pick")
        if self.arrange is not None:
            if picked is None:
                message = u"ترتيب الكروت: اختار الكارت واضغط OK  ·  رجوع للإنهاء"
            else:
                message = u"«%s» ← اختار مكانه الجديد واضغط OK" % layout.HOME_TILES_META[self.home_shown[picked]][0]
            self.text("home_desc", message, layout.HOME_DESC)

    def draw_count_badge(self, widget, asset, card, inset):
        path = os.path.join(ROOT, "data", "card-counts", str(self.width), asset + ".png")
        x, y, w, h = inset
        self.image(widget, path, (card[0] + x, card[1] + y, w, h), external=True)

    def render_home_count_badges(self):
        first = self.route.index < layout.HOME_PAGE_SIZE
        boxes = layout.HOME if first else layout.HOME_MORE
        start = 0 if first else layout.HOME_PAGE_SIZE
        visible = self.home_shown[start:start + len(boxes)]
        for widget, section in zip(COUNT_BADGES, layout.HOME_COUNT_SECTIONS):
            if section in visible:
                asset = "home-%d-%d" % (section, self.text_size)
                self.draw_count_badge(widget, asset, boxes[visible.index(section)], layout.HOME_COUNT_INSET)
            else:
                self.hide_widget(widget)

    # ------------------------------------------------------------------ home card order
    def home_pages(self, suffix):
        """Custom-order home pictures for this screen + text size (None: the shipped default order)."""
        order = self.home_order
        if order == homeorder.DEFAULT:
            self.home_shown = order
            return None
        key = (self.art, self.width, suffix, order)
        pages = self.home_art.get(key)
        if key not in self.home_art or (pages and not all(os.path.isfile(path) for path in pages)):
            pages = homeorder.compose(self.art, self.width, suffix, order)
            self.home_art[key] = pages
        # if the pictures could not be made, the cards stay in their original places AND open what they show
        self.home_shown = order if pages else homeorder.DEFAULT
        return pages

    def open_home_menu(self):
        labels = dict(TEXT_SIZES)
        options = []
        if self.arrange is None:
            options.append((u"ترتيب أماكن الكروت", self.start_arrange))
        else:
            options.append((u"إنهاء الترتيب وحفظه", self.end_arrange))
        options.append((u"حجم الخط  ·  %s" % labels[self.text_size], self.open_text_size_menu))
        if self.home_order != homeorder.DEFAULT:
            options.append((u"رجوع للترتيب الأصلي", self.reset_home_order))
        self.open_choice(u"قائمة الرئيسية", u"حرّك أي كارت لأي مكان في القائمة", options)

    def start_arrange(self):
        if not homeorder.available():
            self.flash(u"ترتيب الكروت يحتاج مكتبة الصور (python-pillow)")
            return
        self.arrange = {"from": None}
        self.render()

    def end_arrange(self):
        self.arrange = None
        self.render()
        self.flash(u"تم حفظ ترتيب الكروت")

    def reset_home_order(self):
        self.arrange = None
        self.home_order = homeorder.DEFAULT
        homeorder.save(self.home_order)
        self.render()
        self.flash(u"رجعت الكروت لترتيبها الأصلي")

    def arrange_ok(self):
        index = self.route.index
        picked = self.arrange.get("from")
        if picked is None:
            self.arrange["from"] = index           # lift the card under the cursor
            self.render_home_selection()
            return
        self.arrange["from"] = None
        if picked == index:
            self.render_home_selection()
            return
        title = layout.HOME_TILES_META[self.home_shown[picked]][0]
        new_order = homeorder.move(self.home_shown, picked, index)
        self.home_order = new_order
        saved = homeorder.save(new_order)
        self.render()
        if self.home_shown != new_order:
            self.flash(u"تعذر رسم الترتيب الجديد على هذه الشاشة")
        elif not saved:
            self.flash(u"تم النقل للجلسة الحالية فقط (تعذر الحفظ)")
        else:
            self.flash(u"تم نقل «%s»" % title)

    def move_home(self, direction):
        route = self.route
        index = route.index
        first_size = layout.HOME_PAGE_SIZE
        columns = layout.HOME_COLUMNS
        last_row = first_size - columns
        if index >= first_size:
            slot = index - first_size
            if direction == "up" and slot < columns:
                self.home_first_page()
                return
            if direction == "down" and slot + columns >= len(layout.HOME_MORE):
                return
            route.index = first_size + grid_step(slot, len(layout.HOME_MORE), columns, direction)
        elif direction == "down" and index >= last_row:
            route.index = first_size + index - last_row
            self.render()
            return
        else:
            route.index = grid_step(index, first_size, columns, direction)
        if route.index != index:
            self.render_home_selection()

    def home_first_page(self):
        columns = layout.HOME_COLUMNS
        column = (self.route.index - layout.HOME_PAGE_SIZE) % columns
        self.route.index = layout.HOME_PAGE_SIZE - columns + column
        self.render()

    def open_quran_gallery(self, gallery):
        if gallery == "mubtahileen":
            title = u"موسوعة الابتهالات وكبار المبتهلين"
            people = self.catalog.mubtahileen
        else:
            title = u"قراء القرآن الكريم"
            people = self.catalog.reciters
        self.open(Route("gallery", people, key=gallery, folder_title=title))

    AYAT = None
    WEEKDAYS = (u"الاثنين", u"الثلاثاء", u"الأربعاء", u"الخميس", u"الجمعة", u"السبت", u"الأحد")

    def ayah_of_day(self):
        if UltraQuran.AYAT is None:
            try:
                from .support import data_json
                UltraQuran.AYAT = data_json("ayat.json")
            except Exception:
                UltraQuran.AYAT = [[u"إن هذا القرآن يهدي للتي هي أقوم", u"الإسراء", 9]]
        import datetime
        ayat = UltraQuran.AYAT
        now = datetime.datetime.now()
        # a new ayah every two hours (12 a day), never the same one two slots in a row
        return ayat[(now.date().toordinal() * 12 + now.hour // 2) % len(ayat)]

    def draw_ayah(self, text):
        """Short ayah: one big line. Longer ayah: two balanced lines, each its own label, both the same size,
        closer together than the font's own line height, centred between the caption and the surah line."""
        lines = ayah_lines(text).split(u"\n")
        box = layout.HOME_AYAH
        if len(lines) == 1 or gFont is None:
            self.hide_widget("home_ayah2")
            self.text("home_ayah", u"\n".join(lines), box)
            return
        x, y, w, h = box
        names = ("home_ayah", "home_ayah2")
        size = self._ayah_size(lines, box)
        line_h = int(size * LINE_HEIGHT + 0.999) + 2
        pitch = size * AYAH_PITCH
        mid = y + h / 2.0
        for i, name in enumerate(names):
            top = int(round(mid + (i - 0.5) * pitch - line_h / 2.0))
            value = lines[i]
            if self._widget_cache.get((name, "value")) != value or self._widget_cache.get((name, "size")) != size:
                try:
                    self._set_label_font(name, layout.pixel(size, self.width))
                except Exception:
                    pass
                self[name].setText(native(plain(value)))
                self._widget_cache[(name, "value")] = value
                self._widget_cache[(name, "size")] = size
                self._widget_cache.pop((name, "fit"), None)
            self.place(name, (x, top, w, line_h))

    def _ayah_size(self, lines, box):
        """Largest size (AYAH_TWO_MAX down to the floor) at which BOTH lines stay on one line in the box width."""
        key = (tuple(lines), self.width, self.text_size)
        if self._widget_cache.get(("ayah_size", "for")) == key:
            return self._widget_cache[("ayah_size", "value")]
        floor = FIT_FLOOR.get("home_ayah", 19)
        maximum = min((AYAH_TWO_MAX * self.text_size + 50) // 100,
                      int((box[3] + 10) / (LINE_HEIGHT + AYAH_PITCH)))
        maximum = max(AYAH_TWO_MAX, maximum)
        size = floor
        try:
            name = "home_ayah2"
            w = layout.scaled(box, self.width)[2]
            self.place(name, (box[0], box[1], box[2], int(maximum * LINE_HEIGHT) + 2))
            for candidate in range(maximum, floor - 1, -1):
                pixels = layout.pixel(candidate, self.width)
                self._set_label_font(name, pixels)
                if all(self._fits_box(name, plain(line), w, 0, pixels) for line in lines):
                    size = candidate
                    break
        except Exception:
            pass
        self._widget_cache.pop(("home_ayah2", "value"), None)      # measuring changed the label
        self._widget_cache[("ayah_size", "for")] = key
        self._widget_cache[("ayah_size", "value")] = size
        return size

    # ------------------------------------------------------------------ Ramadan decoration (home)
    ZINA_SPOTS = (65, 689, 1275, 1852)      # the gaps between the hero's inner cards (1080p master)
    ZINA_SWING = (1, 2, 1, 0)                 # frames: 0 leans one way, 1 hangs straight, 2 leans the other way

    def zina_dir(self):
        path = os.path.join(ROOT, "zina", str(self.width))
        return path if os.path.isdir(path) else None

    def render_zina(self):
        """A bunting rope over the hero's top edge and four lanterns in the gaps between its cards, from three
        months before Ramadan to the third day of Eid. The lanterns sway slowly (one small picture each per tick)."""
        import datetime
        today = datetime.date.today()
        if self.zina_on is None or self.zina_on[0] != today:
            try:
                self.zina_on = (today, zina_season(today))
            except (ValueError, IndexError):
                self.zina_on = (today, False)
        folder = self.zina_dir()
        if not self.zina_on[1] or folder is None:
            self.zina_timer.stop()
            return
        self.image("zina_rope", os.path.join(folder, "rope.png"), (53, 76, 1814, 26), external=True)
        self.draw_zina_lanterns(folder)
        self.zina_timer.start(1100, False)

    def draw_zina_lanterns(self, folder):
        for index, spot in enumerate(self.ZINA_SPOTS):
            frame = self.ZINA_SWING[(self.zina_frame + index) % len(self.ZINA_SWING)]
            self.image("zina_l%d" % index, os.path.join(folder, "lan%d-%d.png" % (index, frame)), (spot - 15, 80, 30, 70), external=True)

    def zina_tick(self):
        if self.route.name != "home" or "zina_rope" not in self._shown_widgets:
            self.zina_timer.stop()
            return
        folder = self.zina_dir()
        if folder is None:
            return
        self.zina_frame = (self.zina_frame + 1) % len(self.ZINA_SWING)
        try:
            self.draw_zina_lanterns(folder)
        except Exception:
            self.zina_timer.stop()

    def render_ramadan_countdown(self, date=None):
        """Footer chip: caption, digits and unit are baked images (plugin font, old label colours, centred on the
        chip's middle line), so nothing sits high or low whatever the receiver's text renderer does."""
        if date is None:
            import datetime
            date = datetime.date.today()
        days, ramadan_day = ramadan_countdown(date)
        if ramadan_day is not None:
            caption, number, unit = "today", ramadan_day, None
        else:
            caption, number = "wait", days
            unit = "ayyam" if 3 <= days <= 10 else "yawm" if days <= 2 else "yawman"
        self.image("rchip", "rchip-fanous", layout.HOME_RAMADAN_CHIP)
        if self.route.name in ("home", "gallery") or (self.route.name == "lgallery" and not self.gallery_has_downloads()):
            self.hide_widget("rnav")
        else:
            nav = "rchip-nav-mushaf" if self.route.name == "mushaf" else "rchip-nav"
            self.image("rnav", nav, layout.HOME_RAMADAN_NAV)
        self.image("rcap", "rtxt-" + caption, layout.HOME_RAMADAN_CAPTION)
        if unit:
            self.image("runit", "rtxt-" + unit, layout.HOME_RAMADAN_UNIT)
        else:
            self.hide_widget("runit")
        digits = [int(digit) for digit in str(max(0, int(number)))][:3]
        face = "rnums" if len(digits) > 2 else "rnum"
        widths = [layout.RAMADAN_DIGIT_W[face][digit] for digit in digits]
        center = layout.RAMADAN_MEDAL_CX if unit else layout.RAMADAN_TODAY_CX
        x = center - sum(widths) // 2
        top, height = layout.RAMADAN_DIGIT_Y
        for index in range(3):
            name = "rdig%d" % index
            if index < len(digits):
                self.image(name, "%s-%d" % (face, digits[index]), (x, top, widths[index], height))
                x += widths[index]
            else:
                self.hide_widget(name)

    def render_home_hero(self):
        """Ayah of the day, continue listening, Hijri date + clock, and a line about the focused section."""
        if self.route.name != "home":
            return
        import datetime
        text, surah, number = self.ayah_of_day()
        # no ornate brackets: the receiver mirrors them to the wrong end of an Arabic line
        self.draw_ayah(text)
        self.text("home_ayah_ref", u"سورة %s  ·  الآية %d" % (surah, number), layout.HOME_AYAH_REF)
        now = datetime.datetime.now()
        today = now.date()
        try:
            hijri = hijri_today(today)
        except (ValueError, IndexError):
            hijri = u""
        self.text("home_clock", u"%02d:%02d" % (now.hour, now.minute), layout.HOME_CLOCK)
        self.text("home_date", u"%s  %s" % (self.WEEKDAYS[now.weekday()], hijri), layout.HOME_DATE)
        self.render_ramadan_countdown(today)
        section = self.home_shown[self.route.index]
        description = layout.HOME_TILES_DESC[section]
        if section == 0:
            description = description % len(self.catalog.reciters)
        elif section == 16:
            seasons = self.catalog.libraries[16]["items"]
            description = description % sum(len(season.get("children", ())) for season in seasons)
        self.text("home_desc", description, layout.HOME_DESC)
        audio = self.audio
        if self.mini_player_active():
            entry = self.playing_items[self.playing_index]
            title = self.catalog.track(entry)[0]
            self.text("home_resume_cap", u"يُشغَّل الآن", layout.HOME_RESUME_CAP)
            self.text("home_resume_title", plain(strip_duration(title)), layout.HOME_RESUME_TITLE)
            total = audio.total()
            when = u"%s / %s" % (self.duration(audio.shown_position()), self.duration(total)) if total > 0 else u"بث مباشر" if audio.live else u""
            who = plain(self.playing_who(entry))
            self.text("home_resume_sub", who or when, layout.HOME_RESUME_SUB)
            hint = u"زر التشغيل: إيقاف واستئناف"
            self.text("home_resume_hint", (when + u"  ·  " + hint) if (who and when) else hint, layout.HOME_RESUME_HINT)
            return
        last = None
        try:
            from .player import RESUME
            last = RESUME.latest()
        except Exception:
            last = None
        if last:
            url, seconds, title, total, who = last
            self.text("home_resume_cap", u"كمّل الاستماع", layout.HOME_RESUME_CAP)
            self.text("home_resume_title", plain(strip_duration(title)), layout.HOME_RESUME_TITLE)
            at = self.duration(int(seconds * PTS))
            when = (u"توقفت عند %s من %s" % (at, self.duration(int(total * PTS)))) if total else u"توقفت عند %s" % at
            if who:
                self.text("home_resume_sub", plain(who), layout.HOME_RESUME_SUB)
                self.text("home_resume_hint", when + u"  ·  الأخضر للاستكمال", layout.HOME_RESUME_HINT)
            else:
                self.text("home_resume_sub", when, layout.HOME_RESUME_SUB)
                self.text("home_resume_hint", u"الزر الأخضر: كمّل من حيث توقفت", layout.HOME_RESUME_HINT)
        else:
            self.text("home_resume_cap", u"ابدأ الاستماع", layout.HOME_RESUME_CAP)
            self.text("home_resume_title", u"اختر قسماً وابدأ", layout.HOME_RESUME_TITLE)
            self.text("home_resume_sub", u"كل ما تسمعه يُحفظ مكانه", layout.HOME_RESUME_SUB)
            self.hide_widget("home_resume_hint")

    def playing_who(self, entry):
        """Who is heard: the reciter / munshid for Quran editions, the folder or section for library media."""
        try:
            if entry[0] is None:
                return u"إذاعة القرآن الكريم"
            who = self.catalog.track(entry)[1] or u""
            if isinstance(entry[0], int) and who and not who.startswith((u"الشيخ", u"القارئ", u"فضيلة", u"د.")):
                who = u"الشيخ " + who
            return who
        except Exception:
            return u""

    def resume_last(self):
        """Green on home: continue the most recent unfinished recording where it stopped."""
        try:
            from .player import RESUME
            last = RESUME.latest()
        except Exception:
            last = None
        if not last:
            self.flash(u"لا يوجد شيء لاستكماله بعد")
            return
        url, seconds, title, total, who = last
        play_url = self.downloader.local_media_path(url, is_video=False) or url
        self.playing_items = [("lib", (title, who or u"استكمال الاستماع", u"صوتي", url))]
        self.playing_index = 0
        self.lib_durations = {url: total}
        self.lib_route = None
        self.lib_indices = []
        self.audio.play(title, play_url, False, total, who=who)
        self.render()

    def render_main_folders(self):
        """Quran portal: four tall folder cards (everything is baked into the card art)."""
        route = self.route
        folders = route.items or self.catalog.main_portal_folders()
        route.items = folders
        for i, folder in enumerate(folders[:4]):
            self.image("ecard%d" % i, "portal-%d" % i, layout.PORTAL_CARDS[i])
            if i < 3:
                self.draw_count_badge(COUNT_BADGES[i], "portal-%d" % i,
                                      layout.PORTAL_CARDS[i], layout.PORTAL_COUNT_INSET)
        if folders:
            self.highlight(layout.PORTAL_CARDS[min(route.index, 3)], "portal")

    def _update_gallery_counter(self):
        """Show the page and item counts next to the title in the top bar."""
        route = self.route
        size = layout.POSTER_PAGE_SIZE
        pages = max(1, (len(route.items) + size - 1) // size)
        self.text("gallery_page", u"صفحة %d من %d  ·  %d من %d" % (route.index // size + 1, pages, route.index + 1,
                                                                   len(route.items)), layout.GALLERY_PAGE)

    def gallery(self):
        route = self.route
        page_size = layout.POSTER_PAGE_SIZE
        start = (route.index // page_size) * page_size
        page_items = route.items[start:start + page_size]
        visible_ids = []
        for i, (reciter_id, name, _) in enumerate(page_items):
            x, y, w, h = layout.POSTERS[i]
            self.reciter_card_image("poster%d" % i, reciter_id, (x, y, w, h))
            self.text("card%d" % i, flat_text(name), (x + 8, y + h - layout.POSTER_PLATE + 4, w - 16, layout.POSTER_PLATE - 8))
            visible_ids.append(reciter_id)
        self.portraits.request(visible_ids)
        focused = route.items[route.index][0]
        self.highlight(layout.POSTERS[route.index - start], "poster", reciter_id=focused)
        self._update_gallery_counter()

    def library_gallery(self):
        """Encyclopedia section shown like the sheikhs' gallery: one poster card per series / programme /
        preacher, the name on the card's plate."""
        route = self.route
        page_size = layout.POSTER_PAGE_SIZE
        start = (route.index // page_size) * page_size
        names = []
        for i, item in enumerate(route.items[start:start + page_size]):
            x, y, w, h = layout.POSTERS[i]
            name = item.get("poster")
            names.append(name)
            path = self.lposters.card_path(name)
            if path:
                self.image("poster%d" % i, path, (x, y, w, h), external=True)
            else:
                self.image("poster%d" % i, "lposter-default", (x, y, w, h))
            title = item["title"].split(u" · ")[0] if len(item["title"]) > 26 else item["title"]
            self.text("card%d" % i, flat_text(title), (x + 8, y + h - layout.POSTER_PLATE + 4, w - 16,
                                                         layout.POSTER_PLATE - 8))
        self.lposters.request(names)
        self.highlight(layout.POSTERS[route.index - start], "poster")
        self._update_gallery_counter()

    def gallery_has_downloads(self):
        return self.route.name == "lgallery" and self.route.key in (1, 24, MAHMOUD_VIDEO_OWNER)

    def _update_reciter_bio_panel(self, reciter_id):
        bio = self.reciter_bio(reciter_id)
        if self.bio_open:
            name = self.catalog.reciter[reciter_id][1] if reciter_id in self.catalog.reciter else u""
            self.draw_bio_full(name, bio or {}, living_label=u"الحالة / الوفاة")
            return
        if reciter_id == 950:
            heading = u"السيرة الذاتية لفارس المنابر"
        elif is_mubtahil(reciter_id):
            heading = u"السيرة الذاتية للمبتهل"
        else:
            heading = u"السيرة الذاتية للقارئ"
        self.text("bio_heading", heading, layout.EDITIONS_BIO_HEADING)
        if bio:
            self.text("bio_born", u"الميلاد والنشأة\n" + bio.get("born", u"—"), layout.EDITIONS_BIO_BORN)
            if bio.get("died"):
                self.text("bio_died", u"الحالة / الوفاة\n" + bio["died"], layout.EDITIONS_BIO_DIED)
            else:
                self.text("bio_died", u"الحالة\nأطال الله في عمره", layout.EDITIONS_BIO_DIED)
            self.bio_text(bio.get("summary", u""), layout.EDITIONS_BIO_TEXT)
            self.text("bio_source", flat_text(u"المصدر · " + bio.get("source", u"الهيئة العامة للاستعلامات")), layout.EDITIONS_BIO_SOURCE)

    def render_mahmoud_hub(self):
        section = self.catalog.libraries[MAHMOUD_LIBRARY]
        bio = section["bio"]
        self.render_deck(MAHMOUD_NAME, u"اختر المكتبة  ·  الصوتيات أو الفيديو",
                         ["deck-mahmoud-audio", "deck-mahmoud-video"],
                         [u"%d تسجيلًا" % section["audio_count"], u"%d حلقة" % section["video_count"]])
        if self.bio_open:
            self.draw_bio_full(MAHMOUD_NAME, bio, living_label=u"الوفاة")
        else:
            self.image("poster0", "portrait-mahmoud", layout.EDITIONS_POSTER)
            x, y, w, h = layout.EDITIONS_POSTER
            self.text("card0", MAHMOUD_NAME, (x + 8, y + h - 76, w - 16, 73))
            self.text("bio_recordings", u"%d فيديو" % section["video_count"], layout.EDITIONS_BADGE_REC)
            self.text("bio_riwayas", u"%d تسجيل صوتي" % section["audio_count"], layout.EDITIONS_BADGE_RIW)
            self.text("bio_heading", u"السيرة الذاتية", layout.EDITIONS_BIO_HEADING)
            self.text("bio_born", u"الميلاد والنشأة\n" + bio["born"], layout.EDITIONS_BIO_BORN)
            self.text("bio_died", u"الوفاة\n" + bio["died"], layout.EDITIONS_BIO_DIED)
            self.bio_text(bio["summary"], layout.EDITIONS_BIO_TEXT)
            self.text("bio_source", u"الأصفر لتوسيع السيرة الذاتية", layout.EDITIONS_BIO_SOURCE)

    def render_reciter_hub(self):
        """Show the audio, archive and available YouTube collections for this sheikh."""
        route = self.route
        reciter_id = route.key
        reciter = self.catalog.reciter[reciter_id]
        reciter_name = reciter[1]
        recordings = reciter[2]
        self.catalog.request_reciter_videos(reciter_id)
        videos = self.catalog.reciter_videos(reciter_id)
        folders = self.catalog.reciter_hub_folders(reciter_id)
        route.items = folders

        px, py, pw, ph = layout.EDITIONS_POSTER
        self.reciter_card_image("poster0", reciter_id, layout.EDITIONS_POSTER)
        self.text("card0", flat_text(reciter_name), (px + 8, py + ph - 76, pw - 16, 73))
        self.portraits.request([reciter_id])

        state = self.catalog.reciter_videos_state(reciter_id)
        total = sum(len(ed[3]) for ed in recordings)
        if reciter_id == 950:
            kind = "kishk"
            self.text("bio_recordings", u"%d خطبة صوتية" % total, layout.EDITIONS_BADGE_REC)
            self.text("bio_riwayas", u"%d خطبة مرئية" % len(videos) if videos else u"الخطب المصورة", layout.EDITIONS_BADGE_RIW)
            hub_title = u"فارس المنابر  ·  " + reciter_name
            hub_sub = u"اختر المكتبة  ·  الخطب الصوتية أو الخطب المصوّرة"
            audio_badge = u"الخطب: %d" % total
        elif is_mubtahil(reciter_id):
            kind = "mub"
            self.text("bio_recordings", u"%d ابتهال صوتي" % total, layout.EDITIONS_BADGE_REC)
            self.text("bio_riwayas", u"%d فيديو" % len(videos) if videos else u"المكتبة المرئية", layout.EDITIONS_BADGE_RIW)
            hub_title = u"فضيلة المبتهل  ·  " + reciter_name
            hub_sub = u"اختر المكتبة  ·  الابتهالات والتواشيح الصوتية أو الحفلات المرئية"
            audio_badge = u"الابتهالات: %d" % total
        else:
            kind = "rec"
            self.text("bio_recordings", u"%d تسجيل صوتي" % len(recordings), layout.EDITIONS_BADGE_REC)
            self.text("bio_riwayas", u"%d فيديو" % len(videos) if videos else u"المكتبة المرئية", layout.EDITIONS_BADGE_RIW)
            hub_title = (u"فضيلة " if reciter_name.startswith(u"الشيخ") else u"فضيلة الشيخ ") + reciter_name
            hub_sub = u"اختر المكتبة  ·  المكتبة الصوتية أو المكتبة المرئية"
            audio_badge = u"المصاحف والتسجيلات: %d" % len(recordings)
        if state == "ready":
            video_badge = u"الفيديوهات: %d" % len(videos)
        elif state == "searching":
            video_badge = u"جارٍ البحث…"
        elif state == "offline":
            video_badge = u"تعذّر الاتصال"
        else:
            video_badge = u"لا توجد فيديوهات بعد"
        arts = ["deck-%s-audio" % kind, "deck-%s-video" % kind]
        badges = [audio_badge, video_badge]
        if len(folders) > 2:
            hub_sub = u"المكتبة الصوتية والأرشيف المرئي وتسجيلات يوتيوب"
            arts.append("deck-youtube")
            badges.append(folders[-1]["badge"])
        self._update_reciter_bio_panel(reciter_id)
        self.render_deck(hub_title, hub_sub, arts, badges)

    def deck_size(self):
        """Number of tall folder cards when the current screen is a folder deck, else 0."""
        route = self.route
        if route.name == "reciter_hub":
            return len(route.items)
        if route.name == "mahmoud_hub":
            return 2
        if route.name == "shaarawy_folders":
            if self.shaarawy_root():
                return 2
            if self.shaarawy_audio_root():
                return min(4, len(route.items))
        return 0

    def deck_window(self, n):
        """First visible card index: the focused card always stays inside the three visible slots."""
        route = self.route
        visible = min(layout.DECK_VISIBLE, n)
        start = getattr(route, "deck_start", 0)
        if route.index < start:
            start = route.index
        elif route.index >= start + visible:
            start = route.index - visible + 1
        start = max(0, min(start, n - visible))
        route.deck_start = start
        return start, visible

    def render_deck(self, title, sub, arts, badges):
        """Tall glass folder cards beside the poster / biography tower (3 visible, the rest slide in)."""
        route = self.route
        n = len(arts)
        route.index = max(0, min(route.index, n - 1))
        start, visible = self.deck_window(n)
        boxes = layout.deck_cards(visible)
        if n > visible:
            hidden = n - visible
            sub = u"%s  ·  %s" % (sub, u"بالسهم لعرض فولدر آخر" if hidden == 1 else u"بالسهم لعرض %d فولدرات أخرى" % hidden)
        self.text("title", flat_text(title), layout.EDITIONS_TITLE)
        self.text("sub", flat_text(sub), layout.EDITIONS_SUB)
        bx, by, bw, bh = layout.DECK_BADGE
        for slot in range(visible):
            i = start + slot
            x, y, w, h = boxes[slot]
            self.image("ecard%d" % slot, arts[i], boxes[slot])
            if badges[i]:
                self.text("deck_badge%d" % slot, flat_text(badges[i]), (x + bx, y + by, bw, bh))
        self.highlight(boxes[route.index - start], "deck")

    def render_reciter_videos(self):
        """Rare Video Recitations Library for the Sheikh."""
        route = self.route
        reciter_id = route.key
        reciter = self.catalog.reciter[reciter_id]
        reciter_name = reciter[1]
        videos = route.items
        state = self.catalog.reciter_videos_state(reciter_id)

        px, py, pw, ph = layout.EDITIONS_POSTER
        self.reciter_card_image("poster0", reciter_id, layout.EDITIONS_POSTER)
        self.text("card0", flat_text(reciter_name), (px + 8, py + ph - 76, pw - 16, 73))
        self.portraits.request([reciter_id])

        self.text("bio_recordings", u"%d فيديو" % len(videos), layout.EDITIONS_BADGE_REC)
        self.text("bio_riwayas", u"أرشيف الإنترنت", layout.EDITIONS_BADGE_RIW)
        self._update_reciter_bio_panel(reciter_id)

        self.text("title", flat_text(u"المكتبة المرئية  ·  " + reciter_name), layout.EDITIONS_TITLE)
        page_size = layout.ECARD_PAGE_SIZE
        start = (route.index // page_size) * page_size
        total_pages = max(1, (len(videos) + page_size - 1) // page_size)
        self.text("sub", u"صفحة %d من %d  ·  %d فيديو مرئي  ·  الأحمر أو رجوع: العودة" % (
            start // page_size + 1, total_pages, len(videos)
        ), layout.EDITIONS_SUB)
        if not videos:
            messages = {
                "searching": (u"جارٍ البحث عن فيديوهات الشيخ…", u"البحث في أرشيف الإنترنت · انتظر لحظات"),
                "offline": (u"تعذّر الاتصال بأرشيف الإنترنت", u"تحقق من الشبكة ثم ارجع وافتح المكتبة مرة أخرى"),
                "empty": (u"لا توجد فيديوهات موثّقة للشيخ حالياً", u"تُضاف أولاً بأول مع تحديثات البلجن"),
            }
            title, hint = messages.get(state, messages["empty"])
            x, y, w, h = layout.ECARDS[0]
            parts = layout.card_parts("ecard", (x, y, w, h))
            self.image("ecard0", "ecard-bg", (x, y, w, h))
            self.text("ecard_num0", u"—", parts["num"])
            self.text("ecard_title0", title, parts["title"])
            self.text("ecard_meta0", hint, parts["meta"])
            return

        visible = videos[start:start + page_size]
        for i, item in enumerate(visible):
            x, y, w, h = layout.ECARDS[i]
            parts = layout.card_parts("ecard", (x, y, w, h))
            idx = start + i
            self.image("ecard%d" % i, "ecard-bg", (x, y, w, h))
            self.text("ecard_num%d" % i, "%02d" % (idx + 1), parts["num"])
            self.text("ecard_title%d" % i, flat_text(item["title"]), parts["title"])
            meta = item.get("badge", u"فيديو مرئي")
            if item.get("duration") and item["duration"] not in meta:
                meta += u"  ·  %s" % item["duration"]
            if self.downloader.is_media_downloaded(item.get("audio"), is_video=True):
                meta = u"• محمّل بدون نت  ·  " + meta
            elif self.downloader.is_media_queued(item.get("audio")):
                meta = u"• جارٍ التحميل  ·  " + meta
            self.text("ecard_meta%d" % i, flat_text(meta), parts["meta"])
        if videos:
            self.highlight(layout.ECARDS[route.index - start], "ecard")

    def render_editions(self):
        route = self.route
        reciter_id = route.key
        reciter_name = self.catalog.reciter[reciter_id][1]
        recordings = route.items

        px, py, pw, ph = layout.EDITIONS_POSTER
        self.reciter_card_image("poster0", reciter_id, layout.EDITIONS_POSTER)
        self.text("card0", flat_text(reciter_name), (px + 8, py + ph - 76, pw - 16, 73))
        self.portraits.request([reciter_id])

        total_items = sum(len(e[3]) for e in recordings)
        if reciter_id == 950:
            self.text("bio_recordings", u"%d مصنفات" % len(recordings), layout.EDITIONS_BADGE_REC)
            self.text("bio_riwayas", u"%d خطبة" % total_items, layout.EDITIONS_BADGE_RIW)
            ed_heading = u"فولدرات ومصنفات خطب الشيخ عبد الحميد كشك"
            sub_line = u"%s  ·  %d مصنفات تضم %d خطبة ومحاضرة صوتية" % (reciter_name, len(recordings), total_items)
            item_unit = u"خطبة"
        elif is_mubtahil(reciter_id):
            self.text("bio_recordings", u"%d مصنفات" % len(recordings), layout.EDITIONS_BADGE_REC)
            self.text("bio_riwayas", u"%d ابتهال" % total_items, layout.EDITIONS_BADGE_RIW)
            ed_heading = u"فولدرات الابتهالات والتواشيح الصوتية"
            sub_line = u"%s  ·  %d مصنفات تضم %d ابتهالاً وتوشيحاً" % (reciter_name, len(recordings), total_items)
            item_unit = u"ابتهال"
        else:
            self.text("bio_recordings", u"%d تسجيل" % len(recordings), layout.EDITIONS_BADGE_REC)
            self.text("bio_riwayas", u"%d رواية" % self.catalog.riwayas(recordings), layout.EDITIONS_BADGE_RIW)
            ed_heading = u"الروايات والتسجيلات"
            sub_line = u"%s  ·  %d رواية ومصدر صوتي" % (reciter_name, len(recordings))
            item_unit = u"سورة"

        self._update_reciter_bio_panel(reciter_id)
        self.text("title", ed_heading, layout.EDITIONS_TITLE)
        dl_msg = self.downloader.status_text()
        if dl_msg:
            sub_line += u"   ·   " + dl_msg
        self.text("sub", flat_text(sub_line), layout.EDITIONS_SUB)

        page_size = layout.ECARD_PAGE_SIZE
        start = (route.index // page_size) * page_size
        visible = recordings[start:start + page_size]
        for i, edition in enumerate(visible):
            x, y, w, h = layout.ECARDS[i]
            parts = layout.card_parts("ecard", (x, y, w, h))
            ed_id = edition[0]
            self.image("ecard%d" % i, "ecard-bg", (x, y, w, h))
            self.text("ecard_num%d" % i, "%02d" % (start + i + 1), parts["num"])
            self.text("ecard_title%d" % i, flat_text(edition[1]), parts["title"])
            src_name = self.catalog.source_label(edition[2])
            dl_cnt = self.downloader.downloaded_count(ed_id)
            unit_txt = item_unit
            if item_unit == u"سورة" and self.catalog.is_custom_edition(ed_id):
                unit_txt = u"تلاوة"
            meta_txt = u"%d %s  ·  %s" % (len(edition[3]), unit_txt, src_name)
            if dl_cnt > 0:
                meta_txt += u"  ·  %d محمّلة" % dl_cnt
            self.text("ecard_meta%d" % i, flat_text(meta_txt), parts["meta"])
        self.highlight(layout.ECARDS[route.index - start], "ecard")

    def _update_shaarawy_folders_bio_panel(self):
        """Left panel while browsing Shaarawy or Dr. Mostafa Mahmoud folder trees."""
        route = self.route
        is_mahmoud = (route.key == MAHMOUD_VIDEO_OWNER)
        section = self.catalog.libraries[MAHMOUD_LIBRARY if is_mahmoud else 1]
        bio = section.get("bio", {})
        if self.bio_open:
            if is_mahmoud:
                self.draw_bio_full(MAHMOUD_NAME, bio, living_label=u"الوفاة")
            else:
                self.draw_bio_full(u"الإمام محمد متولي الشعراوي", self.reciter_bio(999, u"محمد متولي الشعراوي", self.catalog.bios.get(999) or bio) or bio,
                                   living_label=u"الوفاة واللقب")
            return
        folders = route.items or section.get("folders", [])
        folder = folders[route.index] if folders else {}
        px, py, pw, ph = layout.EDITIONS_POSTER
        if is_mahmoud:
            self.image("poster0", "portrait-mahmoud", layout.EDITIONS_POSTER)
            self.text("card0", MAHMOUD_NAME, (px + 8, py + ph - 76, pw - 16, 73))
        else:
            poster_id = folder.get("poster_id", 999)
            poster_name = folder.get("poster_name", u"محمد متولي الشعراوي")
            self.reciter_card_image("poster0", poster_id, layout.EDITIONS_POSTER)
            self.text("card0", flat_text(poster_name), (px + 8, py + ph - 76, pw - 16, 73))

        self.text("bio_recordings", folder.get("count_label") or folder.get("badge", u""), layout.EDITIONS_BADGE_REC)
        self.text("bio_riwayas", folder.get("riwayas_label") or (u"مكتبة د. مصطفى محمود" if is_mahmoud else u""), layout.EDITIONS_BADGE_RIW)
        born_txt = folder.get("born") or bio.get("born", u"1921م · شبين الكوم" if is_mahmoud else u"15 أبريل 1911م")
        died_txt = folder.get("died") or bio.get("died", u"31 أكتوبر 2009م" if is_mahmoud else u"17 يونيو 1998م")
        self.text("bio_born", u"الميلاد والنشأة\n" + born_txt, layout.EDITIONS_BIO_BORN)
        self.text("bio_died", (u"الوفاة\n" if is_mahmoud else u"الوفاة واللقب\n") + died_txt, layout.EDITIONS_BIO_DIED)
        default_head = MAHMOUD_NAME if is_mahmoud else u"موسوعة الشيخ الشعراوي"
        self.text("bio_heading", flat_text(folder.get("subtitle") or folder.get("title") or default_head), layout.EDITIONS_BIO_HEADING)
        summary = folder.get("summary") or folder.get("body") or bio.get("summary", u"")
        if self.mini_player_active():
            self.bio_text(summary, layout.EDITIONS_BIO_TEXT_SHORT)
            self.mini_player(layout.EDITIONS_MINI, "bio_source")
        else:
            self.bio_text(summary, layout.EDITIONS_BIO_TEXT)
            self.text("bio_source", u"اضغط زر الموافقة لفتح الفولدر  ·  رجوع للعودة", layout.EDITIONS_BIO_SOURCE)

    def draw_bio_full(self, name, bio, living_label=u"الحالة / الوفاة"):
        """The whole left tower becomes the biography: name, birth, death, the full text (rolling when it is
        longer than the box) and its source. Back, OK or yellow / INFO again bring the photo card back."""
        for widget in ("poster0", "card0", "bio_recordings", "bio_riwayas", "elapsed", "duration", "status", "progress"):
            self.hide_widget(widget)
        self.image("page", "bio-full", layout.BIO_FULL_PANEL)
        self.text("bio_heading", u"السيرة الذاتية  ·  " + plain(name or u""), layout.BIO_FULL_HEADING)
        self.text("bio_born", u"الميلاد والنشأة\n" + (bio.get("born") or u"—"), layout.BIO_FULL_BORN)
        if bio.get("died"):
            self.text("bio_died", living_label + u"\n" + bio["died"], layout.BIO_FULL_DIED)
        else:
            self.text("bio_died", u"الحالة\nأطال الله في عمره", layout.BIO_FULL_DIED)
        self.bio_text(bio.get("summary", u"") or u"لا توجد سيرة مفصلة بعد", layout.BIO_FULL_TEXT)
        source = bio.get("source") or u"الهيئة العامة للاستعلامات"
        self.text("bio_source", u"المصدر · %s  ·  رجوع للإغلاق" % source, layout.BIO_FULL_SOURCE)

    def toggle_bio(self):
        if self.route.name == "mushaf":
            self.open_mushaf_reciter_menu()
            return True
        if self.route.name not in BIO_VIEWS:
            return False
        if self.route.name == "reciter_hub" or self.route.name == "editions" or self.route.name == "reciter_videos":
            if self.route.key not in self.catalog.reciter:
                return False
        self.bio_open = not self.bio_open
        self.render()
        return True

    def close_bio(self):
        """True when the full biography was open (it is closed now and the screen redrawn)."""
        if not self.bio_open:
            return False
        self.bio_open = False
        self.render()
        return True

    def shaarawy_root(self):
        """True on the first screen of the Sheikh's encyclopedia (the two big folders: audio | video)."""
        route = self.route
        return route.name == "shaarawy_folders" and route.items is self.catalog.libraries[1].get("folders")

    def shaarawy_audio_root(self):
        """True inside the Sheikh's audio folder (tafsir | programs | sermons | clips)."""
        route = self.route
        folders = self.catalog.libraries[1].get("folders") or []
        return route.name == "shaarawy_folders" and bool(folders) and route.items is folders[0].get("folders")

    def render_shaarawy_root(self):
        folders = self.route.items
        self.portraits.request([999])
        badges = [f.get("count_label") or f.get("badge", u"") for f in folders[:2]]
        self.render_deck(u"فضيلة الإمام الشيخ محمد متولي الشعراوي", u"اختر المكتبة  ·  الصوتيات أو الفيديو",
                         ["deck-sh-audio", "deck-sh-video"], badges)
        self._update_shaarawy_folders_bio_panel()

    def render_shaarawy_audio_root(self):
        folders = self.route.items[:4]
        self.portraits.request([999])
        badges = [f.get("count_label") or f.get("badge", u"") for f in folders]
        self.render_deck(u"صوتيات الإمام الشعراوي", u"التفسير · البرامج · الخطب · المقتطفات",
                         ["deck-sha-%d" % i for i in range(len(folders))], badges)
        self._update_shaarawy_folders_bio_panel()

    def render_shaarawy_folders(self):
        """Folder levels of the Sheikh's encyclopedia: root (audio | video) -> surahs / programs -> items."""
        route = self.route
        section = self.catalog.libraries[1]
        folders = route.items or section.get("folders", [])
        if self.shaarawy_root():
            self.render_shaarawy_root()
            return
        if self.shaarawy_audio_root():
            self.render_shaarawy_audio_root()
            return
        is_mahmoud = (route.key == MAHMOUD_VIDEO_OWNER)
        if not is_mahmoud:
            self.portraits.request([999])

        default_t = MAHMOUD_NAME if is_mahmoud else (section.get("title") or u"موسوعة الشيخ الشعراوي")
        self.text("title", flat_text(route.folder_title or default_t), layout.EDITIONS_TITLE)
        page_size = layout.ECARD_PAGE_SIZE
        start = (route.index // page_size) * page_size
        total_pages = max(1, (len(folders) + page_size - 1) // page_size)
        if total_pages > 1:
            sub_line = u"صفحة %d من %d  ·  %d فولدراً  ·  الموافقة: فتح الفولدر  ·  رجوع: العودة" % (start // page_size + 1, total_pages, len(folders))
        else:
            sub_line = u"اختر الفولدر المطلوب  ·  %d فولدرات  ·  الموافقة: فتح  ·  رجوع: العودة" % len(folders) if len(folders) > 2 else u"اختر القسم المطلوب  ·  الصوتيات أو الفيديو  ·  الموافقة: فتح  ·  رجوع: العودة"
        self.text("sub", flat_text(sub_line), layout.EDITIONS_SUB)

        for i, folder in enumerate(folders[start:start + page_size]):
            x, y, w, h = layout.ECARDS[i]
            parts = layout.card_parts("ecard", (x, y, w, h))
            self.image("ecard%d" % i, "ecard-bg", (x, y, w, h))
            self.text("ecard_num%d" % i, "%02d" % (start + i + 1), parts["num"])
            self.text("ecard_title%d" % i, flat_text(folder["title"]), parts["title"])
            self.text("ecard_meta%d" % i, flat_text(folder.get("badge", u"")), parts["meta"])
        if folders:
            self.highlight(layout.ECARDS[route.index - start], "ecard")
        self._update_shaarawy_folders_bio_panel()

    def _update_shaarawy_bio_panel(self):
        route = self.route
        is_mahmoud = (route.key == MAHMOUD_VIDEO_OWNER)
        section = self.catalog.libraries[MAHMOUD_LIBRARY if is_mahmoud else 1]
        bio = section.get("bio", {})
        if self.bio_open:
            if is_mahmoud:
                self.draw_bio_full(MAHMOUD_NAME, bio, living_label=u"الوفاة")
            else:
                self.draw_bio_full(u"الإمام محمد متولي الشعراوي", self.reciter_bio(999, u"محمد متولي الشعراوي", self.catalog.bios.get(999) or bio) or bio,
                                   living_label=u"الوفاة واللقب")
            return
        current = route.items[route.index] if route.items else {}

        self.text("bio_born", u"الميلاد والنشأة\n" + bio.get("born", u"1921م · شبين الكوم" if is_mahmoud else u"15 أبريل 1911م"), layout.EDITIONS_BIO_BORN)
        self.text("bio_died", (u"الوفاة\n" if is_mahmoud else u"الوفاة واللقب\n") + bio.get("died", u"31 أكتوبر 2009م" if is_mahmoud else u"17 يونيو 1998م"), layout.EDITIONS_BIO_DIED)

        default_h = MAHMOUD_NAME if is_mahmoud else u"خواطر الشيخ الشعراوي"
        self.text("bio_heading", flat_text(current.get("subtitle") or route.folder_title or default_h), layout.EDITIONS_BIO_HEADING)
        body_clean = current.get("body") or bio.get("summary", u"")
        if self.mini_player_active():
            self.bio_text(body_clean, layout.EDITIONS_BIO_TEXT_SHORT)
            self.mini_player(layout.EDITIONS_MINI, "bio_source")
        else:
            self.bio_text(body_clean, layout.EDITIONS_BIO_TEXT)
        if self.mini_player_active():
            pass
        elif current.get("video"):
            self.text("bio_source", u"اضغط زر الموافقة لمشاهدة الفيديو بالعرض الكامل", layout.EDITIONS_BIO_SOURCE)
        else:
            self.text("bio_source", u"اضغط زر الموافقة للاستماع · رجوع لقائمة الفولدرات", layout.EDITIONS_BIO_SOURCE)

    def render_shaarawy(self):
        route = self.route
        is_mahmoud = (route.key == MAHMOUD_VIDEO_OWNER)
        section = self.catalog.libraries[MAHMOUD_LIBRARY if is_mahmoud else 1]

        px, py, pw, ph = layout.EDITIONS_POSTER
        if is_mahmoud:
            self.image("poster0", "portrait-mahmoud", layout.EDITIONS_POSTER)
            self.text("card0", MAHMOUD_NAME, (px + 8, py + ph - 76, pw - 16, 73))
        else:
            self.reciter_card_image("poster0", 999, layout.EDITIONS_POSTER)
            self.text("card0", u"محمد متولي الشعراوي", (px + 8, py + ph - 76, pw - 16, 73))
            self.portraits.request([999])

        all_items = route.all_items or route.items
        vid_count = sum(1 for item in all_items if item.get("video"))
        if vid_count > 0:
            self.text("bio_recordings", u"%d حلقة مرئية" % vid_count, layout.EDITIONS_BADGE_REC)
        else:
            self.text("bio_recordings", u"%d تسجيلاً صوتياً" % len(route.items), layout.EDITIONS_BADGE_REC)
        total_secs = sum(self.clock_seconds(item.get("duration")) for item in route.items)
        self.text("bio_riwayas", (u"%.1f ساعة" % (total_secs / 3600.0)) if total_secs else u"%d مادة" % len(route.items), layout.EDITIONS_BADGE_RIW)

        header_title = route.folder_title or (MAHMOUD_NAME if is_mahmoud else u"موسوعة الشيخ محمد متولي الشعراوي")
        self.text("title", flat_text(header_title), layout.EDITIONS_TITLE)
        page_size = layout.ECARD_PAGE_SIZE
        start = (route.index // page_size) * page_size
        total_pages = max(1, (len(route.items) + page_size - 1) // page_size)
        sub_line = u"صفحة %d من %d  ·  %d مادة بالفولدر  ·  الأحمر: تحميل للهارد  ·  رجوع: العودة" % (
            start // page_size + 1, total_pages, len(route.items)
        )
        self.text("sub", flat_text(sub_line), layout.EDITIONS_SUB)

        active_url = None
        if self.playing_items and self.playing_index is not None and 0 <= self.playing_index < len(self.playing_items):
            active_url = self.catalog.track(self.playing_items[self.playing_index])[3]

        visible = route.items[start:start + page_size]
        for i, item in enumerate(visible):
            x, y, w, h = layout.ECARDS[i]
            parts = layout.card_parts("ecard", (x, y, w, h))
            idx = start + i
            title_txt = item.get("short") or item["title"]
            playing = bool(active_url and item.get("audio") == active_url and self.audio is not None
                           and self.audio.state in ("connecting", "playing", "paused"))
            self.image("ecard%d" % i, "ecard-bg", (x, y, w, h))
            self.text("ecard_num%d" % i, "%03d" % (idx + 1), parts["num"])
            self.text("ecard_title%d" % i, flat_text(title_txt), parts["title"])

            meta_txt = item.get("badge") or item.get("subtitle") or u"خواطر الشعراوي"
            if self.downloader.is_media_downloaded(item.get("audio"), is_video=bool(item.get("video"))):
                meta_txt = u"• محمّل بدون نت  ·  " + meta_txt
            elif self.downloader.is_media_queued(item.get("audio")):
                meta_txt = u"• جارٍ التحميل  ·  " + meta_txt
            self.text("ecard_meta%d" % i, flat_text(meta_txt), parts["meta"])
            if playing:
                self.play_marks("ecard_meta%d" % i, parts["meta"])
        if route.items:
            self.highlight(layout.ECARDS[route.index - start], "ecard")
        self._update_shaarawy_bio_panel()

    def show_video_osd(self, auto_hide=True):
        self.video_osd_visible = True
        if self.route.name == "video":
            self.render()
        if auto_hide:
            pages = max([1] + [len(self._text_pages[name][0])
                                for name in ("v_title", "v_queue", "p_reciter")
                                if name in self._shown_widgets and name in self._text_pages])
            self.video_osd_timer.start(max(6000, pages * (1000 * TEXT_PAGE_SECONDS + 1200)), True)

    def auto_hide_video_osd(self):
        if self.route.name == "video" and self.audio is not None and self.audio.state == "playing":
            self.video_osd_visible = False
            self.render()

    def render_video(self):
        """Ultra Stalker Floating Islands Full-Screen Video Player (`livebar2` architecture)."""
        route = self.route
        if not route.items:
            return
        if not self.video_osd_visible:
            return

        item = route.items[route.index]
        owner_id, owner_name = self.video_owner()
        shaarawy = owner_id == 999
        self.image("background", "video-bar", layout.VIDEO_BAR)
        if owner_id == MAHMOUD_VIDEO_OWNER:
            self.image("poster0", "video-mahmoud", layout.VIDEO_POSTER)
        elif isinstance(owner_id, int):
            self.reciter_card_image("poster0", owner_id, layout.VIDEO_POSTER)
        else:
            self.image("poster0", "grid3-reciter-default", layout.VIDEO_POSTER)
        self.text("card0", flat_text(owner_name.replace(u"الشيخ ", u"", 1)), layout.VIDEO_POSTER_NAME)

        is_local_vid = self.downloader.is_media_downloaded(item.get("audio"), is_video=True)
        self.text("p_source", u"• فيديو من الهارد" if is_local_vid else u"• فيديو مرئي", layout.VIDEO_BADGE_1)
        source = u"YouTube" if item.get("youtube_id") else (u"جودة فائقة HD" if shaarawy else u"أرشيف الإنترنت")
        self.text("p_mode", source, layout.VIDEO_BADGE_2)
        video_title = flat_text(item["title"])
        self.text("v_title", video_title, layout.VIDEO_TITLE)
        # short titles sit in the middle of the plaque, long ones start from the right edge
        self.align_label("v_title", 2 if len(video_title) > 62 else 1)
        self.text("p_reciter", flat_text(owner_name), layout.VIDEO_RECITER)
        for centred in ("v_queue", "p_reciter", "p_info", "dl_status"):
            self.align_label(centred, 1)

        if route.index + 1 < len(route.items):
            next_title = route.items[route.index + 1]["title"]
            self.text("v_queue", u"التالي:  " + flat_text(next_title), layout.VIDEO_QUEUE_TEXT)
        elif shaarawy:
            self.text("v_queue", u"نهاية حلقات الفولدر الحالي  ·  موسوعة الشيخ محمد متولي الشعراوي", layout.VIDEO_QUEUE_TEXT)
        else:
            self.text("v_queue", u"آخر فيديو في المكتبة المرئية  ·  " + flat_text(owner_name), layout.VIDEO_QUEUE_TEXT)

        self.text("p_info", (u"الحلقة %d من %d" if shaarawy else u"الفيديو %d من %d") % (route.index + 1, len(route.items)), layout.VIDEO_INFO)
        self.text("dl_status", u"التقديم والترجيع بأزرار الأرقام\nزر ١ و ٣ عشر ثوانٍ  ·  ٤ و ٦ دقيقة  ·  ٧ و ٩ خمس دقائق", layout.VIDEO_HINT)
        self.update_video_player()

    def video_owner(self):
        """(id, name) of the sheikh whose video is playing (Shaarawy keeps his own encyclopedia)."""
        route = self.route
        item = route.items[route.index] if (route.items and 0 <= route.index < len(route.items)) else {}
        key = item.get("owner") if item.get("owner") is not None else route.key
        if key == MAHMOUD_VIDEO_OWNER:
            return MAHMOUD_VIDEO_OWNER, MAHMOUD_NAME
        if key in self.catalog.reciter and key != 999:
            return key, self.catalog.reciter[key][1]
        if isinstance(key, int):
            if key == 999:
                return 999, SHAARAWY_NAME
            p_name = self.portraits.display_name(key)
            if p_name:
                return key, p_name
        if isinstance(key, type(u"")) or isinstance(key, str):
            return key, key
        return 999, SHAARAWY_NAME

    def update_video_player(self):
        if self.route.name != "video" or not self.video_osd_visible or not self.route.items:
            return
        item = self.route.items[self.route.index]
        state = self.audio.state if self.audio is not None else "idle"
        if self.youtube_lookup is not None:
            state = "resolving"
        status_map = {
            "resolving": u"جارٍ البحث عن بث يوتيوب…",
            "connecting": u"جارٍ الاتصال ببث الفيديو المرئي…",
            "playing": u"قيد العرض المرئي الآن",
            "paused": u"الفيديو متوقف مؤقتاً",
            "finished": u"انتهى عرض الحلقة المرئية",
            "error": u"تعذّر تشغيل الفيديو · اضغط الأخضر للإعادة",
            "idle": u"جاهز للتشغيل المرئي",
        }
        if self.audio is not None and state in ("playing", "paused", "connecting", "finished"):
            position = self.audio.shown_position()
            total_pts = self.audio.total()
            if total_pts <= 0:
                dur_str = item.get("duration") or u"45:00"
                parts = [int(p) for p in dur_str.split(":") if p.isdigit()]
                if len(parts) == 3:
                    est_sec = parts[0] * 3600 + parts[1] * 60 + parts[2]
                elif len(parts) == 2:
                    est_sec = parts[0] * 60 + parts[1]
                else:
                    est_sec = 2700
                total_pts = int(est_sec * PTS)
                total_str = dur_str
            else:
                total_str = self.duration(total_pts)
            self.text("elapsed", self.duration(position), layout.VIDEO_ELAPSED)
            self.text("duration", total_str, layout.VIDEO_DURATION)
            value = self.progress_value(position, total_pts)
            rem_pts = max(0, total_pts - position) if total_pts else 0
            status_line = status_map.get(state, u"قيد العرض")
            note = self.audio.status_note()
            if total_pts > 0 and state in ("playing", "paused"):
                status_line += u"  ·  %d%%  ·  المتبقي %s" % (int(value), self.duration(rem_pts))
            if note and state in ("playing", "paused", "connecting"):
                status_line += u"  ·  " + note
            self.text("status", status_line, layout.VIDEO_STATUS)
            self.set_progress(value)
            self.place("progress", layout.VIDEO_PROGRESS)
        else:
            self.text("elapsed", u"00:00", layout.VIDEO_ELAPSED)
            self.text("duration", item.get("duration") or u"45:00", layout.VIDEO_DURATION)
            self.text("status", status_map.get(state, u"قيد العرض"), layout.VIDEO_STATUS)
            self.set_progress(0)
            self.place("progress", layout.VIDEO_PROGRESS)

    def _update_library_reader(self):
        route = self.route
        section = self.catalog.libraries[route.key]
        title = section["title"]
        current = route.items[route.index]
        body_raw = current.get("body", u"")
        if current.get("bio") == "shanqiti":
            body_raw = SHANQITI_BIO
        source_qr = current.get("source_qr")
        body_box = layout.LIB_SOURCE_BODY if source_qr else layout.LIB_BODY
        lines = wrap(body_raw, 42 * 100 // self.text_size).split(u"\n")
        line_height = int(self.scaled_font("lib_body") * LINE_HEIGHT + 0.999)
        per_page = min(5 if source_qr else 12, max(1, (body_box[3] - 2) // line_height))
        pages = max(1, (len(lines) + per_page - 1) // per_page)
        key = (route.key, id(route), route.index, self.text_size)
        if self.lib_page_key != key:
            self.lib_page_key = key
            self.lib_page = 0
            self.lib_timer.stop()
            if pages > 1:
                self.lib_timer.start(LIB_PAGE_MS, True)
        self.lib_pages = pages
        self.lib_page %= pages
        badge = current.get("badge") or title
        if pages > 1:
            badge = u"صفحة %d من %d  ·  زر ٢ و ٨ لتقليب النص" % (self.lib_page + 1, pages)
            shown = lines[self.lib_page * per_page:(self.lib_page + 1) * per_page]
            while shown and not shown[0].strip():
                shown = shown[1:]
        else:
            shown = lines[:per_page]
        self.text("lib_badge", flat_text(badge), layout.LIB_BADGE)
        self.text("lib_heading", flat_text(current.get("subtitle", current["title"])), layout.LIB_HEADING)
        self.align_label("lib_body", 1)
        balanced = balanced_wrap(body_raw.strip(), 44 * 100 // self.text_size) if (pages == 1 and u"\n" not in body_raw.strip()) else []
        body = balanced if 0 < len(balanced) <= per_page else shown
        self.text("lib_body", u"\n".join(body), body_box)
        if source_qr:
            filename = source_qr + ".png"
            qr_path = os.path.join(ROOT, "data", "source-qr", filename)
            if not os.path.isfile(qr_path):
                qr_path = os.path.join(ROOT, "data", "mahmoud-qr", filename)
            self.image("page", qr_path, layout.LIB_SOURCE_QR, external=True)
        else:
            self.hide_widget("page")
        if self.mini_player(layout.LIB_MINI, "lib_action"):
            pass
        elif current.get("counter"):
            target = current["counter"]
            val = self.tasbih_counts.get((route.key, route.index), 0)
            self.text("lib_action", u"المسبحة التفاعلية: %d من %d  ·  اضغط زر الموافقة للتسبيح" % (val, target), layout.LIB_ACTION)
        elif current.get("children"):
            self.text("lib_action", u"اضغط زر الموافقة لفتح الفولدر  ·  رجوع للعودة", layout.LIB_ACTION)
        elif current.get("video"):
            self.text("lib_action", u"اضغط زر الموافقة أو الأخضر لتشغيل الفيديو", layout.LIB_ACTION)
        elif current.get("edition"):
            self.text("lib_action", u"اضغط زر الموافقة لفتح سور المصحف المعلم · 114 سورة", layout.LIB_ACTION)
        elif current.get("audio"):
            self.text("lib_action", u"اضغط زر الموافقة أو الزر الأخضر للاستماع الصوتي المباشر", layout.LIB_ACTION)
        elif source_qr:
            self.text("lib_action", u"امسح رمز QR بكاميرا الموبايل لفتح المصدر", layout.LIB_ACTION)
        else:
            self.text("lib_action", u"تنقّل بالأسهم بين الصناديق · العنصر %d من %d" % (route.index + 1, len(route.items)), layout.LIB_ACTION)

    def lib_turn(self, step, auto=False):
        """Flip the reading panel page (auto every few seconds, or with keys 2 / 8)."""
        if self.route.name != "library" or self.lib_pages <= 1:
            self.lib_timer.stop()
            if self.route.name != "library":
                self.lib_page_key = None
            return
        self.lib_page = (self.lib_page + step) % self.lib_pages
        self._update_library_reader()
        self.lib_timer.start(LIB_PAGE_MS if auto else LIB_PAGE_MS * 2, True)

    def render_library(self):
        route = self.route
        section = self.catalog.libraries[route.key]
        title = section["title"]
        sub = section["sub"]
        if route.key == 13:
            sub = u"التاريخ الهجري اليوم: %s  ·  %s" % (hijri_today(), sub)
        if route.folder_title:
            sub = u"%s  ·  %s" % (title, sub)
            title = route.folder_title
        self.text("title", flat_text(title), layout.LIST_TITLE)
        self.text("sub", flat_text(sub), layout.LIST_SUB)

        if route.name == "quiz":
            q_list = route.items
            q_idx = route.question_index % len(q_list)
            q_obj = q_list[q_idx]
            self.text("count", u"السؤال %d من %d  ·  النتيجة: %d" % (q_idx + 1, len(q_list), route.score), layout.LIST_COUNT)
            self.text("lib_badge", u"المسابقة الإسلامية التفاعلية  ·  النقاط: %d" % route.score, layout.LIB_BADGE)
            self.text("lib_heading", u"السؤال %d من %d" % (q_idx + 1, len(q_list)), layout.LIB_HEADING)
            body_text = q_obj["q"]
            if route.answered is not None:
                correct = (route.answered == q_obj["answer"])
                verdict = u"• إجابة صحيحة! أحسنت" if correct else (u"• الإجابة الصحيحة: " + q_obj["options"][q_obj["answer"]])
                body_text += u"\n\n" + verdict + u"\n\nالشرح والفائدة:\n" + q_obj["explanation"]
            self.align_label("lib_body", 1)
            self.text("lib_body", wrap(body_text, 48), layout.LIB_BODY)
            action_hint = u"اضغط زر الموافقة أو الأصفر للسؤال التالي" if route.answered is not None else u"اختر الصندوق الصحيح بالأسهم ثم اضغط زر الموافقة"
            self.text("lib_action", action_hint, layout.LIB_ACTION)

            letters = (u"أ", u"ب", u"ج", u"د")
            for i, option_text in enumerate(q_obj["options"][:4]):
                x, y, w, h = layout.LCARDS[i]
                parts = layout.card_parts("lcard", (x, y, w, h))
                badge = u"اضغط زر الموافقة لاختيار هذه الإجابة"
                if route.answered is not None:
                    if i == q_obj["answer"]:
                        badge = u"• الإجابة الصحيحة"
                    elif i == route.answered:
                        badge = u"• اختيارك"
                self.image("lcard%d" % i, "lcard-bg", (x, y, w, h))
                self.text("number%d" % i, letters[i], parts["num"])
                kind = "row" if len(option_text) <= 30 else "radio_row"
                self.text("%s%d" % (kind, i), flat_text(option_text), parts["title"])
                self.text("detail%d" % i, badge, parts["meta"])
            self.highlight(layout.LCARDS[route.index], "lib")
            return

        page_size = layout.LIB_PAGE_SIZE
        start = (route.index // page_size) * page_size
        total_pages = max(1, (len(route.items) + page_size - 1) // page_size)
        self.text("count", u"صفحة %d من %d  ·  %d مادة" % (start // page_size + 1, total_pages, len(route.items)), layout.LIST_COUNT)

        active_url = None
        if self.mini_player_active():
            try:
                active_url = self.catalog.track(self.playing_items[self.playing_index])[3]
            except Exception:
                active_url = None
        mark = None
        visible = route.items[start:start + page_size]
        for i, item in enumerate(visible):
            x, y, w, h = layout.LCARDS[i]
            parts = layout.card_parts("lcard", (x, y, w, h))
            idx = start + i
            self.image("lcard%d" % i, "lcard-bg", (x, y, w, h))
            self.text("number%d" % i, "%03d" % (idx + 1), parts["num"])
            kind, shown_title, extra = card_title(item["title"])
            if item.get("counter"):
                extra = u""          # the count is already shown in the capsule below
            self.text("%s%d" % (kind, i), shown_title, parts["title"])
            badge_text = item.get("badge") or item.get("subtitle") or title
            if extra:
                badge_text = u"%s  ·  %s" % (extra, badge_text)
            if item.get("counter"):
                val = self.tasbih_counts.get((route.key, idx), 0)
                badge_text = u"%s  ·  العدّاد: %d من %d" % (badge_text, val, item["counter"])
            elif item.get("youtube_id"):
                from .youtube import watch_url
                seconds = RESUME.get(watch_url(item["youtube_id"]))
                if seconds:
                    badge_text = u"استكمال من %s  ·  %s" % (format_seconds(int(seconds)), badge_text)
            elif item.get("audio"):
                is_video = bool(item.get("video"))
                dl_prefix = u"• محمّل بدون نت  ·  " if self.downloader.is_media_downloaded(item["audio"], is_video=is_video) else (
                    u"• جارٍ التحميل  ·  " if self.downloader.is_media_queued(item.get("audio")) else (
                        u"• فيديو  ·  " if is_video else (u"• صوت ونص مكتوب  ·  " if len(item.get("body", u"")) > 200 else u"• صوتي  ·  ")
                    )
                )
                badge_text = dl_prefix + badge_text
            self.text("detail%d" % i, flat_text(badge_text), parts["meta"])
            if active_url and item.get("audio") and (item.get("audio") == active_url or
                                                     self.downloader.local_media_path(item["audio"], is_video=bool(item.get("video"))) == active_url):
                mark = ("detail%d" % i, parts["meta"])
        if mark:
            self.play_marks(*mark)
        self.highlight(layout.LCARDS[route.index - start], "lib")
        self._update_library_reader()

    def render_list(self):
        route = self.route
        unit = u"سورة"
        if route.name == "surahs":
            reciter, recording = self.catalog.edition[route.key]
            rec_id = reciter[0]
            if rec_id == 950:
                title = u"خطب الشيخ عبد الحميد كشك"
                unit = u"خطبة"
            elif is_mubtahil(rec_id):
                title = u"الابتهالات والتواشيح الدينية"
                unit = u"ابتهال"
            elif self.catalog.is_custom_edition(route.key):
                title = u"تلاوات وحفلات نادرة مختارة"
                unit = u"تلاوة"
            else:
                title = u"سور القرآن الكريم"
                unit = u"سورة"
            sub = reciter[1] + u"  ·  " + recording[1]
        elif route.name == "radios":
            title, sub = u"إذاعات القرآن الكريم", u"البث المباشر  ·  %d إذاعة قرآنية وإسلامية" % len(route.items)
            unit = u"إذاعة"
        else:
            title, sub = u"المفضلة ومكتبة الهارد (بدون نت)", u"التلاوات والصوتيات المحمّلة على الهارد والمحفوظة في المفضلة"
            unit = u"مادة"

        page_size = layout.SURA_PAGE_SIZE
        start = (route.index // page_size) * page_size
        total_pages = max(1, (len(route.items) + page_size - 1) // page_size)

        self.text("title", title, layout.LIST_TITLE)
        self.text("sub", flat_text(sub), layout.LIST_SUB)
        self.text("count", u"صفحة %d من %d  ·  %d %s" % (start // page_size + 1, total_pages, len(route.items), unit), layout.LIST_COUNT)

        if not route.items:
            self.text("panel", u"القائمة فارغة", layout.SURA_PLAYER_TITLE)
            self.text("status", u"اضغط الزر الأزرق لحفظ السور في المفضلة", layout.SURA_PLAYER_STATUS)
            return

        active_entry = self.playing_items[self.playing_index] if (self.playing_items and self.playing_index is not None) else None
        visible_items = route.items[start:start + page_size]
        is_custom = (route.name == "surahs" and self.catalog.is_custom_edition(route.key))

        for i, entry in enumerate(visible_items):
            x, y, w, h = layout.SURA_CARDS[i]
            parts = layout.card_parts("scard", (x, y, w, h))
            index = start + i
            name, dur_text, number = self.list_item(route.name, entry, index)
            playing = active_entry == entry and self.audio is not None and self.audio.state in ("connecting", "playing", "paused")
            self.image("scard%d" % i, "scard-bg", (x, y, w, h))
            self.text("number%d" % i, "%03d" % number, parts["num"])
            if route.name == "radios" or is_custom:
                label = "radio_row%d" % i
                self.text(label, flat_text(name), parts["title"])
            else:
                label = "row%d" % i
                self.text(label, flat_text(name), parts["title"])
            if dur_text:
                self.text("detail%d" % i, dur_text, parts["meta"])
                if playing:
                    self.play_marks("detail%d" % i, parts["meta"])

        self.highlight(layout.SURA_CARDS[route.index - start], "sura")
        self.render_integrated_player()

    def _refresh_sura_card_title(self, item_index):
        route = self.route
        if route.name not in ("surahs", "radios", "favorites") or not (0 <= item_index < len(route.items)):
            return
        page_size = layout.SURA_PAGE_SIZE
        start = (route.index // page_size) * page_size
        if not (start <= item_index < start + page_size):
            return
        slot = item_index - start
        x, y, w, h = layout.SURA_CARDS[slot]
        parts = layout.card_parts("scard", (x, y, w, h))
        entry = route.items[item_index]
        name, _, _ = self.list_item(route.name, entry, item_index)
        active_entry = self.playing_items[self.playing_index] if (self.playing_items and self.playing_index is not None) else None
        playing = active_entry == entry and self.audio is not None and self.audio.state in ("connecting", "playing", "paused")
        is_custom = (route.name == "surahs" and self.catalog.is_custom_edition(route.key))
        if route.name == "radios" or is_custom:
            label = "radio_row%d" % slot
            self.text(label, flat_text(name), parts["title"])
        else:
            label = "row%d" % slot
            self.text(label, flat_text(name), parts["title"])
        label = "detail%d" % slot
        if playing:
            self.play_marks(label, parts["meta"])
        elif getattr(self, "_pmark_owner", None) == label:
            self.hide_widget("pmark_r")
            self.hide_widget("pmark_l")
            self._pmark_owner = None

    def list_item(self, view, entry, index):
        if view == "radios":
            radio = self.catalog.radio[entry[1]]
            schedule = radio[3] if len(radio) > 3 else u"بث مباشر 24 ساعة"
            return radio[1], u"• " + schedule, index + 1
        if entry[0] == "lib":
            title, sub, detail, _ = entry[1]
            return title, u"%s  ·  • محمّلة" % sub, index + 1
        edition_id, chapter = entry
        sura_title = self.catalog.track_title(edition_id, chapter)
        if view == "favorites" and edition_id in self.catalog.edition:
            rec_name = self.catalog.edition[edition_id][0][1].replace(u"الشيخ ", u"", 1)
            sura_title = u"%s · %s" % (sura_title, rec_name)
        if entry in self.favorites:
            sura_title += u" •"
        if entry in self.measured_durations:
            dur_str = format_seconds(self.measured_durations[entry])
        else:
            dur_str = self.catalog.surah_duration_str(edition_id, chapter)
        if self.downloader.is_downloaded(edition_id, chapter):
            dur_str += u"  ·  • محمّلة"
        elif self.downloader.is_queued(edition_id, chapter):
            dur_str += u"  ·  • تحميل"
        return sura_title, dur_str, (index + 1 if view == "favorites" else chapter)

    def render_integrated_player(self):
        route = self.route
        if not route.items:
            return
        if self.playing_items and self.playing_index is not None and 0 <= self.playing_index < len(self.playing_items):
            items = self.playing_items
            idx = self.playing_index
            is_active_track = True
        else:
            items = route.items
            idx = route.index
            is_active_track = False

        entry = items[idx]
        name, reciter, edition, url, reciter_id = self.catalog.track(entry)
        if reciter_id is not None:
            self.reciter_portrait_image("portrait", reciter_id, layout.SURA_PLAYER_PORTRAIT)
        elif entry[0] is None:
            self.image("portrait", "radio-art", layout.SURA_PLAYER_PORTRAIT)
        elif u"الشعراوي" in (reciter or u""):
            self.reciter_portrait_image("portrait", 999, layout.SURA_PLAYER_PORTRAIT)
        else:
            self.image("portrait", "poster-default", layout.SURA_PLAYER_PORTRAIT)

        if entry[0] is None:
            source_badge = u"• بث إذاعي مباشر"
            meta_line = u"إذاعة قرآنية مباشرة  ·  بث متواصل 24 ساعة"
            riwaya_line = edition
        elif isinstance(entry[0], int):
            ed_id, chapter = entry
            is_local = self.downloader.is_downloaded(ed_id, chapter)
            source_badge = u"• تشغيل من الهارد (بدون نت)" if is_local else u"• بث سحابي فائق النقاء"
            meta_line = self.catalog.surah_meta_str(chapter, edition_id=ed_id)
            src_label = self.catalog.source_label(url)
            if len(edition) > 28 or src_label in edition:
                riwaya_line = flat_text(edition)
            else:
                riwaya_line = flat_text(edition + u"  ·  " + src_label)
        else:
            is_local_media = self.downloader.is_media_downloaded(url)
            source_badge = u"• تشغيل من الهارد (بدون نت)" if is_local_media else u"• صوتيات إسلامية"
            meta_line = edition
            riwaya_line = reciter

        mode_badge = u"التكرار: سورة واحدة" if self.repeat else u"التشغيل: تسلسلي تلقائي"
        self.text("p_source", source_badge, layout.SURA_PLAYER_SOURCE)
        self.text("p_mode", mode_badge, layout.SURA_PLAYER_MODE)

        self.text("panel", flat_text(name), layout.SURA_PLAYER_TITLE)
        self.text("p_meta", meta_line, layout.SURA_PLAYER_META)
        self.text("p_reciter", flat_text(reciter), layout.SURA_PLAYER_RECITER)
        self.text("info", riwaya_line, layout.SURA_PLAYER_RIWAYA)

        self.align_label("queue", 1)
        if idx + 1 < len(items):
            next_entry = items[idx + 1]
            following = self.catalog.track(next_entry)[0]
            if isinstance(next_entry[0], int):
                next_dur = self.catalog.surah_duration_str(next_entry[0], next_entry[1])
                if self.catalog.is_custom_edition(next_entry[0]):
                    self.text("queue", u"التالي  ·  %s  ·  %s" % (following, next_dur) if next_dur else u"التالي  ·  " + following, layout.SURA_PLAYER_QUEUE)
                else:
                    self.text("queue", u"التالي في المصحف  ·  %s (%03d)  ·  %s" % (following, next_entry[1], next_dur), layout.SURA_PLAYER_QUEUE)
            else:
                self.text("queue", u"التالي  ·  " + flat_text(following), layout.SURA_PLAYER_QUEUE)
        else:
            self.text("queue", u"نهاية القائمة الحالية  ·  اكتملت السور", layout.SURA_PLAYER_QUEUE)

        self.text(
            "p_info",
            u"زر ١ و ٣ عشر ثوانٍ  ·  ٤ و ٦ دقيقة  ·  ٧ و ٩ خمس دقائق" if (is_active_track and self.audio is not None and not self.audio.live) else u"العنصر %d من %d  ·  موافقة: تشغيل/إيقاف  ·  القنوات: تغيير الصفحة" % (route.index + 1, len(route.items)),
            layout.SURA_PLAYER_INFO
        )

        dl_msg = self.downloader.status_text()
        if route.name == "surahs":
            dl_cnt = self.downloader.downloaded_count(route.key)
            if dl_msg:
                full_dl = dl_msg + u"\nمكتبة الهارد: محمّل %d من %d سورة" % (dl_cnt, len(route.items))
            else:
                full_dl = u"مكتبة الهارد: محمّل %d من %d سورة · يعمل بدون نت\nالأحمر: ضغطة لتحميل السورة · ضغطة ثانية لتحميل الفولدر كامل" % (dl_cnt, len(route.items))
            self.text("dl_status", full_dl, layout.SURA_PLAYER_DL)
        elif route.name == "favorites":
            self.text("dl_status", dl_msg or u"الأزرق: إضافة أو إزالة من المفضلة  ·  الأحمر: تحميل السورة للهارد", layout.SURA_PLAYER_DL)
        else:
            self.text("dl_status", u"بث إذاعي قرآني مباشر فائق النقاء على مدار الساعة", layout.SURA_PLAYER_DL)

        self.update_player(preview_entry=None if is_active_track else entry)

    def mini_player_active(self):
        audio = self.audio
        return bool(audio is not None and self.playing_items and self.playing_index is not None
                    and audio.state in ("connecting", "playing", "paused"))

    def _hide_mini(self):
        for name in ("elapsed", "duration", "status", "progress"):
            self.hide_widget(name)
        if self._mini_hint_owner:
            self.hide_widget("p_info")
            self._mini_hint_owner = False

    def mini_player(self, rects, title_label):
        """Small now-playing block (title, gold bar, elapsed / remaining / total, key hint) for screens
        that list audio but have no big player.  Returns False (and hides itself) when nothing plays."""
        if not self.mini_player_active():
            self._hide_mini()
            return False
        audio = self.audio
        try:
            p_title = self.catalog.track(self.playing_items[self.playing_index])[0]
        except Exception:
            p_title = u""
        # only the name of what is playing, centred, using the whole line (the font shrinks to fit)
        self.text(title_label, flat_text(plain(p_title)), rects["title"])
        if audio.live:
            self.text("elapsed", u"بث مباشر", rects["elapsed"])
            self.hide_widget("duration")
            self.hide_widget("status")
            self.hide_widget("progress")
        else:
            position = audio.shown_position()
            total = audio.total()
            # only the two times on the bar's line: played on the left, still to go on the right
            self.text("elapsed", self.duration(position), rects["elapsed"])
            self.hide_widget("status")
            if total > 0:
                self.text("duration", self.duration(max(0, total - position)), rects["total"])
                self.set_progress(self.progress_value(position, total))
            else:
                self.text("duration", u"\u2014", rects["total"])
                self.set_progress(0)
            self.place("progress", rects["bar"])
        if "hint" in rects:
            hint = u"موافقة: إيقاف واستئناف  ·  أزرار الأرقام: تقديم وترجيع" if not audio.live else u"موافقة: إيقاف واستئناف"
            self.text("p_info", hint, rects["hint"])
            self._mini_hint_owner = True
        return True

    def _refresh_library_mini(self):
        if self.route.name != "library" or not self.route.items:
            return
        if not self.mini_player(layout.LIB_MINI, "lib_action"):
            self._update_library_reader()      # playback ended: the box shows its normal hint again

    def _refresh_folders_mini(self):
        route = self.route
        if route.name != "shaarawy_folders" or not route.items:
            return
        self._update_shaarawy_folders_bio_panel()

    TOP_STRIP_HIDDEN = ("surahs", "radios", "favorites", "video", "library", "shaarawy", "shaarawy_folders")

    def top_strip(self):
        """While sound plays and the screen has no player of its own: elapsed | gold bar | remaining in the
        middle of the top bar."""
        names = ("top_elapsed", "top_remain", "top_track", "top_fill")
        view = self.route.name
        if (view in self.TOP_STRIP_HIDDEN
                or not self.mini_player_active()):
            for name in names:
                self.hide_widget(name)
            return
        audio = self.audio
        gallery = view in ("gallery", "lgallery")
        if gallery:
            elapsed, track, remain = layout.GALLERY_TOP_ELAPSED, layout.GALLERY_TOP_TRACK, layout.GALLERY_TOP_REMAIN
        else:
            elapsed, track, remain = layout.TOP_ELAPSED, layout.TOP_TRACK, layout.TOP_REMAIN
        if audio.live:
            if not gallery:
                x, y, width, height = elapsed
                elapsed = (x - 60, y, width + 60, height)
            self.text("top_elapsed", u"بث مباشر", elapsed)
            self.hide_widget("top_remain")
            self.hide_widget("top_fill")
            self.place("top_track", track)
            return
        position = audio.shown_position()
        total = audio.total()
        self.text("top_elapsed", self.duration(position), elapsed)
        self.place("top_track", track)
        if total > 0:
            self.text("top_remain", self.duration(max(0, total - position)), remain)
            self.laser("top_fill", track, self.progress_value(position, total))
        else:
            self.hide_widget("top_remain")
            self.hide_widget("top_fill")

    def update_player(self, preview_entry=None):
        self.top_strip()
        if self.route.name == "home":
            self.render_home_hero()
        if self.downloader.pop_updated() and self.route.name in ("surahs", "favorites", "editions"):
            self.render()
            return
        if self.route.name == "video":
            self.update_video_player()
            return
        if self.route.name == "shaarawy":
            self._update_shaarawy_bio_panel()
            return
        if self.route.name == "library":
            self._refresh_library_mini()
            return
        if self.route.name == "shaarawy_folders":
            self._refresh_folders_mini()
            return
        if self.route.name == "mushaf":
            self._update_mushaf_state_label()
            return
        if self.route.name not in ("surahs", "radios", "favorites") or self.audio is None:
            return
        state = self.audio.state if (self.playing_items and preview_entry is None) else "idle"
        status_map = {
            "connecting": u"جارٍ الاتصال بالمصدر الصوتي…",
            "playing": u"قيد التشغيل الآن",
            "paused": u"متوقف مؤقتًا",
            "finished": u"انتهت التلاوة",
            "error": u"تعذّر التشغيل · اضغط موافقة لإعادة المحاولة",
            "idle": u"اضغط زر الموافقة لتشغيل السورة في المشغّل الاحترافي",
        }
        controls_map = {
            "connecting": u"اتصال",
            "playing": u"إيقاف مؤقت",
            "paused": u"استئناف",
            "finished": u"إعادة",
            "error": u"إعادة",
            "idle": u"تشغيل",
        }
        self.text("control", controls_map[state], layout.SURA_PLAYER_CONTROL)
        self.text("p_mode", u"التكرار: سورة واحدة" if self.repeat else u"التشغيل: تسلسلي تلقائي", layout.SURA_PLAYER_MODE)

        active_entry = preview_entry
        if active_entry is None and self.playing_items and self.playing_index is not None:
            active_entry = self.playing_items[self.playing_index]

        if active_entry and active_entry[0] is None:
            self.text("status", status_map[state] + u"  ·  بث إذاعي مباشر", layout.SURA_PLAYER_STATUS)
            self.text("elapsed", u"بث مباشر", layout.SURA_PLAYER_ELAPSED)
            self.text("duration", u"24 ساعة", layout.SURA_PLAYER_DURATION)
            self.hide_widget("progress")
            return

        if state in ("playing", "paused", "connecting", "finished") and not self.audio.live:
            if self.audio.length > 0 and active_entry and isinstance(active_entry[0], int):
                measured_sec = int(self.audio.length // PTS)
                if measured_sec > 2 and self.measured_durations.get(active_entry) != measured_sec:
                    self.measured_durations[active_entry] = measured_sec
            position = self.audio.shown_position()
            total_pts = self.audio.total()
            if total_pts > 0:
                total_str = self.duration(total_pts)
            else:
                total_str = u"\u2014"
            self.text("elapsed", self.duration(position), layout.SURA_PLAYER_ELAPSED)
            self.text("duration", total_str, layout.SURA_PLAYER_DURATION)
            value = self.progress_value(position, total_pts)
            rem_pts = max(0, total_pts - position) if total_pts else 0
            status_line = status_map[state]
            note = self.audio.status_note()
            if total_pts > 0 and state in ("playing", "paused"):
                status_line += u"  ·  %d%%  ·  المتبقي %s" % (int(value), self.duration(rem_pts))
            if note and state in ("playing", "paused", "connecting"):
                status_line += u"  ·  " + note
            self.text("status", status_line, layout.SURA_PLAYER_STATUS)
            self.set_progress(value)
            self.place("progress", layout.SURA_PLAYER_PROGRESS)
        else:
            self.text("status", status_map[state], layout.SURA_PLAYER_STATUS)
            self.text("elapsed", u"00:00", layout.SURA_PLAYER_ELAPSED)
            if active_entry and isinstance(active_entry[0], int):
                total_str = self.catalog.surah_duration_str(active_entry[0], active_entry[1])
            else:
                total_str = u"—"
            self.text("duration", total_str, layout.SURA_PLAYER_DURATION)
            self.set_progress(0)
            self.place("progress", layout.SURA_PLAYER_PROGRESS)

    @staticmethod
    def progress_value(position, total):
        """Percent as a float (the bar uses tenths of a percent; texts show int())."""
        if not total or total <= 0:
            return 0
        return min(100.0, max(0.0, position * 100.0 / total))

    def set_progress(self, value):
        """Percent 0..100 (float). The gold fill is resized to exactly that share of the track."""
        self._progress_value = max(0.0, min(100.0, float(value or 0)))
        self._place_fill()

    def _place_fill(self):
        box = self._progress_box
        if box is None or "progress" not in self._shown_widgets:
            self.hide_widget("progress_fill")
            return
        self.laser("progress_fill", box, self._progress_value)

    def laser(self, name, box, percent):
        """Show `percent` of the track `box` with its laser image (cut, never squeezed)."""
        x, y, w, h = box
        px, py, pw, ph = layout.scaled(box, self.width)
        fill = int(round(pw * max(0.0, min(100.0, percent)) / 100.0))
        if fill < 2:
            self.hide_widget(name)
            return
        path = os.path.join(self.art, "laser-%dx%d.png" % (w, h))
        instance = self[name].instance
        if self._widget_cache.get((name, "value")) != path:
            if not os.path.isfile(path):
                path = os.path.join(self.art, "laser-368x12.png")
            instance.setPixmapFromFile(native(path))
            self._widget_cache[(name, "value")] = path
        position = (px, py, min(pw, fill), ph)
        if self._widget_cache.get((name, "box")) != position:
            instance.move(ePoint(px, py))
            instance.resize(eSize(min(pw, fill), ph))
            self._widget_cache[(name, "box")] = position
        if name not in self._shown_widgets:
            self[name].show()
            self._shown_widgets.add(name)

    @staticmethod
    def duration(pts):
        seconds = max(0, int(pts // PTS))
        hours, seconds = divmod(seconds, 3600)
        minutes, seconds = divmod(seconds, 60)
        return u"%d:%02d:%02d" % (hours, minutes, seconds) if hours else u"%02d:%02d" % (minutes, seconds)


    # ------------------------------------------------------------------ Mushaf Page-by-Page (الوجه) Audio Engine
    MUSHAF_AUDIO_PREFS_PATH = "/etc/enigma2/ultra-quran-mushaf-audio.json"
    MUSHAF_PAGE_RECITERS = (
        ("Husary_128kbps", u"الشيخ محمود خليل الحصري (مرتل)", "hafs"),
        ("Husary_128kbps_Mujawwad", u"الشيخ محمود خليل الحصري (مجود)", "hafs"),
        ("Minshawy_Murattal_128kbps", u"الشيخ محمد صديق المنشاوي (مرتل)", "hafs"),
        ("Minshawy_Mujawwad_192kbps", u"الشيخ محمد صديق المنشاوي (مجود)", "hafs"),
        ("Abdul_Basit_Murattal_192kbps", u"الشيخ عبد الباسط عبد الصمد (مرتل)", "hafs"),
        ("Abdul_Basit_Mujawwad_128kbps", u"الشيخ عبد الباسط عبد الصمد (مجود)", "hafs"),
        ("Alafasy_128kbps", u"الشيخ مشاري راشد العفاسي", "hafs"),
        ("Abdurrahmaan_As-Sudais_192kbps", u"الشيخ عبد الرحمن السديس", "hafs"),
        ("Saood_ash-Shuraym_128kbps", u"الشيخ سعود الشريم", "hafs"),
        ("Maher_AlMuaiqly_64kbps", u"الشيخ ماهر المعيقلي", "hafs"),
        ("Ghamadi_40kbps", u"الشيخ سعد الغامدي", "hafs"),
        ("Hudhaify_128kbps", u"الشيخ علي بن عبد الرحمن الحذيفي", "hafs"),
        ("Muhammad_Ayyoub_128kbps", u"الشيخ محمد أيوب", "hafs"),
        ("Mohammad_al_Tablaway_128kbps", u"الشيخ محمد محمود الطبلاوي", "hafs"),
        ("Muhammad_Jibreel_128kbps", u"الشيخ محمد جبريل", "hafs"),
        ("Abu_Bakr_Ash-Shaatree_128kbps", u"الشيخ أبو بكر الشاطري", "hafs"),
        ("Ahmed_ibn_Ali_al-Ajamy_64kbps_QuranExplorer.Com", u"الشيخ أحمد بن علي العجمي", "hafs"),
        ("Salah_Al_Budair_128kbps", u"الشيخ صلاح البدير", "hafs"),
        ("Abdullaah_3awwaad_Al-Juhaynee_128kbps", u"الشيخ عبد الله عواد الجهني", "hafs"),
        ("Ahmed_Neana_128kbps", u"الشيخ أحمد نعينع", "hafs"),
        ("mahmoud_ali_al_banna_32kbps", u"الشيخ محمود علي البنا", "hafs"),
        ("warsh/warsh_ibrahim_aldosary_128kbps", u"الشيخ إبراهيم الدوسري (رواية ورش)", "warsh"),
    )

    def _init_mushaf_audio_prefs(self):
        self.mushaf_reciter_slug = "Husary_128kbps"
        self.mushaf_hafs_slug = "Husary_128kbps"
        self.mushaf_page_repeat = False
        self.mushaf_audio_mode = False
        self.mushaf_audio_page = None
        self.jump_auto_play = False
        try:
            if os.path.isfile(self.MUSHAF_AUDIO_PREFS_PATH):
                with io.open(self.MUSHAF_AUDIO_PREFS_PATH, "r", encoding="utf-8") as handle:
                    data = json.load(handle)
                slug = data.get("reciter_slug")
                if slug and any(r[0] == slug for r in self.MUSHAF_PAGE_RECITERS):
                    self.mushaf_reciter_slug = slug
                hafs_slug = data.get("hafs_slug")
                if hafs_slug and any(r[0] == hafs_slug for r in self.MUSHAF_PAGE_RECITERS):
                    self.mushaf_hafs_slug = hafs_slug
                self.mushaf_page_repeat = bool(data.get("repeat_page", False))
        except Exception:
            pass

    def _save_mushaf_audio_prefs(self):
        try:
            payload = {
                "reciter_slug": self.mushaf_reciter_slug,
                "hafs_slug": self.mushaf_hafs_slug,
                "repeat_page": bool(self.mushaf_page_repeat),
            }
            with io.open(self.MUSHAF_AUDIO_PREFS_PATH, "w", encoding="utf-8") as handle:
                handle.write(u"%s" % json.dumps(payload, ensure_ascii=False))
        except Exception:
            pass

    def mushaf_reciter_name(self, slug=None):
        slug = slug or getattr(self, "mushaf_reciter_slug", "Husary_128kbps")
        for s, name, _ in self.MUSHAF_PAGE_RECITERS:
            if s == slug:
                return name
        return u"الشيخ محمود خليل الحصري (مرتل)"

    def mushaf_reciter_short_name(self, slug=None):
        return self.mushaf_reciter_name(slug).replace(u"الشيخ ", u"", 1)

    def mushaf_page_url(self, page, slug=None):
        slug = slug or getattr(self, "mushaf_reciter_slug", "Husary_128kbps")
        page = max(1, min(604, int(page)))
        return "https://everyayah.com/data/%s/PageMp3s/Page%03d.mp3" % (slug, page)

    def mushaf_audio_active(self):
        return bool(
            getattr(self, "mushaf_audio_mode", False)
            and self.audio is not None
            and self.playing_items
            and self.audio.state in ("connecting", "playing", "paused")
        )

    def mushaf_audio_is_current_page(self):
        if not self.mushaf_audio_active():
            return False
        url = self.mushaf_page_url(self.mushaf_page)
        local_url = self.downloader.local_media_path(url, is_video=False) or url
        try:
            cur_url = self.playing_items[self.playing_index][1][3]
            return cur_url in (url, local_url) and getattr(self, "mushaf_audio_page", None) == self.mushaf_page
        except Exception:
            return False

    def play_mushaf_page(self, page=None, announce=True):
        if page is not None:
            self.mushaf_page = max(1, min(604, int(page)))
        page = self.mushaf_page
        url = self.mushaf_page_url(page)
        play_url = self.downloader.local_media_path(url, is_video=False) or url
        rec_name = self.mushaf_reciter_name()
        pdata = self.mushaf.page_data(page) or {}
        surahs_str = u" · ".join(pdata.get("surahs") or [u"القرآن الكريم"])
        title = u"تلاوة الوجه %d (صفحة %d)  ·  %s" % (page, page, surahs_str)
        badge = u"تلاوة الوجه %d من 604" % page
        self.playing_items = [("lib", (title, rec_name, badge, url))]
        self.playing_index = 0
        self.lib_durations = {url: 0}
        self.lib_route = None
        self.lib_indices = []
        self.mushaf_audio_mode = True
        self.mushaf_audio_page = page
        if self.audio is not None:
            self.audio.play(title, play_url, False, 0, who=rec_name)
        next_page = (page % 604) + 1
        try:
            fastlink.prefetch(self.mushaf_page_url(next_page))
            self.mushaf.request_page(next_page, full_download=False)
        except Exception:
            pass
        if self.route.name == "mushaf":
            self.render()
        if announce:
            mode_lbl = u"تكرار الوجه للحفظ" if self.mushaf_page_repeat else u"تتابع الأوجه تلقائياً"
            self.flash(u"تلاوة الوجه %d  ·  %s  ·  %s" % (page, self.mushaf_reciter_short_name(), mode_lbl))

    def toggle_mushaf_page_audio(self):
        if self.mushaf_audio_is_current_page() and self.audio is not None:
            if self.audio.state in ("playing", "paused"):
                self.audio.toggle()
                self.top_strip()
                self._update_mushaf_state_label()
                if self.audio.state == "paused":
                    self.flash(u"تم إيقاف تلاوة الوجه %d مؤقتاً  ·  اضغط الأخضر للاستئناف" % self.mushaf_page)
                else:
                    self.flash(u"استئناف تلاوة الوجه %d  ·  %s" % (self.mushaf_page, self.mushaf_reciter_short_name()))
                return
        self.play_mushaf_page(self.mushaf_page, announce=True)

    def select_mushaf_reciter(self, slug):
        self.mushaf_reciter_slug = slug
        for s, _, riw in self.MUSHAF_PAGE_RECITERS:
            if s == slug and riw == "hafs":
                self.mushaf_hafs_slug = slug
                break
        self._save_mushaf_audio_prefs()
        self.play_mushaf_page(self.mushaf_page, announce=True)

    def open_mushaf_reciter_menu(self):
        cur_idx = 0
        options = []
        for idx, (slug, name, _) in enumerate(self.MUSHAF_PAGE_RECITERS):
            title, _, edition = name.partition(u" (")
            details = edition.rstrip(u")")
            if slug == self.mushaf_reciter_slug:
                cur_idx = idx
                details = (details + u"  ·  " if details else u"") + u"القارئ الحالي"
            label = title + (u"\n" + details if details else u"")
            options.append((label, lambda s=slug: self.select_mushaf_reciter(s)))
        self.open_choice(
            u"اختيار قارئ المصحف",
            u"",
            options,
            index=cur_idx,
            mushaf_panel="reciters",
        )

    def toggle_mushaf_page_repeat(self):
        self.mushaf_page_repeat = not getattr(self, "mushaf_page_repeat", False)
        self._save_mushaf_audio_prefs()
        if self.route.name == "mushaf":
            self._update_mushaf_state_label()
        if self.mushaf_page_repeat:
            self.flash(u"نظام التلاوة: تكرار الوجه %d تلقائياً (للحفظ والمراجعة)" % self.mushaf_page)
        else:
            self.flash(u"نظام التلاوة: انتقال تلقائي للوجه التالي وتقليب الصفحات مع القارئ")

    def start_mushaf_page_jump_and_play(self):
        self.jump_auto_play = True
        self.jump_buffer = ""
        self.jump_label()

    def open_mushaf_page_download_menu(self):
        page = self.mushaf_page
        rec_short = self.mushaf_reciter_short_name()
        url = self.mushaf_page_url(page)
        item = {
            "title": u"تلاوة الوجه %03d · %s" % (page, rec_short),
            "badge": u"الوجه %d من 604" % page,
            "audio": url,
        }
        all_items = [
            {
                "title": u"تلاوة الوجه %03d · %s" % (p, rec_short),
                "badge": u"الوجه %d من 604" % p,
                "audio": self.mushaf_page_url(p),
            }
            for p in range(1, 605)
        ]
        sec_title = u"تلاوات أوجه المصحف · " + rec_short
        if self.downloader.is_media_downloaded(url, is_video=False):
            one_lbl = u"تلاوة الوجه %d محفوظة على الهارد" % page
        else:
            one_lbl = u"تحميل تلاوة الوجه %d" % page
        options = [
            (one_lbl, lambda: self._download_one(item, sec_title, False)),
            (u"تحميل المصحف الصوتي كاملاً\n604 وجه",
             lambda: self._download_folder(all_items, sec_title, sec_title)),
        ]
        self.open_choice(u"تحميل التلاوة للهارد", rec_short, options, mushaf_panel="downloads")

    def open_mushaf_translation_submenu(self):
        cur_lang = self.mushaf_translation.language
        cur_idx = 0
        options = []
        for idx, (key, title) in enumerate(LANGUAGES):
            if key == cur_lang:
                cur_idx = idx
                lbl = u"• %s" % title
            else:
                lbl = title
            options.append((lbl, lambda k=key: self.select_translation(k)))
        self.open_choice(u"لغة ترجمة معاني القرآن", u"", options, index=cur_idx, mushaf_panel="translations")

    def _update_mushaf_state_label(self):
        if self.route.name != "mushaf":
            return
        page = self.mushaf_page
        subs = max(1, getattr(self, "tafsir_subs", 1))
        if self.mushaf_audio_active() and getattr(self, "mushaf_audio_page", None) == page:
            st = self.audio.state if self.audio is not None else "idle"
            st_lbl = u"متوقف مؤقتاً" if st == "paused" else (u"جارٍ الاتصال…" if st == "connecting" else u"قيد التلاوة الآن")
            mode_lbl = u"تكرار الوجه للحفظ" if self.mushaf_page_repeat else u"تتابع الأوجه تلقائياً"
            line1 = u"%s  ·  الوجه %d  ·  %s" % (st_lbl, page, self.mushaf_reciter_short_name())
            line2 = u"%s  ·  الأخضر: إيقاف/تشغيل  ·  MENU: القارئ" % mode_lbl
            self.text("mushaf_state", plain(line1 + u"\n" + line2), layout.MUSHAF_STATE)
            return
        bulk = self.mushaf.bulk_state()
        if bulk["saved"] >= 604:
            second = u"الأخضر: سماع الوجه %d  ·  MENU: اختيار القارئ (%s)" % (page, self.mushaf_reciter_short_name())
        elif bulk["running"]:
            second = u"جارٍ تحميل المصحف %d/604  ·  الأخضر: سماع الوجه %d" % (bulk["saved"], page)
        elif bulk["error"]:
            second = u"الأخضر: سماع الوجه %d  ·  الأزرق: متابعة تحميل المصحف (%d/604)" % (page, bulk["saved"])
        else:
            second = u"الأخضر: سماع الوجه %d (%s)  ·  الأزرق: تحميل المصحف" % (page, self.mushaf_reciter_short_name())
        line1 = u"%s  ·  الوجه %d  ·  التفسير %d/%d" % (self.mushaf.riwaya_name(), page, self.tafsir_sub + 1, subs)
        self.text("mushaf_state", plain(line1 + u"\n" + second), layout.MUSHAF_STATE)

    def open_text_size_menu(self):
        labels = dict(TEXT_SIZES)
        options = [(u"%s (%d%%)" % (label, size), lambda size=size: self.set_text_size(size))
                   for size, label in TEXT_SIZES]
        current = next(i for i, (size, label) in enumerate(TEXT_SIZES) if size == self.text_size)
        self.open_choice(u"حجم الخط", u"الحجم الحالي: %s" % labels[self.text_size], options, index=current)

    def set_text_size(self, size):
        if size == self.text_size or size not in dict(TEXT_SIZES):
            return
        self.text_size = size
        self.tafsir_sub = self.translation_sub = 0
        self.render()
        try:
            with io.open(TEXT_SIZE_PATH + ".tmp", "w", encoding="ascii") as handle:
                handle.write(u"%d chosen\n" % size)
            os.rename(TEXT_SIZE_PATH + ".tmp", TEXT_SIZE_PATH)
        except (IOError, OSError):
            log_exception("Could not save the text size preference")
            self.flash(u"تم تغيير حجم الخط للجلسة الحالية")

    def translation_menu(self):
        if self.route.name != "mushaf":
            if self.route.name == "home":
                self.open_home_menu()
            return
        panel = self.dialog.get("mushaf_panel") if self.dialog else None
        audio_active = self.mushaf_audio_active()
        if audio_active and panel in (None, "main"):
            self.open_mushaf_reciter_menu()
            return
        if panel == "main":
            self.close_dialog()
            return

        rec_short = self.mushaf_reciter_short_name()
        is_playing = self.mushaf_audio_is_current_page() and self.audio.state == "playing"
        play_label = u"إيقاف التلاوة مؤقتاً" if is_playing else u"تشغيل تلاوة الوجه الحالي"
        repeat_label = u"تكرار الوجه الحالي للحفظ" if self.mushaf_page_repeat else u"تتابع الأوجه تلقائياً"
        language = dict(LANGUAGES)[self.mushaf_translation.language]
        options = [
            (play_label, self.toggle_mushaf_page_audio),
            (u"اختيار قارئ المصحف\n" + rec_short, self.open_mushaf_reciter_menu),
            (u"الانتقال إلى وجه بالرقم\nتشغيل التلاوة فوراً", self.start_mushaf_page_jump_and_play),
            (u"نظام التلاوة\n" + repeat_label, self.toggle_mushaf_page_repeat),
            (u"تحميل التلاوة للهارد\nالوجه الحالي أو المصحف الصوتي كاملاً", self.open_mushaf_page_download_menu),
            (u"لغة ترجمة معاني القرآن\n" + language, self.open_mushaf_translation_submenu),
            (u"فتح مكتبة القرّاء الكاملة", lambda: self.open(Route("gallery", self.catalog.reciters))),
            (u"حجم خط الواجهة", self.open_text_size_menu),
        ]
        self.open_choice(u"قائمة المصحف", u"", options, mushaf_panel="main")

    def select_translation(self, language):
        self.mushaf_translation.select(language)
        self.translation_sub = 0
        self.render()

    def render_mushaf_translation(self, page):
        language = self.mushaf_translation.language
        self.text("mushaf_translation_title", u"ترجمة معاني القرآن", layout.MUSHAF_TRANS_TITLE)
        self.text("mushaf_translation_language", dict(LANGUAGES)[language], layout.MUSHAF_TRANS_LANG)
        self.text("mushaf_translation_page", u"الوجه (صفحة) %d من 604" % page, layout.MUSHAF_TRANS_PAGE)
        key = (language, self.mushaf.riwaya, page, self.width, self.text_size)
        x, y, width, height = layout.MUSHAF_TRANS_TEXT
        size = self.scaled_font(MUSHAF_TRANSLATION_ROWS[0])
        pixels = max(6, layout.pixel(size, self.width))
        line_height = max(layout.MUSHAF_TRANS_LINE_HEIGHT, int(size * LINE_HEIGHT + 0.999) + 2)
        step = (layout.MUSHAF_TRANS_LINE_STEP * self.text_size + 50) // 100
        if self.translation_layout is None or self.translation_layout[0] != key:
            source = None
            try:
                rows, source = self.mushaf_translation.page(self.mushaf.riwaya, page)
            except (IOError, OSError, ValueError, TypeError, KeyError, IndexError):
                log_exception("Could not read the current Mushaf page translation")
                rows = ()
            target_width = layout.scaled(layout.MUSHAF_TRANS_TEXT, self.width)[2]
            margin = text_width_pad(pixels) + max(2, layout.pixel(5, self.width))
            lines = translation_lines(rows, target_width - margin, pixels)
            self.translation_layout = (key, lines, source)
        _, lines, source = self.translation_layout
        per_page = min(len(MUSHAF_TRANSLATION_ROWS), 1 + (height - line_height) // step)
        self.translation_subs = max(1, (len(lines) + per_page - 1) // per_page)
        self.translation_sub %= self.translation_subs
        start = self.translation_sub * per_page
        shown = lines[start:start + per_page] or [u"الترجمة غير متوفرة لهذه الصفحة"]
        for index, (name, line) in enumerate(zip(MUSHAF_TRANSLATION_ROWS, shown)):
            self._set_label_font(name, pixels)
            self.text(name, line, (x, y + index * step, width, line_height))
        self.text("mushaf_translation_hint", u"MENU: قائمة المصحف  ·  2 / 8: الترجمة  ·  %d/%d" %
                  (self.translation_sub + 1, self.translation_subs), layout.MUSHAF_TRANS_HINT)
        if lines:
            x, y, width, height = layout.MUSHAF_TRANS_PROGRESS
            fill = max(1, width * (self.translation_sub + 1) // self.translation_subs)
            self.place("mushaf_translation_fill", (x, y, fill, height))
        if source:
            self.text("mushaf_translation_credit", u"%s v%s · %s" %
                      (source["source"], source["version"], source["publisher_credit"].split(" - ", 1)[-1]),
                      layout.MUSHAF_TRANS_CREDIT)

    def render_mushaf(self):
        page = self.mushaf_page
        mode = self.mushaf_mode
        self.mushaf.request_page(page, full_download=True)
        self.image("mframe", "mushaf-frame", layout.MUSHAF_FRAME)
        if not (self.dialog and self.dialog.get("mushaf_panel")):
            self.render_mushaf_translation(page)
        pdata = self.mushaf.page_data(page)
        has_img = self.mushaf.has_image(page)
        juz_num = (pdata or {}).get("juz") or ((page - 1) // 20 + 1)
        surahs_str = (pdata or {}).get("surahs") or [u"القرآن الكريم"]
        self.text("mushaf_surah", flat_text(plain(u" · ".join(surahs_str))), layout.MUSHAF_SURAH)
        self.text("mushaf_juz", u"الجزء %d  ·  الوجه (صفحة) %d من 604" % (juz_num, page), layout.MUSHAF_JUZ)
        rows = self.mushaf.tafsir(page)
        lines = []
        last_surah = None
        for surah_name, ayah_no, body in rows:
            if surah_name != last_surah and (last_surah is not None or ayah_no == 1):
                lines.append(u"﴿ سورة %s ﴾" % surah_name)
            last_surah = surah_name
            lines.extend(textwrap.wrap(u"(%d) %s" % (ayah_no, body), 38 * 100 // self.text_size,
                                       break_long_words=False, break_on_hyphens=False))
            lines.append(u"")
        while lines and not lines[-1]:
            lines.pop()
        size = self.scaled_font("mushaf_tafsir")
        per = (layout.MUSHAF_TAFSIR[3] - 2) // int(size * LINE_HEIGHT + 0.999)
        subs = max(1, (len(lines) + per - 1) // per)
        self.tafsir_subs = subs
        self.tafsir_sub %= subs
        shown = lines[self.tafsir_sub * per:(self.tafsir_sub + 1) * per]
        self._set_label_font("mushaf_tafsir", max(6, layout.pixel(size, self.width)))
        self.text("mushaf_tafsir", plain(u"\n".join(shown)) if shown else u"التفسير الميسر غير متوفر لهذه الصفحة", layout.MUSHAF_TAFSIR)
        self._update_mushaf_state_label()
        self.set_progress(page * 100.0 / 604)
        self.place("progress", layout.MUSHAF_PROGRESS)

        if has_img and mode == "large":
            halves = self.mushaf.page_halves(page)
            self.mushaf_half = min(self.mushaf_half, halves - 1)
            path = self.mushaf.page_image_path(page, half=self.mushaf_half)
            if path:
                self.image("page", path, layout.MUSHAF_IMG, external=True)
                if halves > 1:
                    self.text("mushaf_juz", u"الجزء %d  ·  الوجه %d  ·  %s" % (
                        juz_num, page, u"النصف الأول" if self.mushaf_half == 0 else u"النصف الثاني"), layout.MUSHAF_JUZ)
                return
        if has_img and mode in ("image", "large"):
            path = self.mushaf.page_image_path(page)
            if path:
                self.image("page", path, layout.MUSHAF_IMG, external=True)
                return
        if self.mushaf.page_failed(page) or self.mushaf.bulk_state()["error"]:
            hint = u"تعذّر تحميل صفحة %d\nتحقق من الإنترنت ثم اضغط الزر الأزرق\nلتحميل المصحف كامل وحفظه على الهارد" % page
        else:
            hint = u"جارٍ تحميل صفحة %d\nمصحف %s\nتُحفظ الصفحة على الهارد للتصفح بدون إنترنت" % (page, self.mushaf.riwaya_name())
        self.text("mushaf_hint", plain(hint), layout.MUSHAF_IMG)

    def move(self, direction):
        """Move across the current screen using the remote's directional keys."""
        route = self.route
        if self.jump_buffer is not None:
            return
        if route.name == "video":
            self.show_video_osd(auto_hide=True)
            if direction == "up":
                self.skip_video(-1)
            elif direction == "down":
                self.skip_video(1)
            return
        if route.name == "mushaf":
            if direction in ("up", "down"):
                self.tafsir_sub = (self.tafsir_sub + (1 if direction == "down" else -1)) % max(1, getattr(self, "tafsir_subs", 1))
                self.render()
            else:
                self.mushaf_turn(1 if direction == "left" else -1)
            return
        old_idx = route.index
        if route.name == "home":
            self.move_home(direction)
            return
        deck = self.deck_size()
        if deck:
            if direction in ("left", "right"):
                route.index = (route.index + (1 if direction == "left" else -1)) % deck
                self.render()
            return
        if route.name == "quiz":
            route.index = grid_step(route.index, 4, 2, direction)
            if route.index != old_idx:
                self.highlight(layout.LCARDS[route.index], "lib")
            return
        if route.name in ("gallery", "lgallery"):
            cols, page_size = layout.POSTER_COLS, layout.POSTER_PAGE_SIZE
            if not route.items:
                return
            route.index = grid_step(route.index, len(route.items), cols, direction)
            if route.index != old_idx and (old_idx // page_size) == (route.index // page_size):
                start = (route.index // page_size) * page_size
                self.highlight(layout.POSTERS[route.index - start], "poster")
                self._update_gallery_counter()
                return
        elif route.name in ("main_folders", "editions", "shaarawy", "shaarawy_folders", "reciter_videos"):
            if not route.items:
                return
            if route.name == "main_folders":
                route.index = grid_step(route.index, len(route.items), 4, direction)
                if route.index != old_idx:
                    self.highlight(layout.PORTAL_CARDS[route.index], "portal")
                return
            route.index = grid_step(route.index, len(route.items), layout.ECARD_COLS, direction)
            if route.index == old_idx:
                return
            page_size = layout.ECARD_PAGE_SIZE
            if (old_idx // page_size) == (route.index // page_size):
                start = (route.index // page_size) * page_size
                self.highlight(layout.ECARDS[route.index - start], "ecard")
                if route.name == "shaarawy_folders":
                    self._update_shaarawy_folders_bio_panel()
                elif route.name == "shaarawy":
                    self._update_shaarawy_bio_panel()
                return
        elif route.name == "library" and route.items:
            route.index = grid_step(route.index, len(route.items), layout.LIB_COLS, direction)
            if route.index == old_idx:
                return
            page_size = layout.LIB_PAGE_SIZE
            if (old_idx // page_size) == (route.index // page_size):
                start = (route.index // page_size) * page_size
                self.highlight(layout.LCARDS[route.index - start], "lib")
                self._update_library_reader()
                return
        elif route.name in ("surahs", "radios", "favorites") and route.items:
            route.index = grid_step(route.index, len(route.items), layout.SURA_COLS, direction)
            if route.index == old_idx:
                return
            page_size = layout.SURA_PAGE_SIZE
            if (old_idx // page_size) == (route.index // page_size):
                start = (route.index // page_size) * page_size
                self.highlight(layout.SURA_CARDS[route.index - start], "sura")
                self.render_integrated_player()
                return
        self.render()

    def mushaf_turn(self, direction):
        """Walk the large-print halves before turning the page."""
        if self.mushaf_mode == "large" and self.mushaf.has_image(self.mushaf_page):
            halves = self.mushaf.page_halves(self.mushaf_page)
            target = self.mushaf_half + direction
            if 0 <= target < halves:
                self.mushaf_half = target
                self.render()
                return
            self.page_step(direction)
            if direction < 0 and self.mushaf.has_image(self.mushaf_page):
                self.mushaf_half = self.mushaf.page_halves(self.mushaf_page) - 1
                self.render()
            return
        self.page_step(direction)

    def page_step(self, direction):
        """Page up / down (CH+/CH-). Circular too: past the last page goes to the first, and back."""
        route = self.route
        if route.name == "video":
            self.skip_video(direction)
            return
        if route.name == "home":
            if direction > 0 and route.index < layout.HOME_PAGE_SIZE:
                route.index = layout.HOME_PAGE_SIZE - layout.HOME_COLUMNS + route.index % layout.HOME_COLUMNS
                self.move_home("down")
            elif direction < 0 and route.index >= layout.HOME_PAGE_SIZE:
                self.home_first_page()
            return
        if route.name == "mushaf":
            self.mushaf_page = (self.mushaf_page - 1 + direction) % 604 + 1
            self.translation_sub = 0
            self.mushaf_half = 0
            self.tafsir_sub = 0
            if self.mushaf_audio_active():
                self.play_mushaf_page(self.mushaf_page, announce=True)
                return
        elif route.name == "quiz":
            route.question_index = (route.question_index + direction) % len(route.items)
            route.answered = None
            route.index = 0
        else:
            sizes = {
                "gallery": layout.POSTER_PAGE_SIZE, "lgallery": layout.POSTER_PAGE_SIZE,
                "main_folders": layout.ECARD_PAGE_SIZE,
                "editions": layout.ECARD_PAGE_SIZE,
                "shaarawy": layout.ECARD_PAGE_SIZE, "shaarawy_folders": layout.ECARD_PAGE_SIZE,
                "reciter_videos": layout.ECARD_PAGE_SIZE, "library": layout.LIB_PAGE_SIZE,
                "surahs": layout.SURA_PAGE_SIZE, "radios": layout.SURA_PAGE_SIZE,
                "favorites": layout.SURA_PAGE_SIZE,
            }
            size = sizes.get(route.name)
            if not size or not route.items:
                return
            pages = (len(route.items) + size - 1) // size
            page = ((route.index // size) + direction) % pages
            # keep the same slot on the new page when it exists, otherwise land on the page's last item
            route.index = min(len(route.items) - 1, page * size + route.index % size)
        self.render()

    def _open_shaarawy_item(self, item, owner_id=999):
        route = self.route
        if item.get("video"):
            video_items = [it for it in route.items if it.get("video")] or [item]
            try:
                vid_idx = video_items.index(item)
            except ValueError:
                vid_idx = 0
            self.video_osd_visible = True
            self.open(Route("video", video_items, key=owner_id, index=vid_idx))
            self._start_video_episode()
        elif item.get("audio"):
            self.play_library_item(item, MAHMOUD_NAME if owner_id == MAHMOUD_VIDEO_OWNER else u"الشيخ محمد متولي الشعراوي")
            self.render()

    def _start_video_episode(self):
        route = self.route
        if route.name != "video" or not route.items:
            return
        self._cancel_youtube_lookup()
        item = route.items[route.index]
        if item.get("youtube_id"):
            if self.audio is None:
                return
            self.audio.release()
            self.playing_items = None
            self.playing_index = None
            lookup = {"cancel": threading.Event(), "result": None, "item": item}
            self.youtube_lookup = lookup

            def resolve():
                try:
                    from .youtube import UltraYouTubeResolver
                    lookup["result"] = UltraYouTubeResolver().extract_candidates(
                        item["youtube_id"], cancel_event=lookup["cancel"])
                except Exception:
                    log_exception("YouTube video resolution failed")
                    lookup["result"] = []

            worker = threading.Thread(target=resolve)
            worker.daemon = True
            worker.start()
            self.show_video_osd(auto_hide=False)
            return
        url = item["audio"]
        play_url = self.downloader.local_media_path(url, is_video=True) or url
        self._play_video_source(item, play_url)

    def _cancel_youtube_lookup(self):
        if self.youtube_lookup is not None:
            self.youtube_lookup["cancel"].set()
            self.youtube_lookup = None

    def _finish_youtube_lookup(self):
        lookup = self.youtube_lookup
        if lookup is None or lookup["result"] is None:
            return
        self.youtube_lookup = None
        if self.route.name != "video" or self.route.items[self.route.index] is not lookup["item"]:
            return
        if not lookup["result"]:
            self.audio._fail(u"لم يتوفر بث للفيديو على يوتيوب")
            return
        from .youtube import watch_url
        item = lookup["item"]
        self._play_video_source(item, watch_url(item["youtube_id"]), lookup["result"])

    def _play_video_source(self, item, url, video_streams=()):
        owner = self.video_owner()[1]
        track_entry = ("lib", (item["title"], owner, item.get("badge", u"فيديو مرئي"), url))
        self.playing_items = [track_entry]
        self.playing_index = 0
        if self.audio is not None:
            self.audio.play(item["title"], url, False, self.clock_seconds(item.get("duration")), video=True,
                            who=owner, video_streams=video_streams)
        self._prefetch_focus()
        self.show_video_osd(auto_hide=True)

    @staticmethod
    def clock_seconds(text):
        try:
            parts = [int(p) for p in (text or u"").split(":") if p.strip().isdigit()]
        except Exception:
            return 0
        total = 0
        for part in parts[-3:]:
            total = total * 60 + part
        return total if len(parts) >= 2 else 0

    def skip_video(self, step):
        route = self.route
        if route.name != "video" or not route.items:
            return
        route.index = (route.index + step) % len(route.items)
        self._start_video_episode()

    def accept(self):
        if self.bio_open and self.route.name == "mahmoud_hub":
            self.close_bio()
            return
        if self.bio_open:
            self.bio_open = False          # entering anything closes the full biography first
        route = self.route
        if self.jump_buffer is not None:
            self.commit_jump()
        elif route.name == "video":
            if self.video_osd_visible:
                self.video_osd_visible = False
                self.video_osd_timer.stop()
                self.render()
            else:
                self.show_video_osd(auto_hide=True)
        elif route.name == "home" and self.arrange is not None:
            self.arrange_ok()
        elif route.name == "home":
            key = self.home_shown[route.index]
            if key == 0:
                self.open_quran_gallery("reciters")
            elif key == 20:
                self.open(Route("mushaf", key=self.mushaf.base_dir))
            elif key == 21:
                self.open_quran_gallery("mubtahileen")
            elif key == 22:
                self.open(Route("reciter_hub", self.catalog.reciter_hub_folders(950), 950))
            elif key == 1:
                self.open(Route("shaarawy_folders", self.catalog.libraries[1]["folders"], key=1,
                                folder_title=self.catalog.libraries[1].get("title")))
            elif key == 10:
                self.open(Route("radios", [(None, radio[0]) for radio in self.catalog.radios]))
            elif key == 14:
                self.open(Route("quiz", self.catalog.libraries[14]["questions"], key=14))
            elif key in self.catalog.libraries:
                items = self.catalog.libraries[key]["items"]
                if key == 11 and len(items) == 4:
                    items = [items[1], items[3], items[0], items[2]]
                if key != MAHMOUD_LIBRARY and gallery_items(items):
                    self.open(Route("lgallery", items, key=key))      # series / programmes / preachers as posters
                else:
                    self.open(Route("mahmoud_hub" if key == MAHMOUD_LIBRARY else "library", items, key=key))
            else:
                self.flash(u"القسم قيد الإعداد")
        elif route.name == "gallery":
            key, _, editions = route.items[route.index]
            self.open(Route("reciter_hub", self.catalog.reciter_hub_folders(key), key))
        elif route.name == "lgallery":
            item = route.items[route.index]
            children = folder_items(item)
            if gallery_items(children):
                self.open(Route("lgallery", children, key=route.key, folder_title=item["title"]))
            elif route.key in (1, MAHMOUD_VIDEO_OWNER):
                key = MAHMOUD_VIDEO_OWNER if route.key == MAHMOUD_VIDEO_OWNER else route.index
                self.open(Route("shaarawy", children, key=key, folder_title=item["title"]))
            else:
                self.open(Route("library", children, key=route.key, folder_title=item["title"]))
        elif route.name == "reciter_hub":
            reciter_id = route.key
            folder = route.items[route.index]["id"]
            if folder == "audio":
                editions = self.catalog.reciter[reciter_id][2]
                self.open(Route("editions", editions, reciter_id))
            elif folder == "youtube":
                items = self.catalog.reciter_youtube_folders(reciter_id)
                self.open(Route("library", items, RECITER_YOUTUBE_LIBRARY,
                                folder_title=self.catalog.reciter[reciter_id][1]))
            else:
                self.catalog.request_reciter_videos(reciter_id, retry=True)
                videos = self.catalog.reciter_videos(reciter_id)
                self.open(Route("reciter_videos", videos, reciter_id))
        elif route.name == "reciter_videos":
            if route.items:
                self._open_shaarawy_item(route.items[route.index], owner_id=route.key)
        elif route.name == "editions":
            key = route.items[route.index][0]
            self.open(Route("surahs", self.catalog.tracks(key), key))
        elif route.name in ("main_folders", "shaarawy_folders") and route.items:
            folder = route.items[route.index]
            action = folder.get("action")
            if action == "reciters_gallery":
                self.open_quran_gallery("reciters")
            elif action == "mubtahileen_gallery":
                self.open_quran_gallery("mubtahileen")
            elif action == "kishk_hub":
                self.open(Route("reciter_hub", self.catalog.reciter_hub_folders(950), 950))
            elif action == "mushaf_viewer":
                self.open(Route("mushaf", key=self.mushaf.base_dir))
            elif gallery_items(folder_items(folder)):
                self.open(Route("lgallery", folder_items(folder), key=route.key, folder_title=folder["title"]))
            elif folder.get("folders"):
                self.open(Route("shaarawy_folders", folder["folders"], key=route.key, folder_title=folder["title"]))
            elif folder.get("children"):
                children = folder["children"]
                if any(ch.get("children") or ch.get("folders") for ch in children):
                    self.open(Route("shaarawy_folders", children, key=route.key, folder_title=folder["title"]))
                else:
                    sub_key = MAHMOUD_VIDEO_OWNER if route.key == MAHMOUD_VIDEO_OWNER else route.index
                    self.open(Route("shaarawy", children, key=sub_key, folder_title=folder["title"]))
            else:
                sub_key = MAHMOUD_VIDEO_OWNER if route.key == MAHMOUD_VIDEO_OWNER else route.index
                self.open(Route("shaarawy", folder["items"], key=sub_key, folder_title=folder["title"]))
        elif route.name == "shaarawy" and route.items:
            owner = MAHMOUD_VIDEO_OWNER if route.key == MAHMOUD_VIDEO_OWNER else 999
            self._open_shaarawy_item(route.items[route.index], owner_id=owner)
        elif route.name == "mahmoud_hub":
            folder = route.items[route.index]
            children = folder["children"]
            if gallery_items(children):
                self.open(Route("lgallery", children, key=MAHMOUD_VIDEO_OWNER, folder_title=folder["title"]))
            elif any(ch.get("children") or ch.get("folders") for ch in children):
                self.open(Route("shaarawy_folders", children, key=MAHMOUD_VIDEO_OWNER, folder_title=folder["title"]))
            else:
                self.open(Route("shaarawy", children, key=MAHMOUD_VIDEO_OWNER, folder_title=folder["title"]))
        elif route.name == "library":
            item = route.items[route.index]
            if item.get("children"):
                children = item["children"]
                next_view = "lgallery" if gallery_items(children) else "library"
                self.open(Route(next_view, children, key=route.key, folder_title=item["title"]))
            elif item.get("video") and (item.get("audio") or item.get("youtube_id")):
                owner = item.get("owner") or route.folder_title or self.catalog.libraries[route.key]["title"]
                if route.key == MAHMOUD_LIBRARY:
                    owner = MAHMOUD_VIDEO_OWNER
                self._open_shaarawy_item(item, owner_id=owner)
            elif item.get("source_qr") and not item.get("audio"):
                self.flash(u"امسح رمز QR بكاميرا الموبايل لفتح المصدر")
            elif item.get("counter"):
                target = item["counter"]
                k = (route.key, route.index)
                val = self.tasbih_counts.get(k, 0) + 1
                completed = val >= target
                self.tasbih_counts[k] = 0 if completed else val
                self.render()
                if completed:
                    self.flash(u"تقبّل الله! أتممت الورد · %d مرة" % target)
            elif item.get("edition") and item["edition"] in self.catalog.edition:
                ed_key = item["edition"]
                self.open(Route("surahs", self.catalog.tracks(ed_key), ed_key))
            elif item.get("audio"):
                self.play_library_item(item, route.folder_title or self.catalog.libraries[route.key]["title"])
            else:
                if route.index + 1 < len(route.items):
                    route.index += 1
                    self.render()
        elif route.name == "quiz":
            q_obj = route.items[route.question_index % len(route.items)]
            if route.answered is None:
                route.answered = route.index
                correct = (route.index == q_obj["answer"])
                if correct:
                    route.score += 1
                self.render()
                if correct:
                    self.flash(u"إجابة صحيحة! أحسنت")
                else:
                    self.flash(u"الإجابة الصحيحة: " + q_obj["options"][q_obj["answer"]])
            else:
                route.question_index = (route.question_index + 1) % len(route.items)
                route.answered = None
                route.index = 0
                self.render()
        elif route.name == "mushaf":
            self.mushaf_half = 0
            self.mushaf_mode = "large" if self.mushaf_mode == "image" else "image"
            self.render()
            self.flash(u"وضع العرض: خط كبير" if self.mushaf_mode == "large" else u"وضع العرض: الصفحة كاملة")
        elif route.name in ("surahs", "radios", "favorites") and route.items:
            selected = route.items[route.index]
            current_playing = (
                self.playing_items[self.playing_index]
                if (self.playing_items and self.playing_index is not None and 0 <= self.playing_index < len(self.playing_items))
                else None
            )
            if current_playing == selected and self.audio is not None and self.audio.state in ("playing", "paused", "error", "finished"):
                self.play_control()
            else:
                self.mushaf_audio_mode = False
                prev_idx = self.playing_index if self.playing_items == route.items else None
                self.playing_items = list(route.items)
                self.playing_index = route.index
                self.start_track(prev_index=prev_idx)

    @staticmethod
    def _playlist_item(item):
        return bool(item.get("audio")) and not item.get("video") and not item.get("children") and not item.get("live") \
            and "qurango.net/radio" not in item.get("audio", "")

    def play_library_item(self, item, section_title):
        """Plays the item and queues the folder's other recordings after it (auto-continue, keys 2 / 8)."""
        url = item["audio"]
        play_url = self.downloader.local_media_path(url, is_video=False) or url
        is_live = False if play_url.startswith("/") else bool(item.get("live", "qurango.net/radio" in url))
        current = None
        if self.playing_items and self.playing_index is not None and 0 <= self.playing_index < len(self.playing_items):
            current = self.playing_items[self.playing_index]
        if (current is not None and current[0] == "lib" and current[1][3] in (url, play_url)
                and self.audio is not None and self.audio.state in ("playing", "paused")):
            self.play_control()
            return
        route = self.route
        items = route.items if (route.items and item in route.items) else [item]
        entries, indices = [], []
        self.lib_durations = {}
        if is_live or not self._playlist_item(item):
            entries = [("lib", (item["title"], section_title, item.get("badge", u"صوتيات إسلامية"), play_url))]
            indices = [route.items.index(item) if item in (route.items or []) else None]
        else:
            for i, it in enumerate(items):
                if it is item or self._playlist_item(it):
                    entries.append(("lib", (it["title"], section_title, it.get("badge", u"صوتيات إسلامية"), it["audio"])))
                    indices.append(i if items is route.items else None)
                    self.lib_durations[it["audio"]] = self.clock_seconds(it.get("duration"))
        self.mushaf_audio_mode = False
        self.playing_items = entries
        self.playing_index = next(n for n, e in enumerate(entries) if e[1][3] in (url, play_url))
        self.lib_route = route
        self.lib_indices = indices
        self.audio.play(item["title"], play_url, is_live, 0 if is_live else self.clock_seconds(item.get("duration")),
                        who=self.playing_who(self.playing_items[self.playing_index]))
        if self.route.name == "library":
            self._update_library_reader()
        elif self.route.name == "shaarawy":
            self._update_shaarawy_bio_panel()

    def start_track(self, prev_index=None):
        """Instant Surah start without redundant full-screen redraws."""
        if not self.playing_items or self.playing_index is None:
            return
        entry = self.playing_items[self.playing_index]
        title, _, _, url, _ = self.catalog.track(entry)
        if isinstance(entry[0], int) and self.downloader.is_downloaded(entry[0], entry[1]):
            url = self.downloader.surah_path(entry[0], entry[1])
        elif entry[0] == "lib":
            url = self.downloader.local_media_path(url, is_video=False) or url
        is_live = (entry[0] is None) or (entry[0] == "lib" and "qurango.net/radio" in url)
        expected = 0
        if entry[0] == "lib":
            expected = getattr(self, "lib_durations", {}).get(entry[1][3], 0)
            indices = getattr(self, "lib_indices", None) or []
            library_route = getattr(self, "lib_route", None)
            item_index = indices[self.playing_index] if self.playing_index < len(indices) else None
            if library_route is not None and item_index is not None:
                if not url.startswith("/") and library_route.items[item_index].get("audio") == entry[1][3]:
                    is_live = is_live or bool(library_route.items[item_index].get("live"))
                if library_route is self.route:
                    self.route.index = item_index      # the focus follows the playing recording
        if isinstance(entry[0], int):
            try:
                expected = self.catalog.surah_duration_seconds(entry[0], entry[1])
            except Exception:
                expected = 0
        self.audio.play(title, url, is_live, expected, who=self.playing_who(entry))
        self._prefetch_focus()
        if self.route.name in ("surahs", "radios", "favorites"):
            if prev_index is not None and prev_index != self.playing_index:
                self._refresh_sura_card_title(prev_index)
            self._refresh_sura_card_title(self.playing_index)
            self.render_integrated_player()
        else:
            self.render()

    def play_control(self):
        if self.route.name == "mushaf":
            self.toggle_mushaf_page_audio()
            return
        if self.route.name == "video":
            self.show_video_osd(auto_hide=True)
            if self.youtube_lookup is not None:
                return
            if self.audio is not None and self.audio.state in ("idle", "error", "finished"):
                self._start_video_episode()
            elif self.audio is not None and self.audio.state != "connecting":
                self.audio.toggle()
                self.update_video_player()
            return
        if not self.playing_items or self.audio is None:
            if self.route.name in ("surahs", "radios", "favorites") and self.route.items:
                self.playing_items = list(self.route.items)
                self.playing_index = self.route.index
                self.start_track()
            return
        if self.audio.state in ("idle", "error", "finished"):
            self.start_track()
        elif self.audio.state != "connecting" and not self.audio.toggle():
            self.flash(u"الإيقاف المؤقت غير متاح لهذا البث")
        elif self.route.name in ("surahs", "radios", "favorites"):
            self.update_player()
        else:
            self.render()

    def seek(self, direction):
        self.seek_by(10 * direction)

    def can_seek_keys(self):
        """Digits seek while a track is on; otherwise they keep their navigation meaning."""
        audio = self.audio
        return bool(self.playing_items and audio is not None and self.route.name in
                    ("surahs", "radios", "favorites", "library", "shaarawy", "video")
                    and audio.state in ("playing", "paused", "connecting"))

    def seek_by(self, seconds):
        audio = self.audio
        if not self.playing_items or audio is None:
            return
        if audio.live:
            self.flash(u"بث مباشر · لا يوجد تقديم أو ترجيع")
        elif audio.state == "connecting":
            return
        elif not audio.seek_seconds(seconds):
            self.flash(u"التقديم والترجيع غير متاحين الآن")
        if self.route.name == "video":
            self.show_video_osd(auto_hide=True)

    def skip(self, step):
        if self.route.name == "video":
            self.skip_video(step)
            return
        if not self.playing_items or self.playing_index is None:
            return
        target = self.playing_index + step
        if 0 <= target < len(self.playing_items):
            prev_idx = self.playing_index
            self.playing_index = target
            old_page = self.route.index // layout.SURA_PAGE_SIZE
            if self.route.name in ("surahs", "radios", "favorites") and self.route.items == self.playing_items:
                self.route.index = target
            new_page = self.route.index // layout.SURA_PAGE_SIZE
            if old_page != new_page:
                self.start_track(prev_index=prev_idx)
                self.render()
            else:
                if self.route.name in ("surahs", "radios", "favorites"):
                    start = new_page * layout.SURA_PAGE_SIZE
                    self.highlight(layout.SURA_CARDS[self.route.index - start], "sura")
                self.start_track(prev_index=prev_idx)
        else:
            self.flash(u"وصلت إلى طرف القائمة")

    def track_ended(self):
        if self.route.name == "video":
            if self.route.index + 1 < len(self.route.items):
                self.skip_video(1)
            elif self.audio is not None:
                self.audio.finished()
                self.show_video_osd(auto_hide=False)
            return
        if not self.playing_items or self.audio is None:
            return
        if getattr(self, "mushaf_audio_mode", False):
            if getattr(self, "mushaf_page_repeat", False):
                self.play_mushaf_page(self.mushaf_page, announce=False)
            elif self.mushaf_page < 604:
                self.mushaf_page += 1
                self.mushaf_half = 0
                self.tafsir_sub = 0
                self.translation_sub = 0
                self.play_mushaf_page(self.mushaf_page, announce=False)
            else:
                self.audio.finished()
                if self.route.name == "mushaf":
                    self._update_mushaf_state_label()
            return
        if self.repeat:
            self.start_track()
        elif self.playing_index + 1 < len(self.playing_items):
            self.skip(1)
        else:
            self.audio.finished()

    def back(self):
        if self.jump_buffer is not None:
            self.cancel_jump()
            return
        if self.close_bio():
            return
        if self.route.name == "home" and self.arrange is not None:
            if self.arrange.get("from") is not None:
                self.arrange["from"] = None        # put the lifted card back
                self.render_home_selection()
            else:
                self.end_arrange()
            return
        if len(self.stack) == 1:
            if self.route.name == "home" and self.route.index >= layout.HOME_PAGE_SIZE:
                self.home_first_page()
                return
            self.close()
            return
        route = self.stack.pop()
        if route.name == "video":
            self._cancel_youtube_lookup()
            self.video_osd_timer.stop()
        # sound keeps playing wherever you go inside the plugin (it stops when the plugin closes);
        # only a video stops when its full-screen view is left, because the picture needs that screen
        if route.name == "video" and self.audio is not None and self.playing_items:
            self.audio.release()
            self.playing_items = None
            self.playing_index = None
            self.repeat = False
        self.render()

    # ------------------------------------------------------------------ online update (red key on home)
    # One card, built like Ultra Audio's update card: brand and title, a gold status line, the release notes
    # (UP / DOWN pages them), a download bar while it works, and the colour keys it answers to.
    UPD_WIDGETS = ("upd", "upd_fill", "upd_status", "upd_notes", "upd_page", "upd_green", "upd_red")

    def check_update(self):
        from .updater import UPDATER
        if UPDATER.state == "available":
            self._update_card("ready")
            return
        if UPDATER.state == "done":
            self._update_card("done")
            return
        if UPDATER.busy():
            self._update_card("busy")
        elif UPDATER.check(manual=True):
            self._update_card("checking")
        self.update_timer.start(1000, False)

    def poll_update(self):
        from .updater import UPDATER
        state = UPDATER.state
        if state == "checking":
            return
        if state in ("downloading", "installing"):
            if self.upd:
                self._update_card("busy")
            return
        self.update_timer.stop()
        if not self.upd:
            # closed while it checked, or the quiet check at start: only a short note on the home screen
            if state == "available" and self.route.name == "home":
                self.flash(u"يوجد تحديث جديد %s  ·  اضغط الزر الأحمر للتثبيت" % UPDATER.info.get("version", u""))
            elif state == "done":
                self._update_card("done")
            return
        if state == "available":
            self._update_card("ready")
        elif state == "latest":
            self._update_card("latest")
        elif state == "done":
            self._update_card("done")
        else:
            self._update_card("error")

    def _update_card(self, phase):
        self.upd = {"phase": phase, "page": 0}
        self.hide_notice()
        self.draw_update()

    @staticmethod
    def _update_notes(info):
        notes = info.get("notes_ar") or info.get("notes") or []
        if not isinstance(notes, list):
            notes = [part.strip() for part in u"%s" % notes.replace(u"  ·  ", u"\n").splitlines() if part.strip()]
        lines = []
        for note in notes:
            parts = wrap(note, layout.UPD_WRAP).split(u"\n")
            lines.append(u"•  " + parts[0])
            lines.extend(u"    " + part for part in parts[1:])
        return lines

    def draw_update(self):
        from .updater import UPDATER
        from . import VERSION
        card = self.upd
        if not card:
            return
        phase = card["phase"]
        info = UPDATER.info or {}
        version = info.get("version", u"")
        green = red = u""
        percent = None
        if phase == "ready":
            status = u"إصدار جديد  ·  %s" % version
            lines = self._update_notes(info) or [u"تحسينات عامة للبلجن."]
            green, red = u"تحديث", u"رجوع"
        elif phase == "busy":
            if UPDATER.state == "installing":
                status = u"جارٍ تثبيت الإصدار %s…" % version
                lines = [u"يتم التثبيت الآن، لا تغلق الجهاز.", u"تظهر رسالة إعادة التشغيل عند الانتهاء."]
                percent = 100
            else:
                status = u"جارٍ التحميل  ·  %d%%" % UPDATER.progress
                lines = [u"يتم تحميل الحزمة والتحقق من بصمتها قبل التثبيت.", u"يرجى الانتظار حتى الانتهاء."]
                percent = UPDATER.progress
        elif phase == "checking":
            status = u"جارٍ البحث عن تحديث…"
            lines = [u"الإصدار المثبت: %s" % VERSION]
            red = u"رجوع"
        elif phase == "latest":
            status = u"أنت على آخر إصدار  ·  %s" % VERSION
            lines = [u"لا يوجد تحديث جديد الآن.", u"يبحث البلجن عن التحديثات تلقائياً عند فتحه."]
            red = u"رجوع"
        elif phase == "done":
            status = u"تم تثبيت الإصدار %s" % version
            lines = [u"يلزم إعادة تشغيل الواجهة لتفعيل الإصدار الجديد."]
            green, red = u"إعادة التشغيل", u"لاحقاً"
        else:
            status = u"تعذّر التحديث"
            lines = [UPDATER.message or u"تعذر الاتصال بخادم التحديث", u"تحقق من الإنترنت ثم حاول مرة أخرى."]
            red = u"رجوع"
        per = layout.UPD_LINES
        pages = max(1, (len(lines) + per - 1) // per)
        card["pages"] = pages
        card["page"] = min(card.get("page", 0), pages - 1)
        shown = lines[card["page"] * per:(card["page"] + 1) * per]
        art = "update-busy" if percent is not None else "update-ready" if green else "update-back" if red else "update-busy"
        self.image("upd", art, layout.UPD_PANEL)
        self.text("upd_status", status, layout.UPD_STATUS)
        self.text("upd_notes", u"\n".join(shown), layout.UPD_NOTES)
        if pages > 1:
            self.text("upd_page", u"صفحة %d من %d  ·  أعلى / أسفل للمزيد" % (card["page"] + 1, pages), layout.UPD_PAGE)
        else:
            self.hide_widget("upd_page")
        if percent is not None:
            self.laser("upd_fill", layout.UPD_TRACK, percent)
        else:
            self.hide_widget("upd_fill")
        for name, value in (("upd_green", green), ("upd_red", red)):
            if value:
                self.text(name, value, getattr(layout, "UPD_" + name[4:].upper()))
            else:
                self.hide_widget(name)

    def close_update(self):
        self.upd = None
        for name in self.UPD_WIDGETS:
            self.hide_widget(name)

    def update_key(self, key):
        card = self.upd
        phase = card["phase"]
        if key in ("up", "down", "chplus", "chminus", "left", "right"):
            step = -1 if key in ("up", "chminus", "left") else 1
            page = max(0, min(card.get("pages", 1) - 1, card["page"] + step))
            if page != card["page"]:
                card["page"] = page
                self.draw_update()
            return
        if phase == "busy":
            return                               # a download / install in progress cannot be left half way
        if key in ("green", "ok") and phase == "ready":
            self._start_install()
        elif key in ("green", "ok") and phase == "done":
            self.close_update()
            self._restart_gui()
        elif key in ("red", "cancel", "ok", "exit"):
            self.close_update()

    def _start_install(self):
        from .updater import UPDATER
        if UPDATER.install():
            self._update_card("busy")
            self.update_timer.start(500, False)

    def _restart_gui(self):
        try:
            from Screens.Standby import TryQuitMainloop
            self.session.open(TryQuitMainloop, 3)
        except Exception:
            log_exception("GUI restart failed")
            self.flash(u"أعد تشغيل الجهاز لتفعيل التحديث")

    def red(self):
        route = self.route
        if route.name == "home":
            self.check_update()
            return
        if route.name == "video":
            self.skip_video(-1)
        elif route.name == "mushaf":
            self.mushaf.toggle_riwaya()
            self.mushaf_half = 0
            self.translation_sub = 0
            self.tafsir_sub = 0
            if self.mushaf.riwaya == "warsh":
                self.mushaf_reciter_slug = "warsh/warsh_ibrahim_aldosary_128kbps"
            else:
                self.mushaf_reciter_slug = getattr(self, "mushaf_hafs_slug", "Husary_128kbps") or "Husary_128kbps"
            self._save_mushaf_audio_prefs()
            if self.mushaf_audio_active():
                self.play_mushaf_page(self.mushaf_page, announce=False)
            self.render()
            self.flash(u"الرواية: %s  ·  القارئ: %s" % (self.mushaf.riwaya_name(), self.mushaf_reciter_short_name()))
        elif route.name == "shaarawy" and route.items:
            item = route.items[route.index]
            sec_owner = MAHMOUD_NAME if route.key == MAHMOUD_VIDEO_OWNER else SHAARAWY_NAME
            if item.get("audio") and not item.get("live"):
                self.choose_download(item, collect_media({"items": route.items}), sec_owner,
                                     route.folder_title or sec_owner, video=bool(item.get("video")))
            else:
                self.back()
        elif route.name == "shaarawy_folders" and self.shaarawy_root():
            self.back()
        elif self.gallery_has_downloads():
            folder = route.items[route.index]
            owner = MAHMOUD_NAME if route.key == MAHMOUD_VIDEO_OWNER else self.catalog.libraries[route.key]["title"]
            self.choose_download(None, collect_media(folder), owner, folder["title"])
        elif route.name == "shaarawy_folders" and route.items:
            folder = route.items[route.index]
            sec_owner = MAHMOUD_NAME if route.key == MAHMOUD_VIDEO_OWNER else SHAARAWY_NAME
            self.choose_download(None, collect_media(folder), sec_owner, folder.get("title", u""))
        elif route.name == "reciter_videos" and route.items:
            item = route.items[route.index]
            dl_pool = collect_media({"items": route.items})
            if not item.get("audio") and not dl_pool:
                self.back()
                return
            reciter_name = self.catalog.reciter.get(route.key, (0, u"القرآن الكريم"))[1]
            self.choose_download(item if item.get("audio") else None, dl_pool, reciter_name,
                                 u"فيديوهات " + reciter_name, video=True)
        elif route.name in ("reciter_hub", "mahmoud_hub"):
            self.back()
        elif route.name == "library" and route.items:
            if route.key in YOUTUBE_LIBRARIES:
                self.back()
                return
            item = route.items[route.index]
            sec_title = self.catalog.libraries[route.key]["title"]
            if item.get("video") and item.get("audio"):
                self.choose_download(item, collect_media({"items": route.items}), sec_title,
                                     route.folder_title or sec_title, video=True)
            elif item.get("children"):
                self.choose_download(None, collect_media(item), sec_title, item["title"])
            elif item.get("audio") and not item.get("live") and "qurango.net/radio" not in item.get("audio", ""):
                self.choose_download(item, collect_media({"items": route.items}), sec_title,
                                     route.folder_title or sec_title)
            else:
                self.page_step(-1)
        elif route.name in ("gallery", "lgallery", "radios"):
            self.page_step(-1)
        elif route.name == "editions" and route.items:
            ed_id = route.items[route.index][0]
            if not self.download_room_ok():
                return
            count = self.downloader.enqueue_edition(ed_id)
            self.render()
            if count > 0:
                self.flash(u"بدأ تحميل فولدر الرواية بالكامل · %d سورة على الهارد" % count)
            else:
                self.flash(u"فولدر الرواية محمّل بالكامل على الهارد")
        elif route.name in ("surahs", "favorites") and route.items:
            entry = route.items[route.index]
            if not isinstance(entry[0], int):
                return
            ed_id, chapter = entry
            self.choose_surah_download(ed_id, chapter)

    def download_room_ok(self):
        if self.downloader.has_room():
            return True
        self.flash(u"مفيش مساحة كفاية للتحميل · وصّل هارد أو فلاشة USB")
        return False

    def choose_download(self, item, folder_items, section_title, folder_title, video=False):
        """Red key: ask 'this item only' or 'the whole folder' (or just confirm a folder)."""
        if not self.download_room_ok():
            return
        kind = u"الفيديو" if video else u"المادة"
        options = []
        if item is not None:
            if self.downloader.is_media_downloaded(item.get("audio"), is_video=bool(item.get("video"))):
                label = u"%s محمّلة بالفعل على الهارد" % kind if not video else u"الفيديو محمّل بالفعل على الهارد"
            else:
                label = u"تحميل هذه %s فقط" % kind if not video else u"تحميل هذا الفيديو فقط"
            options.append((label, lambda: self._download_one(item, section_title, video)))
        if folder_items:
            options.append((u"تحميل الفولدر كامل  ·  %d مادة" % len(folder_items),
                            lambda: self._download_folder(folder_items, section_title, folder_title)))
        if not options:
            self.flash(u"هذا الفولدر بث مباشر أو نصوص للقراءة · لا يحتاج تحميل")
            return
        sub = flat_text(item.get("title", u"")) if item is not None else flat_text(folder_title)
        self.open_choice(u"التحميل على الهارد", sub, options)

    def _download_one(self, item, section_title, video=False):
        if self.downloader.enqueue_media(item, section_title):
            self.render()
            self.flash(u"بدأ حفظ الفيديو على الهارد للمشاهدة بدون إنترنت" if video else
                       u"بدأ حفظ المادة على الهارد للتشغيل بدون إنترنت")
        else:
            self.flash(u"محمّل بالفعل على الهارد أو قيد التحميل")

    def choose_surah_download(self, ed_id, chapter):
        from .youtube import watch_audio_id
        if self.catalog.contains((ed_id, chapter)) and watch_audio_id(self.catalog.track((ed_id, chapter))[3]):
            self.flash(u"تسجيلات يوتيوب متاحة للاستماع أونلاين")
            return
        if not self.download_room_ok():
            return
        name = self.catalog.track_title(ed_id, chapter)
        total = len(self.catalog.edition[ed_id][1][3]) if ed_id in self.catalog.edition else 0
        if self.downloader.is_downloaded(ed_id, chapter):
            one = u"%s محمّلة بالفعل" % plain(name)
        elif self.downloader.is_queued(ed_id, chapter):
            one = u"%s قيد التحميل" % plain(name)
        else:
            one = u"تحميل %s فقط" % plain(name)

        def surah():
            if self.downloader.enqueue_surah(ed_id, chapter):
                self.render()
                self.flash(u"بدأ تحميل %s على الهارد" % plain(name))
            else:
                self.flash(u"%s محمّلة أو قيد التحميل على الهارد" % plain(name))

        def edition():
            count = self.downloader.enqueue_edition(ed_id)
            self.render()
            if count > 0:
                self.flash(u"بدأ تحميل فولدر الشيخ بالكامل · %d سورة على الهارد" % count)
            else:
                self.flash(u"جميع سور هذا المصحف محمّلة أو قيد التحميل على الهارد")

        reciter = u""
        try:
            reciter = self.catalog.edition[ed_id][0][1]
        except Exception:
            pass
        self.open_choice(u"التحميل على الهارد", reciter,
                         [(one, surah), (u"تحميل فولدر الشيخ كامل  ·  %d سورة" % total, edition)])

    def _download_folder(self, items, section_title, folder_title):
        if not items:
            self.flash(u"هذا الفولدر بث مباشر أو نصوص للقراءة · لا يحتاج تحميل")
            return
        count = self.downloader.enqueue_media_many(items, section_title)
        self.render()
        if count > 0:
            self.flash(u"بدأ تحميل الفولدر كامل على الهارد · %d مادة" % count)
        else:
            self.flash(u"فولدر «%s» محمّل بالكامل أو قيد التحميل" % flat_text(folder_title))

    def yellow(self):
        route = self.route
        if route.name in BIO_VIEWS and self.toggle_bio():
            return
        if route.name == "video":
            self.accept()
        elif route.name == "home":
            self.open(Route("mushaf", key=self.mushaf.base_dir))
        elif self.gallery_has_downloads():
            self.jump_buffer = ""
            self.jump_label()
        elif route.name in ("gallery", "lgallery"):
            self.page_step(1)
        elif route.name == "quiz":
            route.question_index = (route.question_index + 1) % len(route.items)
            route.answered = None
            route.index = 0
            self.render()
        elif route.name in ("surahs", "favorites") and self.playing_items and self.audio is not None and not self.audio.live and self.audio.state in ("playing", "paused", "connecting"):
            self.repeat = not self.repeat
            self.update_player()
        elif route.name in ("mushaf", "main_folders", "surahs", "editions", "shaarawy", "shaarawy_folders", "radios", "favorites", "library"):
            self.jump_buffer = ""
            self.jump_label()

    def green(self):
        route = self.route
        if route.name == "video":
            self.play_control()
        elif route.name == "home":
            self.resume_last()
        elif (route.name in ("main_folders", "shaarawy_folders", "reciter_videos", "reciter_hub", "mahmoud_hub")
              or self.gallery_has_downloads()) and route.items:
            self.accept()
        elif route.name == "shaarawy" and route.items:
            owner = MAHMOUD_VIDEO_OWNER if route.key == MAHMOUD_VIDEO_OWNER else 999
            self._open_shaarawy_item(route.items[route.index], owner_id=owner)
        elif route.name in ("surahs", "radios", "favorites"):
            self.play_control()
        elif route.name == "editions" and route.items:
            ed_id = route.items[route.index][0]
            if not self.download_room_ok():
                return
            count = self.downloader.enqueue_edition(ed_id)
            self.render()
            if count > 0:
                self.flash(u"بدأ تحميل فولدر الرواية بالكامل · %d سورة على الهارد" % count)
            else:
                self.flash(u"فولدر الرواية محمّل بالكامل على الهارد")
        elif route.name in ("gallery", "lgallery", "reciter_hub"):
            self.open(Route("mushaf", key=self.mushaf.base_dir))
        elif route.name == "library":
            item = route.items[route.index]
            if item.get("children") or item.get("action") or item.get("video") or item.get("source_qr"):
                self.accept()
            elif item.get("audio"):
                self.play_library_item(item, route.folder_title or self.catalog.libraries[route.key]["title"])
            elif item.get("edition") and item["edition"] in self.catalog.edition:
                ed_key = item["edition"]
                self.open(Route("surahs", self.catalog.tracks(ed_key), ed_key))
            else:
                self.flash(u"هذه المادة للقراءة والتدبر")
        elif route.name == "mushaf":
            self.toggle_mushaf_page_audio()

    def blue(self):
        route = self.route
        if route.name == "video":
            self.skip_video(1)
            return
        if route.name == "mushaf":
            state = self.mushaf.bulk_state()
            name = self.mushaf.riwaya_name()
            if state["saved"] >= 604:
                self.flash(u"مصحف %s محفوظ بالكامل على الهارد · 604 صفحة" % name)
            elif state["running"]:
                self.flash(u"التحميل شغال: %d / 604 صفحة (مصحف %s)" % (state["saved"], name))
            else:
                self.mushaf.start_full_download()
                self.flash(u"بدأ تحميل مصحف %s كامل على الهارد · %d / 604" % (name, state["saved"]))
            self.render()
            return
        if route.name in ("home", "main_folders", "gallery", "lgallery", "reciter_hub", "editions", "shaarawy", "shaarawy_folders", "radios", "library", "quiz", "mahmoud_hub"):
            self.open(Route("favorites", self.offline_and_favorites_list()))
            return
        if route.name not in ("surahs", "favorites") or not route.items:
            return
        entry = route.items[route.index]
        if entry[0] is None or entry[0] == "lib":
            self.flash(u"هذه المادة محفوظة في مكتبة الهارد للاستماع بدون نت")
            return
        if entry in self.favorites:
            updated = [item for item in self.favorites if item != entry]
            message = u"تمت الإزالة من المفضلة"
        elif len(self.favorites) < 200:
            updated = self.favorites + [entry]
            message = u"تم الحفظ في المفضلة"
        else:
            self.flash(u"المفضلة ممتلئة")
            return
        try:
            save_favorites(updated)
        except (IOError, OSError):
            log_exception("Could not save favorites")
            self.flash(u"تعذّر حفظ المفضلة")
            return
        self.favorites = updated
        if route.name == "favorites":
            route.items = self.offline_and_favorites_list()
            route.index = min(route.index, max(0, len(route.items) - 1))
        self.render()
        self.flash(message)

    def jump_label(self):
        if self.route.name == "mushaf":
            prompt = u"اكتب رقم الوجه (1-604) للتشغيل   ·   " if getattr(self, "jump_auto_play", False) else u"اكتب رقم الوجه / الصفحة (1-604)   ·   "
        else:
            prompt = u"اكتب الرقم ثم اضغط موافقة   ·   "
        self.text("jump", prompt + (self.jump_buffer or (u"_" * self.jump_digits())), (480, 932, 960, 60))

    def jump_digits(self):
        return max(3, len(str(len(self.route.items))))

    def cancel_jump(self):
        self.jump_buffer = None
        self.jump_timer.stop()
        self.hide_widget("jump")

    SEEK_KEYS = {1: -10, 3: 10, 4: -60, 6: 60, 7: -300, 9: 300}

    def number(self, digit):
        if self.jump_buffer is None and self.route.name == "library" and self.lib_pages > 1 and digit in (2, 8):
            self.lib_turn(-1 if digit == 2 else 1)
            return
        if (self.jump_buffer is None and self.route.name == "mushaf"
                and self.translation_subs > 1 and digit in (2, 8)):
            self.translation_sub = (self.translation_sub + (-1 if digit == 2 else 1)) % self.translation_subs
            self.render()
            return
        if self.jump_buffer is None and self.can_seek_keys():
            if digit in self.SEEK_KEYS:
                self.seek_by(self.SEEK_KEYS[digit])
                return
            if digit == 5:
                self.play_control()
                return
            if digit == 2:
                self.skip(-1)
                return
            if digit == 8:
                self.skip(1)
                return
            if digit == 0 and self.route.name in ("surahs", "favorites", "radios", "library", "shaarawy"):
                self.jump_buffer = ""
                self.jump_label()
                return
        if self.route.name == "home" and 0 <= digit <= 9:
            if self.route.index < layout.HOME_PAGE_SIZE and digit:
                self.route.index = digit - 1
            elif self.route.index >= layout.HOME_PAGE_SIZE:
                self.route.index = layout.HOME_PAGE_SIZE + (digit or 10) - 1
            self.render_home_selection()
            return
        if self.route.name == "gallery" and self.jump_buffer is None and digit == 0:
            if self.route.key == "mubtahileen":
                self.route.items = self.catalog.reciters
                self.route.key = "reciters"
                self.route.folder_title = u"قراء القرآن الكريم"
                self.route.index = 0
                self.render()
                self.flash(u"تم التبديل إلى معرض قراء القرآن الكريم (%d قارئ)" % len(self.catalog.reciters))
            else:
                self.route.items = self.catalog.mubtahileen
                self.route.key = "mubtahileen"
                self.route.folder_title = u"موسوعة الابتهالات وكبار المبتهلين"
                self.route.index = 0
                self.render()
                self.flash(u"تم التبديل إلى معرض كبار المبتهلين (%d مبتهل)" % len(self.catalog.mubtahileen))
            return
        if self.route.name not in ("gallery", "lgallery", "main_folders", "surahs", "mushaf", "editions", "shaarawy", "shaarawy_folders", "radios", "favorites", "library"):
            return
        self.jump_buffer = (self.jump_buffer or "") + str(digit)
        if len(self.jump_buffer) >= self.jump_digits():
            self.commit_jump()
        else:
            self.jump_label()
            self.jump_timer.start(2400)

    def commit_jump(self):
        value = self.jump_buffer
        self.cancel_jump()
        if not value:
            return
        number = int(value)
        route = self.route
        auto_play = getattr(self, "jump_auto_play", False)
        self.jump_auto_play = False
        if route.name == "mushaf" and 1 <= number <= 604:
            self.mushaf_page = number
            self.translation_sub = 0
            self.mushaf_half = 0
            self.tafsir_sub = 0
            if auto_play or self.mushaf_audio_active():
                self.play_mushaf_page(self.mushaf_page, announce=True)
                return
            self.render()
            self.flash(u"الوجه %d (صفحة %d)  ·  اضغط الزر الأخضر لسماع تلاوة هذا الوجه" % (number, number))
            return
        elif route.name == "surahs" and (route.key, number) in route.items:
            route.index = route.items.index((route.key, number))
        elif route.name in ("gallery", "lgallery", "main_folders", "editions", "shaarawy", "shaarawy_folders", "radios", "favorites", "library") and 1 <= number <= len(route.items):
            route.index = number - 1
        else:
            self.flash(u"الرقم غير متاح في القائمة الحالية")
            return
        self.render()

    def cleanup(self):
        self._cancel_youtube_lookup()
        self.bio_scroll.close()
        self.bio_timer.close()
        self.jump_timer.close()
        self.notice.close()
        self.portrait_timer.close()
        self.warm_timer.close()
        self.download_timer.close()
        self.mushaf_timer.close()
        self.sync_timer.close()
        self.video_osd_timer.close()
        self.lib_timer.close()
        self.zina_timer.close()
        self.update_timer.close()
        if self.audio is not None:
            self.audio.close()
