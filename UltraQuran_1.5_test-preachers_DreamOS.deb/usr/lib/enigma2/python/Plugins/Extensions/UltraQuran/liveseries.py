# -*- coding: utf-8 -*-
"""Shows that are still on air pick up their new episodes by themselves, without a plugin update.

دولة التلاوة (season 2) airs every Friday and Saturday and the full HD episode is uploaded to the
programme's official YouTube channel. The channel's public RSS feed (no key, no login) is read in the
background at most every few hours; every new full episode found there is remembered in a small file
under /etc/enigma2 and appended to the season folder as the next "الحلقة N". Clips, shorts and
re-uploads from other channels are ignored, so the folder only ever holds the official full episodes.
"""
import io
import json
import os
import re
import threading
import time

from .support import log, log_exception

FEED = "https://www.youtube.com/feeds/videos.xml?channel_id=%s"
STATE_PATH = "/etc/enigma2/ultra-quran-live-series.json"
CHECK_EVERY = 3 * 3600          # seconds between two looks at the feed

# library id, folder title, official channel, first day of the season (ISO date)
SHOWS = (
    (16, u"الموسم الثاني", "UC6TGOIKLo_Wuaqt7SdgVLWQ", "2026-11-13"),
)

ORDINALS = (
    (u"الحادية عشرة", 11), (u"الحادية عشر", 11), (u"الثانية عشرة", 12), (u"الثانية عشر", 12),
    (u"الثالثة عشرة", 13), (u"الثالثة عشر", 13), (u"الرابعة عشرة", 14), (u"الرابعة عشر", 14),
    (u"الخامسة عشرة", 15), (u"الخامسة عشر", 15), (u"السادسة عشرة", 16), (u"السادسة عشر", 16),
    (u"السابعة عشرة", 17), (u"السابعة عشر", 17), (u"الثامنة عشرة", 18), (u"الثامنة عشر", 18),
    (u"التاسعة عشرة", 19), (u"التاسعة عشر", 19), (u"العشرون", 20), (u"الحادية والعشرون", 21),
    (u"الثانية والعشرون", 22), (u"الثالثة والعشرون", 23), (u"الرابعة والعشرون", 24),
    (u"الخامسة والعشرون", 25), (u"السادسة والعشرون", 26), (u"السابعة والعشرون", 27),
    (u"الثامنة والعشرون", 28), (u"التاسعة والعشرون", 29), (u"الثلاثون", 30),
    (u"الأولى", 1), (u"الاولى", 1), (u"الثانية", 2), (u"الثالثة", 3), (u"الرابعة", 4), (u"الخامسة", 5),
    (u"السادسة", 6), (u"السابعة", 7), (u"الثامنة", 8), (u"التاسعة", 9), (u"العاشرة", 10),
)
ARABIC_DIGITS = dict(zip(u"٠١٢٣٤٥٦٧٨٩", u"0123456789"))

_lock = threading.Lock()
_running = [False]


def _load_state():
    try:
        with io.open(STATE_PATH, "r", encoding="utf-8") as handle:
            state = json.load(handle)
        return state if isinstance(state, dict) else {}
    except (IOError, OSError, ValueError):
        return {}


def _save_state(state):
    tmp = STATE_PATH + ".tmp"
    try:
        text = json.dumps(state, ensure_ascii=False)
        if isinstance(text, bytes):
            text = text.decode("utf-8")
        with io.open(tmp, "w", encoding="utf-8") as handle:
            handle.write(text)
        os.rename(tmp, STATE_PATH)
    except (IOError, OSError):
        log("live series: cannot save %s" % STATE_PATH)


def _text(value):
    return (value.replace("&amp;", "&").replace("&quot;", '"').replace("&#39;", "'")
            .replace("&lt;", "<").replace("&gt;", ">").strip())


def parse_feed(xml):
    """[(video_id, title, published_iso)] from a YouTube channel feed, newest first, shorts left out."""
    out = []
    for entry in re.findall(r"<entry>(.*?)</entry>", xml, re.S):
        vid = re.search(r"<yt:videoId>([\w-]{11})</yt:videoId>", entry)
        title = re.search(r"<title>(.*?)</title>", entry, re.S)
        published = re.search(r"<published>([^<]+)</published>", entry)
        link = re.search(r'<link rel="alternate" href="([^"]+)"', entry)
        if not (vid and title and published):
            continue
        if link and "/shorts/" in link.group(1):
            continue
        out.append((vid.group(1), _text(title.group(1)), published.group(1)[:19]))
    return out


def is_full_episode(title):
    return u"حلق" in title and u"كامل" in title and u"برومو" not in title and u"اعلان" not in title \
        and u"إعلان" not in title


def episode_number(title):
    plain = u"".join(ARABIC_DIGITS.get(ch, ch) for ch in title)
    match = re.search(u"الحلقة\\s*(?:رقم\\s*)?(\\d{1,2})", plain)
    if match:
        return int(match.group(1))
    for word, number in ORDINALS:
        if u"الحلقة " + word in title or u"حلقة " + word in title:
            return number
    return None


def headline(title):
    """The episode's own line, without the programme name and the 'full episode' boilerplate."""
    parts = [part.strip() for part in re.split(u"[|｜]", title) if part.strip()]
    keep = [part for part in parts
            if u"دولة التلاوة" not in part and u"الحلقة" not in part and u"كامل" not in part]
    return keep[0] if keep else (parts[0] if parts else title)


def _check(force=False):
    state = _load_state()
    now = time.time()
    if not force and now - float(state.get("checked", 0)) < CHECK_EVERY:
        return
    from .youtube import _http_text
    changed = False
    for lib_id, folder, channel, since in SHOWS:
        try:
            xml = _http_text(FEED % channel, timeout=6, limit=2 * 1024 * 1024)
        except Exception as error:
            log("live series: feed unavailable (%s)" % error)
            continue
        key = "%d:%s" % (lib_id, folder)
        known = state.setdefault(key, [])
        seen = set(row[0] for row in known)
        for vid, title, published in parse_feed(xml):
            if vid in seen or published[:10] < since or not is_full_episode(title):
                continue
            known.append([vid, title, published])
            seen.add(vid)
            changed = True
            log("live series: new episode %s" % vid)
        known.sort(key=lambda row: row[2])
    state["checked"] = now
    _save_state(state)          # also keeps the time of this look, so the feed is read at most every few hours


def refresh_async(force=False):
    """Look at the feeds in the background (never blocks the screen)."""
    with _lock:
        if _running[0]:
            return
        _running[0] = True

    def run():
        try:
            _check(force)
        except Exception:
            log_exception("live series refresh failed")
        finally:
            _running[0] = False

    thread = threading.Thread(target=run)
    thread.daemon = True
    thread.start()


def apply(lib_id, library):
    """Append the remembered new episodes to the library's folder (idempotent)."""
    if not isinstance(library, dict):
        return library
    state = None
    for show_lib, folder, _channel, _since in SHOWS:
        if show_lib != lib_id:
            continue
        if state is None:
            state = _load_state()
        rows = state.get("%d:%s" % (lib_id, folder)) or []
        for item in library.get("items") or []:
            if item.get("title") != folder:
                continue
            children = item.setdefault("children", [])
            present = set(child.get("youtube_id") for child in children)
            numbers = [episode_number(child.get("title", u"")) or 0 for child in children]
            last = max(numbers or [0])
            for vid, title, _published in rows:
                if vid in present:
                    continue
                number = episode_number(title)
                if not number or number in numbers:
                    number = last + 1
                last = max(last, number)
                numbers.append(number)
                present.add(vid)
                children.append({
                    "title": u"الحلقة %d" % number, "owner": u"دولة التلاوة", "video": True,
                    "youtube_id": vid, "badge": u"YouTube · حلقة جديدة", "subtitle": u"الحلقة %d" % number,
                    "body": headline(title),
                })
            children.sort(key=lambda child: episode_number(child.get("title", u"")) or 999)
            count = len(children)
            item["badge"] = u"%d %s · بتتجدد تلقائيًا" % (count, u"حلقات" if 3 <= count <= 10 else u"حلقة")
    return library
