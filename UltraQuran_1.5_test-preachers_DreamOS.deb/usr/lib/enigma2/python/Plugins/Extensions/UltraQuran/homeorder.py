# -*- coding: utf-8 -*-
"""The user's own order of the home screen cards (MENU > ترتيب الكروت).

The 25 home cards are drawn at build time into two full-screen pictures (home-gallery = first page,
home-sections = second page, plus the -115 / -130 large-text variants). To show a custom order the
cards are cut out of those pictures and pasted into their new places, once per screen size and text
size; the result is cached (hard drive when there is one, otherwise /tmp) and rebuilt only when the
order or the artwork changes. Without PIL the default order is kept.
"""
import hashlib
import io
import os

from . import layout
from .support import has_room, log, log_exception, on_hard_drive, storage_root

try:
    from PIL import Image
except ImportError:
    Image = None

ORDER_PATH = "/etc/enigma2/ultra-quran-home-order.txt"
DEFAULT = tuple(layout.HOME_SECTIONS)
PAGE = layout.HOME_PAGE_SIZE
PAGES = ("home-gallery", "home-sections")          # first page, second page
COMPOSE_VERSION = "3"


def available():
    return Image is not None


def normalize(order):
    """A valid permutation of the home sections: unknown ids dropped, new sections appended at the end."""
    valid = set(DEFAULT)
    out = []
    for value in order or ():
        try:
            value = int(value)
        except (TypeError, ValueError):
            continue
        if value in valid and value not in out:
            out.append(value)
    for value in DEFAULT:
        if value not in out:
            out.append(value)
    return tuple(out)


def load():
    try:
        with io.open(ORDER_PATH, "r", encoding="ascii") as handle:
            text = handle.read()
    except (IOError, OSError):
        return DEFAULT
    return normalize(part for part in text.replace("\n", ",").split(",") if part.strip())


def save(order):
    order = normalize(order)
    try:
        if order == DEFAULT:
            if os.path.exists(ORDER_PATH):
                os.remove(ORDER_PATH)
            return True
        with io.open(ORDER_PATH + ".tmp", "w", encoding="ascii") as handle:
            handle.write(u",".join(u"%d" % value for value in order) + u"\n")
        os.rename(ORDER_PATH + ".tmp", ORDER_PATH)
        return True
    except (IOError, OSError):
        log_exception("Could not save the home card order")
        return False


def move(order, source, target):
    """Move the card at slot `source` to slot `target`; the cards in between shift by one."""
    order = list(normalize(order))
    if not (0 <= source < len(order) and 0 <= target < len(order)) or source == target:
        return tuple(order)
    order.insert(target, order.pop(source))
    return tuple(order)


def _slots(width):
    boxes = list(layout.HOME) + list(layout.HOME_MORE)
    return [layout.scaled(box, width) for box in boxes]


def _cache_dir(width):
    root = storage_root()
    base = os.path.join(root, "home-order") if (on_hard_drive(root) and has_room(root, 16 * 1024 * 1024)) \
        else "/tmp/ultra-quran-home-order"
    return os.path.join(base, str(width))


def compose(art_dir, width, suffix, order):
    """Paths (first page, second page) showing `order`, or None for the default order / on any failure."""
    order = normalize(order)
    if order == DEFAULT or Image is None:
        return None
    sources = [os.path.join(art_dir, name + suffix + ".png") for name in PAGES]
    if not all(os.path.isfile(path) for path in sources):
        return None
    slots = _slots(width)
    if len(slots) != len(DEFAULT):
        return None
    stamp = "|".join([COMPOSE_VERSION, str(width), suffix, ",".join(str(v) for v in order)]
                     + ["%s:%d:%d" % (p, int(os.path.getmtime(p)), os.path.getsize(p)) for p in sources])
    key = hashlib.sha1(stamp.encode("utf-8")).hexdigest()[:12]
    out_dir = _cache_dir(width)
    targets = [os.path.join(out_dir, "%s%s-%s.png" % (name, suffix, key)) for name in PAGES]
    if all(os.path.isfile(path) and os.path.getsize(path) > 1024 for path in targets):
        return tuple(targets)
    try:
        if not os.path.isdir(out_dir):
            os.makedirs(out_dir)
        for name in os.listdir(out_dir):          # older orders of this text size
            if name.startswith(tuple(p + suffix + "-" for p in PAGES)) and name not in [os.path.basename(t) for t in targets]:
                try:
                    os.remove(os.path.join(out_dir, name))
                except OSError:
                    pass
        pad = 1                                   # the gaps between cards are fully transparent
        tiles = {}
        for page_no, source in enumerate(sources):
            with Image.open(source) as im:
                im.load()
                im = im.convert("RGBA")
                for slot, section in enumerate(DEFAULT):
                    if (slot < PAGE) != (page_no == 0):
                        continue
                    x, y, w, h = slots[slot]
                    tiles[section] = im.crop((x - pad, y - pad, x + w + pad, y + h + pad))
        for page_no, source in enumerate(sources):
            with Image.open(source) as im:
                im.load()
                page = im.convert("RGBA")
            for slot, section in enumerate(order):
                if (slot < PAGE) != (page_no == 0):
                    continue
                x, y, w, h = slots[slot]
                size = (w + 2 * pad, h + 2 * pad)
                tile = tiles[section]
                if tile.size != size:              # rows can differ by one pixel after scaling
                    tile = tile.resize(size, getattr(getattr(Image, "Resampling", Image), "LANCZOS", Image.BICUBIC))
                page.paste(Image.new("RGBA", size, (0, 0, 0, 0)), (x - pad, y - pad))
                page.paste(tile, (x - pad, y - pad))
            tmp = targets[page_no] + ".tmp"
            page.save(tmp, format="PNG", compress_level=3)
            os.chmod(tmp, 0o644)
            os.rename(tmp, targets[page_no])
        log(u"home cards composed in a custom order (%s, width %d)" % (suffix or "100", width))
        return tuple(targets)
    except Exception:
        log_exception("Could not compose the custom home card order")
        for path in targets:
            try:
                if os.path.exists(path + ".tmp"):
                    os.remove(path + ".tmp")
            except OSError:
                pass
        return None
