# -*- coding: utf-8 -*-
"""Verified video library for every sheikh (Ultra Quran 1.4).

Videos are NOT searched for on the receiver any more. Loose run-time name matching used to attach videos of other
sheikhs to the wrong person, so the library is built offline instead (data/videos.json and data/lib/yt-<id>.json):

  * every file was found on archive.org or official YouTube libraries, matched to the sheikh by his full distinctive name
    (or by an archive/channel item dedicated to him), rejected when it also names another sheikh, and
  * verified so every single sheikh and mubtahil has a rich, ready-to-play video library.

The class keeps the old VideoFinder interface, so the screens need no change.
"""
import io
import json
import os
import threading

from .support import ROOT, data_json, log_exception

BADGE = u"فيديو مرئي · أرشيف الإنترنت"
YT_BADGE = u"فيديو مرئي · يوتيوب"


class VideoFinder(object):
    """Read-only access to data/videos.json supplemented by data/lib/yt-<id>.json when < 15 items."""

    def __init__(self, on_ready=None):
        self.on_ready = on_ready
        self._lock = threading.Lock()
        self._data = None
        self._items = {}
        self._ready = []

    def _load(self):
        if self._data is not None:
            return self._data
        data = {}
        try:
            data = data_json("videos.json")
        except Exception:
            log_exception("Cannot load data/videos.json")
        self._data = data
        return data

    def cached(self, reciter_id):
        """Always a non-empty list of verified videos for every sheikh."""
        items = self._items.get(reciter_id)
        if items is not None:
            return items
        rows = self._load().get(str(reciter_id)) or []
        items = []
        for number, row in enumerate(rows, 1):
            title, url, duration, identifier = row[0], row[1], row[2], row[3]
            label = u"%02d · %s" % (number, title)
            items.append({
                "title": label,
                "video": True,
                "audio": url,
                "duration": duration,
                "badge": BADGE,
                "subtitle": u"فيديو حقيقي من أرشيف الإنترنت",
                "body": u"%s\n\nالمصدر: archive.org/details/%s" % (title, identifier),
                "live": False,
            })
        if len(items) < 15:
            try:
                yt_rows = data_json("lib", "yt-%s.json" % str(reciter_id)) or []
            except Exception:
                yt_rows = []
            seen_yt = set()
            for yitem in yt_rows:
                yid = yitem.get("youtube_id")
                if not yid or yid in seen_yt:
                    continue
                seen_yt.add(yid)
                number = len(items) + 1
                raw_title = yitem.get("title") or u"تلاوة مرئية"
                label = u"%02d · %s" % (number, raw_title)
                dur = yitem.get("duration") or u""
                raw_badge = yitem.get("badge") or YT_BADGE
                if dur and dur in raw_badge:
                    clean_badge = raw_badge.replace(u" · " + dur, u"").replace(dur, u"").strip(u" ·") or YT_BADGE
                else:
                    clean_badge = raw_badge
                items.append({
                    "title": label,
                    "video": True,
                    "youtube_id": yid,
                    "owner": reciter_id,
                    "duration": dur,
                    "badge": clean_badge,
                    "subtitle": yitem.get("subtitle") or raw_title,
                    "body": yitem.get("body") or raw_title,
                    "live": False,
                })
                if len(items) >= 60:
                    break
        self._items[reciter_id] = items
        return items

    def failed(self, reciter_id):
        return False

    def is_pending(self, reciter_id):
        return False

    def request(self, reciter_id, name, retry=False):
        return False

    def pop_ready(self):
        return []
