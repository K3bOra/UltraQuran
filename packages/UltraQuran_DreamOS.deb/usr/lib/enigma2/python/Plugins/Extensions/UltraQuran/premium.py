# -*- coding: utf-8 -*-
"""Poster artwork for Ultra Quran 0.5.0 "Royal Emerald" (pure Pillow, drawn on the 1080p master grid).

* compose_card / compose_player build a poster from ANY photo (cover-crop for portraits, blurred backdrop +
  sharp portrait for wide or tiny photos) with a gold-edged emerald name plate;
* fallback_card / fallback_player redraw the ORIGINAL default artwork (geometric diamonds, book / headphones
  medallion, "القرآن الكريم · تلاوات خاشعة") - it is used for every sheikh that has no photo.
"""
import math
import os

try:
    from PIL import Image, ImageChops, ImageDraw, ImageEnhance, ImageFilter, ImageFont, ImageOps
except ImportError:  # pragma: no cover - receiver without Pillow
    Image = None

from . import layout
from .support import ROOT

CARD_W, CARD_H = layout.POSTER_SIZE
PLATE_H = layout.POSTER_PLATE
PHOTO_H = CARD_H - PLATE_H
PLAYER_W, PLAYER_H = 200, 210
BASE = (8, 26, 28)
EDGE = (150, 124, 74)
GOLD = (222, 186, 110)
GOLD2 = (244, 216, 150)
MINT = (118, 196, 164)


def available():
    return Image is not None


def _lanczos():
    return getattr(getattr(Image, "Resampling", Image), "LANCZOS", Image.BICUBIC)


def accent_from_image(rgb):
    """Kept for API compatibility: the interface does not tint itself per sheikh."""
    return GOLD


def _vertical_alpha(size, start, end, y0, y1):
    w, h = size
    mask = Image.new("L", (1, h), 0)
    px = mask.load()
    for y in range(h):
        if y <= y0:
            a = start
        elif y >= y1:
            a = end
        else:
            a = start + (end - start) * (y - y0) / float(max(1, y1 - y0))
        px[0, y] = int(max(0, min(255, a)))
    return mask.resize((w, h))


def _gradient(size, top, bottom):
    w, h = size
    column = Image.new("RGB", (1, h))
    px = column.load()
    for y in range(h):
        t = y / float(max(1, h - 1))
        px[0, y] = tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(3))
    return column.resize((w, h))


def rounded_mask(w, h, radius, ss=4):
    hi = Image.new("L", (w * ss, h * ss), 0)
    if hasattr(ImageDraw.ImageDraw, "rounded_rectangle"):
        ImageDraw.Draw(hi).rounded_rectangle((0, 0, w * ss - 1, h * ss - 1), radius * ss, fill=255)
    else:
        ImageDraw.Draw(hi).rectangle((0, 0, w * ss - 1, h * ss - 1), fill=255)
    return hi.resize((w, h), _lanczos())


def _border(size, radius, color, width=1, ss=4):
    w, h = size
    hi = Image.new("RGBA", (w * ss, h * ss), (0, 0, 0, 0))
    if hasattr(ImageDraw.ImageDraw, "rounded_rectangle"):
        ImageDraw.Draw(hi).rounded_rectangle((0, 0, w * ss - 1, h * ss - 1), radius * ss,
                                             outline=color, width=int(width * ss))
    return hi.resize((w, h), _lanczos())


def _finish(card, radius=16):
    w, h = card.size
    out = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    out.paste(card, (0, 0), rounded_mask(w, h, radius))
    out.alpha_composite(_border((w, h), radius, EDGE + (235,), 1.5))
    return out


def _plate(card, y0):
    """Emerald name plate with a hairline of gold on top."""
    w, h = card.size
    fade = Image.new("RGBA", (w, 70), BASE + (255,))
    fade.putalpha(_vertical_alpha((w, 70), 0, 235, 0, 70))
    card.alpha_composite(fade, (0, y0 - 70))
    plate = _gradient((w, h - y0), (10, 36, 36), (5, 18, 20)).convert("RGBA")
    card.alpha_composite(plate, (0, y0))
    line = Image.new("RGBA", (w - 56, 1), GOLD + (150,))
    line.putalpha(Image.linear_gradient("L").resize((1, 1)).resize((w - 56, 1)).point(lambda v: 150))
    card.alpha_composite(line, (28, y0 + 1))


def compose_card(src, accent=None):
    """Poster: photo (cover or soft backdrop) + gold-edged emerald name plate."""
    src = src.convert("RGB")
    w, h = CARD_W, CARD_H
    card = Image.new("RGBA", (w, h), BASE + (255,))
    # always a clean full-bleed photo: no blurred bands above / below wide pictures
    wide = src.width / float(src.height) > 1.15
    full = ImageOps.fit(src, (w, PHOTO_H), _lanczos(), centering=(0.5, 0.2 if wide else 0.28))
    if max(w / float(src.width), PHOTO_H / float(src.height)) > 1.25:
        full = full.filter(ImageFilter.UnsharpMask(radius=1.6, percent=60, threshold=2))
    card.paste(full, (0, 0))
    _plate(card, PHOTO_H)
    return _finish(card)


def compose_player(src, accent=None):
    """Rounded portrait for the studio player."""
    src = src.convert("RGB")
    w, h = PLAYER_W, PLAYER_H
    base = ImageOps.fit(src, (w, h), _lanczos(), centering=(0.5, 0.22)).convert("RGBA")
    return _finish(base, 18)


# ----------------------------------------------------------------- original default artwork
def _font(size):
    path = os.path.join(ROOT, "fonts", "Cairo-SemiBold.ttf")
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        return ImageFont.load_default()


def _squares(layer, cx, cy, sizes, color, width):
    d = ImageDraw.Draw(layer)
    for size, ang in sizes:
        pts = []
        for k in range(4):
            a = math.radians(ang + 45 + 90 * k)
            pts.append((cx + size * math.cos(a), cy + size * math.sin(a)))
        d.line(pts + [pts[0]], fill=color, width=width, joint="curve")


def _text_ar(layer, xy, text, size, fill):
    d = ImageDraw.Draw(layer)
    kw = {"font": _font(size), "anchor": "mm"}
    try:
        kw.update(direction="rtl", language="ar")
        d.text(xy, text, fill=fill, **kw)
    except Exception:
        kw.pop("direction", None)
        kw.pop("language", None)
        d.text(xy, text, fill=fill, **kw)


def fallback_card(reciter_id=0, name=u""):
    """The ORIGINAL default poster: diamonds + book medallion + 'القرآن الكريم / تلاوات خاشعة'."""
    S = 3
    w, h = CARD_W, CARD_H
    W, H = w * S, h * S
    top, bottom = (40, 76, 73), (9, 27, 30)
    img = _gradient((W, H), top, bottom).convert("RGBA")
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    cx, cy = W // 2, int(H * 0.37)
    _squares(layer, cx, cy, ((118 * S, 0), (88 * S, 0), (96 * S, 45 + 0)), (214, 184, 120, 120), int(1.6 * S))
    _squares(layer, cx, cy, ((70 * S, 45),), (214, 184, 120, 95), int(1.4 * S))
    d = ImageDraw.Draw(layer)
    r = 44 * S
    d.rounded_rectangle((cx - r, cy - r, cx + r, cy + r), 22 * S, fill=(8, 28, 30, 235), outline=(224, 192, 124, 255), width=int(2 * S))
    # open book
    bw, bh = 24 * S, 20 * S
    pts_l = [(cx, cy - bh + 4 * S), (cx - bw, cy - bh + 9 * S), (cx - bw, cy + bh), (cx, cy + bh - 5 * S)]
    pts_r = [(cx, cy - bh + 4 * S), (cx + bw, cy - bh + 9 * S), (cx + bw, cy + bh), (cx, cy + bh - 5 * S)]
    for pts in (pts_l, pts_r):
        d.line(pts + [pts[0]], fill=(238, 206, 140, 255), width=int(3 * S), joint="curve")
    d.line([(cx, cy - bh + 4 * S), (cx, cy + bh - 5 * S)], fill=(238, 206, 140, 255), width=int(3 * S))
    _text_ar(layer, (W // 2, int(H * 0.615)), u"القرآن الكريم", 21 * S, (240, 222, 176, 255))
    _text_ar(layer, (W // 2, int(H * 0.70)), u"تلاوات خاشعة", 15 * S, (118, 204, 168, 255))
    img.alpha_composite(layer)
    img = img.resize((w, h), _lanczos())
    band_y = h - PLATE_H + 6
    band = _gradient((w, h - band_y), (14, 44, 44), (6, 22, 24)).convert("RGBA")
    img.alpha_composite(band, (0, band_y))
    img.alpha_composite(Image.new("RGBA", (w, 1), (214, 184, 120, 190)), (0, band_y))
    return _finish(img)


def fallback_player(reciter_id=0, name=u""):
    """The ORIGINAL default portrait tile: nested diamonds with a headphones glyph."""
    S = 3
    w, h = PLAYER_W, PLAYER_H
    W, H = w * S, h * S
    img = _gradient((W, H), (30, 66, 62), (10, 30, 32)).convert("RGBA")
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    cx, cy = W // 2, H // 2
    _squares(layer, cx, cy, ((70 * S, 0), (50 * S, 0), (58 * S, 45)), (214, 184, 120, 125), int(1.5 * S))
    d = ImageDraw.Draw(layer)
    r = 25 * S
    d.rounded_rectangle((cx - r, cy - r, cx + r, cy + r), 8 * S, fill=(8, 28, 30, 230), outline=(214, 184, 120, 220), width=int(1.6 * S))
    col = (244, 214, 148, 255)
    d.arc((cx - 15 * S, cy - 16 * S, cx + 15 * S, cy + 14 * S), 180, 360, fill=col, width=int(3.2 * S))
    d.rounded_rectangle((cx - 17 * S, cy - 3 * S, cx - 10 * S, cy + 12 * S), 3 * S, fill=col)
    d.rounded_rectangle((cx + 10 * S, cy - 3 * S, cx + 17 * S, cy + 12 * S), 3 * S, fill=col)
    img.alpha_composite(layer)
    return _finish(img.resize((w, h), _lanczos()), 18)
