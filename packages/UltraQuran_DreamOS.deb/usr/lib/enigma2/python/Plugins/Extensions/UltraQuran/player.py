# -*- coding: utf-8 -*-
"""Ultra Quran playback engine.

Ported from the Ultra Stalker "New 2" player design:
  * engine fallback chain (4097 -> 5002 exteplayer3 -> 5001 gstplayer -> 8193 ServiceApp)
  * native offline local file support (files on /media/hdd play without network checks or false reconnects)
  * early-EOF guard: an end-of-file during the first seconds is a bad engine, not a finished track
  * a late EOF is only a real end when the position is near the known duration;
    otherwise the stream is re-opened and resumed from the last position
  * sane duration: the engine length is ignored while it is missing / absurdly short
  * absolute numeric seek with an accumulated target and coalesced seekTo() calls
"""
import os
import time

from enigma import eServiceReference, iPlayableService

from . import pipeplay
from . import fastlink
from .support import IS_DREAMOS, Timer, log, log_exception, native

clock = getattr(time, "monotonic", time.time)
PTS = 90000
START_TIMEOUT = 20          # seconds without confirmed playback before the next engine is tried
EARLY_WINDOW = 8            # an EOF this soon after (re)start is treated as a bad engine
STALL_TIMEOUT = 60          # only a really dead stream is re-opened; the engine does its own buffering
MAX_RECONNECT = 3           # consecutive reconnects that made no progress
QUIET = 3.0 if IS_DREAMOS else 1.2                 # seconds after (re)start during which stale service events are ignored  (DreamOS players send stop events while they start: Ultra Stalker waits too)
SEEK_COALESCE = 0.35
SEEK_DUPLICATE = 0.055
SEEK_END_GUARD = 15         # seconds kept before the end on forward seeks
TARGET_HOLD = 12            # a seek target is shown until the engine really arrives there (at most this long)
FROZEN_AFTER = 8            # seconds an engine may repeat the same position before it is treated as not reporting
ENGINE_FRESH = 1.6          # an engine position read this recently is the truth; older -> the display keeps counting
RESUME_RETRY = 0.9          # seconds between resume seek attempts until the position is confirmed
RESUME_TRIES = 9
EOF = getattr(iPlayableService, "evEOF", None)
FAILED = getattr(iPlayableService, "evTuneFailed", None)
START = getattr(iPlayableService, "evStart", None)
STREAM_ERROR = getattr(iPlayableService, "evStreamError", None)

PIPE = 1                    # pseudo engine id: ffmpeg decodes, the plugin's own clock paces it (pipeplay.py)
PIPE_CONNECT_TIMEOUT = 45   # the first start also probes ffmpeg and the sound routes
ENGINE_NAMES = {PIPE: "ffmpeg", 4097: "GStreamer", 5002: "ExtePlayer3", 5001: "GstPlayer", 8193: "ServiceApp"}


RESUME_PATH = "/etc/enigma2/ultra-quran-resume.json"
RESUME_MIN = 30             # a recording is remembered once it played this long ...
RESUME_TAIL = 30            # ... and forgotten when it stopped this close to its end
RESUME_KEEP = 400           # most recent recordings kept
RESUME_EVERY = 15           # seconds between saves while playing


class ResumeStore(object):
    """Last position of every recording / video (seconds), so it continues where it was stopped."""

    def __init__(self, path=RESUME_PATH):
        self.path = path
        self.data = None
        self.dirty = False

    def _load(self):
        if self.data is None:
            self.data = {}
            try:
                import json
                with open(self.path) as handle:
                    raw = json.load(handle)
                if isinstance(raw, dict):
                    self.data = dict((k, v) for k, v in raw.items() if isinstance(v, list) and len(v) >= 2)
            except Exception:
                self.data = {}
        return self.data

    def get(self, key):
        entry = self._load().get(key)
        return float(entry[0]) if entry else 0.0

    def put(self, key, seconds, title=u"", total=0, video=False, who=u""):
        data = self._load()
        old = data.get(key)
        if old and abs(float(old[0]) - seconds) < 5 and len(old) >= 6:
            return
        data[key] = [int(seconds), int(time.time()), title or u"", int(total or 0), 1 if video else 0, who or u""]
        if len(data) > RESUME_KEEP:
            for k, _ in sorted(data.items(), key=lambda kv: kv[1][1])[:len(data) - RESUME_KEEP]:
                data.pop(k, None)
        self.save()

    def latest(self):
        """(url, seconds, title, total, who) of the most recent unfinished audio recording, or None."""
        best = None
        for key, entry in self._load().items():
            if len(entry) >= 5 and not entry[4] and entry[2] and (best is None or entry[1] > best[1][1]):
                best = (key, entry)
        if best is None:
            return None
        key, entry = best
        return key, float(entry[0]), entry[2], int(entry[3]), (entry[5] if len(entry) >= 6 else u"")

    def drop(self, key):
        if self._load().pop(key, None) is not None:
            self.save()

    def save(self):
        try:
            import json
            tmp = self.path + ".tmp"
            with open(tmp, "w") as handle:
                json.dump(self.data, handle)
            os.rename(tmp, self.path)
        except Exception:
            pass


RESUME = ResumeStore()


def same_ref(first, second):
    return first is not None and second is not None and first.toString() == second.toString()


VIDEO_EXT = (".mp4", ".mkv", ".avi", ".mov", ".webm", ".flv", ".m4v", ".ts", ".m3u8", ".mpg", ".mpeg", ".wmv", ".3gp")


def looks_like_video(url):
    path = (url or "").split("?", 1)[0].split("#", 1)[0].lower()
    return path.endswith(VIDEO_EXT)


PLAYER_FILE = "/etc/enigma2/ultra-quran-player.txt"
PLAYER_NAMES = {"exteplayer3": 5002, "exteplayer": 5002, "5002": 5002, "gstreamer": 4097, "4097": 4097,
                "dreamos": 8193, "serviceapp": 8193, "8193": 8193, "gstplayer": 5001, "5001": 5001}


def preferred_player():
    """/etc/enigma2/ultra-quran-player.txt: exteplayer3 / gstreamer / dreamos (or 5002 / 4097 / 8193) is tried first."""
    try:
        with open(PLAYER_FILE) as handle:
            return PLAYER_NAMES.get(handle.read().strip().lower())
    except EnvironmentError:
        return None


def available_engines(video=False, url=""):
    """The ffmpeg engine plays sound only, so anything with a picture always uses Enigma's own engines."""
    result = [PIPE] if (not video and pipeplay.can_play(url)) else []
    exte = os.path.exists("/usr/bin/exteplayer3")
    if IS_DREAMOS:
        # DreamOS: its own media player (8193) first (Ultra Stalker's default); newer Dreamboxes also get
        # exteplayer3 (ServiceApp 5002): it comes right after, before the GStreamer service
        engines = [8193] + ([5002] if exte else []) + [4097]
        if os.path.exists("/usr/bin/gstplayer"):
            engines.append(5001)
    else:
        engines = [4097]
        if exte:
            engines.append(5002)
        if os.path.exists("/usr/bin/gstplayer"):
            engines.append(5001)
        for path in ("/usr/lib/enigma2/python/Plugins/SystemPlugins/ServiceApp",
                     "/usr/lib/enigma2/python/Plugins/Extensions/ServiceApp",
                     "/var/lib/dpkg/status"):
            if os.path.exists(path):
                engines.append(8193)
                break
    wanted = preferred_player()
    if wanted in engines:
        engines.remove(wanted)
        engines.insert(0, wanted)
    return result + engines


class Audio(object):
    def __init__(self, nav, update, ended):
        self.nav = nav
        self.update = update
        self.ended = ended
        self.timer = Timer(self.tick)
        self.seek_timer = Timer(self.apply_seek)
        self._event_conn = None
        if hasattr(self.nav.event, "append"):
            self.nav.event.append(self.event)
        elif hasattr(self.nav.event, "connect"):
            self._event_conn = self.nav.event.connect(self.event)
        self.ref = None
        self.previous = None
        self.state = "idle"
        self.note = u""
        self.live = False
        self.is_local = False
        self.switching = False
        self.url = ""
        self.title = ""
        self.expected = 0              # catalogue estimate in seconds (only a fallback)
        self.engines = [4097]
        self.engine_index = 0
        self.position = self.length = 0
        self.pending = None
        self.started = False
        self.start_time = 0
        self.quiet_until = 0
        self.advance = 0               # PTS actually played since the engine was (re)started
        self.last_position = None
        self.last_move = 0
        self.resume_to = 0
        self.resume_tries = 0
        self.resume_next = 0
        self.resume_sent = False
        self.reconnects = 0
        self.progress_mark = 0
        self.seek_target = None
        self.seek_origin = None
        self.seek_hold_until = 0
        self.seek_sent_at = 0
        self.seek_key_at = 0
        self.interval = 0
        self.dead = False
        self.hint = u""
        self.hint_until = 0
        self.anchor = 0                # display timeline: position anchor (PTS) ...
        self.anchor_at = 0             # ... and the moment it was taken
        self.read_ok_at = 0            # last time the engine reported a usable position
        self.moved_at = 0              # last time the engine position changed
        self.pipe = None               # pipeplay.PipeEngine while the ffmpeg engine is in use
        self.offset = 0
        self.last_raw = None
        try:
            pipeplay.warm_up()
        except Exception:
            pass
        self.video = False

    # ------------------------------------------------------------------ helpers
    def current(self):
        current = self.nav.getCurrentlyPlayingServiceReference()
        if current is None:
            getter = getattr(self.nav, "getCurrentlyPlayingServiceOrGroup", None)
            if getter is not None:
                current = getter()
        return current

    @property
    def engine_name(self):
        return ENGINE_NAMES.get(self.engines[self.engine_index], "")

    def using_pipe(self):
        return self.engines[self.engine_index] == PIPE

    def _stop_pipe(self):
        if self.pipe is not None:
            try:
                self.pipe.stop()
            except Exception:
                log_exception("pipe stop failed")

    def total(self):
        """Trusted duration in PTS, or 0 when unknown."""
        if self.live:
            return 0
        engine = self.length
        guess = int(self.expected * PTS) if self.expected else 0
        if engine > 0 and guess > 5 * 60 * PTS and engine * 2 < guess:
            engine = 0                     # a joined / re-tagged mp3 whose header claims a fraction of its length
        if self.is_local and engine > 0:
            return max(engine, self.position)
        if engine > 0:
            return max(engine, self.position)
        if guess > 0:
            return max(guess, self.position)
        return 0

    def status_note(self):
        if self.hint and clock() < self.hint_until:
            return self.hint
        return self.note

    def _anchor(self, position, now=None):
        self.catchup = False
        self.anchor = max(0, int(position))
        self.anchor_at = now if now is not None else clock()

    def shown_position(self):
        """Smooth, never-freezing position for the UI.

        * the engine position is the truth whenever the engine reports one;
        * between engine reads (and whenever the engine reports nothing, e.g. while a stream
          buffers after a seek) the display keeps counting from the last known point, so the
          seconds counter always runs while playing and never drops back to 00:00;
        * a fresh seek shows its target at once and for at most TARGET_HOLD seconds."""
        if self.pipe is not None and self.using_pipe() and self.state in ("playing", "paused", "connecting"):
            if self.seek_target is not None:
                return self.seek_target
            value = int(self.pipe.position() * PTS)
            total = self.total()
            return min(value, total) if total > 0 else value
        now = clock()
        if self.state != "playing":
            return self.anchor
        if getattr(self, "catchup", False):
            return self.anchor
        fresh = now - self.read_ok_at <= ENGINE_FRESH
        if fresh and self.seek_target is None and 2.5 < now - self.moved_at <= FROZEN_AFTER:
            return self.anchor            # the engine says it is buffering: show the truth (it stands still)
        value = self.anchor + int(max(0.0, now - self.anchor_at) * PTS)
        total = self.total()
        if total > 0:
            value = min(value, total)
        return value

    def _timer(self, interval):
        if self.interval != interval:
            self.interval = interval
            self.timer.start(interval, False)

    # --------------------------------------------------------------------- play
    def remember(self):
        """Store where the current recording is (called while playing, on pause, stop and track change)."""
        try:
            if not self.url or self.live or self.state not in ("playing", "paused"):
                return
            position = self.shown_position() / float(PTS)
            total = self.total() / float(PTS)
            if total > 0 and position >= total - RESUME_TAIL:
                RESUME.drop(self.url)
            elif position >= RESUME_MIN:
                RESUME.put(self.url, position, self.title, total, self.video, getattr(self, "who", u""))
            self.saved_at = clock()
        except Exception:
            log_exception("resume save failed")

    def play(self, title, url, live=False, expected=0, video=False, who=u""):
        self.remember()                    # the recording that is being left keeps its place
        self.who = who or u""              # the sheikh / reciter, for the home "continue listening" card
        current = self.current()
        if self.ref is None or (current is not None and not same_ref(current, self.ref)):
            group = getattr(self.nav, "getCurrentlyPlayingServiceOrGroup", None)
            self.previous = (group() if group else None) or current
        self.timer.stop()
        self.seek_timer.stop()
        self.interval = 0
        self.title = native(title)
        self.url = native(url)
        self.is_local = bool(url and url.startswith("/"))
        # the data-server address found while the item was focused (saves the redirect at the start)
        self.stream = self.url if self.is_local else native(fastlink.final(self.url))
        self.live = False if self.is_local else live
        self.expected = int(expected or 0)
        self.video = bool(video) or looks_like_video(self.url)
        self.engines = available_engines(self.video, self.url)
        self.engine_index = 0
        self.reconnects = 0
        self.progress_mark = 0
        self.note = u""
        self.state = "connecting"
        self.seek_target = None
        self.resume_to = 0
        self._mute(False)
        resume = 0 if self.live else RESUME.get(self.url)
        if resume < RESUME_MIN or (self.expected and resume >= self.expected - RESUME_TAIL):
            resume = 0
        self.saved_at = clock()
        self._open(resume=int(resume * PTS))
        if resume:
            self.hint = u"استكمال من حيث توقفت  ·  " + self.clock_text(resume)
            self.hint_until = clock() + 5
            log(u"Resume %s at %d s" % (self.title, resume))
        try:
            from .frontpanel import UltraQuranFrontSummary
            UltraQuranFrontSummary.set_title(title)
        except Exception:
            pass
        self.update()
        self._timer(250)

    def _open(self, resume=0):
        """(Re)start the stream with the current engine."""
        self.pending = None
        self.started = False
        self.position = self.length = 0
        self.advance = 0
        self.last_position = None
        self.start_time = clock()
        self.last_move = self.start_time
        self.quiet_until = self.start_time + (0.35 if self.is_local else QUIET)
        self.resume_to = int(resume or 0)
        self._anchor(self.resume_to)
        self.read_ok_at = 0
        self.moved_at = 0
        self.offset = 0                # engine clock -> media time (engines that restart at 0 after a seek)
        self.last_raw = None
        self.resume_tries = 0
        self.resume_next = 0
        self.resume_sent = False
        current = self.current()
        if self.using_pipe():
            self._open_pipe(resume)
            return
        self._stop_pipe()
        new_ref = eServiceReference(self.engines[self.engine_index], 0, self._stream_url())
        new_ref.setName(self.title)
        self.switching = True
        try:
            if self.ref is not None or same_ref(current, new_ref):
                self.nav.stopService()
            self.ref = new_ref
            if self.nav.playService(self.ref) not in (None, 0, False):
                self.pending = "error"
        except Exception:
            log_exception("Playback start failed (%s)" % self.engine_name)
            self.pending = "error"
        finally:
            self.switching = False

    def _open_pipe(self, resume):
        """ffmpeg engine: Enigma's own player is stopped (so nothing else holds the sound) and the plugin plays."""
        self.resume_to = 0                 # the start offset goes straight to ffmpeg (-ss); no seek-and-hope
        self._anchor(int(resume or 0))
        self.switching = True
        try:
            if self.current() is not None:
                self.nav.stopService()
            if self.ref is None:
                self.ref = eServiceReference(4097, 0, self.url)     # placeholder: marks "we own the audio now"
        except Exception:
            log_exception("Could not stop the running service")
        finally:
            self.switching = False
        if self.pipe is None:
            self.pipe = pipeplay.PipeEngine()
        self.pipe.start(self._stream_url(), (resume or 0) / float(PTS), self.is_local, (self.expected or 0))

    def _stream_url(self):
        """The resolved address for the first try; any retry or other engine goes back to the catalogue link."""
        stream = getattr(self, "stream", None) or self.url
        if stream != self.url and (self.engine_index or self.reconnects):
            fastlink.forget(self.url)
            self.stream = self.url
            return self.url
        return stream

    # ------------------------------------------------------------------- events
    def event(self, event):
        if self.using_pipe():
            return
        if self.switching:
            if event == START:
                self.started = True
            return
        if self.ref is None or self.dead or not same_ref(self.current(), self.ref):
            return
        if event == START:
            self.started = True
            return
        if clock() < self.quiet_until:
            return
        if event == EOF:
            self.pending = "eof"
        elif event in (FAILED, STREAM_ERROR):
            self.pending = "error"

    # --------------------------------------------------------------------- tick
    def _read(self):
        service = self.nav.getCurrentService()
        if service is None:
            return False
        try:
            seek = service.seek()
            if seek is None:
                return False
            error, length = seek.getLength()
            if not error and length > 0:
                # some engines report the REST of the file after an HTTP seek: the longest length seen wins
                self.length = max(self.length, int(length))
            error, position = seek.getPlayPosition()
            now = clock()
            if not error and position > 0:
                raw = int(position)
                target = self.seek_target if self.seek_target is not None else (
                    self.resume_to if (self.resume_to and self.resume_sent) else None)
                self.last_raw = raw
                if self.seek_target is not None:
                    # a user seek in the middle: an engine that ignored it keeps counting from where it was,
                    # one that restarted its clock reports about the time since the seek
                    # (a stale engine repeats its OLD position: that is not a drop, so it is not mistaken for this)
                    since = max(0.0, now - self.seek_sent_at)
                    before = getattr(self, "seek_raw", None)
                    prev = getattr(self, "seek_prev_raw", None)
                    self.seek_prev_raw = raw
                    counting = prev is not None and raw > prev and abs(raw - int(since * PTS)) <= int(1.5 * PTS)
                    restarted = (before is not None and raw != before and raw <= int((since + 3) * PTS)
                                 and (raw < before or counting))
                else:
                    # resume after a re-open: the engine was near 0 already, so only a DROP of its clock proves
                    # that it restarted counting at the resume point (an ignored seek keeps counting up)
                    before = getattr(self, "resume_raw", None)
                    restarted = before is not None and raw < before - int(0.3 * PTS)
                if (target is not None and target > 8 * PTS and restarted
                        and abs(raw + self.offset - target) > 4 * PTS):
                    # the engine restarted its clock at the seek point (GStreamer + HTTP mp3 without an
                    # index): it counts from 0 again although it plays at the target -> map it back
                    self.offset = int(target) - raw
                    log("Engine counts from the seek point: offset %d s" % (self.offset // PTS))
                position = raw + self.offset
                if self.last_position is not None:
                    delta = position - self.last_position
                    if 0 < delta <= 5 * PTS:
                        self.advance += delta
                        self.last_move = now
                unchanged = position == self.last_position
                if not unchanged:
                    self.moved_at = now
                self.last_position = position
                self.position = position
                self.read_ok_at = now
                if self.resume_to and position < self.resume_to - 6 * PTS:
                    pass                       # re-opened stream still at its start: keep showing the resume point
                elif self.seek_target is not None and not self._arrived(position):
                    pass                       # stale read from before the seek (or the engine is still on its way)
                elif unchanged and self.state == "playing" and self.seek_target is None \
                        and now - self.moved_at > FROZEN_AFTER:
                    # the engine repeats one position while sound/picture play: count on our own clock
                    if getattr(self, "catchup", False):
                        self.catchup = False
                        self._anchor(self.anchor, self.anchor_at)
                elif self.state == "playing" and 0 < self.shown_position() - position <= 10 * PTS:
                    if not getattr(self, "catchup", False):
                        self._anchor(self.shown_position(), now)
                        self.catchup = True    # engine a little behind the counter: hold, never count backwards
                else:
                    self.catchup = False
                    self._anchor(position, now)
        except Exception:
            return False
        return True

    def tick(self):
        if self.ref is None or self.dead:
            return
        now = clock()
        if self.state == "playing" and now - getattr(self, "saved_at", 0) >= RESUME_EVERY:
            self.remember()
        pending, self.pending = self.pending, None
        if pending:
            self._interrupted(pending)
            return
        if self.using_pipe():
            self._tick_pipe(now)
            return
        current = self.current()
        if current is not None and not same_ref(current, self.ref):
            if self.state != "connecting" or now - self.start_time >= 3:
                self._recover(u"تغيّرت الخدمة")
            return
        have = self._read() if current is not None else False
        if self.resume_to:
            self._apply_resume()
        if self.state == "connecting":
            confirmed = self.advance >= int(0.4 * PTS)
            if not confirmed and self.is_local and (have or self.started) and now - self.start_time >= 0.4:
                confirmed = True
            if not confirmed and have and self.started and (self.live or self.length == 0) and now - self.start_time >= 2.5:
                confirmed = True
            if not confirmed and current is not None and self.started and not self.read_ok_at and now - self.start_time >= 4:
                confirmed = True               # the engine plays but never reports a position: the counter runs on its own
            if confirmed:
                self.state = "playing"
                self.note = u""
                if self.resume_to:
                    self._anchor(self.resume_to, now)
                else:
                    self._anchor(self.position if self.read_ok_at else self.anchor, now)
                self.moved_at = now
                self._timer(500)
                self.last_move = now
            elif now - self.start_time >= (6 if self.is_local else START_TIMEOUT):
                self._next_engine(u"انتهت مهلة الاتصال")
                return
        elif self.state == "playing":
            if self.seek_target is not None:
                since = now - self.seek_sent_at
                if self.read_ok_at > self.seek_sent_at and self._arrived(self.position):
                    self.seek_target = None
                    self.last_move = now
                elif (since >= 4 and self.seek_sent_at and now - self.read_ok_at <= ENGINE_FRESH and self.position > 0
                      and abs(self.position - (self.seek_origin + int(since * PTS))) <= 4 * PTS):
                    # the engine keeps playing on its old timeline: it accepted the seek but ignored it
                    self.seek_target = None
                    self.last_move = now
                    self._anchor(self.position, now)
                    self.hint = u"التقديم غير متاح لهذا الملف"
                    self.hint_until = now + 2.5
                elif now >= self.seek_hold_until:
                    # the engine did not land on the target: from now on its own position is shown
                    self.seek_target = None
                    self.last_move = now
                    if now - self.read_ok_at <= ENGINE_FRESH and self.position > 0:
                        self._anchor(self.position, now)
            idle = now - self.last_move
            frozen = now - self.moved_at > FROZEN_AFTER and self.advance < 20 * PTS
            if not self.is_local:
                if 2.5 < idle <= FROZEN_AFTER and have and not self.live:
                    self.note = u"تخزين مؤقت…"
                elif idle <= 2.5 or frozen:
                    self.note = u""
                if idle > STALL_TIMEOUT and not frozen:
                    self._recover(u"توقّف البث")
                    return
            if self.advance > 20 * PTS and self.progress_mark != 1:
                self.progress_mark = 1
                self.reconnects = 0
        elif self.state == "paused":
            self.last_move = now
        self.update()

    def _tick_pipe(self, now):
        """Everything comes from the plugin's own clock: no engine position is ever read."""
        pipe = self.pipe
        if pipe is None:
            return
        status = pipe.status
        self.position = int(pipe.position() * PTS)
        if pipe.duration > 0:
            self.length = int(pipe.duration * PTS)
        self.advance = int(pipe.played() * PTS)
        self._anchor(self.position, now)
        if status == "error":
            self._pipe_error(pipe)
            return
        if status == "ended":
            self._pipe_ended()
            return
        if self.state == "connecting":
            if pipe.status == "playing" and pipe.has_audio():
                self.state = "playing"
                self.note = u""
                self.last_move = now
                self.moved_at = now
                pipeplay.note_success()
                self._timer(500)
            elif now - self.start_time >= PIPE_CONNECT_TIMEOUT:
                pipeplay.note_failure(u"timeout")
                self._next_engine(u"انتهت مهلة الاتصال")
                return
        elif self.state == "playing":
            self.note = u"تخزين مؤقت…" if (pipe.is_starved() and not self.is_local) else u""
            if self.advance > 20 * PTS and self.progress_mark != 1:
                self.progress_mark = 1
                self.reconnects = 0
        self.update()

    def _pipe_error(self, pipe):
        log(u"ffmpeg engine error: %s" % pipe.error)
        if self.advance < 3 * PTS and self.state == "connecting":
            if pipe.no_route:
                pipeplay.note_failure(pipe.error)
            self._stop_pipe()
            self._next_engine(u"محرك ffmpeg: " + pipe.error)
            return
        self._stop_pipe()
        if self.is_local:
            self._fail(pipe.error)
        else:
            self._recover(u"انقطع الاتصال")

    def _pipe_ended(self):
        self._stop_pipe()
        lengths = [t for t in (self.length, int(self.expected * PTS) if self.expected else 0) if t > 0]
        if self.live:
            self._recover(u"انقطع البث المباشر")
        elif self.is_local or not lengths or self._near_end():
            self._finish_track()
        else:
            self._recover(u"انتهى البث مبكراً")

    def _apply_resume(self):
        """Jump back to the resume point as soon as the engine accepts a seek, and only
        consider it done once the reported position really is there (some engines
        return success from seekTo() and silently keep playing from the start)."""
        now = clock()
        target = self.resume_to
        if self.resume_sent and self.position >= target - 6 * PTS:
            self._resume_done()
            return
        if not (self.started or self.advance > 0 or self.last_position is not None):
            return
        if now < self.resume_next:
            return
        if self.resume_tries >= RESUME_TRIES:
            log("Resume gave up at %d s" % (target // PTS))
            self._resume_done()
            return
        self.resume_tries += 1
        self.resume_next = now + RESUME_RETRY
        try:
            service = self.nav.getCurrentService()
            seek = service.seek() if service is not None else None
            if seek is None:
                return
            if seek.seekTo(int(target)) not in (None, 0, False):
                delta = int(target - self.position)
                seek.seekRelative(1 if delta >= 0 else -1, abs(delta))
            self.resume_sent = True
            self.resume_raw = self.last_raw
            self.last_position = None
            self.last_move = now
        except Exception:
            log_exception("Resume seek failed")

    def _resume_done(self):
        self.resume_to = 0
        self.resume_sent = False
        self.last_position = None
        self.last_move = clock()
        self._mute(False)

    def _mute(self, on):
        """Kept as a no-op: the player never touches the receiver volume."""
        return

    # -------------------------------------------------------------- recovery
    def _near_end(self):
        """An end-of-stream close to the shortest known length (engine estimate or the real length from
        the catalogue) is the real end of the track - never a reason to reconnect and replay it."""
        position = max(self.position, self.resume_to)
        lengths = [t for t in (self.length, int(self.expected * PTS) if self.expected else 0) if t > 0]
        if not lengths:
            return False
        total = min(lengths)
        if len(lengths) == 2 and lengths[1] > 5 * 60 * PTS and lengths[0] * 2 < lengths[1]:
            total = lengths[1]             # the engine's length is a broken header: the catalogue knows better
        return position >= total - max(8 * PTS, int(total * 0.05))

    def _interrupted(self, kind):
        now = clock()
        played = self.advance
        if self.is_local:
            # Local Hard Drive file: an EOF after decoding starts is always the real end of the track
            if kind == "eof" and (played >= int(0.3 * PTS) or self.position > 0 or now - self.start_time >= 1.2):
                self._finish_track()
                return
            self._next_engine(u"محرك بديل للملف المحلي")
            return
        if self.live:
            self._recover(u"انقطع البث المباشر")
            return
        if kind == "eof" and self._near_end():
            self._finish_track()
            return
        if now - self.start_time < EARLY_WINDOW and played < 2 * PTS:
            self._next_engine(u"انتهى البث مبكراً")
            return
        self._recover(u"انقطع الاتصال")

    def _recover(self, reason):
        """The stream dropped in the middle: re-open it and resume where it stopped."""
        log(u"Recover: " + reason)
        position = self.seek_target if self.seek_target is not None else self.position
        position = max(position, self.resume_to)
        if self.advance >= 5 * PTS:
            self.reconnects = 0
        self.reconnects += 1
        if self.reconnects > MAX_RECONNECT:
            total = self.total()
            if not self.live and (total <= 0 and position > 30 * PTS or total > 0 and position >= int(total * 0.9)):
                self._finish_track()
            else:
                self._fail(u"تعذّر استكمال التشغيل")
            return
        self.note = u"إعادة الاتصال (%d)…" % self.reconnects
        self.state = "connecting"
        self.seek_target = None
        self._open(resume=0 if self.live else max(0, position - 2 * PTS))
        self.update()
        self._timer(250)

    def _next_engine(self, reason):
        log(u"Engine %s failed: %s" % (self.engine_name, reason))
        if self.engine_index + 1 < len(self.engines):
            self.engine_index += 1
            self.note = u"محرك بديل: " + self.engine_name
            self.state = "connecting"
            here = max(self.position, self.resume_to)
            resume = here if here > 10 * PTS and not self.live else 0
            self._open(resume=resume)
            self.update()
            self._timer(250)
        else:
            self._fail(reason)

    def _fail(self, reason):
        self._stop_pipe()
        self._mute(False)
        self.resume_to = 0
        self.state = "error"
        self.note = u""
        self.seek_target = None
        self.timer.stop()
        self.interval = 0
        self.update()
        log(reason)

    def _finish_track(self):
        if self.url:
            RESUME.drop(self.url)          # heard to the end: next time it starts from the beginning
        self._stop_pipe()
        self._mute(False)
        self.resume_to = 0
        self.timer.stop()
        self.interval = 0
        self.seek_target = None
        self.ended()

    # ----------------------------------------------------------- pause / seek
    def toggle(self):
        if self.state in ("playing", "paused") and self.using_pipe() and self.pipe is not None:
            if self.state == "playing":
                if not self.pipe.pause():
                    return False
                self.state = "paused"
                self.remember()
            else:
                if not self.pipe.resume():
                    return False
                self.state = "playing"
                self.last_move = clock()
            self.update()
            return True
        if self.state not in ("playing", "paused") or not same_ref(self.current(), self.ref):
            return False
        try:
            service = self.nav.getCurrentService()
            pause = service.pause() if service is not None else None
            if pause is None:
                return False
            if self.state == "playing":
                shown = self.shown_position()
                if pause.pause() not in (None, 0, False):
                    return False
                self._anchor(shown)
                self.state = "paused"
                self.remember()
            else:
                if pause.unpause() not in (None, 0, False):
                    return False
                self.state = "playing"
                self.last_move = clock()
                self._anchor(self.anchor)
                self.moved_at = clock()
            self.update()
            return True
        except Exception:
            log_exception("Pause / resume failed")
            return False

    def seekable(self):
        if self.using_pipe():
            if self.live or self.state not in ("playing", "paused") or self.pipe is None:
                return None
            return self.pipe
        if self.live or self.state not in ("playing", "paused") or not same_ref(self.current(), self.ref):
            return None
        try:
            service = self.nav.getCurrentService()
            seek = service.seek() if service is not None else None
            if seek is None:
                return None
            return seek
        except Exception:
            return None

    def seek_seconds(self, seconds):
        """Relative seek with an accumulated absolute target (fast repeated presses add up)."""
        now = clock()
        if now - self.seek_key_at < SEEK_DUPLICATE:
            return True
        self.seek_key_at = now
        if self.seekable() is None:
            return False
        base = self.seek_target if self.seek_target is not None else self.shown_position()
        target = base + int(seconds * PTS)
        total = self.total()
        if target < 0:
            target = 0
        if seconds > 0 and total > 2 * SEEK_END_GUARD * PTS:
            target = min(target, total - SEEK_END_GUARD * PTS)
            if target <= base and base >= total - SEEK_END_GUARD * PTS:
                target = base
        self.seek_back = (self.anchor, self.anchor_at)
        self.seek_origin = base
        self.seek_target = target
        self._anchor(target, now)
        self.moved_at = now
        self.hint = (u"تقديم  +" if seconds > 0 else u"ترجيع  \u2212") + self.label(abs(seconds))
        self.hint_until = now + 1.6
        self.seek_hold_until = now + TARGET_HOLD
        self.last_move = now
        if now - self.seek_sent_at >= SEEK_COALESCE:
            self.apply_seek()
        else:
            self.seek_timer.start(int(SEEK_COALESCE * 1000), True)
        self.update()
        return True

    def _arrived(self, position):
        """Did the engine land on the seek target? (Ultra Stalker rule: the tolerance grows with the jump,
        and having covered most of the way also counts - engines land on a key frame near the target.)"""
        target = self.seek_target
        if target is None:
            return True
        if position <= 0:
            return False
        origin = getattr(self, "seek_origin", None)
        error = abs(position - target)
        if origin is None:
            return error <= 20 * PTS
        distance = abs(target - origin)
        if error <= min(20 * PTS, max(3 * PTS, distance // 3)):
            return True
        moved = (position - origin) if target >= origin else (origin - position)
        return moved >= int(distance * 0.6) and error <= distance

    @staticmethod
    def clock_text(seconds):
        seconds = int(seconds)
        hours, rest = divmod(seconds, 3600)
        return u"%d:%02d:%02d" % (hours, rest // 60, rest % 60) if hours else u"%02d:%02d" % (rest // 60, rest % 60)

    @staticmethod
    def label(seconds):
        seconds = int(seconds)
        if seconds >= 60 and seconds % 60 == 0:
            return u"%d د" % (seconds // 60)
        return u"%d ث" % seconds

    def apply_seek(self):
        target = self.seek_target
        if target is None:
            return
        self.seek_sent_at = clock()
        self.seek_raw = self.last_raw
        self.seek_prev_raw = None
        seek = self.seekable()
        ok = False
        if seek is not None and self.using_pipe():
            ok = bool(seek.seek(target / float(PTS)))
            if ok:
                self.seek_target = None        # the engine shows the new place at once and counts from there
                self.last_move = clock()
                self.update()
                return
        elif seek is not None:
            try:
                ok = seek.seekTo(int(target)) in (None, 0, False)
            except Exception:
                log_exception("seekTo failed")
            if not ok:
                try:
                    delta = int(target - self.position)
                    ok = seek.seekRelative(1 if delta >= 0 else -1, abs(delta)) in (None, 0, False)
                except Exception:
                    log_exception("Seek failed")
        if not ok:
            # the engine cannot seek in this stream: never show a fake position
            self.seek_target = None
            back = getattr(self, "seek_back", None)
            if back:
                self.anchor, self.anchor_at = back
            self.hint = u"التقديم غير متاح لهذا الملف"
            self.hint_until = clock() + 2.5
            self.update()

    def seek(self, direction):
        return self.seek_seconds(10 * direction)

    # ----------------------------------------------------------------- finish
    def finished(self):
        self.state = "finished"
        self.note = u""
        self.seek_target = None
        if self.length:
            self.position = self.length
            self._anchor(self.length)
        self.update()

    def release(self):
        self.remember()
        self._stop_pipe()
        self._mute(False)
        self.resume_to = 0
        self.timer.stop()
        self.seek_timer.stop()
        self.interval = 0
        try:
            from .frontpanel import UltraQuranFrontSummary
            UltraQuranFrontSummary.reset()
        except Exception:
            pass
        if self.ref is None:
            return
        target, original = self.ref, self.previous
        self.ref = self.previous = None
        self.pending = None
        self.state = "idle"
        self.note = u""
        self.seek_target = None
        try:
            current = self.current()
            if same_ref(current, target):
                self.nav.stopService()
                current = None
            if current is None and original is not None:
                self.nav.playService(original)
        except Exception:
            log_exception("Could not restore previous service")

    def close(self):
        self.dead = True
        self.release()
        self.timer.close()
        self.seek_timer.close()
        try:
            if self._event_conn is not None:
                self._event_conn = None
            elif hasattr(self.nav.event, "remove") and self.event in self.nav.event:
                self.nav.event.remove(self.event)
        except Exception:
            pass
