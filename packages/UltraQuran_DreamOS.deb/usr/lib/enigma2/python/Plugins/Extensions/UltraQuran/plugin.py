from Plugins.Plugin import PluginDescriptor


def main(session, **kwargs):
    try:
        from .screen import UltraQuran
        session.open(UltraQuran)
    except Exception:
        from .support import log_exception
        log_exception("Cannot open Ultra Quran")
        # Queue a notification instead of opening a second modal dialog while
        # Enigma2 is still unwinding an unsuccessful session.open().
        try:
            from Screens.MessageBox import MessageBox
            from Tools.Notifications import AddPopup
            AddPopup("Ultra Quran could not open. See /tmp/ultra-quran.log.",
                     MessageBox.TYPE_ERROR, 8, "UltraQuranOpenError")
        except Exception:
            log_exception("Cannot queue the startup notification")


def Plugins(**kwargs):
    return [PluginDescriptor(
        name="Ultra Quran",
        description="Quran recitations, Mushaf and radio",
        where=PluginDescriptor.WHERE_PLUGINMENU,
        icon="plugin.png",
        fnc=main,
    )]
