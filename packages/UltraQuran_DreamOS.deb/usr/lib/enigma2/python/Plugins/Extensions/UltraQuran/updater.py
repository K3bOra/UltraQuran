# -*- coding: utf-8 -*-
"""Online update of Ultra Quran from GitHub.

The plugin reads a small manifest (update.json) from github.com/K3bOra/UltraQuran (same layout as
Ultra Stalker's repository):

    {"version": "0.7.7",
     "ipk": "https://github.com/K3bOra/UltraQuran/releases/download/v0.7.7/enigma2-plugin-extensions-ultraquran_0.7.7_all.ipk",
     "ipk_sha256": "...", "deb": ".../enigma2-plugin-extensions-ultraquran_0.7.7_all.deb", "deb_sha256": "...",
     "notes_ar": "what is new"}

Only packages from the project's own GitHub releases are accepted, and their SHA-256 must match.

When it names a newer version, the right package for this image (.ipk for OpenATV / OpenBH with opkg,
.deb for DreamOS with dpkg) is downloaded to /tmp and installed; Enigma2 is then restarted on request.
Everything slow runs in a worker thread; the screen polls `state`.

The manifest address is UPDATE_URL below, or the first line of /etc/enigma2/ultra-quran-update-url.txt.
"""
import os
import re
import subprocess
import threading
import time

from . import VERSION
from .support import log, log_exception

UPDATE_URL = "https://raw.githubusercontent.com/K3bOra/UltraQuran/main/update.json"
ALLOWED = r"^https://github\.com/K3bOra/UltraQuran/releases/download/[^/]+/[-_A-Za-z0-9.]+\.(ipk|deb)$"
UPDATE_URL_FILE = "/etc/enigma2/ultra-quran-update-url.txt"
HERE = os.path.dirname(os.path.abspath(__file__))
UA = "UltraQuran/%s (Enigma2)" % VERSION
from .support import IS_DREAMOS


def manifest_url():
    try:
        with open(UPDATE_URL_FILE) as handle:
            line = handle.read().strip().splitlines()[0].strip()
        if line.startswith("http"):
            return line
    except Exception:
        pass
    return UPDATE_URL


def configured():
    return "OWNER/REPO" not in manifest_url()


def notes(info):
    text = info.get("notes_ar") or info.get("notes") or u""
    if isinstance(text, list):
        text = u"  ·  ".join(text)
    return text


def version_tuple(text):
    return tuple(int(x) for x in re.findall(r"\d+", str(text or ""))[:4]) or (0,)


def _contexts():
    try:
        import ssl
    except ImportError:
        return [None]
    out = [None]
    bundle = os.path.join(HERE, "certs", "cacert.pem")
    try:
        if os.path.isfile(bundle):
            out.append(ssl.create_default_context(cafile=bundle))
    except Exception:
        pass
    try:
        out.append(ssl._create_unverified_context())
    except Exception:
        pass
    return out


def _open(url, timeout=20):
    try:
        from urllib.request import Request, urlopen
    except ImportError:
        from urllib2 import Request, urlopen
    last = None
    for ctx in _contexts():
        try:
            req = Request(url, headers={"User-Agent": UA, "Accept": "*/*", "Cache-Control": "no-cache"})
            return urlopen(req, timeout=timeout, **({"context": ctx} if ctx is not None else {}))
        except Exception as exc:
            last = exc
            if not any(w in str(exc).lower() for w in ("ssl", "certificate", "tls", "handshake")):
                break
    raise last if last is not None else IOError("no connection")


def _wget(url, target, timeout=60):
    for cmd in (["wget", "-q", "-T", str(timeout), "-U", UA, "-O", target, url],
                ["curl", "-s", "-L", "--max-time", str(timeout * 10), "-A", UA, "-o", target, url]):
        try:
            if subprocess.call(cmd) == 0 and os.path.isfile(target) and os.path.getsize(target) > 0:
                return True
        except Exception:
            continue
    return False


class Updater(object):
    """state: idle | checking | latest | available | downloading | installing | done | error"""

    def __init__(self):
        self.state = "idle"
        self.info = {}
        self.message = u""
        self.progress = 0
        self.manual = False
        self.lock = threading.Lock()

    def busy(self):
        return self.state in ("checking", "downloading", "installing")

    def _run(self, target):
        thread = threading.Thread(target=target)
        thread.daemon = True
        thread.start()

    # -------------------------------------------------------------- check
    def check(self, manual=True):
        if self.busy():
            return False
        self.manual = manual
        if not configured():
            self.state = "error"
            self.message = u"رابط التحديث غير مضبوط بعد"
            return True
        self.state = "checking"
        self._run(self._check)
        return True

    def _check(self):
        try:
            import json
            url = manifest_url()
            sep = "&" if "?" in url else "?"
            resp = _open(url + sep + "t=%d" % int(time.time()))        # no stale CDN copy
            try:
                data = json.loads(resp.read(65536).decode("utf-8", "replace"))
            finally:
                resp.close()
            self.info = data
            if version_tuple(data.get("version")) > version_tuple(VERSION):
                self.state = "available"
            else:
                self.state = "latest"
        except Exception as exc:
            log(u"update check failed: %s" % exc)
            self.message = u"تعذر الاتصال بخادم التحديث"
            self.state = "error"

    # ------------------------------------------------------------ install
    def install(self):
        if self.busy() or self.state != "available":
            return False
        self.state = "downloading"
        self.progress = 0
        self._run(self._install)
        return True

    def _install(self):
        kind = "deb" if IS_DREAMOS else "ipk"
        url = self.info.get(kind) or ""
        if not url:
            self.message = u"لا يوجد ملف تحديث لهذا الجهاز"
            self.state = "error"
            return
        if not re.match(ALLOWED, url):
            log(u"update refused (not a project release): %s" % url)
            self.message = u"رابط التحديث غير موثوق"
            self.state = "error"
            return
        target = "/tmp/ultraquran-update.%s" % kind
        try:
            if os.path.exists(target):
                os.remove(target)
        except OSError:
            pass
        ok = False
        try:
            resp = _open(url, timeout=30)
            total = 0
            try:
                total = int(resp.info().get("Content-Length") or 0)
            except ValueError:
                total = 0
            done = 0
            with open(target, "wb") as handle:
                while True:
                    piece = resp.read(65536)
                    if not piece:
                        break
                    handle.write(piece)
                    done += len(piece)
                    if total:
                        self.progress = min(99, done * 100 // total)
            resp.close()
            ok = done > 1024 and (not total or done >= total)
        except Exception as exc:
            log(u"update download (python) failed: %s" % exc)
        if not ok:
            ok = _wget(url, target)
        if not ok:
            self.message = u"تعذر تحميل ملف التحديث"
            self.state = "error"
            return
        expected = (self.info.get(kind + "_sha256") or "").strip().lower()
        if expected:
            import hashlib
            digest = hashlib.sha256()
            with open(target, "rb") as handle:
                for piece in iter(lambda: handle.read(1 << 20), b""):
                    digest.update(piece)
            if digest.hexdigest() != expected:
                log(u"update refused: sha256 mismatch")
                self.message = u"ملف التحديث تالف · حاول مرة أخرى"
                self.state = "error"
                try:
                    os.remove(target)
                except OSError:
                    pass
                return
        self.progress = 100
        self.state = "installing"
        if kind == "deb":
            cmd = ["dpkg", "-i", "--force-overwrite", target]
        else:
            cmd = ["opkg", "install", "--force-reinstall", "--force-overwrite", target]
        try:
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            out = proc.communicate()[0]
            text = out.decode("utf-8", "replace") if isinstance(out, bytes) else (out or "")
            log(u"update install (%s): rc=%s %s" % (kind, proc.returncode, text[-400:]))
            if proc.returncode == 0:
                self.state = "done"
            else:
                self.message = u"فشل التثبيت (%s)" % (text.strip().splitlines()[-1][:60] if text.strip() else proc.returncode)
                self.state = "error"
        except Exception as exc:
            log_exception("update install failed")
            self.message = u"فشل التثبيت: %s" % exc
            self.state = "error"
        finally:
            try:
                os.remove(target)
            except OSError:
                pass


UPDATER = Updater()
