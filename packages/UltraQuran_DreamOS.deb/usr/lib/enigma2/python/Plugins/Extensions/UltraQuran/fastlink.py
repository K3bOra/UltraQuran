# -*- coding: utf-8 -*-
"""Faster starts: the address a recording really lives at is found in the background while the item is only
focused, so pressing OK goes straight to the file server.

archive.org (and most mirrors) answer the catalogue link with a redirect to the data server; following it
costs one or more round trips (often a second or two) at every start, seek and engine retry. Here the link
of the focused item (and of the next track in a playlist) is opened once with a 1-byte range request and the
final address is kept for a while. Anything that fails simply keeps the original link.
"""
from __future__ import absolute_import

import threading
import time

try:
    from urllib.request import Request, urlopen
except ImportError:  # Python 2 (DreamOS)
    from urllib2 import Request, urlopen

KEEP = 20 * 60          # data-server links stay valid for hours; keep them 20 minutes
MAX_JOBS = 3
_cache = {}             # url -> (final url, time)
_running = set()
_lock = threading.Lock()


def _resolve(url):
    from .portraits import _ssl_contexts
    final = None
    for ctx in _ssl_contexts():
        try:
            kwargs = {"timeout": 8}
            if ctx is not None:
                kwargs["context"] = ctx
            resp = urlopen(Request(url, headers={"User-Agent": "UltraQuran/1.0", "Range": "bytes=0-0"}), **kwargs)
            try:
                status = getattr(resp, "status", None) or resp.getcode()
                if status in (200, 206):
                    final = resp.geturl()
            finally:
                resp.close()
            break
        except Exception as exc:
            text = str(exc).lower()
            if not any(word in text for word in ("ssl", "certificate", "tls", "handshake")):
                break
    return final


def prefetch(url):
    """Find the final address of `url` in the background (no-op for local files and known links)."""
    if not url or not url.startswith("http"):
        return
    now = time.time()
    with _lock:
        hit = _cache.get(url)
        if (hit and now - hit[1] < KEEP) or url in _running or len(_running) >= MAX_JOBS:
            return
        _running.add(url)

    def work():
        try:
            final = _resolve(url)
            with _lock:
                if final:
                    _cache[url] = (final, time.time())
                if len(_cache) > 300:
                    for key, _ in sorted(_cache.items(), key=lambda kv: kv[1][1])[:100]:
                        _cache.pop(key, None)
        except Exception:
            pass
        finally:
            with _lock:
                _running.discard(url)

    thread = threading.Thread(target=work)
    thread.daemon = True
    thread.start()


def final(url):
    """The data-server address of `url` when it is already known, otherwise `url` itself (never waits)."""
    with _lock:
        hit = _cache.get(url)
    if hit and time.time() - hit[1] < KEEP and hit[0]:
        return hit[0]
    return url


def forget(url):
    with _lock:
        _cache.pop(url, None)
