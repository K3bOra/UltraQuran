# -*- coding: utf-8 -*-
"""Permanent Hard-Drive Written & Illustrated Mushaf Engine (Ultra Quran 1.1.0).

Automatically downloads and permanently stores all 604 pages of the Holy Quran
into the plugin's folder on the Hard Drive (<storage_root>/mushaf) so that the user
can browse and read the Mushaf at any time without needing a USB flash drive or
re-downloading:
  1. Complete Uthmani Quran text (604 pages, Tanzil / AlQuran Cloud) saved permanently
     in <storage_root>/mushaf/pages.json (single fast download + per-page instant fetch).
  2. High-resolution Madinah Mushaf page images (001.png .. 604.png) downloaded and
     composited cleanly onto the 1662x765 Royal Emerald parchment canvas without stretching.
"""
import io
import json
import os
import ssl
import subprocess
import tempfile
import threading
import time

try:
    from urllib.error import HTTPError
    from urllib.parse import quote
    from urllib.request import Request, urlopen
except ImportError:
    from urllib import quote
    from urllib2 import HTTPError, Request, urlopen

try:
    from PIL import Image, ImageChops, ImageDraw, ImageOps
except ImportError:
    Image = None

from .support import ROOT, data_json, log, log_exception, storage_root

USER_AGENT = "Mozilla/5.0 (X11; Linux armv7l) UltraQuran/1.1.0"

# Full 604-page Uthmani Quran JSON (single request, ~1.5 MB) and single-page instant API
FULL_QURAN_API = "https://api.alquran.cloud/v1/quran/quran-uthmani"
PAGE_QURAN_API = "https://api.alquran.cloud/v1/page/%d/quran-uthmani"

# High-resolution 604 Madinah Mushaf pages (King Fahd Complex calligraphy, Hafs).
# Primary: the Quran.app / quran_android 1920px set - printed-mushaf look with the
# ornamental surah header frames. The older frameless set stays as a fallback mirror.
IMAGE_MIRRORS = (
    "https://cdn.jsdelivr.net/gh/GovarJabbar/Quran-PNG@master/%03d.png",
    "https://raw.githubusercontent.com/GovarJabbar/Quran-PNG/master/%03d.png",
    "https://govarjabbar.github.io/Quran-PNG/%03d.png",
    "https://files.quran.app/hafs/madani/width_1920/page%03d.png",
)

# Warsh 'an Nafi' Mushaf (King Fahd Complex, Madinah print): 604 transparent PNG pages, 1280 px, that follow the
# Madinah page breaks one to one. Served by jsDelivr / GitHub exactly like the Hafs pages (fast, no rate limit).
WARSH_MIRRORS = (
    "https://cdn.jsdelivr.net/gh/samaneng2002/nurani-warsh-mushaf@main/pages/page_warsh_%03d.png",
    "https://raw.githubusercontent.com/samaneng2002/nurani-warsh-mushaf/main/pages/page_warsh_%03d.png",
)
# Last resort: the public domain Warsh scan on Wikimedia Commons (slow, rendered on demand, rate limited).
_WARSH_PDF = ("%D8%A7%D9%84%D9%85%D8%B5%D8%AD%D9%81_%D8%A8%D8%B1%D9%88%D8%A7%D9%8A%D8%A9_"
              "%D9%88%D8%B1%D8%B4_%D8%B9%D9%86_%D9%86%D8%A7%D9%81%D8%B9.pdf").replace("%", "%%")
WARSH_SCAN_MIRRORS = (
    "https://upload.wikimedia.org/wikipedia/commons/thumb/9/9e/" + _WARSH_PDF + "/page%d-1280px-" + _WARSH_PDF + ".jpg",
    "https://commons.wikimedia.org/wiki/Special:FilePath/" + _WARSH_PDF + "?width=1280&page=%d",
)
RIWAYAT = ("hafs", "warsh")
RIWAYA_NAMES = {"hafs": u"حفص عن عاصم", "warsh": u"ورش عن نافع"}
PAGE_FILES = {"hafs": "pc-%03d.png", "warsh": "pk-%03d.png"}
PAGE_PREFIX_RIWAYA = {"pc-": "hafs", "pk-": "warsh"}

PARCHMENT_BG = (228, 222, 203)      # #e4decb (matches art/1920/mushaf.png parchment box)
BORDER_GOLD = (182, 152, 92)        # subtle warm gold frame
INK_DARK = (20, 38, 34)             # deep emerald-black ink for calligraphy

ARABIC_DIGITS = u"٠١٢٣٤٥٦٧٨٩"


def to_arabic_digits(number):
    try:
        return u"".join(ARABIC_DIGITS[int(ch)] if ch.isdigit() else ch for ch in str(number))
    except Exception:
        return str(number)


def _ssl_contexts():
    contexts = []
    cafile = os.path.join(ROOT, "certs", "cacert.pem")
    if hasattr(ssl, "create_default_context"):
        try:
            if os.path.isfile(cafile):
                contexts.append(ssl.create_default_context(cafile=cafile))
            else:
                contexts.append(ssl.create_default_context())
        except Exception:
            pass
    if hasattr(ssl, "_create_unverified_context"):
        try:
            contexts.append(ssl._create_unverified_context())
        except Exception:
            pass
    return contexts or [None]


def http_get_bytes(url, timeout=15, max_bytes=8 * 1024 * 1024):
    headers = {"User-Agent": USER_AGENT, "Accept": "*/*"}
    for ctx in _ssl_contexts():
        try:
            req = Request(url, headers=headers)
            kwargs = {"timeout": timeout}
            if ctx is not None:
                kwargs["context"] = ctx
            resp = urlopen(req, **kwargs)
            try:
                data = resp.read(max_bytes)
            finally:
                resp.close()
            if data and len(data) > 64:
                return data
        except Exception:
            continue
    # Fallback to wget / curl on Enigma2 receivers with older Python SSL libraries
    for cmd in (
        ["/usr/bin/wget", "-q", "-T", str(timeout), "-U", USER_AGENT, "-O", "-", url],
        ["wget", "-q", "-T", str(timeout), "-U", USER_AGENT, "-O", "-", url],
        ["/usr/bin/curl", "-s", "-L", "--max-time", str(timeout), "-A", USER_AGENT, url],
        ["curl", "-s", "-L", "--max-time", str(timeout), "-A", USER_AGENT, url],
    ):
        try:
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            out, _ = proc.communicate()
            if proc.returncode == 0 and out and len(out) > 64:
                return out
        except Exception:
            continue
    return None


def http_get_status(url, timeout=25, max_bytes=6 * 1024 * 1024):
    """(status, bytes): status 200 with data, the HTTP error code, or 0 when the network itself failed.
    No hidden retries - Wikimedia answers 429 to bursts, so the caller decides how long to wait."""
    headers = {"User-Agent": USER_AGENT, "Accept": "image/*,*/*"}
    for ctx in _ssl_contexts():
        try:
            req = Request(url, headers=headers)
            kwargs = {"timeout": timeout}
            if ctx is not None:
                kwargs["context"] = ctx
            resp = urlopen(req, **kwargs)
            try:
                data = resp.read(max_bytes)
            finally:
                resp.close()
            return 200, data
        except HTTPError as error:
            return error.code, None
        except Exception:
            continue
    return 0, None


def find_mushaf_dir(media_root="/media"):
    """Return the persistent Mushaf directory on the Hard Drive (or inside the plugin folder)."""
    # 1. Check if an existing USB/HDD mount already has a populated mushaf folder
    try:
        mounts = sorted(os.listdir(media_root))
    except OSError:
        mounts = []
    for folder in ("UltraQuran", "UltraDeen"):
        for entry in mounts:
            directory = os.path.join(media_root, entry, folder, "mushaf")
            if os.path.isdir(directory) and (
                os.path.isfile(os.path.join(directory, "001.png"))
                or os.path.isfile(os.path.join(directory, "pages.json"))
            ):
                return directory

    # 2. Default to the plugin's permanent storage_root()/mushaf on the Hard Drive
    candidates = (
        os.path.join(storage_root(media_root), "mushaf"),
        os.path.join(ROOT, "mushaf"),
        "/etc/enigma2/ultra-quran-cache/mushaf",
        "/tmp/ultra-quran-cache/mushaf",
    )
    for path in candidates:
        try:
            if not os.path.isdir(path):
                os.makedirs(path)
            if os.access(path, os.W_OK):
                return path
        except OSError:
            continue
    return candidates[-1]


PAGE_CANVAS = (704, 832)            # the page stage inside the illuminated frame (layout.MUSHAF_IMG)
PAGE_FILE = PAGE_FILES["hafs"]      # v4 pages (bold ink, larger letters); older page sets are removed
OLD_PAGE_PREFIXES = ("pg-", "pq-", "pb-", "pw-")     # pw-: the 0.6.7 Warsh scan, replaced by the KFGQPC set
INK = (12, 52, 70)                  # deep lapis-emerald ink
PAPER_TOP = (248, 241, 219)
PAPER_BOTTOM = (237, 225, 194)


def _paper(size):
    """Warm parchment with a soft vertical gradient and a gentle vignette (cheap PIL-only)."""
    w, h = size
    grad = Image.linear_gradient("L").resize((w, h))
    top = Image.new("RGB", (w, h), PAPER_TOP)
    bottom = Image.new("RGB", (w, h), PAPER_BOTTOM)
    paper = Image.composite(bottom, top, grad)
    edge = Image.radial_gradient("L").resize((w, h))          # 0 centre .. 255 corners
    shade = Image.new("RGB", (w, h), (206, 184, 140))
    return Image.composite(shade, paper, edge.point(lambda v: max(0, v - 150) // 2))


def page_canvas_size(width):
    """Pixel size of the page stage for a given screen width (same rounding as layout.scaled)."""
    if not width or width == 1920:
        return PAGE_CANVAS
    from . import layout
    return tuple(layout.scaled((0, 0, PAGE_CANVAS[0], PAGE_CANVAS[1]), width)[2:])


def _variant_path(full_path, width):
    return full_path[:-4] + "-%d.png" % width


def half_path(full_path, half):
    """Large-print halves of a page: pq-050-a.png (top lines) / pq-050-b.png (bottom lines)."""
    return full_path[:-4] + ("-a.png" if half == 0 else "-b.png")


def _split_row(alpha):
    """Row index between two text lines closest to the middle of the page (least ink)."""
    w, h = alpha.size
    small = alpha.resize((max(1, w // 8), h))
    data = small.tobytes()
    sw = small.size[0]
    lo, hi = int(h * 0.38), int(h * 0.62)
    best, best_row = None, h // 2
    for y in range(lo, hi):
        row = data[y * sw:(y + 1) * sw]
        ink = sum(bytearray(row))
        score = ink + abs(y - h // 2) // 4
        if best is None or score < best:
            best, best_row = score, y
    return best_row


def _spread(alpha, ratio):
    """Give the lines of a large-print half more breathing room so the half fills the frame:
    the extra height is shared between the real gaps between lines (never inside a line)."""
    w, h = alpha.size
    want = int(min(w * ratio, h * 1.6))
    if want <= h + 8:
        return alpha
    small = alpha.resize((max(1, w // 8), h))
    data = small.tobytes()
    sw = small.size[0]
    rows = [sum(bytearray(data[y * sw:(y + 1) * sw])) for y in range(h)]
    limit = max(rows) * 0.004
    min_run = max(10, 18 * w // 1800)
    gaps, start = [], None
    for y, value in enumerate(rows):
        if value < limit:
            if start is None:
                start = y
        elif start is not None:
            if y - start >= min_run and start > 0:
                gaps.append((start + y) // 2)
            start = None
    if not gaps:
        return alpha
    extra = want - h
    each = extra // len(gaps)
    out = Image.new("L", (w, h + each * len(gaps)), 0)
    top, offset = 0, 0
    for cut in gaps + [h]:
        out.paste(alpha.crop((0, top, w, cut)), (0, top + offset))
        offset += each
        top = cut
    return out


def _place(alpha, size, margin_x, margin_y, ink, resample):
    cw, ch = size
    scale = min((cw - margin_x) / float(alpha.width), (ch - margin_y) / float(alpha.height))
    tw, th = max(1, int(alpha.width * scale)), max(1, int(alpha.height * scale))
    mask = alpha.resize((tw, th), resample)
    canvas = _paper((cw, ch))
    canvas.paste(Image.new("RGB", (tw, th), ink), ((cw - tw) // 2, (ch - th) // 2), mask)
    return canvas


def _compose_mushaf_canvases(raw_png_bytes, full_path, split_path=None, width=1920, scan=False):
    """Downloaded Mushaf page -> one tall coloured canvas sized exactly for the illuminated frame."""
    if Image is None or not raw_png_bytes:
        return False
    try:
        im = Image.open(io.BytesIO(raw_png_bytes))
        im.load()
        if im.width < 100 or im.height < 100:
            return False
        resample = getattr(getattr(Image, "Resampling", Image), "LANCZOS", Image.BICUBIC)
        rgba = im.convert("RGBA")
        # Ink coverage = opacity x darkness. The page PNGs store their anti-aliasing as grey
        # palette shades (opaque), so using the alpha channel alone paints every edge pixel as
        # solid ink (jagged, heavy letters). Multiplying by the inverted grey keeps the
        # calligraphy smooth and crisp at every resolution.
        # bold, full-bodied ink exactly like the original Ultra Quran pages (the users' favourite look)
        alpha = rgba.split()[3]
        if alpha.getextrema()[0] == 255:            # no transparency: dark ink on white paper
            alpha = ImageOps.invert(rgba.convert("L"))
            if scan:
                # scanned / JPEG page (Warsh): drop the paper noise and thicken the thin strokes to match the bold look
                alpha = alpha.point(lambda v: 0 if v < 22 else min(255, int((v - 22) * 1.5)))
        bbox = alpha.getbbox()
        if not bbox:
            return False
        pad = 24
        alpha = alpha.crop((max(0, bbox[0] - pad), max(0, bbox[1] - pad),
                            min(alpha.width, bbox[2] + pad), min(alpha.height, bbox[3] + pad)))
        factor = max(1, min(alpha.width // (PAGE_CANVAS[0] * 2), alpha.height // (PAGE_CANVAS[1] * 2)))
        if factor > 1:
            alpha = alpha.reduce(factor) if hasattr(alpha, "reduce") else alpha.resize(
                (alpha.width // factor, alpha.height // factor), resample)
        targets = [(full_path, PAGE_CANVAS, None)]
        if width and width != 1920:
            targets.append((_variant_path(full_path, width), page_canvas_size(width), width))
        stage = PAGE_CANVAS[1] / float(PAGE_CANVAS[0])
        if alpha.height <= alpha.width * stage * 1.25:
            # short ornamental page (Al-Fatiha / start of Al-Baqara): already fills the width whole
            halves = (alpha,)
        else:
            split = _split_row(alpha)
            halves = (alpha.crop((0, 0, alpha.width, split)), alpha.crop((0, split, alpha.width, alpha.height)))
        for stale in (half_path(full_path, 1),):
            if len(halves) == 1 and os.path.isfile(stale):
                os.unlink(stale)
        for path, (cw, ch), variant in targets:
            margin = max(4, 30 * cw // PAGE_CANVAS[0])   # fill the frame window (letters ~4% bigger)
            _atomic_save(_place(alpha, (cw, ch), margin, margin, INK, resample), path)
            # large print: each half fills the whole width of the frame (about 1.4x bigger letters)
            side = max(6, 42 * cw // PAGE_CANVAS[0])   # just clear of the overlay frame (letters ~6% bigger)
            for k, part in enumerate(halves):
                box = part.getbbox()
                if box:
                    part = part.crop((0, box[1], part.width, box[3]))
                part = _spread(part, (ch - side) / float(cw - side))
                hp = half_path(full_path, k)
                _atomic_save(_place(part, (cw, ch), side, side, INK, resample),
                             _variant_path(hp, variant) if variant else hp)
        return True
    except Exception:
        log_exception("Failed composing Mushaf page image")
        return False


def _compact(image):
    """160-colour palette page: visually identical (two-tone ink on parchment) at ~1/3 of the
    size, so the whole 604-page mushaf takes ~60 MB on the hard drive instead of ~190 MB."""
    if image.mode != "RGB":
        return image
    for kwargs in ({"colors": 160, "dither": 0}, {"colors": 160}):
        try:
            return image.quantize(**kwargs)
        except Exception:
            continue
    return image


def _atomic_save(image, target_path):
    directory = os.path.dirname(target_path)
    if not os.path.isdir(directory):
        os.makedirs(directory)
    fd, tmp_path = tempfile.mkstemp(prefix=".mushaf-", suffix=".png", dir=directory)
    os.close(fd)
    image = _compact(image)
    try:
        image.save(tmp_path, format="PNG", compress_level=6)
        os.chmod(tmp_path, 0o644)
        os.rename(tmp_path, target_path)
    finally:
        if os.path.exists(tmp_path):
            try:
                os.unlink(tmp_path)
            except OSError:
                pass


class MushafManager(object):
    """Manages permanent offline storage and background downloading of all 604 Mushaf pages."""

    def __init__(self, on_update=None):
        self.on_update = on_update
        self._lock = threading.Lock()
        self.base_dir = find_mushaf_dir()
        self._pages_text = {}           # {page_int: {"surahs": [...], "juz": int, "text": u"..."}}
        self._sets = {r: {"images": set(), "splits": set()} for r in RIWAYAT}   # saved page images per riwaya
        self.riwaya = "hafs"
        self._image_pages = self._sets["hafs"]["images"]    # pages of the CURRENT riwaya that are on disk
        self._split_pages = self._sets["hafs"]["splits"]
        self._priority_page = 1
        self._worker = None
        self._full_download_requested = False
        self._bulk = {r: False for r in RIWAYAT}        # "download the whole mushaf" running, per riwaya
        self._bulk_error = {r: False for r in RIWAYAT}
        self._failed_view = set()                       # (riwaya, page) whose download failed (placeholder message)
        self._retry_at = {r: {} for r in RIWAYAT}       # page -> time before which a failed page is not retried
        self._attempts = {r: {} for r in RIWAYAT}       # page -> failed tries in the current "download all" run
        self._downloading_text = False
        self._dirty = False
        self._load_disk_state()

    def _load_disk_state(self):
        self.base_dir = find_mushaf_dir()
        pages_file = os.path.join(self.base_dir, "pages.json")
        if os.path.isfile(pages_file):
            try:
                with io.open(pages_file, "r", encoding="utf-8") as handle:
                    raw = json.load(handle)
                if isinstance(raw, dict):
                    self._pages_text = {int(k): v for k, v in raw.items() if str(k).isdigit()}
            except Exception:
                pass
        try:
            if os.path.isdir(self.base_dir):
                for name in os.listdir(self.base_dir):
                    if name.endswith(".png"):
                        if name.startswith(OLD_PAGE_PREFIXES) and name[3:6].isdigit():
                            # page from the previous (frameless) source: replaced by the new set
                            try:
                                os.unlink(os.path.join(self.base_dir, name))
                            except OSError:
                                pass
                            continue
                        if name[:3] in PAGE_PREFIX_RIWAYA and len(name) == 10 and name[3:6].isdigit():
                            p = int(name[3:6])
                            if 1 <= p <= 604 and os.path.isfile(
                                    half_path(os.path.join(self.base_dir, name), 0)):
                                bucket = self._sets[PAGE_PREFIX_RIWAYA[name[:3]]]
                                bucket["images"].add(p)
                                bucket["splits"].add(p)
                    elif name.startswith("page_") and name.endswith(".json") and name[5:8].isdigit():
                        p = int(name[5:8])
                        if p not in self._pages_text:
                            try:
                                with io.open(os.path.join(self.base_dir, name), "r", encoding="utf-8") as h:
                                    self._pages_text[p] = json.load(h)
                            except Exception:
                                pass
        except OSError:
            pass
        try:   # remembered choice of riwaya
            with io.open(os.path.join(self.base_dir, "riwaya.txt"), "r", encoding="utf-8") as handle:
                saved = handle.read().strip()
            if saved in RIWAYAT:
                self.riwaya = saved
                self._image_pages = self._sets[saved]["images"]
                self._split_pages = self._sets[saved]["splits"]
        except (IOError, OSError):
            pass

    def page_path(self, page, riwaya=None):
        return os.path.join(self.base_dir, PAGE_FILES[riwaya or self.riwaya] % page)

    def set_riwaya(self, riwaya):
        if riwaya not in RIWAYAT:
            return
        with self._lock:
            self.riwaya = riwaya
            self._image_pages = self._sets[riwaya]["images"]
            self._split_pages = self._sets[riwaya]["splits"]
        try:
            with io.open(os.path.join(self.base_dir, "riwaya.txt"), "w", encoding="utf-8") as handle:
                handle.write(u"" + riwaya)
        except (IOError, OSError):
            pass

    def toggle_riwaya(self):
        self.set_riwaya("warsh" if self.riwaya == "hafs" else "hafs")
        return self.riwaya

    def page_failed(self, page):
        return (self.riwaya, page) in self._failed_view

    def riwaya_name(self):
        return RIWAYA_NAMES[self.riwaya]

    def bulk_state(self):
        """What the UI shows for the whole-mushaf download: saved pages, running / stopped, network error."""
        return {"riwaya": self.riwaya, "saved": len(self._image_pages), "total": 604,
                "running": bool(self._bulk[self.riwaya]), "error": bool(self._bulk_error[self.riwaya])}

    def start_full_download(self):
        """Blue button: download every page of the current riwaya to the hard drive (retries, resumes)."""
        with self._lock:
            self._bulk[self.riwaya] = True
            self._bulk_error[self.riwaya] = False
            self._retry_at[self.riwaya] = {}
            self._attempts[self.riwaya] = {}
            self._full_download_requested = True
            if self._worker is None or not self._worker.is_alive():
                worker = threading.Thread(target=self._worker_loop)
                worker.daemon = True
                self._worker = worker
                worker.start()

    def pop_updated(self):
        with self._lock:
            was = self._dirty
            self._dirty = False
            return was

    def _notify(self):
        with self._lock:
            self._dirty = True
        if self.on_update is not None:
            try:
                self.on_update()
            except Exception:
                pass

    def has_text(self, page):
        return page in self._pages_text

    def page_halves(self, page):
        """2 when the page is shown in two large-print halves, 1 for the short opening pages."""
        path = self.page_path(page)
        return 2 if os.path.isfile(half_path(path, 1)) else 1

    def saved_pages(self):
        """How many of the 604 page images are already stored on the hard drive."""
        return len(self._image_pages)

    def has_image(self, page):
        if page in self._image_pages:
            return True
        path = self.page_path(page)
        if (os.path.isfile(path) and os.path.getsize(path) > 1024
                and os.path.isfile(half_path(path, 0))):
            self._image_pages.add(page)
            return True
        return False

    def page_image_path(self, page, split=False, half=None):
        path = self.page_path(page)
        if half is not None:
            path = half_path(path, half)
        if not (os.path.isfile(path) and os.path.getsize(path) > 1024):
            return None
        width = getattr(self, "display_width", 1920)
        if width == 1920 or Image is None:
            return path
        variant = _variant_path(path, width)
        if os.path.isfile(variant) and os.path.getsize(variant) > 1024:
            return variant
        try:  # page saved earlier at full-HD size: fit it to this screen once
            with Image.open(path) as im:
                im.load()
                resample = getattr(getattr(Image, "Resampling", Image), "LANCZOS", Image.BICUBIC)
                _atomic_save(im.convert("RGB").resize(page_canvas_size(width), resample), variant)
            return variant
        except Exception:
            log_exception("Could not scale Mushaf page %d for width %d" % (page, width))
            return path

    def tafsir(self, page):
        """Tafsir Al-Muyassar rows [[surah, ayah, text], ...] of a Mushaf page (bundled with the plugin, read lazily)."""
        group = (page - 1) // 20
        cache = self.__dict__.setdefault("_tafsir_cache", {})
        if group not in cache:
            try:
                rows = data_json("tafsir", "%d.json" % group)
                cache.clear()
                cache[group] = rows
            except Exception:
                cache[group] = {}
        return cache[group].get(str(page), [])

    def page_data(self, page):
        return self._pages_text.get(page)

    def downloaded_text_count(self):
        return len(self._pages_text)

    def downloaded_image_count(self):
        return len(self._image_pages)

    def is_complete(self):
        return len(self._pages_text) >= 604 and len(self._image_pages) >= 604

    def status_summary(self):
        txt_cnt = len(self._pages_text)
        img_cnt = len(self._image_pages)
        if txt_cnt >= 604 and img_cnt >= 604:
            return u"محفوظ بالكامل على الهارد (604 صفحة · يعمل بدون نت)"
        if txt_cnt >= 604:
            return u"النص الكامل محفوظ على الهارد (604 صفحة) · الصور: %d/604" % img_cnt
        if txt_cnt > 0 or img_cnt > 0:
            return u"جارٍ الحفظ الدائم على الهارد (النص %d/604 · الصور %d/604)" % (txt_cnt, img_cnt)
        return u"جارٍ تحميل وحفظ المصحف الشريف على الهارد…"

    def request_page(self, page, full_download=True):
        """Prioritize `page` (and adjacent pages) and start permanent HDD download."""
        with self._lock:
            self._priority_page = max(1, min(604, int(page)))
            if full_download:
                self._bulk[self.riwaya] = True     # the open riwaya saves itself to the hard drive in the background
                self._full_download_requested = True
            if self._worker is None or not self._worker.is_alive():
                worker = threading.Thread(target=self._worker_loop)
                worker.daemon = True
                self._worker = worker
                worker.start()

    def _fetch_single_page_text(self, page):
        if page in self._pages_text:
            return True
        raw = http_get_bytes(PAGE_QURAN_API % page, timeout=10)
        if not raw:
            return False
        try:
            payload = json.loads(raw.decode("utf-8", "replace"))
            data = payload.get("data") or {}
            ayahs = data.get("ayahs") or []
            if not ayahs:
                return False
            entry = self._build_page_entry(ayahs)
            self._pages_text[page] = entry
            pfile = os.path.join(self.base_dir, "page_%03d.json" % page)
            with io.open(pfile, "w", encoding="utf-8") as h:
                h.write(u"" + json.dumps(entry, ensure_ascii=False))
            return True
        except Exception:
            return False

    def _fetch_all_pages_text(self):
        if len(self._pages_text) >= 604:
            return True
        raw = http_get_bytes(FULL_QURAN_API, timeout=25, max_bytes=10 * 1024 * 1024)
        if not raw:
            return False
        try:
            payload = json.loads(raw.decode("utf-8", "replace"))
            surahs = (payload.get("data") or {}).get("surahs") or []
            if not surahs:
                return False
            by_page = {}
            for surah in surahs:
                s_info = {
                    "number": surah.get("number"),
                    "name": surah.get("name") or u"",
                }
                for ayah in surah.get("ayahs") or []:
                    p = int(ayah.get("page") or 0)
                    if 1 <= p <= 604:
                        ayah_copy = dict(ayah)
                        ayah_copy["surah"] = s_info
                        by_page.setdefault(p, []).append(ayah_copy)
            if len(by_page) < 600:
                return False
            built = {}
            for p, ayahs in by_page.items():
                built[p] = self._build_page_entry(ayahs)
            self._pages_text.update(built)
            pages_file = os.path.join(self.base_dir, "pages.json")
            fd, tmp_path = tempfile.mkstemp(prefix=".pages-", suffix=".json", dir=self.base_dir)
            os.close(fd)
            try:
                with io.open(tmp_path, "w", encoding="utf-8") as h:
                    h.write(u"" + json.dumps({str(k): v for k, v in self._pages_text.items()}, ensure_ascii=False))
                os.chmod(tmp_path, 0o644)
                os.rename(tmp_path, pages_file)
            finally:
                if os.path.exists(tmp_path):
                    try:
                        os.unlink(tmp_path)
                    except OSError:
                        pass
            self._write_manifest()
            return True
        except Exception:
            log_exception("Failed downloading full Quran text JSON")
            return False

    @staticmethod
    def _build_page_entry(ayahs):
        surah_names = []
        juz = 1
        blocks = []
        current_surah = None
        current_parts = []
        bismillah = u"بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ"

        for a in ayahs:
            if a.get("juz"):
                juz = int(a["juz"])
            s_obj = a.get("surah") or {}
            s_num = int(s_obj.get("number") or 0)
            s_name = (s_obj.get("name") or u"").strip()
            if s_name and s_name not in surah_names:
                surah_names.append(s_name)
            text = (a.get("text") or u"").strip()
            num_in_surah = int(a.get("numberInSurah") or 1)

            if s_num != current_surah:
                if current_parts:
                    blocks.append(u" ".join(current_parts))
                    current_parts = []
                current_surah = s_num
                if s_name:
                    blocks.append(u"﴿ " + s_name + u" ﴾")
                if num_in_surah == 1 and s_num not in (1, 9):
                    if text.startswith(bismillah):
                        text = text[len(bismillah):].strip()
                    blocks.append(bismillah)

            current_parts.append(u"%s ﴿%s﴾" % (text, to_arabic_digits(num_in_surah)))

        if current_parts:
            blocks.append(u" ".join(current_parts))

        return {
            "juz": juz,
            "surahs": surah_names,
            "text": u"\n\n".join(blocks),
        }

    def _download_warsh_scan(self, page):
        """Raw JPEG of the Wikimedia Warsh scan (fallback). On the site's 'slow down' (429/503) wait and retry."""
        for attempt in range(3):
            busy = False
            for pattern in WARSH_SCAN_MIRRORS:
                status, raw = http_get_status(pattern % page, timeout=45)
                if raw and len(raw) > 4096:
                    return raw
                if status in (429, 503, 504):
                    busy = True
                    break
                if status == 0:                     # old SSL stack on the receiver: wget / curl fallback
                    raw = http_get_bytes(pattern % page, timeout=45)
                    if raw and len(raw) > 4096:
                        return raw
            if not busy:
                return None
            time.sleep(10 + 12 * attempt)
        return None

    def _download_warsh_page(self, page):
        """(raw bytes, is_scan): the KFGQPC Warsh PNG from jsDelivr / GitHub, else the Wikimedia scan."""
        for pattern in WARSH_MIRRORS:
            raw = http_get_bytes(pattern % page, timeout=15)
            if raw and len(raw) > 4096:
                return raw, False
        raw = self._download_warsh_scan(page)
        return raw, True

    def _fetch_single_page_image(self, page, riwaya=None):
        riwaya = riwaya or self.riwaya
        bucket = self._sets[riwaya]
        full_path = self.page_path(page, riwaya)
        split_path = full_path
        if (os.path.isfile(full_path) and os.path.getsize(full_path) > 1024
                and os.path.isfile(half_path(full_path, 0))):
            bucket["images"].add(page)
            bucket["splits"].add(page)
            return True
        width = getattr(self, "display_width", 1920)
        if riwaya == "warsh":
            raw, scan = self._download_warsh_page(page)
            if not raw or not _compose_mushaf_canvases(raw, full_path, split_path, width, scan=scan):
                return False
        else:
            for pattern in IMAGE_MIRRORS:
                raw = http_get_bytes(pattern % page, timeout=12)
                if raw and _compose_mushaf_canvases(raw, full_path, split_path, width):
                    break
            else:
                return False
        bucket["images"].add(page)
        bucket["splits"].add(page)
        if len(bucket["images"]) >= 604:
            self._write_manifest()
        return True

    def _write_manifest(self):
        manifest_path = os.path.join(self.base_dir, "manifest.json")
        try:
            with io.open(manifest_path, "w", encoding="utf-8") as h:
                h.write(u'{"format": 5, "source": "Quran-PNG madinah (Hafs) + KFGQPC Warsh", "pages": 604}\n')
        except Exception:
            pass

    def _worker_loop(self):
        consecutive_failures = 0
        while True:
            with self._lock:
                target = self._priority_page
                riwaya = self.riwaya
                bulk = self._bulk[riwaya]
            bucket = self._sets[riwaya]
            gentle = 0.08

            # Step 1: the page on screen first (text + image)
            if not self.has_text(target):
                if self._fetch_single_page_text(target):
                    self._notify()
            if target not in bucket["images"] or target not in bucket["splits"]:
                if self._fetch_single_page_image(target, riwaya):
                    self._failed_view.discard((riwaya, target))
                    self._notify()
                else:
                    self._failed_view.add((riwaya, target))
                    self._notify()

            # Step 2: the neighbours, so turning a page is instant
            for neighbor in (target % 604 + 1, (target - 2) % 604 + 1):
                if self._priority_page != target or self.riwaya != riwaya:
                    break
                if not self.has_text(neighbor):
                    if self._fetch_single_page_text(neighbor):
                        self._notify()
                if neighbor not in bucket["images"] or neighbor not in bucket["splits"]:
                    if self._fetch_single_page_image(neighbor, riwaya):
                        self._notify()

            # Step 3: the whole Quran text (one request, ~2 s)
            if len(self._pages_text) < 604:
                if self._fetch_all_pages_text():
                    self._notify()

            if not bulk:
                return

            # Step 4: every remaining page image, saved to the hard drive (a failed page is retried later, 3 times)
            now = time.time()
            retry = self._retry_at[riwaya]
            attempts = self._attempts[riwaya]
            next_missing = None
            waiting = False
            for offset in range(604):
                candidate = (self._priority_page - 1 + offset) % 604 + 1
                if candidate in bucket["images"] and candidate in bucket["splits"]:
                    continue
                if attempts.get(candidate, 0) >= 3:
                    continue
                if retry.get(candidate, 0) > now:
                    waiting = True
                    continue
                next_missing = candidate
                break

            if next_missing is None:
                if waiting:
                    time.sleep(3.0)                 # only pages that wait for their next try are left
                    continue
                if len(bucket["images"]) >= 604:
                    self._write_manifest()
                else:
                    self._bulk_error[riwaya] = True     # some pages never came: stop honestly, keep what we have
                self._bulk[riwaya] = False
                self._notify()
                return

            if self._fetch_single_page_image(next_missing, riwaya):
                consecutive_failures = 0
                retry.pop(next_missing, None)
                if len(bucket["images"]) % 5 == 0 or next_missing == self._priority_page:
                    self._notify()
            else:
                consecutive_failures += 1
                attempts[next_missing] = attempts.get(next_missing, 0) + 1
                retry[next_missing] = time.time() + 45
                if consecutive_failures >= 8:       # the network (or the site) is not answering: stop, keep progress
                    self._bulk[riwaya] = False
                    self._bulk_error[riwaya] = True
                    self._notify()
                    return
                time.sleep(2.0)
            time.sleep(gentle)
