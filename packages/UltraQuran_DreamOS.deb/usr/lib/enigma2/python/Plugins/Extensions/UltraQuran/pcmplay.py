# -*- coding: utf-8 -*-
"""A tiny 'aplay' written in Python: reads raw S16_LE PCM on stdin and plays it on an ALSA or DVB audio device.

Run as its own process (python pcmplay.py -D plughw:0,0 -r 48000 -c 2 --buffer-time=500000) so it holds the sound card
exactly like aplay would. Needs only libasound.so.2 and Python's ctypes for ALSA, or gst-launch-1.0 (dvbaudiosink) /
direct DVB PES output for DVB-only receivers (Hisilicon / Dreambox / Broadcom images without an ALSA PCM driver).

  --check    exit 0 when libasound or gst-launch-1.0 or /dev/dvb/adapter0/audio0 can be used (nothing is opened)
"""
from __future__ import print_function, division

import ctypes
import ctypes.util
import errno
import fcntl
import glob
import os
import select
import shutil
import signal
import struct
import subprocess
import sys
import threading
import time

SND_PCM_NONBLOCK = 1
SND_PCM_STREAM_PLAYBACK = 0
SND_PCM_FORMAT_S16_LE = 2
SND_PCM_ACCESS_RW_INTERLEAVED = 3
EPIPE, ESTRPIPE, EAGAIN, EINTR = 32, 86, 11, 4
ENOENT, ENODEV = 2, 19

AUDIO_STOP = 0x6F01
AUDIO_PLAY = 0x6F02
AUDIO_PAUSE = 0x6F03
AUDIO_CONTINUE = 0x6F04
AUDIO_SELECT_SOURCE = 0x6F05
AUDIO_SET_MUTE = 0x6F06
AUDIO_SET_AV_SYNC = 0x6F07
AUDIO_SET_BYPASS_MODE = 0x6F08
AUDIO_CLEAR_BUFFER = 0x6F0C
AUDIO_SOURCE_DEMUX = 0
AUDIO_SOURCE_MEMORY = 1

HERE = os.path.dirname(os.path.abspath(__file__))
GSTPLAY = os.path.join(HERE, "gstplay.py")

_monotonic = getattr(time, "monotonic", time.time)
try:
    _DEVNULL = subprocess.DEVNULL
except AttributeError:
    _DEVNULL = open(os.devnull, "r+b")


def _which(cmd):
    if hasattr(shutil, "which"):
        res = shutil.which(cmd)
        if res:
            return res
    for d in os.environ.get("PATH", "").split(os.pathsep) + ["/usr/local/bin", "/usr/sbin", "/usr/bin", "/sbin", "/bin"]:
        if d:
            p = os.path.join(d, cmd)
            if os.path.isfile(p) and os.access(p, os.X_OK):
                return p
    return None


def _start_daemon(target, args=()):
    t = threading.Thread(target=target, args=tuple(args))
    t.daemon = True
    t.start()
    return t


def _wait_proc(proc, timeout=2.5):
    try:
        return proc.wait(timeout=timeout)
    except TypeError:
        deadline = _monotonic() + float(timeout)
        while proc.poll() is None:
            if _monotonic() >= deadline:
                raise RuntimeError("wait timed out")
            time.sleep(0.04)
        return proc.returncode


def _communicate_proc(proc, payload=None, timeout=4.0):
    try:
        return proc.communicate(payload, timeout=timeout)
    except TypeError:
        box = {}

        def work():
            try:
                box["res"] = proc.communicate(payload)
            except Exception as e:
                box["err"] = e

        t = _start_daemon(work)
        t.join(timeout)
        if t.is_alive():
            try:
                proc.kill()
            except Exception:
                pass
            raise RuntimeError("communicate timed out")
        if "err" in box:
            raise box["err"]
        return box.get("res", (b"", b""))


def err(msg):
    try:
        sys.stderr.write(msg + "\n")
        sys.stderr.flush()
    except Exception:
        pass


def load():
    names = []
    found = ctypes.util.find_library("asound")
    if found:
        names.append(found)
    names += ["libasound.so.2", "/usr/lib/libasound.so.2", "/lib/libasound.so.2", "libasound.so"]
    last = None
    for name in names:
        try:
            lib = ctypes.CDLL(name)
            break
        except OSError as e:
            last = e
    else:
        raise OSError("libasound.so.2 not found (%s)" % (last,))
    lib.snd_pcm_open.argtypes = [ctypes.POINTER(ctypes.c_void_p), ctypes.c_char_p, ctypes.c_int, ctypes.c_int]
    lib.snd_pcm_open.restype = ctypes.c_int
    lib.snd_pcm_set_params.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_uint, ctypes.c_uint,
                                       ctypes.c_int, ctypes.c_uint]
    lib.snd_pcm_set_params.restype = ctypes.c_int
    lib.snd_pcm_get_params.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulong), ctypes.POINTER(ctypes.c_ulong)]
    lib.snd_pcm_get_params.restype = ctypes.c_int
    lib.snd_pcm_writei.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_ulong]
    lib.snd_pcm_writei.restype = ctypes.c_long
    lib.snd_pcm_recover.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
    lib.snd_pcm_recover.restype = ctypes.c_int
    lib.snd_pcm_prepare.argtypes = [ctypes.c_void_p]
    lib.snd_pcm_prepare.restype = ctypes.c_int
    lib.snd_pcm_wait.argtypes = [ctypes.c_void_p, ctypes.c_int]
    lib.snd_pcm_wait.restype = ctypes.c_int
    lib.snd_pcm_nonblock.argtypes = [ctypes.c_void_p, ctypes.c_int]
    lib.snd_pcm_nonblock.restype = ctypes.c_int
    lib.snd_pcm_drain.argtypes = [ctypes.c_void_p]
    lib.snd_pcm_drop.argtypes = [ctypes.c_void_p]
    lib.snd_pcm_close.argtypes = [ctypes.c_void_p]
    lib.snd_pcm_sw_params_malloc.argtypes = [ctypes.POINTER(ctypes.c_void_p)]
    lib.snd_pcm_sw_params_current.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    lib.snd_pcm_sw_params_set_start_threshold.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_ulong]
    lib.snd_pcm_sw_params.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    lib.snd_pcm_sw_params_free.argtypes = [ctypes.c_void_p]
    lib.snd_strerror.argtypes = [ctypes.c_int]
    lib.snd_strerror.restype = ctypes.c_char_p
    return lib


def strerror(lib, code):
    try:
        s = lib.snd_strerror(code)
        return s.decode("utf-8", "replace") if isinstance(s, bytes) else str(s)
    except Exception:
        return "error %d" % code


def set_start(lib, pcm, frames):
    sw = ctypes.c_void_p()
    try:
        buffer_frames, period_frames = ctypes.c_ulong(), ctypes.c_ulong()
        if lib.snd_pcm_get_params(pcm, ctypes.byref(buffer_frames), ctypes.byref(period_frames)) < 0 or not buffer_frames.value:
            return
        frames = max(1, min(int(frames), int(buffer_frames.value)))
        if lib.snd_pcm_sw_params_malloc(ctypes.byref(sw)) < 0:
            return
        try:
            if lib.snd_pcm_sw_params_current(pcm, sw) >= 0 and \
                    lib.snd_pcm_sw_params_set_start_threshold(pcm, sw, frames) >= 0:
                lib.snd_pcm_sw_params(pcm, sw)
        finally:
            lib.snd_pcm_sw_params_free(sw)
    except Exception:
        pass


def parse(argv):
    opts = {"device": "default", "rate": 48000, "channels": 2, "buffer": 500000, "check": False, "start_ms": 80,
            "dvb_pipe": ""}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--check":
            opts["check"] = True
        elif a in ("-D", "--device") and i + 1 < len(argv):
            i += 1
            opts["device"] = argv[i]
        elif a in ("-r", "--rate") and i + 1 < len(argv):
            i += 1
            opts["rate"] = int(argv[i])
        elif a in ("-c", "--channels") and i + 1 < len(argv):
            i += 1
            opts["channels"] = int(argv[i])
        elif a.startswith("--buffer-time="):
            opts["buffer"] = int(a.split("=", 1)[1])
        elif a.startswith("--start-ms="):
            opts["start_ms"] = int(a.split("=", 1)[1])
        elif a.startswith("--dvb-pipe="):
            opts["dvb_pipe"] = a.split("=", 1)[1]
        i += 1
    return opts


def _wav_header(rate=48000, channels=2):
    block = channels * 2
    data_len = 0x7FFFFFDB
    riff_len = data_len + 36
    return (b"RIFF" + struct.pack("<I", riff_len) + b"WAVEfmt " +
            struct.pack("<IHHIIHH", 16, 1, channels, rate, rate * block, block, 16) +
            b"data" + struct.pack("<I", data_len))


def _write_all(fd, data):
    off = 0
    total = len(data)
    while off < total:
        n = os.write(fd, data[off:off + 65536])
        if n <= 0:
            raise OSError("audio pipe closed")
        off += n


def _write_all_timeout(fd, data, timeout=4.5):
    """Write all bytes to fd, raising OSError if downstream blocks for longer than `timeout` seconds."""
    flags = fcntl.fcntl(fd, fcntl.F_GETFL)
    if not flags & os.O_NONBLOCK:
        fcntl.fcntl(fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)
    off = 0
    total = len(data)
    deadline = _monotonic() + timeout
    while off < total:
        remaining = deadline - _monotonic()
        if remaining <= 0:
            raise OSError("dvbaudiosink write stalled for %.1fs" % timeout)
        try:
            r, w, _ = select.select([], [fd], [], remaining)
        except select.error as e:
            err_no = e.args[0] if getattr(e, "args", None) else getattr(e, "errno", None)
            if err_no == EINTR:
                continue
            raise OSError("select error on audio pipe: %s" % e)
        if not w:
            raise OSError("dvbaudiosink write stalled for %.1fs" % timeout)
        try:
            n = os.write(fd, data[off:off + 65536])
        except OSError as e:
            if e.errno in (EAGAIN, getattr(errno, "EWOULDBLOCK", EAGAIN), EINTR):
                continue
            raise
        if n <= 0:
            raise OSError("audio pipe closed")
        off += n
        deadline = _monotonic() + timeout


class TsDemuxer(object):
    """Extract raw audio elementary stream bytes from an FFmpeg single-audio MPEG-TS stream."""

    def __init__(self):
        self.buf = b""
        self.in_pes = False

    def feed(self, chunk):
        data = bytearray(self.buf + chunk)
        out = bytearray()
        n = len(data)
        i = 0
        while i + 188 <= n:
            if data[i] != 0x47:
                sync = bytes(data).find(b"\x47", i + 1)
                if sync < 0:
                    self.buf = b""
                    return bytes(out)
                i = sync
                continue
            pkt = data[i:i + 188]
            i += 188
            pid = ((pkt[1] & 0x1F) << 8) | pkt[2]
            if pid < 0x0040 or pid >= 0x1000:
                continue
            pusi = bool(pkt[1] & 0x40)
            afc = (pkt[3] >> 4) & 0x03
            if not (afc & 0x01):
                continue
            pos = 4
            if afc & 0x02:
                pos += 1 + pkt[4]
            if pos >= 188:
                continue
            payload = pkt[pos:188]
            if pusi:
                if len(payload) >= 9 and payload[0] == 0 and payload[1] == 0 and payload[2] == 1:
                    pes_hdr_len = 9 + payload[8]
                    if pes_hdr_len <= len(payload):
                        payload = payload[pes_hdr_len:]
                        self.in_pes = True
                    else:
                        payload = bytearray()
                else:
                    self.in_pes = True
            if self.in_pes and payload:
                out.extend(payload)
        self.buf = bytes(data[i:])
        return bytes(out)


def _kill_children(procs):
    for p in procs:
        if p is not None:
            try:
                p.terminate()
            except Exception:
                pass
    deadline = time.time() + 1.0
    for p in procs:
        if p is not None:
            try:
                _wait_proc(p, timeout=max(0.05, deadline - time.time()))
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass


def _prepare_dvb_node():
    for path in sorted(glob.glob("/dev/dvb/adapter*/audio*")):
        try:
            fd = os.open(path, os.O_RDWR | os.O_NONBLOCK)
        except EnvironmentError:
            continue
        try:
            for req, arg in ((AUDIO_SET_MUTE, 0), (AUDIO_SET_AV_SYNC, 0), (AUDIO_CLEAR_BUFFER, 0)):
                try:
                    fcntl.ioctl(fd, req, arg)
                except EnvironmentError:
                    pass
        finally:
            try:
                os.close(fd)
            except EnvironmentError:
                pass


def _probe_ff_cmd(ff, in_fmt, rate, channels, codec, muxer):
    pcm = b"\x00" * 19200
    if in_fmt == "wav":
        inp = ["-f", "wav", "-ignore_length", "1", "-i", "pipe:0"]
        payload = _wav_header(rate, channels) + pcm
    else:
        inp = ["-f", "s16le", "-ar", str(rate), "-ac", str(channels), "-i", "pipe:0"]
        payload = pcm
    cmd = [ff, "-hide_banner", "-loglevel", "error", "-nostdin"] + inp + [
        "-vn", "-c:a", codec, "-b:a", "128k", "-f", muxer, "pipe:1"]
    p = None
    try:
        p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=_DEVNULL)
        out, _ = _communicate_proc(p, payload, timeout=4.0)
        return p.returncode == 0 and len(out) > 0
    except Exception:
        return False
    finally:
        if p is not None and p.poll() is None:
            try:
                p.kill()
            except Exception:
                pass


def _auto_select_dvb_pipe(rate, channels, raw_only=False, pes=False):
    insp = _which("gst-inspect-1.0")

    def gst_has(el):
        if not insp:
            return False
        try:
            p = subprocess.Popen([insp, el], stdin=_DEVNULL, stdout=_DEVNULL, stderr=_DEVNULL)
            _communicate_proc(p, None, timeout=4.0)
            return p.returncode == 0
        except Exception:
            return False

    if not pes:
        raw_sub = "raw" if gst_has("rawaudioparse") else "wav" if gst_has("wavparse") else "caps"
        for kind, enc_el, parse_el in (
            ("gst-mp2", "avenc_mp2", "mpegaudioparse"),
            ("gst-twolame", "twolamemp2enc", "mpegaudioparse"),
            ("gst-mp3", "lamemp3enc", "mpegaudioparse"),
            ("gst-aac", "avenc_aac", "aacparse"),
            ("gst-faac", "faac", "aacparse"),
            ("gst-voaac", "voaacenc", "aacparse"),
            ("gst-fdkaac", "fdkaacenc", "aacparse"),
            ("gst-ac3", "avenc_ac3", "ac3parse"),
        ):
            if gst_has(enc_el) and gst_has(parse_el):
                return "%s:%s" % (kind, raw_sub)
    ff = _which("ffmpeg")
    if ff:
        for in_fmt in ("s16le", "wav"):
            prefix = "wav-" if in_fmt == "wav" else ""
            for kind, codec, muxer in (
                ("mp2", "mp2", "mp2"),
                ("mp2-mp3", "mp2", "mp3"),
                ("aac", "aac", "adts"),
                ("mpegts-mp2", "mp2", "mpegts"),
                ("mpegts-aac", "aac", "mpegts"),
                ("ac3", "ac3", "ac3"),
            ):
                parser = "aacparse" if codec == "aac" else "ac3parse" if codec == "ac3" else "mpegaudioparse"
                if not pes and not gst_has(parser):
                    continue
                if _probe_ff_cmd(ff, in_fmt, rate, channels, codec, muxer):
                    return prefix + kind
    return "unavailable"


def _gi_sink_ok():
    if not os.path.isfile(GSTPLAY):
        return False
    try:
        p = subprocess.Popen([sys.executable, "-E", "-s", GSTPLAY, "--check"],
                             stdin=_DEVNULL, stdout=_DEVNULL, stderr=_DEVNULL)
        _communicate_proc(p, None, timeout=5.0)
        return p.returncode == 0
    except Exception:
        return False


def _build_ff_enc_cmd(ff, pipe_kind, rate, channels):
    use_wav = pipe_kind.startswith("wav-")
    base = pipe_kind[4:] if use_wav else pipe_kind
    if use_wav:
        inp = ["-f", "wav", "-ignore_length", "1", "-i", "pipe:0"]
    else:
        inp = ["-f", "s16le", "-ar", str(rate), "-ac", str(channels), "-i", "pipe:0"]
    common = [ff, "-hide_banner", "-loglevel", "error", "-nostdin", "-probesize", "4096", "-analyzeduration", "0"] + inp + ["-vn"]
    if base == "mp2-mp3":
        return common + ["-c:a", "mp2", "-b:a", "192k", "-flush_packets", "1", "-f", "mp3", "pipe:1"], use_wav, False, "mpegaudioparse", 1
    if base == "aac":
        return common + ["-c:a", "aac", "-b:a", "128k", "-flush_packets", "1", "-f", "adts", "pipe:1"], use_wav, False, "aacparse", 8
    if base == "mpegts-aac":
        return common + ["-c:a", "aac", "-b:a", "128k", "-flush_packets", "1", "-f", "mpegts", "pipe:1"], use_wav, True, "aacparse", 8
    if base == "ac3":
        return common + ["-c:a", "ac3", "-b:a", "192k", "-flush_packets", "1", "-f", "ac3", "pipe:1"], use_wav, False, "ac3parse", 0
    if base == "mpegts-mp2":
        return common + ["-c:a", "mp2", "-b:a", "192k", "-flush_packets", "1", "-f", "mpegts", "pipe:1"], use_wav, True, "mpegaudioparse", 1
    return common + ["-c:a", "mp2", "-b:a", "192k", "-flush_packets", "1", "-f", "mp2", "pipe:1"], use_wav, False, "mpegaudioparse", 1


def play_dvb_pes(opts, pipe_kind=""):
    """Direct hardware DVB PES writer: encodes PCM to MP2/AAC/AC3 and writes PTS-free PES packets to /dev/dvb/adapter0/audio0."""
    ff = _which("ffmpeg")
    rate = int(opts["rate"])
    channels = int(opts["channels"])
    frame = 2 * channels
    if not pipe_kind or pipe_kind in ("raw", "wav", "caps", "decodebin", "unavailable") or pipe_kind.startswith("gst-"):
        pipe_kind = _auto_select_dvb_pipe(rate, channels, pes=True)
    if not ff or pipe_kind in ("raw", "wav", "caps", "decodebin", "unavailable") or pipe_kind.startswith("gst-"):
        err("aplay: main: audio open error: cannot open audio device %s (no FFmpeg PES encoder available)" % opts["device"])
        return 1
    base = pipe_kind[4:] if pipe_kind.startswith("wav-") else pipe_kind
    in_fmt = "wav" if pipe_kind.startswith("wav-") else "s16le"
    codec = "aac" if "aac" in base else "ac3" if "ac3" in base else "mp2"
    muxer = "mp3" if base == "mp2-mp3" else "mpegts" if "mpegts" in base else ("adts" if codec == "aac" else codec)
    if not _probe_ff_cmd(ff, in_fmt, rate, channels, codec, muxer):
        pipe_kind = _auto_select_dvb_pipe(rate, channels, pes=True)
        if pipe_kind in ("raw", "wav", "caps", "decodebin", "unavailable") or pipe_kind.startswith("gst-"):
            err("aplay: main: audio open error: cannot open audio device %s (no working FFmpeg muxer)" % opts["device"])
            return 1
    enc_cmd, use_wav, use_ts_demux, _, bypass = _build_ff_enc_cmd(ff, pipe_kind, rate, channels)
    nodes = sorted(glob.glob("/dev/dvb/adapter*/audio*"))
    if not nodes:
        err("aplay: main: audio open error: cannot open audio device %s (no /dev/dvb/adapter*/audio*)" % opts["device"])
        return 1
    dvb_fd = None
    last_err = None
    for path in nodes:
        try:
            dvb_fd = os.open(path, os.O_RDWR | os.O_NONBLOCK)
            break
        except OSError as e:
            last_err = e
    if dvb_fd is None:
        err("aplay: main: audio open error: cannot open audio device %s (%s)" % (opts["device"], last_err))
        return 1

    enc = None
    stopping = [False]
    errors = []

    def _cleanup_dvb():
        if dvb_fd is not None:
            for req, arg in ((AUDIO_STOP, 0), (AUDIO_CLEAR_BUFFER, 0), (AUDIO_SELECT_SOURCE, AUDIO_SOURCE_DEMUX)):
                try:
                    fcntl.ioctl(dvb_fd, req, arg)
                except Exception:
                    pass
            try:
                os.close(dvb_fd)
            except Exception:
                pass

    def _on_term(signum, frame_obj):
        stopping[0] = True
        _kill_children([enc])
        _cleanup_dvb()
        sys.exit(0)

    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            signal.signal(sig, _on_term)
        except Exception:
            pass

    try:
        for req, arg in (
            (AUDIO_STOP, 0),
            (AUDIO_CLEAR_BUFFER, 0),
            (AUDIO_SELECT_SOURCE, AUDIO_SOURCE_MEMORY),
            (AUDIO_SET_AV_SYNC, 0),
            (AUDIO_SET_MUTE, 0),
            (AUDIO_SET_BYPASS_MODE, bypass),
            (AUDIO_PLAY, 0),
            (AUDIO_CONTINUE, 0),
        ):
            try:
                fcntl.ioctl(dvb_fd, req, arg)
            except EnvironmentError:
                pass
        enc = subprocess.Popen(enc_cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0)
    except OSError as e:
        _kill_children([enc])
        _cleanup_dvb()
        err("aplay: main: audio open error: cannot open audio device %s (%s)" % (opts["device"], e))
        return 1

    def _drain_err(proc):
        try:
            for raw in iter(proc.stderr.readline, b""):
                line = raw.decode("utf-8", "replace").strip()
                if line:
                    errors.append(line)
                    del errors[:-10]
                    err(line)
        except Exception:
            pass

    _start_daemon(_drain_err, (enc,))
    writer_err = []

    def _pes_writer():
        demux = TsDemuxer() if use_ts_demux else None
        es_fd = enc.stdout.fileno()
        try:
            while not stopping[0]:
                chunk = os.read(es_fd, 4096)
                if not chunk:
                    break
                data = demux.feed(chunk) if demux is not None else chunk
                if not data:
                    continue
                off = 0
                while off < len(data) and not stopping[0]:
                    part = data[off:off + 2048]
                    off += len(part)
                    pes = b"\x00\x00\x01\xc0" + struct.pack(">H", len(part) + 3) + b"\x80\x00\x00" + part
                    _write_all_timeout(dvb_fd, pes, timeout=4.5)
        except Exception as e:
            if not stopping[0]:
                writer_err.append(str(e))
                stopping[0] = True

    pes_thread = _start_daemon(_pes_writer)

    fd_in = sys.stdin.fileno()
    fd_out = enc.stdin.fileno()
    rest = b""
    code = 0
    clock = time.time
    start_t = clock()
    t_mark, w_data, w_card, frames_out = start_t, 0.0, 0.0, 0
    try:
        if use_wav:
            _write_all_timeout(fd_out, _wav_header(rate, channels), timeout=4.5)
        while not stopping[0]:
            t0 = clock()
            chunk = os.read(fd_in, 16384)
            w_data += clock() - t0
            if not chunk:
                break
            if writer_err or enc.poll() is not None:
                reason = writer_err[-1] if writer_err else (errors[-1] if errors else "DVB PES encoder closed")
                err("aplay: main: audio open error: cannot open audio device %s (%s)" % (opts["device"], reason))
                return 1
            data = rest + chunk
            usable = len(data) - len(data) % frame
            rest = data[usable:]
            if usable > 0:
                t0 = clock()
                _write_all_timeout(fd_out, data[:usable], timeout=4.5)
                w_card += clock() - t0
                frames_out += usable // frame
            now = clock()
            if now - t_mark >= 10.0:
                span = now - t_mark
                err("pcmplay: stats played=%.2fx wait_data=%.1fs wait_card=%.1fs underruns=0 in %.0fs"
                    % (frames_out / float(rate) / span, w_data, w_card, span))
                t_mark, w_data, w_card, frames_out = now, 0.0, 0.0, 0
        if not stopping[0] and code == 0:
            try:
                enc.stdin.close()
            except Exception:
                pass
            pes_thread.join(timeout=3.0)
            played_s = frames_out / float(rate)
            rem = min(4.0, max(0.3, played_s - (clock() - start_t) + 0.4))
            if rem > 0:
                time.sleep(rem)
    except KeyboardInterrupt:
        pass
    except EnvironmentError as e:
        if not stopping[0]:
            reason = writer_err[-1] if writer_err else (errors[-1] if errors else str(e))
            err("aplay: main: audio open error: cannot open audio device %s (%s)" % (opts["device"], reason))
            code = 1
    finally:
        stopping[0] = True
        if enc is not None and enc.stdin:
            try:
                enc.stdin.close()
            except Exception:
                pass
        _kill_children([enc])
        _cleanup_dvb()
    return code


def play_dvb(opts):
    """Play raw S16_LE PCM from stdin through GStreamer's dvbaudiosink (or direct PES on dvb-pes)."""
    dev = opts["device"]
    if dev == "dvb-pes":
        return play_dvb_pes(opts, opts.get("dvb_pipe") or "")
    gst = _which("gst-launch-1.0")
    if not gst:
        return play_dvb_pes(opts, opts.get("dvb_pipe") or "")
    _prepare_dvb_node()
    rate = int(opts["rate"])
    channels = int(opts["channels"])
    frame = 2 * channels
    pipe_kind = opts.get("dvb_pipe") or ""
    if not pipe_kind or pipe_kind in ("decodebin", "raw", "wav", "caps", "unavailable"):
        pipe_kind = _auto_select_dvb_pipe(rate, channels, raw_only=(dev == "dvb-raw"))
    ff = _which("ffmpeg")
    if ff and pipe_kind in ("mp2", "mp2-mp3", "aac", "mpegts-mp2", "mpegts-aac", "ac3",
                            "wav-mp2", "wav-mp2-mp3", "wav-aac", "wav-mpegts-mp2", "wav-mpegts-aac", "wav-ac3"):
        base = pipe_kind[4:] if pipe_kind.startswith("wav-") else pipe_kind
        in_fmt = "wav" if pipe_kind.startswith("wav-") else "s16le"
        codec = "aac" if "aac" in base else "ac3" if "ac3" in base else "mp2"
        muxer = "mp3" if base == "mp2-mp3" else "mpegts" if "mpegts" in base else ("adts" if codec == "aac" else codec)
        if not _probe_ff_cmd(ff, in_fmt, rate, channels, codec, muxer):
            pipe_kind = _auto_select_dvb_pipe(rate, channels, raw_only=(dev == "dvb-raw"))

    if pipe_kind == "unavailable":
        err("aplay: main: audio open error: cannot open audio device %s (no compressed DVB encoder/parser; install gstreamer1.0-libav)" % dev)
        return 1
    err("pcmplay: DVB output %s via %s" % (dev, pipe_kind))
    use_gi = _gi_sink_ok()
    enc = None
    sink = None
    use_wav = False
    use_ts_demux = False
    ts_relay_err = []
    stopping = [False]

    try:
        if ff and pipe_kind in ("mp2", "mp2-mp3", "aac", "mpegts-mp2", "mpegts-aac", "ac3",
                                "wav-mp2", "wav-mp2-mp3", "wav-aac", "wav-mpegts-mp2", "wav-mpegts-aac", "wav-ac3"):
            enc_cmd, use_wav, use_ts_demux, parser_el, _ = _build_ff_enc_cmd(ff, pipe_kind, rate, channels)
            if use_gi:
                sink_cmd = [sys.executable, "-E", "-s", GSTPLAY, "--dvb-sink", parser_el,
                            "--rate", str(rate), "--channels", str(channels)]
            else:
                sink_cmd = [gst, "-q", "fdsrc", "fd=0", "do-timestamp=true", "!", parser_el, "!",
                            "dvbaudiosink", "sync=false", "async=false"]
            if use_ts_demux:
                enc = subprocess.Popen(enc_cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0)
                sink = subprocess.Popen(sink_cmd, stdin=subprocess.PIPE, stdout=_DEVNULL, stderr=subprocess.PIPE, bufsize=0)

                def _ts_bridge():
                    demux = TsDemuxer()
                    fd_r = enc.stdout.fileno()
                    fd_w = sink.stdin.fileno()
                    try:
                        while not stopping[0]:
                            chunk = os.read(fd_r, 8192)
                            if not chunk:
                                break
                            es = demux.feed(chunk)
                            if es:
                                _write_all_timeout(fd_w, es, timeout=4.5)
                    except Exception as e:
                        if not stopping[0]:
                            ts_relay_err.append(str(e))
                    finally:
                        for f in (sink.stdin, enc.stdout):
                            try:
                                f.close()
                            except Exception:
                                pass

                ts_thread = _start_daemon(_ts_bridge)
            else:
                ts_thread = None
                enc = subprocess.Popen(enc_cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0)
                sink = subprocess.Popen(sink_cmd, stdin=enc.stdout, stdout=_DEVNULL, stderr=subprocess.PIPE, bufsize=0)
                enc.stdout.close()
            target_proc = enc
        else:
            ts_thread = None
            base, _, raw_sub = pipe_kind.partition(":")
            if base == "wav" or raw_sub == "wav":
                use_wav = True
            if use_gi:
                sink_cmd = [sys.executable, "-E", "-s", GSTPLAY, "--dvb-sink", pipe_kind,
                            "--rate", str(rate), "--channels", str(channels)]
            else:
                if raw_sub == "raw" or base == "raw":
                    src_args = ["fdsrc", "fd=0", "do-timestamp=true", "!", "rawaudioparse", "use-sink-caps=false",
                                "format=pcm", "pcm-format=s16le", "sample-rate=%d" % rate, "num-channels=%d" % channels,
                                "!", "audioconvert", "!", "audioresample"]
                elif use_wav:
                    src_args = ["fdsrc", "fd=0", "do-timestamp=true", "!", "wavparse", "ignore-length=true",
                                "!", "audioconvert", "!", "audioresample"]
                else:
                    src_args = ["fdsrc", "fd=0", "blocksize=4096", "do-timestamp=true", "!",
                                "audio/x-raw,format=S16LE,rate=%d,channels=%d,layout=interleaved" % (rate, channels),
                                "!", "audioconvert", "!", "audioresample"]
                enc_map = {
                    "gst-mp2": ["!", "avenc_mp2", "bitrate=192000", "!", "mpegaudioparse"],
                    "gst-twolame": ["!", "twolamemp2enc", "bitrate=192", "!", "mpegaudioparse"],
                    "gst-mp3": ["!", "lamemp3enc", "target=bitrate", "bitrate=192", "cbr=true", "!", "mpegaudioparse"],
                    "gst-aac": ["!", "avenc_aac", "bitrate=128000", "!", "aacparse"],
                    "gst-faac": ["!", "faac", "bitrate=128000", "!", "aacparse"],
                    "gst-voaac": ["!", "voaacenc", "bitrate=128000", "!", "aacparse"],
                    "gst-fdkaac": ["!", "fdkaacenc", "bitrate=128000", "!", "aacparse"],
                    "gst-ac3": ["!", "avenc_ac3", "bitrate=192000", "!", "ac3parse"],
                }
                sink_cmd = [gst, "-q"] + src_args + enc_map.get(base, []) + ["!", "dvbaudiosink", "sync=false", "async=false"]
            sink = subprocess.Popen(sink_cmd, stdin=subprocess.PIPE, stdout=_DEVNULL, stderr=subprocess.PIPE, bufsize=0)
            target_proc = sink
    except OSError as e:
        _kill_children([enc, sink])
        err("aplay: main: audio open error: cannot open audio device %s (%s)" % (dev, e))
        return 1

    errors = []

    def _on_term(signum, frame_obj):
        stopping[0] = True
        _kill_children([enc, sink])
        sys.exit(0)

    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            signal.signal(sig, _on_term)
        except Exception:
            pass

    def _drain_err(proc, label):
        try:
            for raw in iter(proc.stderr.readline, b""):
                line = raw.decode("utf-8", "replace").strip()
                if line:
                    errors.append(line)
                    del errors[:-10]
                    err(line)
        except Exception:
            pass

    if enc is not None:
        _start_daemon(_drain_err, (enc, "ffmpeg"))
    _start_daemon(_drain_err, (sink, "gst"))

    def _watch_sink():
        while not stopping[0]:
            time.sleep(0.1)
            rc = sink.poll()
            if rc is not None:
                if not stopping[0] and rc != 0:
                    time.sleep(0.05)
                    reason = errors[-1] if errors else "dvbaudiosink exited (%d)" % rc
                    err("aplay: main: audio open error: cannot open audio device %s (%s)" % (dev, reason))
                    _kill_children([enc, sink])
                    os._exit(1)
                return

    _start_daemon(_watch_sink)

    fd_in = sys.stdin.fileno()
    fd_out = target_proc.stdin.fileno()
    rest = b""
    code = 0
    clock = time.time
    start_t = clock()
    t_mark, w_data, w_card, frames_out = start_t, 0.0, 0.0, 0
    try:
        if use_wav:
            _write_all_timeout(fd_out, _wav_header(rate, channels), timeout=4.5)
        while not stopping[0]:
            t0 = clock()
            chunk = os.read(fd_in, 16384)
            w_data += clock() - t0
            if not chunk:
                break
            if sink.poll() is not None or (enc is not None and enc.poll() is not None) or ts_relay_err:
                reason = ts_relay_err[-1] if ts_relay_err else (errors[-1] if errors else "dvbaudiosink closed")
                err("aplay: main: audio open error: cannot open audio device %s (%s)" % (dev, reason))
                return 1
            data = rest + chunk
            usable = len(data) - len(data) % frame
            rest = data[usable:]
            if usable > 0:
                t0 = clock()
                _write_all_timeout(fd_out, data[:usable], timeout=4.5)
                w_card += clock() - t0
                frames_out += usable // frame
            now = clock()
            if now - t_mark >= 10.0:
                span = now - t_mark
                err("pcmplay: stats played=%.2fx wait_data=%.1fs wait_card=%.1fs underruns=0 in %.0fs"
                    % (frames_out / float(rate) / span, w_data, w_card, span))
                t_mark, w_data, w_card, frames_out = now, 0.0, 0.0, 0
        if not stopping[0] and code == 0:
            try:
                target_proc.stdin.close()
            except Exception:
                pass
            if enc is not None:
                try:
                    _wait_proc(enc, timeout=2.5)
                except Exception:
                    pass
            if ts_thread is not None:
                ts_thread.join(timeout=2.5)
            played_s = frames_out / float(rate)
            rem = min(4.0, max(0.3, played_s - (clock() - start_t) + 0.4))
            if rem > 0 and sink.poll() is None:
                time.sleep(rem)
    except KeyboardInterrupt:
        pass
    except EnvironmentError as e:
        if not stopping[0]:
            reason = ts_relay_err[-1] if ts_relay_err else (errors[-1] if errors else str(e))
            err("aplay: main: audio open error: cannot open audio device %s (%s)" % (dev, reason))
            code = 1
    finally:
        stopping[0] = True
        for p in (enc, sink):
            if p is not None and p.stdin:
                try:
                    p.stdin.close()
                except Exception:
                    pass
        _kill_children([enc, sink])
    return code


def main(argv):
    opts = parse(argv)
    dev = opts["device"]
    if opts["check"]:
        try:
            load()
            return 0
        except OSError:
            return 0 if (_which("gst-launch-1.0") or glob.glob("/dev/dvb/adapter*/audio*")) else 2
    if dev in ("dvb", "dvb-raw", "dvb-pes") or dev.startswith("dvb:"):
        return play_dvb(opts)
    try:
        lib = load()
    except OSError as e:
        if _which("gst-launch-1.0") or glob.glob("/dev/dvb/adapter*/audio*"):
            opts["device"] = "dvb"
            return play_dvb(opts)
        err("pcmplay: %s" % e)
        return 2
    frame = 2 * opts["channels"]
    pcm = ctypes.c_void_p()
    dev_bytes = dev.encode("utf-8") if not isinstance(dev, bytes) else dev
    rc = lib.snd_pcm_open(ctypes.byref(pcm), dev_bytes, SND_PCM_STREAM_PLAYBACK, SND_PCM_NONBLOCK)
    if rc < 0:
        if dev == "default" and -rc in (ENOENT, ENODEV) and (_which("gst-launch-1.0") or os.path.exists("/dev/dvb/adapter0/audio0")):
            opts["device"] = "dvb"
            return play_dvb(opts)
        err("aplay: main: audio open error: cannot open audio device %s (%s)" % (dev, strerror(lib, rc)))
        return 1
    rc = lib.snd_pcm_set_params(pcm, SND_PCM_FORMAT_S16_LE, SND_PCM_ACCESS_RW_INTERLEAVED, opts["channels"],
                                opts["rate"], 1, max(20000, opts["buffer"]))
    if rc < 0:
        err("pcmplay: cannot set the sound card to S16_LE %d Hz %d ch on %s (%s)"
            % (opts["rate"], opts["channels"], dev, strerror(lib, rc)))
        lib.snd_pcm_close(pcm)
        return 1
    set_start(lib, pcm, max(1, opts["rate"] * opts["start_ms"] // 1000))
    try:
        buf_f, per_f = ctypes.c_ulong(), ctypes.c_ulong()
        if lib.snd_pcm_get_params(pcm, ctypes.byref(buf_f), ctypes.byref(per_f)) >= 0:
            err("pcmplay: stats card params on %s: buffer=%d frames (%.0f ms) period=%d frames (%.0f ms)"
                % (dev, buf_f.value, buf_f.value * 1000.0 / opts["rate"], per_f.value, per_f.value * 1000.0 / opts["rate"]))
    except Exception:
        pass
    stopping = [False]
    closed = [False]   # the handle must be closed exactly once (a second snd_pcm_close frees it twice)

    pcm_box = [pcm]

    def _close_pcm():
        if not closed[0]:
            closed[0] = True
            try:
                lib.snd_pcm_close(pcm_box[0])
            except Exception:
                pass

    def _on_alsa_term(signum, frame_obj):
        stopping[0] = True
        try:
            lib.snd_pcm_drop(pcm)
        except Exception:
            pass
        _close_pcm()
        sys.exit(0)

    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            signal.signal(sig, _on_alsa_term)
        except Exception:
            pass

    reset_pending = [False]

    def _on_output_reset(signum, frame_obj):
        # No ALSA calls or handle changes inside the asynchronous signal handler.
        reset_pending[0] = True

    try:
        signal.signal(signal.SIGUSR1, _on_output_reset)
        err("pcmplay: reset-ready")
    except (AttributeError, ValueError, OSError):
        pass

    def _reopen_alsa(reason_label, is_transition=False):
        reset_pending[0] = False
        err("pcmplay: %s on %s; reopening handle" % (reason_label, dev))
        try:
            lib.snd_pcm_drop(pcm_box[0])
        except Exception:
            pass
        _close_pcm()
        pcm_new = ctypes.c_void_p()
        rc = -1
        ebusy = getattr(errno, "EBUSY", 16)
        for attempt in range(8 if is_transition else 1):
            if attempt > 0:
                time.sleep(0.035)
            pcm_new = ctypes.c_void_p()
            rc = lib.snd_pcm_open(ctypes.byref(pcm_new), dev_bytes, SND_PCM_STREAM_PLAYBACK, SND_PCM_NONBLOCK)
            if rc >= 0 or -rc not in (ebusy, EAGAIN, EINTR):
                break
        if rc < 0:
            err("pcmplay: write error on %s (reopen failed: %s)" % (dev, strerror(lib, rc)))
            return False
        pcm_box[0] = pcm_new
        closed[0] = False
        rc = lib.snd_pcm_set_params(pcm_box[0], SND_PCM_FORMAT_S16_LE, SND_PCM_ACCESS_RW_INTERLEAVED,
                                    opts["channels"], opts["rate"], 1, max(20000, opts["buffer"]))
        if rc < 0:
            err("pcmplay: write error on %s (reconfigure failed: %s)" % (dev, strerror(lib, rc)))
            _close_pcm()
            return False
        set_start(lib, pcm_box[0], max(1, opts["rate"] * opts["start_ms"] // 1000))
        if is_transition:
            err("pcmplay: output reset complete after TV transition")
        return True

    fd = sys.stdin.fileno()
    rest = b""
    code = 0
    clock = _monotonic
    t_mark, w_data, w_card, frames_out, xr = clock(), 0.0, 0.0, 0, 0
    try:
        while not stopping[0]:
            t0 = clock()
            try:
                chunk = os.read(fd, 4096)
            except EnvironmentError as e:
                # Python 2 may surface EINTR when SIGUSR1 interrupts a waiting read.
                # Reopen ALSA immediately if a TV transition reset is pending, then retry read.
                if getattr(e, "errno", None) == EINTR:
                    w_data += clock() - t0
                    if reset_pending[0] and not stopping[0]:
                        if not _reopen_alsa("TV transition reset", is_transition=True):
                            return 1
                        pcm = pcm_box[0]
                    continue
                raise
            w_data += clock() - t0
            if not chunk:
                break
            data = rest + chunk
            usable = len(data) - len(data) % frame
            rest = data[usable:]
            off = 0
            progress_at = _monotonic()
            recovery_stage = 0
            while off < usable and not stopping[0]:
                # Drivers may report writable while writei still returns EAGAIN/0.
                # Bound ALL no-progress paths, including recoverable errors.
                elapsed = _monotonic() - progress_at
                if elapsed >= 5.0:
                    err("pcmplay: write error on %s (no PCM progress for %.1fs)" % (dev, elapsed))
                    return 1
                requested_reset = reset_pending[0]
                if requested_reset or (elapsed >= 2.5 and recovery_stage < 2):
                    recovery_stage = 2
                    if not _reopen_alsa("TV transition reset" if requested_reset else "ALSA no progress",
                                        is_transition=requested_reset):
                        return 1
                    pcm = pcm_box[0]
                    if requested_reset:
                        progress_at = _monotonic()
                elif elapsed >= 1.2 and recovery_stage < 1:
                    recovery_stage = 1
                    err("pcmplay: ALSA no progress on %s; resetting PCM stream" % dev)
                    lib.snd_pcm_drop(pcm)
                    rc = lib.snd_pcm_prepare(pcm)
                    if rc < 0:
                        err("pcmplay: PCM prepare failed on %s (%s)" % (dev, strerror(lib, rc)))
                frames = (usable - off) // frame
                t0 = clock()
                n = lib.snd_pcm_writei(pcm, data[off:usable], frames)
                w_card += clock() - t0
                if n > 0:
                    off += n * frame
                    frames_out += n
                    progress_at = _monotonic()
                    recovery_stage = 0
                    continue
                if n == -EINTR:
                    time.sleep(0.001)
                    continue
                if n in (0, -EAGAIN):
                    t_w = clock()
                    w_rc = lib.snd_pcm_wait(pcm, 100)
                    w_card += clock() - t_w
                    if w_rc < 0 and w_rc != -EINTR:
                        lib.snd_pcm_recover(pcm, int(w_rc), 1)
                    # Some Broadcom drivers return ready immediately in a stuck DMA state.
                    if w_rc > 0:
                        time.sleep(0.01)
                    continue
                if n == -EPIPE:
                    xr += 1
                    if recovery_stage == 0:
                        err("pcmplay: underrun")
                time.sleep(0.01)
                r = lib.snd_pcm_recover(pcm, int(n), 1)
                if r < 0:
                    lib.snd_pcm_drop(pcm)
                    r = lib.snd_pcm_prepare(pcm)
                    if r < 0:
                        err("pcmplay: write error on %s (%s)" % (dev, strerror(lib, int(n))))
                        return 1
            now = clock()
            if now - t_mark >= 10.0:
                span = now - t_mark
                err("pcmplay: stats played=%.2fx wait_data=%.1fs wait_card=%.1fs underruns=%d in %.0fs"
                    % (frames_out / float(opts["rate"]) / span, w_data, w_card, xr, span))
                t_mark, w_data, w_card, frames_out, xr = now, 0.0, 0.0, 0, 0
        try:
            if stopping[0]:
                lib.snd_pcm_drop(pcm)
            else:
                deadline = _monotonic() + max(5.0, opts["buffer"] / 1000000.0 + 3.0)
                while not stopping[0]:
                    rc = lib.snd_pcm_drain(pcm)
                    if rc == 0:
                        break
                    if rc not in (-EAGAIN, -EINTR) or _monotonic() >= deadline:
                        err("pcmplay: write error on %s (final PCM drain failed: %s)" % (dev, strerror(lib, rc)))
                        code = 1
                        break
                    lib.snd_pcm_wait(pcm, 100)
                    time.sleep(0.01)
        except Exception:
            pass
    except KeyboardInterrupt:
        pass
    except EnvironmentError as e:
        if not stopping[0]:
            err("pcmplay: %s" % e)
            code = 1
    finally:
        _close_pcm()
    return code


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
