# -*- coding: utf-8 -*-
"""Ultra Quran Receiver Frontpanel / VFD / LCD Display Manager.

Supports:
  - Color TFT LCD front panels (Vu+ Duo 4K, Ultimo 4K, GigaBlue UHD, Dreambox Two/Seven)
  - Monochrome OLED / VFD displays (Vu+ Uno 4K SE, Octagon SF8008, Zgemma H7/H9)
When browsing: Displays the Ultra Quran logo on color TFT, or clean title on VFD.
When playing: Displays the currently playing Surah / Video episode / Radio in real-time!
"""
import os
from Screens.Screen import Screen
from Components.Label import Label
from Components.Pixmap import Pixmap
from .support import native

try:
    from enigma import getDesktop
except ImportError:
    getDesktop = lambda i: None

ROOT = os.path.dirname(__file__)
PLUGIN_ICON = os.path.join(ROOT, "plugin.png")


def front_display_geometry():
    try:
        desktop = getDesktop(1)
        if desktop is not None:
            size = desktop.size()
            w, h = int(size.width()), int(size.height())
            if w > 0 and h > 0:
                return w, h
    except Exception:
        pass
    return 132, 64


from .support import IS_DREAMOS


def _icon_for(width, height):
    """The 300x120 icon at exactly (width, height): drawn 1:1 when it already has that size, otherwise a
    pre-scaled copy (so it is never cropped, also on images whose skin has no pixmap scaling)."""
    if (width, height) == (300, 120):
        return PLUGIN_ICON, False
    try:
        stamp = int(os.path.getmtime(PLUGIN_ICON))
    except OSError:
        stamp = 0
    target = "/tmp/ultra-quran-front-%dx%d-%d.png" % (width, height, stamp)
    try:
        if not os.path.isfile(target):
            from PIL import Image
            im = Image.open(PLUGIN_ICON).convert("RGBA")
            resample = getattr(getattr(Image, "Resampling", Image), "LANCZOS", Image.BICUBIC)
            im.resize((width, height), resample).save(target)
        return target, False
    except Exception:
        return PLUGIN_ICON, not IS_DREAMOS        # no PIL: let the skin scale it (OE-A images)


def build_front_skin(width, height):
    """Ultra Stalker's front-panel layout: on colour TFT panels the plugin icon alone, centred on black in
    its native 300x120 proportions (scaled down only when the panel is too small); the playing title
    appears under it. Small monochrome / OLED panels show clean text instead of a broken bitmap."""
    width = max(96, int(width or 132))
    height = max(48, int(height or 64))

    if width >= 220 and height >= 100:
        max_w = max(120, width - max(20, width // 10))
        max_h = max(60, height - max(24, height // 4))
        logo_w = min(300, max_w)
        logo_h = max(48, int(round(float(logo_w) * 120.0 / 300.0)))
        if logo_h > max_h:
            logo_h = max_h
            logo_w = max(120, int(round(float(logo_h) * 300.0 / 120.0)))
        logo_x = max(0, (width - logo_w) // 2)
        logo_y = max(0, (height - logo_h) // 2)
        band = height - (logo_y + logo_h)
        title_y = logo_y + logo_h + 2
        title_h = max(1, band - 4)
        font = max(12, min(24, int(title_h * 0.62)))
        icon, scale = _icon_for(logo_w, logo_h)
        return '''<screen name="UltraQuranFrontSummary" position="0,0" size="%(w)d,%(h)d" backgroundColor="#000000" flags="wfNoBorder">
            <widget name="logo" position="%(lx)d,%(ly)d" size="%(lw)d,%(lh)d" pixmap="%(icon)s" alphatest="blend" transparent="1"%(scale)s />
            <widget name="title" position="4,%(ty)d" size="%(tw)d,%(th)d" font="Regular;%(fs)d" halign="center" valign="center" foregroundColor="#e8c47e" backgroundColor="#000000" transparent="0" noWrap="1" />
        </screen>''' % {
            "w": width, "h": height, "lx": logo_x, "ly": logo_y, "lw": logo_w, "lh": logo_h,
            "ty": title_y, "tw": width - 8, "th": title_h, "fs": font, "icon": icon,
            "scale": ' scale="1"' if scale else "",
        }

    font_size = max(12, min(18, height // 3))
    return '''<screen name="UltraQuranFrontSummary" position="0,0" size="%(w)d,%(h)d" backgroundColor="#000000" flags="wfNoBorder">
        <widget name="title" position="2,0" size="%(tw)d,%(h)d" font="Regular;%(fs)d" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#000000" transparent="0" noWrap="1" />
        <widget name="logo" position="0,0" size="1,1" alphatest="blend" transparent="1" />
    </screen>''' % {
        "w": width, "h": height, "tw": max(20, width - 4), "fs": font_size,
    }


class UltraQuranFrontSummary(Screen):
    """Frontpanel summary screen shown on receiver LCD/VFD."""
    instance = None
    playing = u""

    def __init__(self, session, parent=None):
        Screen.__init__(self, session, parent=parent)
        self.w, self.h = front_display_geometry()
        self.tft = self.w >= 220 and self.h >= 100
        self.skin = build_front_skin(self.w, self.h)
        self["logo"] = Pixmap()
        self["title"] = Label(native(UltraQuranFrontSummary.playing or u"Ultra Quran"))
        UltraQuranFrontSummary.instance = self
        self.onShow.append(self._sync)
        self.onClose.append(self._cleanup)

    def _cleanup(self):
        if UltraQuranFrontSummary.instance is self:
            UltraQuranFrontSummary.instance = None

    def _sync(self):
        """TFT: only the centred icon while browsing (like Ultra Stalker); the title shows while playing."""
        try:
            title = self["title"]
            if self.tft and not UltraQuranFrontSummary.playing:
                title.hide()
            else:
                title.show()
        except Exception:
            pass

    @classmethod
    def set_title(cls, text):
        import re
        text = re.sub(u"[\u0610-\u061a\u064b-\u065f\u0670\u06d6-\u06ed]", u"", text or u"")
        cls.playing = text
        if cls.instance is not None:
            try:
                cls.instance["title"].setText(native(text or u"Ultra Quran"))
                cls.instance._sync()
            except Exception:
                pass

    @classmethod
    def reset(cls):
        cls.playing = u""
        if cls.instance is not None:
            try:
                cls.instance["title"].setText(native(u"Ultra Quran"))
                cls.instance._sync()
            except Exception:
                pass
