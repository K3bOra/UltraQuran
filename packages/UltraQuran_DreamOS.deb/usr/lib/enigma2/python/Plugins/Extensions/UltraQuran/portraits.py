# -*- coding: utf-8 -*-
"""Multi-source Verified Real Reciter Portrait Engine (Ultra Quran 1.0.1).

Downloads and permanently caches verified real photographs of all 260 Quran reciters
and Sheikh Muhammad Metwalli Al-Sha'rawi onto the receiver's Hard Drive
(<storage_root>/portraits_v3) and plugin folder (<ROOT>/portraits_v3) so they persist
permanently and are never re-downloaded on subsequent plugin launches:
  1. Bundled offline sources in <ROOT>/portraits_src/<id>.jpg
  2. Verified direct URLs (Wikimedia Commons, Way2Quran, TVQuran, named Assabile slugs)
  3. TVQuran author portraits with comprehensive Arabic name & spelling variants
  4. Arabic & English Wikipedia exact PageImages API with strict person/title validation
"""
import io
import json
import os
import re
import shutil
import ssl
import subprocess
import tempfile
import threading
import time

try:
    from urllib.parse import quote, unquote
    from urllib.request import Request, urlopen
except ImportError:
    from urllib import quote, unquote
    from urllib2 import Request, urlopen

try:
    from PIL import Image, ImageDraw, ImageOps
except ImportError:
    Image = None

from . import layout, premium
from .support import ROOT, data_json, log, log_exception, storage_root

CACHE_SUBDIR = "portraits_v3"
OLD_SUBDIR = "portraits_v2"
BUNDLED_SUBDIR = "portraits_src"
LEGACY_SUBDIR = "portraits"

FALLBACK_CACHE_DIRS = (
    "/etc/enigma2/ultra-quran-cache/" + CACHE_SUBDIR,
    "/tmp/ultra-quran-cache/" + CACHE_SUBDIR,
)
USER_AGENT = "Mozilla/5.0 (X11; Linux armv7l) AppleWebKit/537.36 (KHTML, like Gecko) UltraQuran/1.0.1"

BAD_IMAGE_KEYWORDS = (
    "statue", "monument", "mosque", "masjid", "map", "flag", "logo",
    "symbol", "coat", "arms", "emblem", ".svg", "book", "mushaf",
    "calligraphy", "khat", "tomb", "grave", "shrine", "minaret",
    "donate", "commons-logo", "wikidata", "question_book", "replace_this"
)


def _purge_legacy_cache():
    """Remove v1 portrait cache folders so any old mismatched images are wiped once."""
    legacy_paths = (
        os.path.join(storage_root(), LEGACY_SUBDIR),
        os.path.join(ROOT, LEGACY_SUBDIR),
        "/etc/enigma2/ultra-quran-cache/" + LEGACY_SUBDIR,
        "/tmp/ultra-quran-cache/" + LEGACY_SUBDIR,
        # 0.2.0 cards (old flat style) are replaced by the 0.3.0+ cinematic cards
        os.path.join(storage_root(), OLD_SUBDIR),
        os.path.join(ROOT, OLD_SUBDIR),
        "/etc/enigma2/ultra-quran-cache/" + OLD_SUBDIR,
        "/tmp/ultra-quran-cache/" + OLD_SUBDIR,
    )
    for path in legacy_paths:
        if os.path.isdir(path):
            try:
                shutil.rmtree(path, ignore_errors=True)
            except Exception:
                pass


WIDTH_FILE = "/etc/enigma2/ultra-quran-width.txt"
_cleaned = []


def on_hard_drive(path):
    """True for a cache on the hard drive / USB stick (never the receiver's small flash memory)."""
    return path.startswith("/media/") or path.startswith("/data/")


def _drop_flash_copies():
    """Older versions wrote every sheikh card twice: on the hard drive AND inside the plugin folder on flash
    (~0.7 MB per sheikh, ~200 MB in all). With a hard drive present the flash copy is removed once."""
    if _cleaned:
        return
    _cleaned.append(1)
    import shutil
    target = os.path.join(ROOT, CACHE_SUBDIR)

    def work():
        try:
            shutil.rmtree(target)
        except Exception:
            pass
    if os.path.isdir(target):
        thread = threading.Thread(target=work)
        thread.daemon = True
        thread.start()


def saved_width():
    """Screen width the plugin last opened with (1920 when unknown)."""
    for path in (WIDTH_FILE, "/sys/class/graphics/fb0/virtual_size"):
        try:
            with open(path) as handle:
                value = int(handle.read().strip().split(",")[0])
            if value in (720, 1280, 1920, 2560, 3840):
                return value
        except Exception:
            continue
    return 1920


def remember_width(width):
    try:
        if saved_width() != width or not os.path.isfile(WIDTH_FILE):
            with open(WIDTH_FILE, "w") as handle:
                handle.write("%d\n" % width)
    except Exception:
        pass


def get_cache_dirs():
    """Persistent portrait cache directory: the hard drive when there is one, otherwise the plugin folder.
    Cards are written to ONE place only (the first directory)."""
    primary = os.path.join(storage_root(), CACHE_SUBDIR)
    if on_hard_drive(primary):
        _drop_flash_copies()
        candidates = (primary,) + FALLBACK_CACHE_DIRS
    else:
        candidates = (primary, os.path.join(ROOT, CACHE_SUBDIR)) + FALLBACK_CACHE_DIRS
    writable = []
    for path in candidates:
        try:
            if not os.path.isdir(path):
                os.makedirs(path)
            if os.access(path, os.W_OK) and path not in writable:
                writable.append(path)
        except OSError:
            continue
    return writable or [FALLBACK_CACHE_DIRS[-1]]


def get_cache_dir():
    return get_cache_dirs()[0]


def _ssl_contexts():
    contexts = []
    cafile = os.path.join(ROOT, "certs", "cacert.pem")
    if hasattr(ssl, "create_default_context"):
        try:
            if os.path.isfile(cafile):
                contexts.append(ssl.create_default_context(cafile=cafile))
            else:
                contexts.append(ssl.create_default_context())
        except Exception:
            pass
    if hasattr(ssl, "_create_unverified_context"):
        try:
            contexts.append(ssl._create_unverified_context())
        except Exception:
            pass
    return contexts or [None]


def http_get(url, timeout=5):
    headers = {
        "User-Agent": USER_AGENT,
        "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
    }
    for ctx in _ssl_contexts():
        try:
            req = Request(url, headers=headers)
            kwargs = {"timeout": timeout}
            if ctx is not None:
                kwargs["context"] = ctx
            resp = urlopen(req, **kwargs)
            try:
                data = resp.read(2 * 1024 * 1024)
            finally:
                resp.close()
            if data and len(data) > 450:
                return data
        except Exception:
            continue
    return None


def _utf8_quote(value):
    try:
        raw = value.encode("utf-8") if not isinstance(value, str) else value
    except Exception:
        raw = str(value)
    return quote(raw)


def _is_valid_portrait_url(url):
    if not url or not url.startswith("http"):
        return False
    lower = unquote(url).lower()
    for bad in BAD_IMAGE_KEYWORDS:
        if bad in lower:
            return False
    return True


def _normalize_arabic(text):
    if not text:
        return u""
    out = text
    for src, dst in (
        (u"أ", u"ا"), (u"إ", u"ا"), (u"آ", u"ا"),
        (u"ة", u"ه"), (u"ى", u"ي"), (u"ی", u"ي"), (u"ؤ", u"و"),
        (u"عبدالله", u"عبد الله"), (u"عبدالرحمن", u"عبد الرحمن"),
        (u"عبدالعزيز", u"عبد العزيز"), (u"عبدالمحسن", u"عبد المحسن"),
        (u"عبدالبارئ", u"عبد البارئ"), (u"عبدالرشيد", u"عبد الرشيد"),
        (u"عبدالباسط", u"عبد الباسط"), (u"عبدالصمد", u"عبد الصمد"),
        (u"عبدالودود", u"عبد الودود"), (u"عبدالولي", u"عبد الولي"),
        (u"عبدالهادي", u"عبد الهادي"), (u"عبدالكريم", u"عبد الكريم"),
        (u"عبدالفتاح", u"عبد الفتاح"), (u"عبدالعظيم", u"عبد العظيم"),
    ):
        out = out.replace(src, dst)
    return out.strip()


def _title_matches_reciter(page_title, reciter_name):
    if not page_title or not reciter_name:
        return True
    norm_page = _normalize_arabic(page_title)
    norm_name = _normalize_arabic(reciter_name)
    tokens = [t for t in norm_name.split() if len(t) > 2 and t not in (u"شيخ", u"الشيخ", u"القارئ", u"بن")]
    if not tokens:
        return True
    if tokens[0] not in norm_page or tokens[-1] not in norm_page:
        return False
    return True


def wiki_pageimage_url(title, lang="ar", reciter_name=None):
    if not title:
        return None
    api = (
        "https://%s.wikipedia.org/w/api.php?action=query&prop=pageimages"
        "&format=json&pithumbsize=500&redirects=1&titles=%s" % (lang, _utf8_quote(title))
    )
    raw = http_get(api, timeout=4)
    if not raw:
        return None
    try:
        payload = json.loads(raw.decode("utf-8", "replace"))
        pages = payload.get("query", {}).get("pages", {})
        for page in pages.values():
            page_title = page.get("title", u"")
            if lang == "ar" and reciter_name and not _title_matches_reciter(page_title, reciter_name):
                continue
            thumb = page.get("thumbnail", {}).get("source")
            if _is_valid_portrait_url(thumb):
                return thumb
    except Exception:
        pass
    return None


def wiki_search_image(name, lang="ar"):
    """Last resort: full-text search on Wikipedia, then take the page image of a page whose title matches."""
    if not name:
        return None
    api = (
        "https://%s.wikipedia.org/w/api.php?action=query&generator=search&gsrlimit=4"
        "&prop=pageimages&piprop=thumbnail&pithumbsize=500&format=json&gsrsearch=%s" % (lang, _utf8_quote(name))
    )
    raw = http_get(api, timeout=5)
    if not raw:
        return None
    try:
        pages = json.loads(raw.decode("utf-8", "replace")).get("query", {}).get("pages", {})
        for page in sorted(pages.values(), key=lambda p: p.get("index", 99)):
            if not _title_matches_reciter(page.get("title", u""), name):
                continue
            thumb = page.get("thumbnail", {}).get("source")
            if _is_valid_portrait_url(thumb):
                return thumb
    except Exception:
        pass
    return None


def commons_search_image(name):
    """Wikimedia Commons file search; the file title must contain the first and last name."""
    if not name:
        return None
    api = (
        "https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrnamespace=6&gsrlimit=6"
        "&prop=imageinfo&iiprop=url&iiurlwidth=500&format=json&gsrsearch=%s" % _utf8_quote(name)
    )
    raw = http_get(api, timeout=5)
    if not raw:
        return None
    try:
        pages = json.loads(raw.decode("utf-8", "replace")).get("query", {}).get("pages", {})
        for page in sorted(pages.values(), key=lambda p: p.get("index", 99)):
            title = page.get("title", u"")
            if not _title_matches_reciter(title, name) or title.lower().endswith((".svg", ".pdf", ".ogg", ".webm")):
                continue
            info = (page.get("imageinfo") or [{}])[0]
            thumb = info.get("thumburl") or info.get("url")
            if _is_valid_portrait_url(thumb):
                return thumb
    except Exception:
        pass
    return None


def tvquran_name_variants(name, wiki_ar=None):
    seeds = []
    for s in (name, wiki_ar):
        if s and s.strip() and s.strip() not in seeds:
            seeds.append(s.strip())
    if not seeds:
        return []

    variants = []

    def add(v):
        v = re.sub(r"\s+", " ", (v or u"").strip())
        if v and v not in variants:
            variants.append(v)

    for seed in seeds:
        add(seed)
        stripped = re.sub(u"^(?:الشيخ|شيخ|القارئ|د\\.|أستاذ)\\s+", u"", seed, flags=re.UNICODE).strip()
        add(stripped)
        words = stripped.split()
        if len(words) >= 3:
            if words[0] == u"عبد" and len(words) >= 4:
                add(words[0] + u" " + words[1] + u" " + words[-1])
                add(words[0] + words[1] + u" " + words[-1])
            else:
                add(words[0] + u" " + words[-1])

    for base_v in list(variants):
        spaced = (
            base_v.replace(u"عبدالله", u"عبد الله")
            .replace(u"عبدالرحمن", u"عبد الرحمن")
            .replace(u"عبدالعزيز", u"عبد العزيز")
            .replace(u"عبدالمحسن", u"عبد المحسن")
            .replace(u"عبدالبارئ", u"عبد البارئ")
            .replace(u"عبدالرشيد", u"عبد الرشيد")
            .replace(u"عبدالباسط", u"عبد الباسط")
            .replace(u"عبدالصمد", u"عبد الصمد")
            .replace(u"عبدالودود", u"عبد الودود")
            .replace(u"عبدالولي", u"عبد الولي")
            .replace(u"عبدالكريم", u"عبد الكريم")
            .replace(u"عبدالفتاح", u"عبد الفتاح")
            .replace(u"عبدالعظيم", u"عبد العظيم")
        )
        add(spaced)
        joined = (
            base_v.replace(u"عبد الله", u"عبدالله")
            .replace(u"عبد الرحمن", u"عبدالرحمن")
            .replace(u"عبد العزيز", u"عبدالعزيز")
            .replace(u"عبد المحسن", u"عبدالمحسن")
            .replace(u"عبد الرشيد", u"عبدالرشيد")
            .replace(u"عبد الفتاح", u"عبدالفتاح")
            .replace(u"عبد العظيم", u"عبدالعظيم")
        )
        add(joined)

        for v in (base_v, spaced, joined):
            add(v.replace(u"أ", u"ا").replace(u"إ", u"ا"))
            if v.endswith(u"ه"):
                add(v[:-1] + u"ة")
            elif v.endswith(u"ة"):
                add(v[:-1] + u"ه")

    return variants


def decode_image(data):
    if Image is None or not data:
        return None
    try:
        im = Image.open(io.BytesIO(data))
        im.load()
        if im.width < 56 or im.height < 56:
            return None
        return im.convert("RGB")
    except Exception:
        for ffmpeg in ("/usr/bin/ffmpeg", "ffmpeg"):
            try:
                proc = subprocess.Popen(
                    [ffmpeg, "-hide_banner", "-loglevel", "error", "-i", "pipe:0", "-f", "image2pipe", "-vcodec", "png", "pipe:1"],
                    stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE
                )
                out, _ = proc.communicate(data)
                if proc.returncode == 0 and out:
                    im = Image.open(io.BytesIO(out))
                    im.load()
                    if im.width >= 56 and im.height >= 56:
                        return im.convert("RGB")
            except Exception:
                continue
    return None


def _supersampled_rounded_mask(w, h, radius, ss=8):
    return premium.rounded_mask(w, h, radius, ss=min(ss, 4))


def _dirs(cache_dirs):
    if isinstance(cache_dirs, (str, bytes)) or not isinstance(cache_dirs, (list, tuple)):
        return [cache_dirs]
    return list(cache_dirs)[:1]


def _save_scaled(image, base_size, widths, cache_dirs, pattern):
    """Save `image` (drawn on the 1080p master grid) for every target width and cache dir."""
    saved = False
    for cdir in _dirs(cache_dirs):
        for w in widths:
            target = layout.scaled((0, 0, base_size[0], base_size[1]), w)[2:]
            out = image.resize(target, premium._lanczos()) if image.size != target else image
            _atomic_save_png(out, os.path.join(cdir, pattern % w))
            saved = True
    return saved


def _save_source(reciter_id, rgb, cache_dirs):
    """Keep a small JPEG of the downloaded photo if not already shipped in portraits_src."""
    if bundled_source(reciter_id):
        return
    try:
        small = rgb.copy()
        small.thumbnail((640, 640))
        bundled_dir = os.path.join(ROOT, BUNDLED_SUBDIR)
        first = _dirs(cache_dirs)[0] if cache_dirs else ""
        if not on_hard_drive(first) and os.path.isdir(bundled_dir) and os.access(bundled_dir, os.W_OK):
            try:
                small.save(os.path.join(bundled_dir, "%d.jpg" % reciter_id), format="JPEG", quality=88, optimize=True)
            except Exception:
                pass
        for cdir in _dirs(cache_dirs):
            path = os.path.join(cdir, "src-%d.jpg" % reciter_id)
            if not os.path.isdir(cdir):
                os.makedirs(cdir)
            small.save(path, format="JPEG", quality=86, optimize=True)
            break
    except Exception:
        pass


def render_portrait_files(reciter_id, source_rgb, cache_dirs, widths=None):
    """Real photo -> calm poster card + studio portrait (the source is kept so a redesign never re-downloads)."""
    if Image is None or source_rgb is None:
        return False
    try:
        target_widths = widths or [2560, 1920]
        accent = premium.accent_from_image(source_rgb)
        card = premium.compose_card(source_rgb, accent)
        player = premium.compose_player(source_rgb, accent)
        ok = _save_scaled(card, card.size, target_widths, cache_dirs, "grid-%d-" % reciter_id + "%d.png")
        ok = _save_scaled(player, player.size, target_widths, cache_dirs, "portrait-%d-" % reciter_id + "%d.png") and ok
        _save_source(reciter_id, source_rgb, cache_dirs)
        return ok
    except Exception:
        log_exception("Failed rendering portrait for reciter %s" % reciter_id)
        return False


def render_fallback_files(reciter_id, name, cache_dirs, widths):
    """Designed placeholder poster (never an empty box) until the real photo is available."""
    if Image is None:
        return False
    try:
        card = premium.fallback_card(reciter_id, name)
        player = premium.fallback_player(reciter_id, name)
        ok = _save_scaled(card, card.size, widths, cache_dirs, "fbgrid-%d-" % reciter_id + "%d.png")
        ok = _save_scaled(player, player.size, widths, cache_dirs, "fbportrait-%d-" % reciter_id + "%d.png") and ok
        return ok
    except Exception:
        log_exception("Failed rendering fallback poster for reciter %s" % reciter_id)
        return False


def bundled_source(reciter_id):
    path = os.path.join(ROOT, BUNDLED_SUBDIR, "%d.jpg" % reciter_id)
    return path if os.path.isfile(path) else None


def _atomic_save_png(image, target_path):
    directory = os.path.dirname(target_path)
    if not os.path.isdir(directory):
        os.makedirs(directory)
    fd, tmp_path = tempfile.mkstemp(prefix=".portrait-", suffix=".png", dir=directory)
    os.close(fd)
    try:
        # Lossless PNG compression (compress_level=6) saves disk space while preserving 100% of RGBA pixels
        image.save(tmp_path, format="PNG", compress_level=3)
        os.chmod(tmp_path, 0o644)
        os.rename(tmp_path, target_path)
    finally:
        if os.path.exists(tmp_path):
            try:
                os.unlink(tmp_path)
            except OSError:
                pass


DESIGN_MARKER = ".design-0.5.2"


def _migrate_design(cache_dirs):
    """0.5.2 redesign: drop stale cards and re-render bundled photos once."""
    for cdir in cache_dirs:
        marker = os.path.join(cdir, DESIGN_MARKER)
        if os.path.isfile(marker):
            continue
        try:
            names = os.listdir(cdir)
        except OSError:
            continue
        for name in names:
            stale = name.startswith(("fbgrid-", "fbportrait-", "focus-", "ambient-", "grid-", "portrait-"))
            if stale:
                try:
                    os.unlink(os.path.join(cdir, name))
                except OSError:
                    pass
        try:
            with open(marker, "w") as handle:
                handle.write("1")
        except (IOError, OSError):
            pass


# Sheikhs whose bundled photo (portraits_src/<id>.jpg) was replaced: their old cards, studio portrait and
# saved source photo are deleted once from every cache, so the new photo is drawn instead of the old one.
REPLACED_PHOTOS = (106, 121, 118, 241, 267, 253)   # 0.9.3: Tablawi, Al-Banna, Al-Husary, Refaat, Abdullah Kamel, Islam Sobhi
PHOTOS_MARKER = ".photos-0.9.3-a"


def _refresh_replaced_photos(cache_dirs):
    for cdir in cache_dirs:
        marker = os.path.join(cdir, PHOTOS_MARKER)
        if os.path.isfile(marker):
            continue
        try:
            names = os.listdir(cdir)
        except OSError:
            continue
        for name in names:
            for rid in REPLACED_PHOTOS:
                if name == "src-%d.jpg" % rid or re.match(
                        r"^(?:grid|portrait|fbgrid|fbportrait|focus|ambient)-%d-\d+\.png$" % rid, name):
                    try:
                        os.unlink(os.path.join(cdir, name))
                    except OSError:
                        pass
        try:
            with open(marker, "w") as handle:
                handle.write("1")
        except (IOError, OSError):
            pass


class PortraitManager(object):
    """Asynchronous multi-source verified portrait resolver & permanent HDD/Plugin cache manager."""

    LOCKED_BUNDLED_IDS = set()

    def __init__(self, width=1920, on_ready=None):
        _purge_legacy_cache()
        self.width = width
        self.on_ready = on_ready
        self.cache_dirs = get_cache_dirs()
        _migrate_design(self.cache_dirs)
        _refresh_replaced_photos(self.cache_dirs)
        self.cache_dir = self.cache_dirs[0]
        self.meta = {}
        try:
            self.meta = data_json("portraits.json")
        except Exception:
            pass
        self._lock = threading.Lock()
        self._pending = set()
        self._failed = set()
        self._queue = []
        self._ready_ids = []
        self._workers = []
        self._card_cache = {}
        self._portrait_cache = {}
        self.names = {}
        self._local_queue = []
        self._local_seen = set()
        self._local_worker = None
        self._path_cache = {}

    def _find(self, pattern, reciter_id, per_width=True):
        """Locate a generated asset in any cache dir (cached per process)."""
        key = (pattern, reciter_id)
        hit = self._path_cache.get(key)
        if hit and os.path.isfile(hit):
            return hit
        for cdir in self.cache_dirs:
            if per_width:
                path = os.path.join(cdir, pattern % (reciter_id, self.width))
            else:
                path = os.path.join(cdir, pattern % reciter_id)
            if os.path.isfile(path) and os.path.getsize(path) > 200:
                self._path_cache[key] = path
                return path
        return None

    def saved_source(self, reciter_id):
        for cdir in self.cache_dirs:
            path = os.path.join(cdir, "src-%d.jpg" % reciter_id)
            if os.path.isfile(path) and os.path.getsize(path) > 1024:
                return path
        return None

    def fallback_card_path(self, reciter_id):
        """Sheikhs without a photo show the ORIGINAL default art shipped in art/ (no generated placeholder)."""
        return None

    def fallback_portrait_path(self, reciter_id):
        return None

    def display_name(self, reciter_id):
        return self.names.get(reciter_id) or self.meta.get(str(reciter_id), {}).get("name", u"")

    def cached_card_path(self, reciter_id):
        cached = self._card_cache.get(reciter_id)
        if cached and os.path.isfile(cached):
            return cached
        for cdir in self.cache_dirs:
            path = os.path.join(cdir, "grid-%d-%d.png" % (reciter_id, self.width))
            if os.path.isfile(path) and os.path.getsize(path) > 1024:
                self._card_cache[reciter_id] = path
                return path
        if Image is not None:
            for cdir in self.cache_dirs:
                for alt_w in (3840, 2560, 1920, 1280, 720):
                    if alt_w == self.width:
                        continue
                    alt_path = os.path.join(cdir, "grid-%d-%d.png" % (reciter_id, alt_w))
                    if os.path.isfile(alt_path) and os.path.getsize(alt_path) > 1024:
                        try:
                            im = Image.open(alt_path).convert("RGBA")
                            target_size = layout.scaled((0, 0, layout.POSTER_SIZE[0], layout.POSTER_SIZE[1]), self.width)[2:]
                            out = im.resize(target_size, premium._lanczos())
                            dest = os.path.join(self.cache_dir, "grid-%d-%d.png" % (reciter_id, self.width))
                            _atomic_save_png(out, dest)
                            self._card_cache[reciter_id] = dest
                            return dest
                        except Exception:
                            pass
        return None

    def cached_portrait_path(self, reciter_id):
        cached = self._portrait_cache.get(reciter_id)
        if cached and os.path.isfile(cached):
            return cached
        for cdir in self.cache_dirs:
            path = os.path.join(cdir, "portrait-%d-%d.png" % (reciter_id, self.width))
            if os.path.isfile(path) and os.path.getsize(path) > 1024:
                self._portrait_cache[reciter_id] = path
                return path
        if Image is not None:
            for cdir in self.cache_dirs:
                for alt_w in (3840, 2560, 1920, 1280, 720):
                    if alt_w == self.width:
                        continue
                    alt_path = os.path.join(cdir, "portrait-%d-%d.png" % (reciter_id, alt_w))
                    if os.path.isfile(alt_path) and os.path.getsize(alt_path) > 1024:
                        try:
                            im = Image.open(alt_path).convert("RGBA")
                            target_size = layout.scaled((0, 0, 200, 210), self.width)[2:]
                            out = im.resize(target_size, premium._lanczos())
                            dest = os.path.join(self.cache_dir, "portrait-%d-%d.png" % (reciter_id, self.width))
                            _atomic_save_png(out, dest)
                            self._portrait_cache[reciter_id] = dest
                            return dest
                        except Exception:
                            pass
        return None

    def pop_ready(self):
        with self._lock:
            ready = list(self._ready_ids)
            del self._ready_ids[:]
        return ready

    def request(self, reciter_ids, retry_failed=False, background=False):
        if Image is None:
            return 0
        if background:
            # Start-up warm-up: never touch the disk / PIL on the interface thread.
            worker = threading.Thread(target=self.request, args=(list(reciter_ids), retry_failed, False))
            worker.daemon = True
            worker.start()
            return 0
        self._queue_local(reciter_ids)
        added = 0
        with self._lock:
            if retry_failed:
                self._failed.clear()
            for rid in reciter_ids:
                if rid in self._pending or (rid in self._failed and not retry_failed):
                    continue
                if self.cached_card_path(rid) and self.cached_portrait_path(rid):
                    continue
                self._pending.add(rid)
                self._queue.append(rid)
                added += 1
            active_workers = [w for w in self._workers if w.is_alive()]
            self._workers = active_workers
            if added and len(self._workers) < 1:
                worker = threading.Thread(target=self._worker_loop)
                worker.daemon = True
                self._workers.append(worker)
                worker.start()
        return added

    def _queue_local(self, reciter_ids):
        """Fast offline work: bundled photos, designed placeholders, focus/ambient colour assets."""
        with self._lock:
            for rid in reciter_ids:
                if rid in self._local_seen:
                    continue
                self._local_seen.add(rid)
                self._local_queue.append(rid)
            if self._local_queue and (self._local_worker is None or not self._local_worker.is_alive()):
                worker = threading.Thread(target=self._local_loop)
                worker.daemon = True
                self._local_worker = worker
                worker.start()

    def _local_loop(self):
        while True:
            with self._lock:
                if not self._local_queue:
                    return
                rid = self._local_queue.pop(0)
            try:
                changed = self.ensure_local(rid)
            except Exception:
                log_exception("Local portrait work failed for %s" % rid)
                changed = False
            if changed and self.on_ready is not None:
                try:
                    with self._lock:
                        self._ready_ids.append(rid)
                    self.on_ready()
                except Exception:
                    pass
            time.sleep(0.3)  # keep the receiver responsive while posters are prepared

    def ensure_local(self, reciter_id):
        """Make sure this sheikh has a card (real > placeholder) and dynamic colour assets. Returns True if changed."""
        widths = [self.width]
        changed = False
        have_real = self.cached_card_path(reciter_id) and self.cached_portrait_path(reciter_id)
        if not have_real:
            src_path = bundled_source(reciter_id) or self.saved_source(reciter_id)
            if src_path:
                try:
                    with open(src_path, "rb") as handle:
                        rgb = decode_image(handle.read())
                except (IOError, OSError):
                    rgb = None
                if rgb is not None and render_portrait_files(reciter_id, rgb, self.cache_dirs, widths):
                    self._card_cache.pop(reciter_id, None)
                    self._portrait_cache.pop(reciter_id, None)
                    self._path_cache.clear()
                    return True
        return changed

    def request_all_catalog(self, reciters):
        extra = [999, 950] + list(range(951, 965))
        all_ids = extra + [entry[0] for entry in reciters if entry[0] not in extra]
        return self.request(all_ids, retry_failed=True)

    def local_pending(self):
        with self._lock:
            return len(self._local_queue)

    def _worker_loop(self):
        while True:
            with self._lock:
                if not self._queue:
                    return
                reciter_id = self._queue.pop(0)
            ok = self.fetch_and_cache(reciter_id)
            with self._lock:
                self._pending.discard(reciter_id)
                if ok:
                    self._ready_ids.append(reciter_id)
                else:
                    self._failed.add(reciter_id)
            if ok and self.on_ready is not None:
                try:
                    self.on_ready()
                except Exception:
                    pass
            time.sleep(0.08)

    def fetch_and_cache(self, reciter_id):
        if self.cached_card_path(reciter_id) and self.cached_portrait_path(reciter_id):
            return True
        if bundled_source(reciter_id):
            self.ensure_local(reciter_id)
            if self.cached_card_path(reciter_id):
                return True
        info = self.meta.get(str(reciter_id), {})
        candidates = list(info.get("urls", []))
        name = info.get("name", "")
        wiki_ar = info.get("wiki_ar") or name
        wiki_en = info.get("wiki_en")
        skip_tvquran = bool(info.get("skip_tvquran"))
        target_widths = [self.width]

        for url in candidates:
            if not _is_valid_portrait_url(url):
                continue
            rgb = decode_image(http_get(url))
            if rgb is not None:
                if render_portrait_files(reciter_id, rgb, self.cache_dirs, widths=target_widths):
                    return True

        if not skip_tvquran:
            for variant in tvquran_name_variants(name, wiki_ar):
                for host in ("https://tvquran.com", "https://www.tvquran.com"):
                    tvq_url = "%s/uploads/authors/images/%s.jpg" % (host, _utf8_quote(variant))
                    rgb = decode_image(http_get(tvq_url, timeout=4))
                    if rgb is not None:
                        if render_portrait_files(reciter_id, rgb, self.cache_dirs, widths=target_widths):
                            return True

        if wiki_en:
            thumb = wiki_pageimage_url(wiki_en, lang="en", reciter_name=name)
            if thumb:
                rgb = decode_image(http_get(thumb))
                if rgb is not None:
                    if render_portrait_files(reciter_id, rgb, self.cache_dirs, widths=target_widths):
                        return True

        for title in (wiki_ar, name, u"القارئ %s" % name if name else None, u"%s (قارئ)" % name if name else None):
            if not title:
                continue
            thumb = wiki_pageimage_url(title, lang="ar", reciter_name=name or wiki_ar)
            if thumb:
                rgb = decode_image(http_get(thumb))
                if rgb is not None:
                    if render_portrait_files(reciter_id, rgb, self.cache_dirs, widths=target_widths):
                        return True

        for finder in (lambda: wiki_search_image(name or wiki_ar), lambda: commons_search_image(name or wiki_ar),
                       lambda: wiki_search_image(u"%s قارئ" % (name or wiki_ar))):
            try:
                thumb = finder()
            except Exception:
                thumb = None
            if thumb:
                rgb = decode_image(http_get(thumb))
                if rgb is not None and render_portrait_files(reciter_id, rgb, self.cache_dirs, widths=target_widths):
                    return True

        return False


def warmup_cli(limit=None, budget_seconds=1500):
    """Background warm-up used by postinst: offline posters for ALL sheikhs first, then photo downloads."""
    try:
        if True:
            cat_payload = data_json("catalog.json")
            reciters = list(cat_payload.get("reciters", [])) + list(cat_payload.get("mubtahileen", []))
            if cat_payload.get("kishk"):
                reciters.append(cat_payload["kishk"])
    except Exception:
        return
    names = dict((entry[0], entry[1]) for entry in reciters)
    names[999] = u"الشيخ محمد متولي الشعراوي"
    ids = [999] + [entry[0] for entry in reciters]
    managers = []
    for width in (saved_width(),):          # only the size this receiver really shows
        mgr = PortraitManager(width=width)
        mgr.names = names
        managers.append(mgr)
    # pass 1: bundled real photos + designed placeholders + colour assets (offline, fast)
    for rid in ids:
        for mgr in managers:
            try:
                mgr.ensure_local(rid)
            except Exception:
                log_exception("warmup ensure_local %s" % rid)
    # pass 2: download the remaining photos (most famous & classic Egyptian reciters first)
    priority = [
        999, 950, 951, 952, 953, 954, 955, 956, 957, 958, 959, 960, 961, 962, 963, 964,
        51, 112, 118, 241, 125, 121, 106, 9,
        901, 902, 903, 904, 905, 906, 907, 908, 909, 910, 911, 912, 913, 914, 915, 916,
        74, 54, 31, 102, 123, 30
    ]
    order = priority + [rid for rid in ids if rid not in priority]
    if limit:
        order = order[:limit]
    started = time.time()
    base = managers[0]
    for rid in order:
        if time.time() - started > budget_seconds:
            break
        if base.cached_card_path(rid) and base.cached_portrait_path(rid):
            continue
        if base.fetch_and_cache(rid):
            for mgr in managers[1:]:
                mgr.cached_card_path(rid)
                mgr.cached_portrait_path(rid)
        time.sleep(0.12)


if __name__ == "__main__":
    warmup_cli()
