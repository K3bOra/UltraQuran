# -*- coding: utf-8 -*-
"""Ultra Quran external audio engine (ffmpeg -> PCM -> sound card) with its OWN playback clock.

Why: Enigma's service engines (4097 / 5002 / 5001 / 8193) report their position and length in
engine-specific ways, buffer on their own and seek over HTTP unreliably - that is what made the
seconds counter and the progress bar jump or freeze on some receivers.  Here ffmpeg decodes the
file / stream to raw PCM, a small relay paces that PCM at exactly 1x real time into the sound card
writer (pcmplay.py / aplay) and the position IS the amount of audio fed to the card.  No engine
position is ever read, so the counter, the bar, pause and seek behave the same on every receiver.

The idea (ffmpeg -> paced PCM relay -> pcmplay.py, route discovery from /proc/asound, DVB pipe
probing) follows Ultra Audio by Ahmed L-HadarY (MIT) - see NOTICE-Ultra-Audio.txt.

Everything slow (tool probing, process start, route test) runs in a worker thread; the methods
called from the GUI thread never block.  Python 2.7 and 3.x compatible.
"""
from __future__ import division, print_function

import collections
import glob
import os
import re
import signal
import struct
import subprocess
import threading
import time

from .support import log

monotonic = getattr(time, "monotonic", time.time)

HERE = os.path.dirname(os.path.abspath(__file__))
PCMPLAY = os.path.join(HERE, "pcmplay.py")
ROUTE_FILE = "/etc/enigma2/ultra-quran-audio-route.txt"
ASOUND = "/proc/asound"

RATE = 48000
FRAME = 4                       # 16 bit stereo
BPS = RATE * FRAME              # bytes per second
CHUNK = BPS // 10               # 0.1 s written at a time
AHEAD = 0.6                     # the relay never feeds the card more than this far ahead of real time
LATENCY = 0.30                  # the card plays this much later than it was fed (display compensation)
QUEUE_SECONDS = 8               # decoded audio kept ready (ffmpeg is held back by the pipe beyond this)
PREBUFFER_LOCAL = 0.4
PREBUFFER_NET = 1.0          # decoded seconds before the clock starts (was 1.5: faster start)
PREBUFFER_TIMEOUT = 6.0
NODATA_LOCAL = 8.0
NODATA_NET = 28.0               # no decoded audio at all for this long while playing -> error
BUFFER_US = 500000


# --------------------------------------------------------------------------------- tiny helpers
def _which(name):
    for folder in os.environ.get("PATH", "").split(os.pathsep) + ["/usr/local/bin", "/usr/sbin", "/usr/bin", "/sbin", "/bin"]:
        if folder:
            path = os.path.join(folder, name)
            if os.path.isfile(path) and os.access(path, os.X_OK):
                return path
    return None


def _text(data):
    if isinstance(data, bytes):
        return data.decode("utf-8", "replace")
    return data


def _native(value):
    if str is bytes and not isinstance(value, bytes):
        return value.encode("utf-8")
    if str is not bytes and isinstance(value, bytes):
        return value.decode("utf-8", "replace")
    return value


def _popen(argv, stdin=None, stdout=None, stderr=None):
    """Own process session (killpg works) and no inherited descriptors."""
    argv = [_native(a) for a in argv]
    kwargs = {"stdin": stdin, "stdout": stdout, "stderr": stderr, "close_fds": True, "bufsize": 0}
    try:
        return subprocess.Popen(argv, start_new_session=True, **kwargs)
    except TypeError:
        kwargs["preexec_fn"] = os.setsid
        return subprocess.Popen(argv, **kwargs)


def _run(argv, timeout=8, data=None):
    """(returncode, stdout, stderr) - never raises, never waits longer than timeout (python 2 safe)."""
    box = {}
    try:
        proc = _popen(argv, stdin=subprocess.PIPE if data is not None else None,
                      stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except Exception as exc:
        return 127, u"", _text(str(exc))

    def work():
        try:
            box["out"] = proc.communicate(data)
        except Exception:
            box["out"] = (b"", b"")

    thread = threading.Thread(target=work)
    thread.daemon = True
    thread.start()
    thread.join(timeout)
    if thread.is_alive():
        _kill([proc])
        thread.join(1.0)
        return 124, u"", u"timeout"
    out, err = box.get("out", (b"", b""))
    return proc.returncode, _text(out or b""), _text(err or b"")


def _kill(procs):
    for proc in procs:
        if proc is None:
            continue
        try:
            os.killpg(proc.pid, signal.SIGTERM)
        except Exception:
            pass
        try:
            proc.terminate()
        except Exception:
            pass
    deadline = monotonic() + 0.3
    for proc in procs:
        if proc is None:
            continue
        while proc.poll() is None and monotonic() < deadline:
            time.sleep(0.02)
        if proc.poll() is None:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except Exception:
                pass
            try:
                proc.kill()
            except Exception:
                pass
    for proc in procs:
        if proc is None:
            continue
        for stream in (proc.stdin, proc.stdout, proc.stderr):
            try:
                if stream is not None:
                    stream.close()
            except Exception:
                pass
        try:
            proc.wait()
        except Exception:
            pass


def _write_all(fd, data):
    view = data
    while view:
        count = os.write(fd, view[:65536])
        if count <= 0:
            raise OSError("audio pipe closed")
        view = view[count:]


# --------------------------------------------------------------------------------- tool probing
_cache = {}
_lock = threading.Lock()
_dead_devices = set()


def reset_tools():
    with _lock:
        _cache.clear()
    _dead_devices.clear()


def quick_available():
    """Cheap test used by the GUI thread: could this engine possibly work here?"""
    if _cache.get("disabled") or user_disabled():
        return False
    if not os.path.isfile(PCMPLAY):
        return False
    return bool(_which("ffmpeg") or _which("gst-launch-1.0"))


def is_mp3(url):
    path = (url or "").split("?", 1)[0].split("#", 1)[0].lower()
    return path.endswith(".mp3")


def can_play(url):
    """GUI thread: use the own-clock engine for this link? (the GStreamer decoder handles mp3 only)."""
    if not quick_available():
        return False
    known = _cache.get("decoder", "?")
    if known == "ffmpeg":
        return True
    if known == "gst":
        return is_mp3(url)
    if known is None:
        return False
    return is_mp3(url) or bool(_which("ffmpeg"))


GST_ELEMENTS = ("fdsrc", "fdsink", "decodebin", "audioconvert", "audioresample")


def gst_decode_ok():
    """gst-launch-1.0 with the elements of: fdsrc ! decodebin ! audioconvert ! audioresample ! fdsink.
    GStreamer is on every Enigma2 image (the receiver's own 4097 player is built on it)."""
    if "gst_ok" not in _cache:
        ok = bool(_which("gst-launch-1.0"))
        if ok and _which("gst-inspect-1.0"):
            ok = all(gst_has(name) for name in GST_ELEMENTS)
        _cache["gst_ok"] = ok
    return _cache["gst_ok"]


def choose_decoder():
    """'ffmpeg' (full ffmpeg with PCM output), else 'gst' (GStreamer), else None."""
    if "decoder" not in _cache:
        decoder = None
        if ffmpeg_path():
            caps = ffmpeg_caps()
            if caps["pcm"] and caps["out"] is not None:
                decoder = "ffmpeg"
        if decoder is None and gst_decode_ok():
            decoder = "gst"
        _cache["decoder"] = decoder
        log(u"audio decoder: %s" % decoder)
    return _cache["decoder"]


# ------------------------------------------------------------------------------- mp3 byte source
_BITRATES = {
    (1, 3): (0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320),
    (2, 3): (0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160),
}
_RATES = {1: (44100, 48000, 32000), 2: (22050, 24000, 16000), 25: (11025, 12000, 8000)}


def mp3_info(head):
    """Header facts of an mp3 from its first bytes: audio start (after ID3v2), bitrate (kbit/s), and from a
    Xing / Info header (VBR) the exact frame count and the 100-step seek table."""
    info = {"start": 0, "bitrate": 0, "frames": 0, "toc": None, "rate": 0, "spf": 1152}
    pos = 0
    if head[:3] == b"ID3" and len(head) >= 10:
        size = 0
        for b in bytearray(head[6:10]):
            size = (size << 7) | (b & 0x7F)
        pos = 10 + size + (10 if bytearray(head[5:6])[0] & 0x10 else 0)
    info["start"] = pos
    data = bytearray(head)
    i = pos
    while i + 4 <= len(data):
        if data[i] == 0xFF and (data[i + 1] & 0xE0) == 0xE0:
            ver_bits = (data[i + 1] >> 3) & 3
            layer_bits = (data[i + 1] >> 1) & 3
            br_index = data[i + 2] >> 4
            sr_index = (data[i + 2] >> 2) & 3
            if ver_bits != 1 and layer_bits == 1 and 0 < br_index < 15 and sr_index < 3:
                version = 1 if ver_bits == 3 else (2 if ver_bits == 2 else 25)
                info["start"] = i
                info["bitrate"] = _BITRATES[(1 if version == 1 else 2, 3)][br_index]
                info["rate"] = _RATES[version][sr_index]
                info["spf"] = 1152 if version == 1 else 576
                mono = (data[i + 3] >> 6) == 3
                side = (17 if mono else 32) if version == 1 else (9 if mono else 17)
                x = i + 4 + side
                tag = bytes(data[x:x + 4])
                if tag in (b"Xing", b"Info") and x + 8 <= len(data):
                    flags = (data[x + 4] << 24) | (data[x + 5] << 16) | (data[x + 6] << 8) | data[x + 7]
                    y = x + 8
                    if flags & 1 and y + 4 <= len(data):
                        info["frames"] = (data[y] << 24) | (data[y + 1] << 16) | (data[y + 2] << 8) | data[y + 3]
                        y += 4
                    if flags & 2:
                        y += 4
                    if flags & 4 and y + 100 <= len(data):
                        info["toc"] = list(data[y:y + 100])
                break
            i += 1
            continue
        i += 1
    return info


def _contexts():
    try:
        import ssl
    except ImportError:
        return [None]
    out = [None]
    bundle = os.path.join(HERE, "certs", "cacert.pem")
    try:
        if os.path.isfile(bundle):
            out.append(ssl.create_default_context(cafile=bundle))
    except Exception:
        pass
    try:
        out.append(ssl._create_unverified_context())          # receivers with an outdated certificate store
    except Exception:
        pass
    return out


def http_open(url, start=0, end=None, timeout=15):
    """(response, status, total size or 0). Range request from `start`; follows redirects."""
    try:
        from urllib.request import Request, urlopen
    except ImportError:                                       # Python 2.7 (DreamOS)
        from urllib2 import Request, urlopen
    headers = {"User-Agent": "UltraQuran/1.0", "Accept": "*/*", "Icy-MetaData": "0"}
    target = _REDIRECTS.get(url)
    if target:
        try:
            return _http_open_once(target, start, end, timeout, headers)
        except Exception:
            _REDIRECTS.pop(url, None)
    resp, status, total = _http_open_once(url, start, end, timeout, headers)
    try:
        final = resp.geturl()
        if final and final != url:
            _REDIRECTS[url] = final
    except Exception:
        pass
    return resp, status, total


_REDIRECTS = {}


def _http_open_once(url, start, end, timeout, headers):
    try:
        from urllib.request import Request, urlopen
    except ImportError:                                       # Python 2.7 (DreamOS)
        from urllib2 import Request, urlopen
    headers = dict(headers)
    if start or end is not None:
        headers["Range"] = "bytes=%d-%s" % (start, "" if end is None else end)
    last = None
    for ctx in _contexts():
        try:
            req = Request(_native(url), headers=headers)
            resp = urlopen(req, timeout=timeout, **({"context": ctx} if ctx is not None else {}))
            status = getattr(resp, "status", None) or resp.getcode()
            total = 0
            crange = resp.info().get("Content-Range") or ""
            match = re.search(r"/(\d+)", crange)
            if match:
                total = int(match.group(1))
            elif status == 200:
                try:
                    total = int(resp.info().get("Content-Length") or 0)
                except ValueError:
                    total = 0
            return resp, status, total
        except Exception as exc:
            last = exc
            text = str(exc).lower()
            if not any(word in text for word in ("ssl", "certificate", "tls", "handshake")):
                break
    raise last if last is not None else IOError("no connection")


def note_failure(reason):
    """Two start failures in a row (no route / no working ffmpeg) switch the engine off for this session."""
    _cache["fails"] = _cache.get("fails", 0) + 1
    log(u"External audio engine start failed (%d): %s" % (_cache["fails"], reason))
    if _cache["fails"] >= 2:
        disable(reason)


def note_success():
    _cache["fails"] = 0


def user_disabled():
    """/etc/enigma2/ultra-quran-engine.txt containing 'enigma' keeps the old Enigma service engines only."""
    try:
        with open("/etc/enigma2/ultra-quran-engine.txt") as handle:
            return handle.read().strip().lower().startswith("enigma")
    except EnvironmentError:
        return False


def disable(reason):
    _cache["disabled"] = reason
    log(u"External audio engine disabled for this session: %s" % reason)


def ffmpeg_path():
    path = _cache.get("ffmpeg")
    if path is None:
        found = _which("ffmpeg")
        ok = False
        if found:
            code, out, err = _run([found, "-version"], timeout=8)
            ok = code == 0 and "ffmpeg version" in (out or err).lower()
        path = found if ok else u""
        _cache["ffmpeg"] = path
    return path or None


def ffmpeg_caps():
    """{'out': 's16le'|'wav'|None, 'pcm': bool, 'opts': set|None, 'protos': set|None}"""
    caps = _cache.get("caps")
    if caps is not None:
        return caps
    ff = ffmpeg_path()
    caps = {"out": None, "pcm": True, "opts": None, "protos": None}
    if ff:
        code, out, _ = _run([ff, "-hide_banner", "-formats"], timeout=10)
        formats = {}
        if code == 0:
            body = out.split("--", 1)[1] if "--" in out else out
            for line in body.splitlines():
                parts = line.split(None, 2)
                if len(parts) < 2 or not re.match(r"^[DEd.]+$", parts[0]):
                    continue
                for name in parts[1].split(","):
                    old = formats.get(name, (False, False))
                    formats[name] = (old[0] or "D" in parts[0], old[1] or "E" in parts[0])
        if formats.get("s16le", (0, 0))[1]:
            caps["out"] = "s16le"
        elif formats.get("wav", (0, 0))[1]:
            caps["out"] = "wav"
        elif not formats:
            caps["out"] = "s16le"          # could not ask: assume the usual
        code, out, _ = _run([ff, "-hide_banner", "-encoders"], timeout=10)
        if code == 0 and out and "pcm_s16le" not in out:
            caps["pcm"] = False
        code, out, _ = _run([ff, "-hide_banner", "-h", "full"], timeout=15)
        names = set(re.findall(r"(?m)^\s+-([A-Za-z0-9_]+)\b", out or u""))
        caps["opts"] = names if len(names) > 100 else None
        code, out, _ = _run([ff, "-hide_banner", "-protocols"], timeout=8)
        if code == 0 and "Input:" in out:
            body = out.split("Input:", 1)[1].split("Output:", 1)[0]
            caps["protos"] = set(x.strip() for x in body.split() if x.strip())
    _cache["caps"] = caps
    return caps


def python_bin():
    """An interpreter (python 2.7 or 3.x) that can run pcmplay.py, or None."""
    if "python" in _cache:
        return _cache["python"]
    import sys
    candidates = []
    exe = getattr(sys, "executable", "") or ""
    if os.path.basename(exe).startswith("python"):
        candidates.append(exe)
    names = ("python3", "python2", "python", "python2.7") + tuple("python3.%d" % i for i in range(20, 4, -1))
    for name in names:
        path = _which(name)
        if path and path not in candidates:
            candidates.append(path)
    found = None
    for py in candidates:
        code, _, _ = _run([py, "-E", "-s", PCMPLAY, "--check"], timeout=15)
        if code == 0:
            found = py
            break
    _cache["python"] = found
    return found


def playback_devices():
    found = set()
    for path in glob.glob(os.path.join(ASOUND, "card*", "pcm*p")):
        match = re.search(r"/card(\d+)/pcm(\d+)p$", path)
        if match:
            found.add(tuple(int(x) for x in match.groups()))
    try:
        with open(os.path.join(ASOUND, "pcm")) as handle:
            for line in handle:
                match = re.match(r"\s*(\d+)-(\d+):", line)
                if match and re.search(r"\bplayback\s+[1-9]\d*", line):
                    found.add(tuple(int(x) for x in match.groups()))
    except EnvironmentError:
        pass
    for path in glob.glob("/dev/snd/pcmC*D*p"):
        match = re.search(r"/pcmC(\d+)D(\d+)p$", path)
        if match:
            found.add(tuple(int(x) for x in match.groups()))
    return sorted(found)


def alsa_cards():
    cards = []
    for index in sorted(set(card for card, _ in playback_devices())):
        try:
            with open(os.path.join(ASOUND, "card%d" % index, "id")) as handle:
                ident = handle.read().strip()
        except EnvironmentError:
            ident = ""
        cards.append((index, re.sub(r"[^A-Za-z0-9_.\-]", "", ident)))
    return cards


def gst_has(name):
    key = "gst_" + name
    if key not in _cache:
        inspect = _which("gst-inspect-1.0")
        _cache[key] = bool(inspect) and _run([inspect, name], timeout=10)[0] == 0
    return _cache[key]


def dvb_sink_ok():
    if not _which("gst-launch-1.0"):
        return False
    return gst_has("dvbaudiosink") or os.path.exists("/dev/dvb/adapter0/audio0")


def _probe_ff_dvb(codec, muxer):
    key = "ffdvb_%s_%s" % (codec, muxer)
    if key in _cache:
        return _cache[key]
    ff = ffmpeg_path()
    ok = False
    if ff:
        cmd = [ff, "-hide_banner", "-loglevel", "error", "-nostdin", "-f", "s16le", "-ar", "48000", "-ac", "2",
               "-i", "pipe:0", "-vn", "-c:a", codec, "-b:a", "128k", "-f", muxer, "pipe:1"]
        code, out, _ = _run(cmd, timeout=6, data=b"\x00" * 19200)
        ok = code == 0
    _cache[key] = ok
    return ok


def dvb_pipe_kind(dev="dvb"):
    """How pcmplay.py must compress PCM for the DVB audio sink ('unavailable' when nothing works)."""
    key = "dvbkind_pes" if dev == "dvb-pes" else "dvbkind_gst"
    if key in _cache:
        return _cache[key]
    if dev != "dvb-pes":
        raw_sub = "raw" if gst_has("rawaudioparse") else "wav" if gst_has("wavparse") else "caps"
        for kind, enc, parse in (("gst-mp2", "avenc_mp2", "mpegaudioparse"), ("gst-twolame", "twolamemp2enc", "mpegaudioparse"),
                                 ("gst-mp3", "lamemp3enc", "mpegaudioparse"), ("gst-aac", "avenc_aac", "aacparse"),
                                 ("gst-faac", "faac", "aacparse"), ("gst-voaac", "voaacenc", "aacparse"),
                                 ("gst-fdkaac", "fdkaacenc", "aacparse"), ("gst-ac3", "avenc_ac3", "ac3parse")):
            if gst_has(enc) and gst_has(parse):
                _cache[key] = "%s:%s" % (kind, raw_sub)
                return _cache[key]
    for kind, codec, muxer in (("mp2", "mp2", "mp2"), ("mp2-mp3", "mp2", "mp3"), ("aac", "aac", "adts"),
                               ("mpegts-mp2", "mp2", "mpegts"), ("mpegts-aac", "aac", "mpegts"), ("ac3", "ac3", "ac3")):
        if _probe_ff_dvb(codec, muxer):
            _cache[key] = kind
            return kind
    _cache[key] = "unavailable"
    return "unavailable"


FORCE_ROUTES = None             # tests only
_oss_probed = []


def ensure_oss_module():
    """No ALSA card and no /dev/dsp (some Dreamboxes): load snd-pcm-oss once, as Ultra Audio does."""
    if _oss_probed or os.path.exists("/dev/dsp") or alsa_cards():
        return
    _oss_probed.append(1)
    modprobe = _which("modprobe")
    if modprobe:
        try:
            _run([modprobe, "snd-pcm-oss"], timeout=4)
        except Exception:
            pass


def candidate_routes():
    """[(kind, device)] best first; kind is 'pcm' (pcmplay.py) or 'aplay'."""
    if FORCE_ROUTES is not None:
        return list(FORCE_ROUTES)
    py = python_bin()
    aplay = _which("aplay")
    devices = []
    ensure_oss_module()
    cards = alsa_cards()
    for card, dev in playback_devices():
        devices.append("plughw:%d,%d" % (card, dev))
    for _, ident in cards:
        if ident:
            devices.append("sysdefault:CARD=%s" % ident)
    if cards or os.path.exists("/dev/dsp"):
        devices.append("default")
    dvb = ["dvb", "dvb-pes", "dvb-raw"] if (dvb_sink_ok() and py) else []
    devices = (devices + dvb) if (cards or os.path.exists("/dev/dsp")) else (dvb + ["default"])
    routes = []
    for dev in devices:
        if dev in _dead_devices:
            continue
        if dev.startswith("dvb"):
            if py:
                routes.append(("pcm", dev))
        else:
            if py:
                routes.append(("pcm", dev))
            if aplay:
                routes.append(("aplay", dev))
    saved = load_route()
    if saved in routes:
        routes.remove(saved)
        routes.insert(0, saved)
    return routes


def load_route():
    try:
        with open(ROUTE_FILE) as handle:
            kind, dev = handle.read().strip().split("|", 1)
        return (kind, dev)
    except Exception:
        return None


def save_route(route):
    try:
        with open(ROUTE_FILE, "w") as handle:
            handle.write("%s|%s\n" % route)
    except EnvironmentError:
        pass


def forget_route():
    try:
        os.remove(ROUTE_FILE)
    except EnvironmentError:
        pass


def writer_argv(kind, dev):
    if kind == "pcm":
        cmd = [python_bin(), "-E", "-s", PCMPLAY, "-D", dev, "-r", str(RATE), "-c", "2",
               "--buffer-time=%d" % BUFFER_US]
        if dev.startswith("dvb"):
            cmd.append("--dvb-pipe=%s" % dvb_pipe_kind(dev))
        cmd.append("--start-ms=180")
        return cmd
    return [_which("aplay"), "-q", "-t", "raw", "-f", "S16_LE", "-r", str(RATE), "-c", "2", "-D", dev,
            "--buffer-time=%d" % BUFFER_US, "-"]


# ------------------------------------------------------------------------------------- the engine
class _Segment(object):
    """One ffmpeg process decoding from `offset`."""

    def __init__(self, offset):
        self.offset = offset
        self.proc = None
        self.chunks = collections.deque()
        self.qbytes = 0
        self.done = False
        self.rc = None
        self.tail = []
        self.cond = threading.Lock()
        self.got_data = 0
        self.killed = False
        self.duration = 0.0
        self.fmt = "s16le"
        self.feed_error = u""


class PipeEngine(object):
    """status: idle -> starting -> playing -> ended | error.  Thread-safe for the GUI thread."""

    def __init__(self):
        self.lock = threading.RLock()
        self.gen = 0
        self.status = "idle"
        self.error = u""
        self.route = None
        self.duration = 0.0
        self.url = u""
        self.local = False
        self.base = 0.0              # media position (s) of the first sample of the current segment
        self.fed = 0.0               # seconds of PCM fed to the card since `base`
        self.t0 = None               # monotonic start of the playback clock
        self.paused = False
        self.pause_at = 0.0
        self.pause_total = 0.0
        self.starved = False
        self.wait_seek = None
        self.seg = None
        self.writer = None
        self.writer_err = []
        self.tls_level = 0
        self.ever_played = 0.0       # seconds actually played since start()
        self.last_data = 0.0
        self.no_route = False

    # ---------------------------------------------------------------- GUI-thread API (non blocking)
    def start(self, url, offset=0.0, local=False, duration=0.0):
        self.stop()
        with self.lock:
            self.gen += 1
            gen = self.gen
            self.url = url
            self.local = bool(local)
            self.duration = float(duration or 0)
            self.base = float(offset or 0)
            self.fed = 0.0
            self.t0 = None
            self.paused = False
            self.pause_total = 0.0
            self.starved = False
            self.error = u""
            self.no_route = False
            self.wait_seek = None
            self.status = "starting"
            self.ever_played = 0.0
            self.last_data = monotonic()
            self.tls_level = 0
        thread = threading.Thread(target=self._guard, args=(gen,))
        thread.daemon = True
        thread.start()

    def stop(self):
        with self.lock:
            self.gen += 1
            seg, writer = self.seg, self.writer
            self.seg = self.writer = None
            self.status = "idle"
            self.t0 = None
        procs = []
        if seg is not None:
            seg.killed = True
            procs.append(seg.proc)
        if writer is not None:
            procs.append(writer)
        if procs:
            _kill(procs)

    def pause(self):
        with self.lock:
            if self.status != "playing" or self.paused:
                return False
            self.paused = True
            self.pause_at = monotonic()
            return True

    def resume(self):
        with self.lock:
            if not self.paused:
                return False
            now = monotonic()
            if self.t0 is not None:
                self.t0 += now - self.pause_at
            self.paused = False
            return True

    def seek(self, seconds):
        with self.lock:
            if self.status not in ("starting", "playing"):
                return False
            seconds = max(0.0, float(seconds))
            self.ever_played += min(self._elapsed(monotonic()), self.fed)
            if self.duration > 0:
                seconds = min(seconds, max(0.0, self.duration - 1.0))
            self.wait_seek = seconds
            self.base = seconds
            self.fed = 0.0
            self.t0 = None
            self.starved = False
            self.last_data = monotonic()
            return True

    def _elapsed(self, now):
        if self.t0 is None:
            return 0.0
        if self.paused:
            return max(0.0, self.pause_at - self.t0)
        return max(0.0, now - self.t0)

    def position(self):
        """Media position in seconds as the listener hears it."""
        with self.lock:
            played = min(self._elapsed(monotonic()), self.fed)
            played = max(0.0, played - LATENCY) if self.t0 is not None else 0.0
            return self.base + played

    def played(self):
        with self.lock:
            return self.ever_played + min(self._elapsed(monotonic()), self.fed)

    def has_audio(self):
        """True once audible audio has been fed (the clock runs)."""
        with self.lock:
            return self.t0 is not None and self.fed > 0

    def is_starved(self):
        with self.lock:
            return self.status == "playing" and not self.paused and self.starved

    def describe(self):
        route = self.route
        return u"ffmpeg → %s %s" % (route[0], route[1]) if route else u"ffmpeg"

    # ---------------------------------------------------------------------------- worker thread
    def _guard(self, gen):
        try:
            self._run(gen)
        except Exception as exc:
            import traceback
            log(u"pipe engine crashed: %s" % traceback.format_exc())
            self._fail(gen, u"crash: %s" % exc)

    def _alive(self, gen):
        return self.gen == gen

    def _fail(self, gen, text):
        with self.lock:
            if self.gen != gen:
                return
            self.status = "error"
            self.error = text
        self._cleanup(gen)

    def _cleanup(self, gen):
        with self.lock:
            seg, writer = self.seg, self.writer
            if self.gen == gen:
                self.seg = self.writer = None
        procs = []
        if seg is not None:
            seg.killed = True
            procs.append(seg.proc)
        if writer is not None:
            procs.append(writer)
        if procs:
            _kill(procs)

    # ---- sound card writer
    def _open_writer(self, gen):
        self.decoder = choose_decoder()
        if self.decoder is None:
            return None, u"لا يوجد ffmpeg كامل ولا GStreamer"
        if self.decoder == "gst" and not is_mp3(self.url):
            return None, u"GStreamer: ملفات mp3 فقط"
        if python_bin() is None and not _which("aplay"):
            return None, u"لا توجد أداة تشغيل صوت"
        last = u""
        for route in candidate_routes():
            if not self._alive(gen):
                return None, u""
            writer, err = self._try_writer(route)
            if writer is not None:
                self.route = route
                save_route(route)
                log(u"audio route: %s %s" % route)
                return writer, u""
            last = err or last
        forget_route()
        return None, last or u"لا يوجد مخرج صوت"

    def _try_writer(self, route):
        kind, dev = route
        if dev.startswith("dvb") and dvb_pipe_kind(dev) == "unavailable":
            return None, u"DVB غير متاح"
        try:
            argv = writer_argv(kind, dev)
            proc = _popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        except Exception as exc:
            return None, u"%s" % exc
        tail = []

        def drain():
            try:
                for raw in iter(proc.stderr.readline, b""):
                    line = _text(raw).rstrip()
                    if line and "xrun" not in line.lower() and "stats" not in line:
                        tail.append(line)
                        del tail[:-12]
            except Exception:
                pass

        thread = threading.Thread(target=drain)
        thread.daemon = True
        thread.start()
        # a route that already worked on this receiver only needs a short look; a new one gets the full probe
        known = load_route() == (kind, dev)
        deadline = monotonic() + (0.15 if known else (1.2 if dev.startswith("dvb") else 0.6))
        while monotonic() < deadline:
            if proc.poll() is not None:
                break
            time.sleep(0.05)
        ok = proc.poll() is None
        if ok:
            try:
                _write_all(proc.stdin.fileno(), b"\x00" * (BPS // 20))
                time.sleep(0.1)
                ok = proc.poll() is None
            except Exception:
                ok = False
        if not ok:
            log(u"audio route failed %s %s: %s" % (kind, dev, u" | ".join(tail[-3:])))
            _kill([proc])
            return None, (tail[-1] if tail else u"")
        self.writer_err = tail
        return proc, u""

    # ---- ffmpeg segment
    def _input_args(self, local):
        known = ffmpeg_caps()["opts"]
        small = is_mp3(self.url)          # an mp3 needs only a few frames to be recognised
        pairs = [("fflags", "+genpts+discardcorrupt"), ("probesize", "65536" if small else "262144"),
                 ("analyzeduration", "200000" if small else "500000")]
        if not local:
            pairs += [("user_agent", "UltraQuran/1.0"), ("reconnect", "1"), ("reconnect_streamed", "1"), ("reconnect_delay_max", "4"),
                      ("rw_timeout", "12000000")]
        args = []
        for name, value in pairs:
            if name in ("user_agent", "reconnect", "reconnect_streamed", "reconnect_delay_max", "rw_timeout") and known is not None \
                    and name not in known:
                continue
            args += ["-" + name, value]
        if self.tls_level == 1:
            bundle = os.path.join(HERE, "certs", "cacert.pem")
            if os.path.isfile(bundle) and (known is None or "ca_file" in known):
                args += ["-ca_file", bundle]
        elif self.tls_level >= 2 and (known is None or "tls_verify" in known):
            args += ["-tls_verify", "0"]
        return args

    def _start_segment(self, offset):
        if getattr(self, "decoder", "ffmpeg") == "gst":
            return self._start_gst_segment(offset)
        caps = ffmpeg_caps()
        fmt = caps["out"] or "s16le"
        cmd = [ffmpeg_path(), "-hide_banner", "-loglevel", "info", "-nostats", "-nostdin"]
        cmd += self._input_args(self.local)
        if offset > 0.05:
            cmd += ["-ss", "%.3f" % offset]
        cmd += ["-i", self.url.split("#", 1)[0], "-map", "0:a:0", "-vn", "-sn", "-dn",
                "-af", "aformat=channel_layouts=stereo,aresample=%d,aformat=sample_fmts=s16:channel_layouts=stereo" % RATE,
                "-ac", "2", "-ar", str(RATE), "-c:a", "pcm_s16le", "-f", fmt]
        if fmt == "wav":
            cmd += ["-bitexact"]
        cmd.append("pipe:1")
        seg = _Segment(offset)
        seg.fmt = fmt
        seg.proc = _popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            seg.proc.stdin.close()
        except Exception:
            pass
        for target in (self._read_err, self._read_pcm):
            thread = threading.Thread(target=target, args=(seg,))
            thread.daemon = True
            thread.start()
        return seg

    # ---- GStreamer decoder: the plugin reads the mp3 bytes itself (from the byte of the start time) and
    # pipes them into  fdsrc ! decodebin ! audioconvert ! audioresample ! S16LE 48 kHz stereo ! fdsink
    def _mp3_meta(self):
        meta = getattr(self, "_meta", None)
        if meta is not None and meta.get("url") == self.url:
            return meta
        meta = {"url": self.url, "total": 0}

        def read_at(start, count):
            """`count` bytes from `start` (small reads: a slow server must not delay the start)."""
            if self.local:
                with open(self.url, "rb") as handle:
                    handle.seek(start)
                    return handle.read(count), os.path.getsize(self.url)
            resp, status, total = http_open(self.url, start, start + count - 1)
            try:
                data = b""
                while len(data) < count:
                    piece = resp.read(count - len(data))
                    if not piece:
                        break
                    data += piece
                    if status == 200 and start == 0:
                        break                      # no Range support: never download the whole file here
            finally:
                resp.close()
            return data, total

        info = mp3_info(b"")
        try:
            head, meta["total"] = read_at(0, 16384)
            info = mp3_info(head)
            if info["start"] > len(head) - 512 or not info["bitrate"]:
                # a big ID3 tag (cover picture): read the first audio frame where the tag ends
                tag_end = info["start"] if info["start"] > 0 else len(head)
                more, total = read_at(tag_end, 8192)
                meta["total"] = meta["total"] or total
                info2 = mp3_info(more)
                if info2["bitrate"]:
                    info2["start"] += tag_end
                    info = info2
                else:
                    info["start"] = tag_end
        except Exception as exc:
            meta["error"] = u"%s" % exc
        meta.update(info)
        audio = max(0, meta["total"] - info["start"])
        duration = 0.0
        by_size = audio * 8.0 / (info["bitrate"] * 1000.0) if (info["bitrate"] and audio) else 0.0
        if info["frames"] and info["rate"]:
            duration = info["frames"] * info["spf"] / float(info["rate"])
            if by_size and duration < by_size * 0.6:
                # joined mp3 files keep the first part's Xing header: trust the size, not the header
                duration = by_size
                meta["toc"] = None
                info["toc"] = None
        elif by_size:
            duration = by_size
        meta["duration"] = duration
        if duration > 5:
            with self.lock:
                if self.duration <= 0 or abs(self.duration - duration) > 2:
                    self.duration = duration       # the real length of THIS file beats the catalogue estimate
        self._meta = meta
        return meta

    def _meta_quietly(self):
        try:
            self._mp3_meta()
        except Exception:
            pass

    def _byte_at(self, meta, seconds):
        if seconds <= 0.05:
            return 0
        start, total = meta.get("start", 0), meta.get("total", 0)
        audio = max(0, total - start)
        duration = meta.get("duration") or self.duration
        if meta.get("toc") and duration and audio:
            pct = max(0.0, min(99.999, seconds * 100.0 / duration))
            low = int(pct)
            a = meta["toc"][low]
            b = meta["toc"][low + 1] if low < 99 else 256
            frac = a + (b - a) * (pct - low)
            return int(start + frac / 256.0 * audio)
        if duration and audio:
            return int(start + min(1.0, seconds / duration) * audio)
        if meta.get("bitrate"):
            return int(start + seconds * meta["bitrate"] * 125)
        return -1

    def _start_gst_segment(self, offset):
        if offset <= 0.05:
            # from the beginning: no need to know the file first - start feeding at once, learn its length aside
            byte = 0
            worker = threading.Thread(target=self._meta_quietly)
            worker.daemon = True
            worker.start()
        else:
            meta = self._mp3_meta()
            byte = self._byte_at(meta, offset)
        seg = _Segment(offset)
        seg.fmt = "s16le"
        cmd = [_which("gst-launch-1.0"), "-q", "fdsrc", "fd=0", "!", "decodebin", "!", "audioconvert", "!",
               "audioresample", "!", "audio/x-raw,format=S16LE,rate=%d,channels=2,layout=interleaved" % RATE,
               "!", "fdsink", "fd=1", "sync=false"]
        seg.proc = _popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        for target in (self._read_err, self._read_pcm):
            thread = threading.Thread(target=target, args=(seg,))
            thread.daemon = True
            thread.start()
        thread = threading.Thread(target=self._feed, args=(seg, max(0, byte), byte < 0 and offset > 0.05))
        thread.daemon = True
        thread.start()
        return seg

    def _feed(self, seg, byte, unknown):
        stdin = seg.proc.stdin
        source = None
        try:
            if unknown:
                raise IOError(u"مدة الملف غير معروفة للتقديم")
            if self.local:
                source = open(self.url, "rb")
                source.seek(byte)
            else:
                tries = 0
                while True:
                    try:
                        source, status, _ = http_open(self.url, byte)
                        break
                    except Exception:
                        tries += 1
                        if tries >= 3 or seg.killed:
                            raise
                        time.sleep(2)
                if byte and status == 200:              # the server ignores Range: skip up to the byte ourselves
                    left = byte
                    while left > 0 and not seg.killed:
                        piece = source.read(min(65536, left))
                        if not piece:
                            break
                        left -= len(piece)
            fd = stdin.fileno()
            while not seg.killed:
                piece = source.read(32768)
                if not piece:
                    break
                _write_all(fd, piece)
        except Exception as exc:
            if not seg.killed:
                seg.feed_error = u"%s" % exc
                seg.tail.append(u"error: %s" % exc)
        finally:
            for thing in (source, stdin):
                try:
                    if thing is not None:
                        thing.close()
                except Exception:
                    pass

    def _read_err(self, seg):
        try:
            for raw in iter(seg.proc.stderr.readline, b""):
                line = _text(raw).strip()
                if not line:
                    continue
                match = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", line)
                if match and not seg.duration:
                    seg.duration = int(match.group(1)) * 3600 + int(match.group(2)) * 60 + float(match.group(3))
                    with self.lock:
                        if self.seg is seg and seg.duration > 5 and (self.duration <= 0 or self.local):
                            self.duration = seg.duration
                        elif self.seg is seg and seg.duration > 5 and self.duration > 0 \
                                and abs(seg.duration - self.duration) > 3:
                            self.duration = seg.duration
                    continue
                seg.tail.append(line)
                del seg.tail[:-15]
        except Exception:
            pass

    def _read_pcm(self, seg):
        fd = seg.proc.stdout.fileno()
        limit = QUEUE_SECONDS * BPS
        try:
            if seg.fmt == "wav":
                buf = b""
                pos = 12
                while True:
                    while len(buf) < pos + 8:
                        piece = os.read(fd, 4096)
                        if not piece:
                            raise EOFError
                        buf += piece
                    cid, size = buf[pos:pos + 4], struct.unpack(str("<I"), buf[pos + 4:pos + 8])[0]
                    pos += 8
                    if cid == b"data":
                        first = buf[pos:]
                        break
                    pos += size + (size & 1)
                if first:
                    self._put(seg, first)
            while not seg.killed:
                while seg.qbytes >= limit and not seg.killed:
                    time.sleep(0.03)
                piece = os.read(fd, 65536)
                if not piece:
                    break
                self._put(seg, piece)
        except (EOFError, EnvironmentError, ValueError):
            pass
        finally:
            try:
                seg.rc = seg.proc.wait()
            except Exception:
                seg.rc = -1
            seg.done = True

    def _put(self, seg, piece):
        with seg.cond:
            seg.chunks.append(piece)
            seg.qbytes += len(piece)
            seg.got_data += len(piece)
        self.last_data = monotonic()

    def _take(self, seg, want):
        with seg.cond:
            if not seg.chunks:
                return b""
            piece = seg.chunks.popleft()
            if len(piece) > want:
                seg.chunks.appendleft(piece[want:])
                piece = piece[:want]
            seg.qbytes -= len(piece)
            return piece

    # ---- the paced relay
    def _run(self, gen):
        writer, why = self._open_writer(gen)
        if not self._alive(gen):
            if writer is not None:
                _kill([writer])
            return
        if writer is None:
            self.no_route = True
            self._fail(gen, why or u"لا يوجد مخرج صوت")
            return
        with self.lock:
            if self.gen != gen:
                _kill([writer])
                return
            self.writer = writer
            start = self.base
        wfd = writer.stdin.fileno()
        seg = self._start_segment(start)
        with self.lock:
            if self.gen != gen:
                seg.killed = True
                _kill([seg.proc, writer])
                return
            self.seg = seg
        began = monotonic()
        prebuffer = PREBUFFER_LOCAL if self.local else PREBUFFER_NET
        no_data_limit = NODATA_LOCAL if self.local else NODATA_NET
        attempt_tls = 0
        while self._alive(gen):
            # ---- seek request: restart the decoder at the new place (the card writer keeps running)
            with self.lock:
                target = self.wait_seek
                self.wait_seek = None
            if target is not None:
                seg.killed = True
                _kill([seg.proc])
                seg = self._start_segment(target)
                with self.lock:
                    if self.gen != gen:
                        seg.killed = True
                        _kill([seg.proc])
                        return
                    self.seg = seg
                    self.status = "starting" if self.status != "playing" else "playing"
                began = monotonic()
                continue
            now = monotonic()
            with self.lock:
                paused = self.paused
            if paused:
                time.sleep(0.04)
                continue
            # ---- start the clock after a small cushion
            if self.t0 is None:
                have = seg.qbytes / float(BPS)
                if have >= prebuffer or (seg.done and seg.got_data > 0) \
                        or (now - began > PREBUFFER_TIMEOUT and seg.got_data > 0):
                    with self.lock:
                        if self.gen == gen and self.t0 is None and self.wait_seek is None:
                            self.t0 = monotonic()
                else:
                    if seg.done and seg.got_data == 0:
                        if seg.rc not in (0, None) and attempt_tls < 2 and self._tls_retry(seg):
                            attempt_tls += 1
                            self.tls_level = attempt_tls
                            seg = self._start_segment(seg.offset)
                            with self.lock:
                                if self.gen != gen:
                                    seg.killed = True
                                    _kill([seg.proc])
                                    return
                                self.seg = seg
                            began = monotonic()
                            continue
                        self._fail(gen, seg.feed_error or (self._best_error(seg) if seg.rc not in (0, None)
                                                           else u"الملف لا يحتوي صوتاً"))
                        return
                    if now - began > no_data_limit:
                        self._fail(gen, u"لا يصل صوت من الرابط")
                        return
                    time.sleep(0.03)
                    continue
            now = monotonic()
            with self.lock:
                if self.gen != gen or self.wait_seek is not None:
                    continue
                elapsed = self._elapsed(now)
                lead = self.fed - elapsed
                if lead < 0 and self.t0 is not None:
                    self.t0 += -lead                  # starved: the clock waits for the audio, never runs ahead of it
                    elapsed = self.fed
                    lead = 0.0
                self.starved = lead < 0.05 and seg.qbytes == 0 and not seg.done
                if self.status == "starting" and self.fed > 0 and elapsed > 0.05:
                    self.status = "playing"
            if lead >= AHEAD:
                time.sleep(min(0.05, lead - AHEAD + 0.005))
                continue
            data = self._take(seg, CHUNK)
            if not data:
                if seg.done and seg.qbytes == 0:
                    # decoder finished: the real end (or an error)
                    if seg.rc not in (0, None) and not seg.killed:
                        if seg.got_data < BPS // 2 or self._error_text(seg):
                            self._fail(gen, self._best_error(seg))
                            return
                    if seg.got_data == 0:
                        self._fail(gen, u"الملف لا يحتوي صوتاً")
                        return
                    # wait until everything fed has been played
                    while self._alive(gen) and self.wait_seek is None:
                        with self.lock:
                            if self.paused:
                                pass
                            elif self._elapsed(monotonic()) >= self.fed:
                                break
                        time.sleep(0.04)
                    time.sleep(LATENCY)
                    with self.lock:
                        if self.gen == gen and self.wait_seek is None:
                            self.ever_played += self.fed
                            self.base += self.fed
                            self.fed = 0.0
                            self.t0 = None
                            self.status = "ended"
                    if self._alive(gen) and self.status == "ended":
                        self._cleanup(gen)
                        return
                    continue
                if monotonic() - self.last_data > no_data_limit and not seg.done:
                    self._fail(gen, u"توقف وصول الصوت")
                    return
                time.sleep(0.02)
                continue
            try:
                _write_all(wfd, data)
            except Exception:
                if self._alive(gen) and not seg.killed:
                    forget_route()
                    self._fail(gen, u"توقف مخرج الصوت")
                return
            with self.lock:
                if self.gen == gen and self.wait_seek is None:
                    self.fed += len(data) / float(BPS)
                    self.last_data = monotonic()

    def _error_text(self, seg):
        bad = [l for l in seg.tail if re.search(r"(error|fail|invalid|not found|refused|denied|no such|unable|"
                                                 r"certificate|timed out|Server returned)", l, re.I)]
        return bad[-1] if bad else u""

    def _best_error(self, seg):
        return seg.feed_error or self._error_text(seg) or (seg.tail[-1] if seg.tail else u"ffmpeg توقف")

    def _tls_retry(self, seg):
        text = u" ".join(seg.tail).lower()
        return bool(re.search(r"certificate|ssl|tls|handshake", text)) and not self.local


def engine_available():
    return quick_available()


_warm = []


def warm_up():
    """Ask ffmpeg / python / the sound routes once in the background when the plugin opens, so the first
    recording starts without waiting for the probes."""
    if _warm or not quick_available():
        return
    _warm.append(1)

    def work():
        try:
            with _lock:
                ffmpeg_path()
                ffmpeg_caps()
                python_bin()
                candidate_routes()
        except Exception as exc:
            log(u"audio warm-up failed: %s" % exc)

    thread = threading.Thread(target=work)
    thread.daemon = True
    thread.start()
