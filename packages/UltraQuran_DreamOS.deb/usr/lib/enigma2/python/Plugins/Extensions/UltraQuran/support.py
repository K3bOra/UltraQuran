# -*- coding: utf-8 -*-
import io
import json
import os
import tempfile
import traceback
from time import strftime

try:
    from enigma import eTimer
except ImportError:
    eTimer = None

try:
    from PIL import Image
except ImportError:
    Image = None

from . import layout

ROOT = os.path.dirname(os.path.abspath(__file__))
LOG_PATH = "/tmp/ultra-quran.log"
FAVORITES_PATH = "/etc/enigma2/ultra-quran-favorites.json"
LEGACY_FAVORITES_PATH = "/etc/enigma2/ultra-deen-favorites.json"
STORAGE_OVERRIDE = None

try:
    text_type = unicode
except NameError:
    text_type = str


def _detect_dreamos():
    """DreamOS images are dpkg/apt based (some also ship opkg, so opkg alone does not mean OE-Alliance).
    Same test as Ultra Stalker's us_env."""
    if os.environ.get("UQ_NOT_DREAMOS"):
        return False
    try:
        if not os.path.exists("/var/lib/dpkg/status"):
            return False
        if os.path.exists("/usr/bin/apt-get"):
            return True
        text = u""
        for path in ("/etc/issue", "/etc/issue.net"):
            try:
                with io.open(path, "rb") as handle:
                    text += handle.read(512).decode("utf-8", "replace").lower()
            except Exception:
                pass
        return "opendreambox" in text or "dreambox" in text
    except Exception:
        return False


IS_DREAMOS = _detect_dreamos()
# DreamOS eLabel.calculateSize() reports text a little narrower than it is drawn (Ultra Stalker adds this)
def text_width_pad(px):
    return int(2 + 0.25 * px) if IS_DREAMOS else 0


def native(value):
    """DreamOS Python 2 expects UTF-8 bytes in SWIG widgets."""
    return value.encode("utf-8") if text_type is not str and isinstance(value, text_type) else value


def storage_root(media_root="/media"):
    """Return the UltraQuran folder on the receiver's hard drive / USB, or inside the plugin directory."""
    if STORAGE_OVERRIDE:
        return STORAGE_OVERRIDE
    preferred = ("hdd", "usb", "sda1", "sdb1", "mmc", "sdcard", "net")
    candidates = []
    try:
        entries = sorted(os.listdir(media_root))
    except OSError:
        entries = []
    for name in preferred:
        if name in entries:
            candidates.append(os.path.join(media_root, name))
    for name in entries:
        path = os.path.join(media_root, name)
        if path not in candidates and name not in ("net", "autofs", "upnp"):
            candidates.append(path)
    for mount in candidates:
        if os.path.isdir(mount) and os.access(mount, os.W_OK):
            target = os.path.join(mount, "UltraQuran")
            try:
                if not os.path.isdir(target):
                    os.makedirs(target)
                return target
            except OSError:
                continue
    dream_data = "/data/UltraQuran" if (os.path.isdir("/data") and os.access("/data", os.W_OK)) else None
    fallbacks = ([dream_data] if dream_data else []) + [os.path.join(ROOT, "storage"), "/etc/enigma2/ultra-quran-cache", "/tmp/ultra-quran-cache"]
    for fallback in fallbacks:
        try:
            if not os.path.isdir(fallback):
                os.makedirs(fallback)
            if os.access(fallback, os.W_OK):
                return fallback
        except OSError:
            continue
    return "/tmp"


def data_json(*parts):
    """Load a bundled data file (data/<parts>.json). The package ships it gzip-compressed (<name>.json.gz,
    about 7x smaller on the receiver's flash); a plain .json next to it (development tree) wins."""
    path = os.path.join(ROOT, "data", *parts)
    if os.path.isfile(path):
        with io.open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    import gzip
    with gzip.open(path + ".gz", "rb") as handle:
        return json.loads(handle.read().decode("utf-8"))


def data_names(*parts):
    """Base names (without .json / .json.gz) of the data files in data/<parts>."""
    folder = os.path.join(ROOT, "data", *parts)
    names = set()
    for name in os.listdir(folder):
        if name.endswith(".json.gz"):
            names.add(name[:-8])
        elif name.endswith(".json"):
            names.add(name[:-5])
    return names


def art_ready(width):
    """Path of a complete art set for `width` (shipped or cached earlier), or None. Never writes anything."""
    master_dir = os.path.join(ROOT, "art", "1920")
    if width == 1920:
        return master_dir
    try:
        names = set(n for n in os.listdir(master_dir) if n.endswith(".png"))
    except OSError:
        return None
    for path in (os.path.join(ROOT, "art", str(width)), os.path.join(storage_root(), "art", str(width)),
                 "/tmp/ultra-quran-art-" + str(width)):
        try:
            if os.path.isdir(path) and names <= set(os.listdir(path)):
                return path
        except OSError:
            continue
    return None


def ensure_art_for_width(width):
    """Ensure native-resolution PNGs exist for `width` (e.g. 2560, 1920, 1280, 720).

    If `art/<width>` is already populated and up-to-date, returns it immediately.
    Otherwise, synthesizes exact-pixel PNGs from `art/1920` once and caches them on disk.
    """
    master_dir = os.path.join(ROOT, "art", "1920")
    if width == 1920 or Image is None or not os.path.isdir(master_dir):
        return master_dir
    shipped = os.path.join(ROOT, "art", str(width))
    try:
        if os.path.isdir(shipped) and set(os.listdir(master_dir)) <= set(os.listdir(shipped)):
            return shipped  # pre-rendered at build time: nothing to compute on the receiver
    except OSError:
        pass

    candidates = [
        os.path.join(storage_root(), "art", str(width)),
        "/tmp/ultra-quran-art-" + str(width),
        os.path.join(ROOT, "art", str(width)),
    ]
    target_dir = candidates[0]
    for path in candidates:
        try:
            if not os.path.isdir(path):
                os.makedirs(path)
            if os.access(path, os.W_OK):
                target_dir = path
                break
        except OSError:
            continue

    try:
        resample = getattr(getattr(Image, "Resampling", Image), "LANCZOS", Image.BICUBIC)
        hi_dir = os.path.join(ROOT, "art", "2560")
        use_hi = width > 1920 and os.path.isdir(hi_dir)
        for name in sorted(os.listdir(master_dir)):
            if not name.endswith(".png"):
                continue
            master_path = os.path.join(master_dir, name)
            hi_path = os.path.join(hi_dir, name)
            src_path = hi_path if (use_hi and os.path.isfile(hi_path)) else master_path
            dst_path = os.path.join(target_dir, name)
            if (
                os.path.isfile(dst_path)
                and os.path.getsize(dst_path) > 128
                and os.path.getmtime(dst_path) >= os.path.getmtime(src_path)
            ):
                continue
            with Image.open(master_path) as im_m:
                tw, th = layout.scaled((0, 0, im_m.width, im_m.height), width)[2:]
            with Image.open(src_path) as im:
                im.load()
                resized = im.resize((tw, th), resample) if im.size != (tw, th) else im.copy()
                fd, tmp_path = tempfile.mkstemp(prefix=".art-", suffix=".png", dir=target_dir)
                os.close(fd)
                try:
                    resized.save(tmp_path, format="PNG", compress_level=6)
                    os.chmod(tmp_path, 0o644)
                    os.rename(tmp_path, dst_path)
                finally:
                    if os.path.exists(tmp_path):
                        try:
                            os.unlink(tmp_path)
                        except OSError:
                            pass
    except Exception:
        log_exception("Could not synthesize art for width %s" % width)
        return master_dir
    return target_dir


def log(message):
    line = u"[UltraQuran] {0} {1}".format(strftime("%H:%M:%S"), message)
    try:
        if os.path.isfile(LOG_PATH) and os.path.getsize(LOG_PATH) > 65536:
            os.rename(LOG_PATH, LOG_PATH + ".1")
        with io.open(LOG_PATH, "a", encoding="utf-8") as handle:
            handle.write(line + u"\n")
    except (IOError, OSError):
        print(native(line))


def log_exception(message):
    log(u"{0}\n{1}".format(message, traceback.format_exc().decode("utf-8", "replace")
                            if text_type is not str else traceback.format_exc()))


class Timer(object):
    def __init__(self, callback):
        self.timer = eTimer()
        self.callback = callback
        callbacks = getattr(self.timer, "callback", None)
        self.connection = None
        if callbacks is not None:
            callbacks.append(callback)
        else:
            self.connection = self.timer.timeout.connect(callback)

    def start(self, ms, single=True):
        self.timer.start(ms, single)

    def stop(self):
        self.timer.stop()

    def close(self):
        self.stop()
        if self.connection is not None:
            self.connection = None
        else:
            if self.callback in self.timer.callback:
                self.timer.callback.remove(self.callback)
        self.callback = None


def load_favorites(catalog, path=FAVORITES_PATH):
    if path == FAVORITES_PATH and not os.path.exists(path):
        path = LEGACY_FAVORITES_PATH
    try:
        with io.open(path, "r", encoding="utf-8") as handle:
            items = json.loads(handle.read(16384))
        result = []
        if isinstance(items, list):
            for value in items[:200]:
                if (isinstance(value, list) and len(value) == 2 and
                        all(type(part) is int for part in value)):
                    entry = tuple(value)
                    if catalog.contains(entry) and entry not in result:
                        result.append(entry)
        return result
    except (IOError, ValueError):
        return []


def save_favorites(items, path=FAVORITES_PATH):
    descriptor, name = tempfile.mkstemp(prefix=".ultra-quran-", dir=os.path.dirname(path))
    try:
        with io.open(descriptor, "w", encoding="ascii") as handle:
            handle.write(text_type(json.dumps(items, separators=(",", ":"))))
            handle.flush()
            os.fsync(handle.fileno())
        os.rename(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)
