# -*- coding: utf-8 -*-
"""Verified video library for every sheikh (Ultra Quran 1.0.0).

Videos are NOT searched for on the receiver any more. Loose run-time name matching used to attach videos of other
sheikhs to the wrong person, so the library is built offline instead (data/videos.json):

  * every file was found on archive.org, matched to the sheikh by his full distinctive name in the file name / title
    (or by an archive item dedicated to him), rejected when it also names another sheikh, and
  * its URL was checked to answer HTTP 200 with a real video size before it was added.

The class keeps the old VideoFinder interface, so the screens need no change.
"""
import io
import json
import os
import threading

from .support import ROOT, data_json, log_exception

BADGE = u"فيديو مرئي · أرشيف الإنترنت"


class VideoFinder(object):
    """Read-only access to data/videos.json (loaded once, lazily)."""

    def __init__(self, on_ready=None):
        self.on_ready = on_ready
        self._lock = threading.Lock()
        self._data = None
        self._items = {}
        self._ready = []

    def _load(self):
        if self._data is not None:
            return self._data
        data = {}
        try:
            data = data_json("videos.json")
        except Exception:
            log_exception("Cannot load data/videos.json")
        self._data = data
        return data

    def cached(self, reciter_id):
        """Always a list: the verified videos of this sheikh ([] when none were found)."""
        items = self._items.get(reciter_id)
        if items is not None:
            return items
        rows = self._load().get(str(reciter_id)) or []
        items = []
        for number, row in enumerate(rows, 1):
            title, url, duration, identifier = row[0], row[1], row[2], row[3]
            label = u"%02d · %s" % (number, title)
            items.append({
                "title": label,
                "video": True,
                "audio": url,
                "duration": duration,
                "badge": BADGE,
                "subtitle": u"فيديو حقيقي من أرشيف الإنترنت",
                "body": u"%s\n\nالمصدر: archive.org/details/%s" % (title, identifier),
                "live": False,
            })
        self._items[reciter_id] = items
        return items

    def failed(self, reciter_id):
        return False

    def is_pending(self, reciter_id):
        return False

    def request(self, reciter_id, name, retry=False):
        return False

    def pop_ready(self):
        return []
