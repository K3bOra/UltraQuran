# -*- coding: utf-8 -*-
"""Background Surah, Full Reciter Folder, Video & Islamic Media Downloader for Ultra Quran 1.1.0.

Uses an O(1) in-memory cache of downloaded chapters and media files on the Hard Drive
(<storage_root>/downloads) so UI rendering and cursor movement perform ZERO synchronous
disk stat() calls on /media/hdd, and everything downloaded plays 100% offline without internet.
"""
import hashlib
import io
import json
import os
import ssl
import subprocess
import tempfile
import threading

try:
    from urllib.parse import quote, unquote, urlsplit, urlunsplit
    from urllib.request import Request, urlopen
except ImportError:
    from urllib import quote, unquote
    from urlparse import urlsplit, urlunsplit
    from urllib2 import Request, urlopen

from .support import ROOT, log, log_exception, storage_root

USER_AGENT = "Mozilla/5.0 (X11; Linux armv7l) UltraQuran/1.1.0"


def _ssl_contexts():
    contexts = []
    cafile = os.path.join(ROOT, "certs", "cacert.pem")
    if hasattr(ssl, "create_default_context"):
        try:
            if os.path.isfile(cafile):
                contexts.append(ssl.create_default_context(cafile=cafile))
            else:
                contexts.append(ssl.create_default_context())
        except Exception:
            pass
    if hasattr(ssl, "_create_unverified_context"):
        try:
            contexts.append(ssl._create_unverified_context())
        except Exception:
            pass
    return contexts or [None]


def _safe_url(url):
    """Ensure URL path and query are properly percent-encoded for urllib/wget."""
    if not url:
        return ""
    try:
        parts = urlsplit(url)
        raw_path = unquote(parts.path)
        if not isinstance(raw_path, str):
            raw_path = raw_path.encode("utf-8")
        safe_path = quote(raw_path, safe="/:@!$&'()*+,;=-._~")
        return urlunsplit((parts.scheme, parts.netloc, safe_path, parts.query, parts.fragment))
    except Exception:
        return url


def _media_hash(url):
    try:
        raw = url.encode("utf-8") if not isinstance(url, bytes) else url
    except Exception:
        raw = str(url).encode("utf-8", "replace")
    return hashlib.md5(raw).hexdigest()[:16]


def _media_ext(url, is_video=False):
    lower = (url or "").lower().split("?", 1)[0]
    for ext in (".mp4", ".mkv", ".ogg", ".mp3", ".m4a", ".aac"):
        if lower.endswith(ext):
            return ext
    return ".mp4" if is_video else ".mp3"


class DownloadManager(object):
    def __init__(self, catalog, on_update=None):
        self.catalog = catalog
        self.on_update = on_update
        self._lock = threading.Lock()
        self._queue = []
        self._queued_keys = set()
        self._active = None
        self._completed_count = 0
        self._total_queued = 0
        self._last_message = u""
        self._dirty = False
        self._worker = None
        self._base_dir_cache = None
        self._dl_cache = {}
        self._media_files = set()
        self._media_meta = {}
        self._media_loaded = False

    @property
    def base_dir(self):
        if self._base_dir_cache is None:
            path = os.path.join(storage_root(), "downloads")
            try:
                if not os.path.isdir(path):
                    os.makedirs(path)
            except OSError:
                pass
            self._base_dir_cache = path
        return self._base_dir_cache

    @property
    def media_dir(self):
        path = os.path.join(self.base_dir, "media")
        try:
            if not os.path.isdir(path):
                os.makedirs(path)
        except OSError:
            pass
        return path

    def _ensure_media_loaded(self):
        if self._media_loaded:
            return
        self._media_loaded = True
        mdir = self.media_dir
        idx_path = os.path.join(mdir, "index.json")
        if os.path.isfile(idx_path):
            try:
                with io.open(idx_path, "r", encoding="utf-8") as handle:
                    data = json.load(handle)
                if isinstance(data, dict):
                    self._media_meta = data
            except Exception:
                self._media_meta = {}
        try:
            if os.path.isdir(mdir):
                for name in os.listdir(mdir):
                    if name == "index.json" or name.startswith("."):
                        continue
                    full = os.path.join(mdir, name)
                    try:
                        if os.path.isfile(full) and os.path.getsize(full) > 1024:
                            self._media_files.add(name)
                    except OSError:
                        pass
        except OSError:
            pass

    def _save_media_index(self):
        idx_path = os.path.join(self.media_dir, "index.json")
        try:
            with io.open(idx_path, "w", encoding="utf-8") as handle:
                handle.write(u"" + json.dumps(self._media_meta, ensure_ascii=False))
        except Exception:
            pass

    def invalidate_cache(self, edition_id=None):
        with self._lock:
            if edition_id is None:
                self._dl_cache.clear()
                self._base_dir_cache = None
                self._media_loaded = False
                self._media_files.clear()
            else:
                self._dl_cache.pop(edition_id, None)

    def edition_folder(self, edition_id):
        if edition_id not in self.catalog.edition:
            return os.path.join(self.base_dir, str(edition_id))
        reciter, recording = self.catalog.edition[edition_id]
        return os.path.join(self.base_dir, "%d_%d" % (reciter[0], recording[0]))

    def surah_path(self, edition_id, chapter):
        return os.path.join(self.edition_folder(edition_id), "%03d.mp3" % chapter)

    def _get_edition_downloaded_set(self, edition_id):
        """Return cached set of downloaded chapter numbers for edition_id (1 directory scan total)."""
        cached = self._dl_cache.get(edition_id)
        if cached is not None:
            return cached
        folder = self.edition_folder(edition_id)
        found = set()
        try:
            if os.path.isdir(folder):
                for name in os.listdir(folder):
                    if name.endswith(".mp3") and len(name) == 7 and name[:3].isdigit():
                        full = os.path.join(folder, name)
                        try:
                            if os.path.getsize(full) > 1024:
                                found.add(int(name[:3]))
                        except OSError:
                            pass
        except OSError:
            pass
        self._dl_cache[edition_id] = found
        return found

    def is_downloaded(self, edition_id, chapter):
        dl_set = self._get_edition_downloaded_set(edition_id)
        if chapter in dl_set:
            return True
        path = self.surah_path(edition_id, chapter)
        if os.path.isfile(path):
            try:
                if os.path.getsize(path) > 1024:
                    dl_set.add(chapter)
                    return True
            except OSError:
                pass
        return False

    def downloaded_count(self, edition_id):
        if edition_id not in self.catalog.edition:
            return 0
        dl_set = self._get_edition_downloaded_set(edition_id)
        return len(dl_set)

    def reciter_downloaded_count(self, reciter_id):
        rec = self.catalog.reciter.get(reciter_id)
        if not rec:
            return 0
        return sum(self.downloaded_count(ed[0]) for ed in rec[2])

    def local_media_path(self, url, is_video=False):
        if not url:
            return None
        if url.startswith("/") and os.path.isfile(url):
            return url
        self._ensure_media_loaded()
        h = _media_hash(url)
        info = self._media_meta.get(h)
        if info and info.get("filename"):
            fname = info["filename"]
        else:
            fname = h + _media_ext(url, is_video=is_video)
        if fname in self._media_files:
            full = os.path.join(self.media_dir, fname)
            if os.path.isfile(full):
                return full
        full = os.path.join(self.media_dir, fname)
        if os.path.isfile(full) and os.path.getsize(full) > 1024:
            self._media_files.add(fname)
            return full
        return None

    def is_media_downloaded(self, url, is_video=False):
        return self.local_media_path(url, is_video=is_video) is not None

    def is_media_queued(self, url):
        if not url:
            return False
        key = ("media", _media_hash(url))
        with self._lock:
            return key in self._queued_keys or (self._active is not None and self._active[:2] == key)

    def is_queued(self, edition_id, chapter):
        with self._lock:
            return (edition_id, chapter) in self._queued_keys or self._active == (edition_id, chapter)

    def all_downloaded_entries(self):
        """Return all downloaded Surahs and Media items on the Hard Drive for offline listening."""
        entries = []
        try:
            if os.path.isdir(self.base_dir):
                for folder_name in sorted(os.listdir(self.base_dir)):
                    if "_" not in folder_name:
                        continue
                    parts = folder_name.split("_", 1)
                    if not (parts[0].isdigit() and parts[1].isdigit()):
                        continue
                    ed_id = int(parts[1])
                    if ed_id not in self.catalog.edition:
                        continue
                    dl_set = self._get_edition_downloaded_set(ed_id)
                    for ch in sorted(dl_set):
                        entries.append((ed_id, ch))
        except OSError:
            pass
        self._ensure_media_loaded()
        for h, meta in sorted(self._media_meta.items(), key=lambda kv: kv[1].get("title", u"")):
            fname = meta.get("filename")
            if fname and fname in self._media_files and not meta.get("video"):
                full_path = os.path.join(self.media_dir, fname)
                if os.path.isfile(full_path):
                    entries.append((
                        "lib",
                        (
                            meta.get("title") or u"مادة صوتية محمّلة",
                            meta.get("section") or u"مكتبة الهارد (بدون نت)",
                            meta.get("badge") or u"• محمّلة على الهارد",
                            meta.get("url") or full_path,
                        ),
                    ))
        return entries

    def pop_updated(self):
        with self._lock:
            was_dirty = self._dirty
            self._dirty = False
            return was_dirty

    def status_text(self):
        with self._lock:
            if self._active is not None:
                if self._active[0] == "media":
                    title = self._active[2].get("title", u"مادة")
                    return u"• جارٍ التحميل على الهارد: %s (%d من %d)" % (
                        title[:28], self._completed_count + 1, max(1, self._total_queued)
                    )
                ed_id, ch = self._active
                sura_name = self.catalog.chapter(ch)
                return u"• جارٍ التحميل على الهارد: سورة %s (%d من %d)" % (
                    sura_name, self._completed_count + 1, max(1, self._total_queued)
                )
            return self._last_message

    def enqueue_surah(self, edition_id, chapter):
        if self.is_downloaded(edition_id, chapter):
            return False
        added = self._enqueue_items([(edition_id, chapter)])
        return added > 0

    def enqueue_edition(self, edition_id):
        if edition_id not in self.catalog.edition:
            return 0
        chapters = self.catalog.edition[edition_id][1][3]
        dl_set = self._get_edition_downloaded_set(edition_id)
        items = [(edition_id, ch) for ch in chapters if ch not in dl_set]
        return self._enqueue_items(items)

    def enqueue_media(self, item, section_title=u""):
        entry = self._media_entry(item, section_title)
        if entry is None:
            return False
        return self._enqueue_items([entry]) > 0

    def enqueue_media_many(self, items, section_title=u""):
        """Queue a whole folder at once; returns how many new files were queued."""
        entries = [e for e in (self._media_entry(it, section_title) for it in items) if e is not None]
        return self._enqueue_items(entries) if entries else 0

    def _media_entry(self, item, section_title=u""):
        url = item.get("audio")
        if not url or item.get("live") or "qurango.net/radio" in url or url.startswith("/"):
            return None
        is_video = bool(item.get("video"))
        if self.is_media_downloaded(url, is_video=is_video):
            return None
        h = _media_hash(url)
        meta = {
            "url": url,
            "title": item.get("title") or u"مادة محمّلة",
            "section": section_title or item.get("subtitle") or u"مكتبة الهارد",
            "badge": item.get("badge") or (u"فيديو محمّل" if is_video else u"صوت محمّل"),
            "video": is_video,
            "filename": h + _media_ext(url, is_video=is_video),
        }
        return ("media", h, meta)

    def _enqueue_items(self, items):
        added = 0
        with self._lock:
            if self._active is None and not self._queue:
                self._completed_count = 0
                self._total_queued = 0
            for entry in items:
                key = entry[:2] if entry[0] == "media" else entry
                active_key = self._active[:2] if (self._active and self._active[0] == "media") else self._active
                if key not in self._queued_keys and key != active_key:
                    self._queue.append(entry)
                    self._queued_keys.add(key)
                    self._total_queued += 1
                    added += 1
            if added:
                self._dirty = True
            if added and (self._worker is None or not self._worker.is_alive()):
                self._worker = threading.Thread(target=self._worker_loop)
                self._worker.daemon = True
                self._worker.start()
        return added

    def _worker_loop(self):
        while True:
            with self._lock:
                if not self._queue:
                    self._active = None
                    if self._total_queued > 0:
                        self._last_message = u"• اكتمل حفظ %d مادة على الهارد للتشغيل بدون نت" % (
                            self._completed_count
                        )
                    self._dirty = True
                    break
                entry = self._queue.pop(0)
                key = entry[:2] if entry[0] == "media" else entry
                self._queued_keys.discard(key)
                self._active = entry
                self._dirty = True
            self._notify()
            if entry[0] == "media":
                ok = self._download_media_one(entry[1], entry[2])
            else:
                ok = self._download_one(entry[0], entry[1])
            with self._lock:
                if ok:
                    self._completed_count += 1
                    if entry[0] != "media":
                        self._dl_cache.setdefault(entry[0], set()).add(entry[1])
                self._active = None
                self._dirty = True
            self._notify()

    def _notify(self):
        if self.on_update is not None:
            try:
                self.on_update()
            except Exception:
                pass

    def _fetch_url_to_file(self, url, target_path, folder):
        safe = _safe_url(url)
        for ctx in _ssl_contexts():
            try:
                req = Request(safe, headers={"User-Agent": USER_AGENT})
                kwargs = {"timeout": 20}
                if ctx is not None:
                    kwargs["context"] = ctx
                resp = urlopen(req, **kwargs)
                try:
                    expected = int(resp.info().get("Content-Length") or 0)
                except (TypeError, ValueError):
                    expected = 0
                fd, tmp_path = tempfile.mkstemp(prefix=".dl-", suffix=".part", dir=folder)
                total_bytes = 0
                try:
                    with os.fdopen(fd, "wb") as out_f:
                        while True:
                            chunk = resp.read(65536)
                            if not chunk:
                                break
                            out_f.write(chunk)
                            total_bytes += len(chunk)
                finally:
                    resp.close()
                if total_bytes > 1024 and (not expected or total_bytes >= expected):
                    os.chmod(tmp_path, 0o644)
                    os.rename(tmp_path, target_path)
                    return total_bytes
                if os.path.exists(tmp_path):
                    os.unlink(tmp_path)        # cut-off download: never kept as a "downloaded" recording
            except Exception:
                continue

        # Fallback to wget / curl for Enigma2 images with older SSL cipher suites
        fd, tmp_path = tempfile.mkstemp(prefix=".dl-", suffix=".part", dir=folder)
        os.close(fd)
        try:
            for cmd in (
                ["/usr/bin/wget", "-q", "-T", "25", "-U", USER_AGENT, "-O", tmp_path, safe],
                ["wget", "-q", "-T", "25", "-U", USER_AGENT, "-O", tmp_path, safe],
                ["/usr/bin/curl", "-s", "-L", "--max-time", "60", "-A", USER_AGENT, "-o", tmp_path, safe],
                ["curl", "-s", "-L", "--max-time", "60", "-A", USER_AGENT, "-o", tmp_path, safe],
            ):
                try:
                    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    proc.communicate()
                    if proc.returncode == 0 and os.path.isfile(tmp_path) and os.path.getsize(tmp_path) > 1024:
                        total_bytes = os.path.getsize(tmp_path)
                        os.chmod(tmp_path, 0o644)
                        os.rename(tmp_path, target_path)
                        return total_bytes
                except Exception:
                    continue
        finally:
            if os.path.exists(tmp_path):
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
        return 0

    def _download_one(self, edition_id, chapter):
        try:
            target = self.surah_path(edition_id, chapter)
            folder = os.path.dirname(target)
            if not os.path.isdir(folder):
                os.makedirs(folder)
            reciter, recording = self.catalog.edition[edition_id]
            info_file = os.path.join(folder, "info.txt")
            if not os.path.isfile(info_file):
                try:
                    with io.open(info_file, "w", encoding="utf-8") as handle:
                        handle.write(u"%s — %s\n" % (reciter[1], recording[1]))
                except OSError:
                    pass
            _, _, _, url, _ = self.catalog.track((edition_id, chapter))
            total_bytes = self._fetch_url_to_file(url, target, folder)
            if total_bytes > 1024:
                log("Downloaded surah %d:%03d -> %s (%d bytes)" % (edition_id, chapter, target, total_bytes))
                return True
        except Exception:
            log_exception("Failed downloading surah %s:%s" % (edition_id, chapter))
        return False

    def _download_media_one(self, h, meta):
        try:
            self._ensure_media_loaded()
            folder = self.media_dir
            fname = meta["filename"]
            target = os.path.join(folder, fname)
            total_bytes = self._fetch_url_to_file(meta["url"], target, folder)
            if total_bytes > 1024:
                self._media_files.add(fname)
                self._media_meta[h] = meta
                self._save_media_index()
                log("Downloaded media %s -> %s (%d bytes)" % (meta.get("title"), target, total_bytes))
                return True
        except Exception:
            log_exception("Failed downloading media %s" % meta.get("url"))
        return False
