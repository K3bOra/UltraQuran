# -*- coding: utf-8 -*-
"""Rolling biography box, the Poster Grid 3 description scroll of Ultra Stalker brought to Ultra Quran.

SMOOTH: a clipped viewport (eWidget) over the box with a tall label inside it; the label moves up one pixel
every STEP_MS (about one line every two seconds), holds at the top and at the end, then starts again.
PAGED fallback (any failure, or /etc/enigma2/ultra-quran-noscroll): the box itself shows a window of whole
lines that moves one line every LINE_MS.
"""
from __future__ import absolute_import

import os

from . import layout
from .support import Timer, native, text_width_pad

STEP_MS = 70
START_HOLD = 5000
END_HOLD = 6000
LINE_MS = 2000
DISABLE_FILE = "/etc/enigma2/ultra-quran-noscroll"
FONT = "UltraQuranUI"
COLOR = 0xeee8d6


class BioScroller(object):
    def __init__(self, screen, label):
        self.screen = screen
        self.label = label
        self.timer = Timer(self._tick)
        self.key = None
        self.box = None
        self.lab = None
        self.mode = None          # None (fits, nothing to do) / "smooth" / "paged"
        self.broken = os.path.exists(DISABLE_FILE)
        self.pos = 0
        self.max = 0
        self.phase = "top"
        self.lines = []
        self.first = 0
        self.window = 1

    # ---------------------------------------------------------------- wrapping
    def wrap(self, text, box, fallback_chars=33):
        """Lines that fill the whole box width (measured with the receiver's own font), so a long biography
        uses the right and left of the box too instead of a narrow column in the middle."""
        try:
            widget = self.screen[self.label]
            inst = widget.instance
            full = layout.scaled(box, self.screen.width)[2]
            limit = full - max(layout.pixel(14, self.screen.width), full // 10)
            limit -= 3 * text_width_pad(layout.pixel(self._size(), self.screen.width))
            sizes = {}

            def width(word):
                if word not in sizes:
                    widget.setText(native(word))
                    sizes[word] = int(inst.calculateSize().width())
                return sizes[word]

            space = max(1, width(u"ا ا") - 2 * width(u"ا"))
            if limit <= 40 or width(u"ا") <= 0:
                raise ValueError("no measure")
            lines = []
            for paragraph in text.split(u"\n"):
                words = paragraph.split()
                if not words:
                    continue
                cur, used = [], 0
                for word in words:
                    need = width(word) + (space if cur else 0)
                    if cur and used + need > limit:
                        lines.append(u" ".join(cur))
                        cur, used = [word], width(word)
                    else:
                        cur.append(word)
                        used += need
                if cur:
                    lines.append(u" ".join(cur))
            return u"\n".join(lines)
        except Exception:
            import textwrap
            out = []
            for paragraph in text.split(u"\n"):
                out.extend(textwrap.wrap(paragraph, fallback_chars, break_long_words=False, break_on_hyphens=False))
            return u"\n".join(out)

    # ---------------------------------------------------------------- public
    def show(self, text, box):
        key = (text, tuple(box), self.screen.width)
        if key == self.key:
            # same text in the same place: keep rolling where it is (the screen just re-drew the full text)
            if self.mode == "smooth":
                self._blank_label()
            elif self.mode == "paged":
                self._show_window()
            return
        self.stop()
        self.key = key
        if not text:
            return
        x, y, w, h = layout.scaled(box, self.screen.width)
        if not self.broken and self._smooth(text, x, y, w, h):
            return
        self._paged(text, w, h)

    def stop(self):
        self.timer.stop()
        self.key = None
        if self.mode == "smooth":
            try:
                self.box.hide()
            except Exception:
                pass
        self.mode = None

    def close(self):
        self.stop()
        try:
            self.timer.close()
        except Exception:
            pass
        self.lab = None
        self.box = None

    # ---------------------------------------------------------------- smooth
    def _ensure(self):
        if self.box is not None and self.lab is not None:
            return True
        from enigma import eWidget, eLabel, gFont, gRGB, ePoint, eSize
        parent = getattr(self.screen, "instance", None)
        if parent is None:
            return False
        box = eWidget(parent)
        try:
            box.setTransparent(True)
        except Exception:
            pass
        lab = eLabel(box)
        lab.setFont(gFont(FONT, layout.pixel(self._size(), self.screen.width)))
        lab.setHAlign(eLabel.alignCenter)
        lab.setVAlign(eLabel.alignTop)
        lab.setForegroundColor(gRGB(COLOR))
        try:
            lab.setTransparent(True)
        except Exception:
            pass
        try:
            box.setZPosition(10)
        except Exception:
            pass
        lab.move(ePoint(0, 0))
        box.hide()
        self.box, self.lab = box, lab
        return True

    def _size(self):
        from .screen import LABELS
        return LABELS[self.label][0]

    def _smooth(self, text, x, y, w, h):
        try:
            from enigma import ePoint, eSize
            if not self._ensure():
                return False
            self.box.move(ePoint(x, y))
            self.box.resize(eSize(w, h))
            self.lab.resize(eSize(w, 8000))
            self.lab.setText(native(text))
            total = int(self.lab.calculateSize().height())
            if total <= h + 2:
                self.box.hide()
                return True              # fits: the normal label shows it, nothing rolls
            self.lab.resize(eSize(w, total + 8))
            self.lab.move(ePoint(0, 0))
            self.pos, self.max, self.phase = 0, total + 6 - h, "top"
            self._blank_label()
            self.box.show()
            self.lab.show()
            self.mode = "smooth"
            self.timer.start(START_HOLD, True)
            return True
        except Exception:
            self.broken = True
            try:
                self.box.hide()
            except Exception:
                pass
            return False

    def _blank_label(self):
        screen = self.screen
        try:
            screen[self.label].setText(native(u""))
            screen._widget_cache[(self.label, "value")] = u""
        except Exception:
            pass

    # ---------------------------------------------------------------- paged
    def _paged(self, text, w, h):
        widget = self.screen[self.label]
        inst = widget.instance
        try:
            widget.setText(native(u"ا"))
            line = max(1, int(inst.calculateSize().height()))
        except Exception:
            line = max(1, layout.pixel(self._size(), self.screen.width) * 5 // 3)
        self.lines = text.split(u"\n")
        self.window = max(1, int((h + 2) // line))
        self.first = 0
        self._show_window()
        if len(self.lines) > self.window:
            self.mode = "paged"
            self.timer.start(START_HOLD, True)
        else:
            self.mode = None

    def _show_window(self):
        shown = u"\n".join(self.lines[self.first:self.first + self.window])
        try:
            self.screen[self.label].setText(native(shown))
            self.screen._widget_cache[(self.label, "value")] = shown
        except Exception:
            pass

    # ---------------------------------------------------------------- timer
    def _tick(self):
        if self.mode == "smooth":
            self._tick_smooth()
        elif self.mode == "paged":
            self._tick_paged()

    def _tick_smooth(self):
        try:
            from enigma import ePoint
            if self.phase == "top":
                self.phase = "run"
                delay = STEP_MS
            elif self.phase == "run":
                step = max(1, int(round(self.screen.width / 1920.0)))
                self.pos = min(self.max, self.pos + step)
                self.lab.move(ePoint(0, -self.pos))
                if self.pos >= self.max:
                    self.phase = "end"
                    delay = END_HOLD
                else:
                    delay = STEP_MS
            else:
                self.pos = 0
                self.lab.move(ePoint(0, 0))
                self.phase = "top"
                delay = START_HOLD
        except Exception:
            # drop back to whole-line paging inside the normal label
            text, box, _width = self.key
            self.broken = True
            self.stop()
            self.key = (text, box, self.screen.width)
            x, y, w, h = layout.scaled(box, self.screen.width)
            self._paged(text, w, h)
            return
        self.timer.start(delay, True)

    def _tick_paged(self):
        last = max(0, len(self.lines) - self.window)
        if self.first >= last:
            self.first = 0
            delay = START_HOLD
        else:
            self.first += 1
            delay = END_HOLD if self.first >= last else LINE_MS
        self._show_window()
        self.timer.start(delay, True)
