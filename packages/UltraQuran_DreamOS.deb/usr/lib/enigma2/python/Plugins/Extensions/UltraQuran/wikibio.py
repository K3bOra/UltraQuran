# -*- coding: utf-8 -*-
"""Full sheikh biographies from Arabic Wikipedia, fetched by the receiver itself the first time a sheikh's
page is opened, then kept on the hard drive (works offline afterwards).

Only an article whose title carries the sheikh's first and family name, and whose description or opening
says he is a reciter / imam / preacher / munshid, is used; otherwise the plugin keeps the biography it ships.
Text: Wikipedia contributors, CC BY-SA 4.0 (see NOTICE-Wikipedia.txt). Dates/places: Wikidata (CC0).
"""
from __future__ import absolute_import

import json
import os
import re
import threading
import time

from .support import log, storage_root

try:
    from urllib.parse import quote
    from urllib.request import Request, urlopen
except ImportError:  # Python 2 (DreamOS)
    from urllib import quote
    from urllib2 import Request, urlopen

try:
    unicode
except NameError:
    unicode = str

API = "https://ar.wikipedia.org/w/api.php?format=json&action=query&"
WIKIDATA = "https://www.wikidata.org/w/api.php?format=json&action=wbgetentities&"
UA = "UltraQuran/1.0.0 (Enigma2 plugin; https://github.com/K3bOra/UltraQuran)"
CACHE_NAME = "wiki-bios.json"
MAX_CHARS = 1600
RETRY_FAILED = 3 * 86400          # network trouble: try again after 3 days
RETRY_MISSING = 30 * 86400        # no matching article: look again after a month
SOURCE = u"ويكيبيديا العربية"

KEYWORDS = re.compile(u"قارئ|مقرئ|قراء|القرآن|قرآن|مبتهل|منشد|إنشاد|ابتهال|إمام|امام|خطيب|داعي|داعية|تلاوة|مؤذن|"
                      u"الأزهر|رجل دين|عالم دين|عالم مسلم|مفسر|تواشيح|فقيه|محدث|واعظ")
SECTION_OK = re.compile(u"نشأ|حياة|حياته|سيرة|سيرته|مسير|تعليم|دراسة|القرآن|إذاع|وفات|أعمال|رحل|مكان|حفظ|بداي|"
                        u"شيوخ|تلاوات|ابتهال|إنشاد|عمل|وظائف|مناصب|إمامة|تكريم|جوائز|أوسمة")
SECTION_SKIP = re.compile(u"مراجع|مصادر|وصلات|انظر|روابط|هوامش|ملاحظات|معرض|قائمة|تسجيلات|الإصدارات")
PAREN_OK = re.compile(u"قارئ|مقرئ|منشد|مبتهل|مؤذن|إمام|امام|قراء")
HARAKAT = re.compile(u"[\u0610-\u061a\u064b-\u065f\u0670\u06d6-\u06ed]")
MONTHS = [u"يناير", u"فبراير", u"مارس", u"أبريل", u"مايو", u"يونيو", u"يوليو", u"أغسطس", u"سبتمبر", u"أكتوبر",
          u"نوفمبر", u"ديسمبر"]


def _text(value):
    if isinstance(value, bytes):
        return value.decode("utf-8", "ignore")
    return value if isinstance(value, unicode) else unicode(value)


def norm(text):
    text = HARAKAT.sub(u"", _text(text or u""))
    text = re.sub(u"[أإآٱ]", u"ا", text)
    text = text.replace(u"ة", u"ه").replace(u"ى", u"ي").replace(u"ـ", u"")
    text = re.sub(u"عبد\\s+", u"عبد", text)
    text = re.sub(u"(^|\\s)ابو\\s+", u"\\1ابو", text)
    text = re.sub(u"[^\u0621-\u064a0-9 ]", u" ", text)
    return u" ".join(text.split())


STOP = set(norm(w) for w in u"الشيخ شيخ القارئ المقرئ فضيلة الإمام الامام الدكتور د المبتهل المنشد".split())


def name_tokens(name):
    name = re.sub(u"\\(.*?\\)", u" ", _text(name))
    return [t for t in norm(name).split() if t not in STOP and len(t) > 1]


def _strip_al(token):
    return token[2:] if token.startswith(u"ال") and len(token) > 4 else token


def title_matches(name, title):
    tokens = name_tokens(name)
    if not tokens:
        return False
    title = _text(title)
    if u"توضيح" in title:
        return False
    paren = re.findall(u"\\((.*?)\\)", title)
    if paren and not any(PAREN_OK.search(p) for p in paren):
        return False
    ttoks = [_strip_al(t) for t in norm(re.sub(u"\\(.*?\\)", u" ", title)).split() if t not in STOP]
    if not ttoks:
        return False
    if len(tokens) == 1:
        return ttoks == [_strip_al(tokens[0])]
    return ttoks[0] == _strip_al(tokens[0]) and _strip_al(tokens[-1]) in ttoks[1:]


def clean(text):
    text = _text(text)
    text = re.sub(u"\\[[^\\]]{0,12}\\]", u"", text)
    text = re.sub(u"\\((?:بال|ب)?(?:الإنجليزية|الإنكليزية|اللاتينية|الفرنسية)[^)]*\\)", u"", text)
    text = re.sub(u"\\([^)\u0600-\u06ff]*[A-Za-z][^)\u0600-\u06ff]*\\)", u"", text)
    text = re.sub(u"\\(\\s*\\)", u"", text)
    text = HARAKAT.sub(u"", text)
    text = text.replace(u"\u200f", u"").replace(u"\u200e", u"").replace(u"\xa0", u" ")
    text = re.sub(u"\\s+([،.؛:])", u"\\1", text)
    return u" ".join(text.split())


def biography_from_extract(extract):
    """Lead + life sections of a plain-text extract (headings come as '== title ==')."""
    parts, total, keep = [], 0, True
    for raw in _text(extract).split(u"\n"):
        line = raw.strip()
        if not line:
            continue
        heading = re.match(u"^=+\\s*(.*?)\\s*=+$", line)
        if heading:
            head = heading.group(1)
            keep = bool(SECTION_OK.search(head)) and not SECTION_SKIP.search(head)
            continue
        if not keep:
            continue
        para = clean(line)
        if len(para) < 25:
            continue
        parts.append(para)
        total += len(para)
        if total >= MAX_CHARS:
            break
    text = u"\n".join(parts)
    if len(text) > MAX_CHARS + 200:
        cut = text[:MAX_CHARS + 200]
        end = max(cut.rfind(u"."), cut.rfind(u"؛"))
        text = cut[:end + 1] if end > MAX_CHARS // 2 else cut.rstrip() + u"…"
    return text


def _date(claims, prop):
    for claim in claims.get(prop, []):
        try:
            value = claim["mainsnak"]["datavalue"]["value"]
            m = re.match(r"([+-]\d+)-(\d\d)-(\d\d)", value["time"])
            year, month, day = int(m.group(1)), int(m.group(2)), int(m.group(3))
            precision = value.get("precision", 11)
            if precision >= 11 and month and day:
                return u"%d %s %dم" % (day, MONTHS[month - 1], year)
            if precision >= 10 and month:
                return u"%s %dم" % (MONTHS[month - 1], year)
            return u"%dم" % year
        except Exception:
            continue
    return None


def _item(claims, prop):
    for claim in claims.get(prop, []):
        try:
            return claim["mainsnak"]["datavalue"]["value"]["id"]
        except Exception:
            continue
    return None


def _get_json(url, timeout=12):
    from .portraits import _ssl_contexts
    last = None
    for ctx in _ssl_contexts():
        try:
            kwargs = {"timeout": timeout}
            if ctx is not None:
                kwargs["context"] = ctx
            resp = urlopen(Request(url, headers={"User-Agent": UA, "Accept": "application/json"}), **kwargs)
            try:
                return json.loads(resp.read(1024 * 1024).decode("utf-8"))
            finally:
                resp.close()
        except Exception as exc:
            last = exc
    raise last or IOError("no connection")


def _q(value):
    return quote(_text(value).encode("utf-8"))


def fetch(name):
    """{'summary', 'born', 'died', 'url', 'source'} for this sheikh, None when Wikipedia has no matching
    article; raises on network trouble."""
    query = u" ".join(name_tokens(name)) or _text(name)
    found = _get_json(API + "list=search&srlimit=6&srprop=snippet&srsearch=" + _q(query))
    hits = (found.get("query") or {}).get("search") or []
    titles = [h["title"] for h in hits if title_matches(name, h.get("title", u""))]
    if not titles:
        return None
    info = _get_json(API + "prop=description|pageprops|extracts&exintro=1&explaintext=1&exlimit=6&redirects=1&titles="
                     + _q(u"|".join(titles[:5])))
    pages = list(((info.get("query") or {}).get("pages") or {}).values())
    chosen = None
    for title in titles:
        for page in pages:
            if page.get("title") != title:
                continue
            check = (page.get("description") or u"") + u" " + (page.get("extract") or u"")[:400]
            if KEYWORDS.search(check):
                chosen = page
                break
        if chosen:
            break
    if chosen is None:
        return None
    title = chosen["title"]
    full = _get_json(API + "prop=extracts&explaintext=1&exsectionformat=wiki&redirects=1&titles=" + _q(title))
    page = list(((full.get("query") or {}).get("pages") or {}).values())
    summary = biography_from_extract(page[0].get("extract", u"") if page else u"")
    if len(summary) < 200:
        return None
    bio = {"summary": summary, "source": SOURCE,
           "url": u"https://ar.wikipedia.org/wiki/" + _text(title).replace(u" ", u"_")}
    qid = (chosen.get("pageprops") or {}).get("wikibase_item")
    if qid:
        try:
            ent = _get_json(WIKIDATA + "props=claims&ids=" + qid)["entities"][qid]["claims"]
            born, died = _date(ent, "P569"), _date(ent, "P570")
            place_id = _item(ent, "P19")
            place = None
            if place_id:
                labels = _get_json(WIKIDATA + "props=labels&languages=ar&ids=" + place_id)
                place = labels["entities"][place_id].get("labels", {}).get("ar", {}).get("value")
            if born or place:
                bio["born"] = u" · ".join(x for x in (born, place) if x)
            if died:
                bio["died"] = died
            elif born:
                bio["died"] = u"حفظه الله"
        except Exception:
            pass
    return bio


class WikiBios(object):
    """Hard-drive cache + one background worker. get() never blocks; on_ready() is called (from the worker)
    when a new biography arrived."""

    def __init__(self, on_ready=None):
        self.on_ready = on_ready
        self.path = os.path.join(storage_root(), CACHE_NAME)
        self.lock = threading.Lock()
        self.data = None
        self.queue = []
        self.busy = False

    def _load(self):
        if self.data is None:
            try:
                with open(self.path) as handle:
                    self.data = json.load(handle)
            except Exception:
                self.data = {}
        return self.data

    def _save(self):
        try:
            tmp = self.path + ".tmp"
            with open(tmp, "w") as handle:
                json.dump(self.data, handle)
            os.rename(tmp, self.path)
        except Exception:
            pass

    def get(self, key):
        entry = self._load().get(str(key))
        if entry and entry.get("summary"):
            return entry
        return None

    def request(self, key, name, shipped=None):
        """Fetch in the background unless the shipped biography is already a full Wikipedia one, it is
        cached, or it was looked up recently."""
        key = str(key)
        if not name or (shipped and shipped.get("source") == SOURCE):
            return
        with self.lock:
            entry = self._load().get(key)
            now = time.time()
            if entry:
                if entry.get("summary"):
                    return
                wait = RETRY_MISSING if entry.get("missing") else RETRY_FAILED
                if now - entry.get("at", 0) < wait:
                    return
            if key in [k for k, _ in self.queue]:
                return
            self.queue.append((key, name))
            if self.busy:
                return
            self.busy = True
        worker = threading.Thread(target=self._work)
        worker.daemon = True
        worker.start()

    def _work(self):
        while True:
            with self.lock:
                if not self.queue:
                    self.busy = False
                    return
                key, name = self.queue.pop(0)
            try:
                bio = fetch(name)
                entry = dict(bio, at=time.time()) if bio else {"missing": 1, "at": time.time()}
            except Exception as exc:
                log("wiki bio %s: %r" % (key, exc))
                entry = {"failed": 1, "at": time.time()}
            with self.lock:
                self._load()[key] = entry
                self._save()
            if entry.get("summary") and self.on_ready is not None:
                try:
                    self.on_ready()
                except Exception:
                    pass
