# -*- coding: utf-8 -*-
import io
import json
import os
import re
import threading
import textwrap

from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
from Screens.Screen import Screen
from enigma import addFont, ePoint, eSize, getDesktop
try:
    from enigma import gFont
except ImportError:
    gFont = None

from . import VERSION, layout
from .catalog import Catalog, format_seconds, hijri_today, strip_duration
from .downloader import DownloadManager
from .mushaf import MushafManager, find_mushaf_dir
from .player import Audio, PTS
from .portraits import PortraitManager
from .scroller import BioScroller
from . import fastlink
from .wikibio import WikiBios, SOURCE as WIKI_SOURCE
from .videos import VideoFinder
from .support import ROOT, Timer, text_width_pad, art_ready, ensure_art_for_width, load_favorites, log, log_exception, native, save_favorites

IMAGES = (
    ("backdrop", "background", "focus", "portrait", "page", "mframe", "pmark_r", "pmark_l",
     "dlg", "dlg_row0", "dlg_row1", "dlg_row2", "dlg_focus")
    + tuple("poster%d" % i for i in range(layout.POSTER_PAGE_SIZE))
    + tuple("ecard%d" % i for i in range(layout.ECARD_PAGE_SIZE))
    + tuple("scard%d" % i for i in range(layout.SURA_PAGE_SIZE))
    + tuple("lcard%d" % i for i in range(layout.LIB_PAGE_SIZE))
)

IMAGE_SET = frozenset(IMAGES)

LABELS = {
    "title": (40, "right"), "sub": (18, "right"),
    "panel": (24, "center"), "p_meta": (16, "center"),
    "p_source": (16, "center"), "p_mode": (16, "center"),
    "p_reciter": (19, "center"), "info": (16, "center"),
    "status": (16, "center"), "elapsed": (16, "right"), "duration": (16, "left"),
    "control": (18, "center"), "queue": (16, "center"), "p_info": (15, "center"),
    "dl_status": (15, "center"), "count": (17, "center"),
    "bio_name": (22, "center"), "bio_born": (15, "center"), "bio_died": (15, "center"),
    "bio_heading": (17, "center"), "bio_text": (16, "center"), "bio_source": (15, "center"),
    "bio_recordings": (16, "center"), "bio_riwayas": (16, "center"),
    "gallery_page": (21, "center"), "notice": (22, "center"),
    "jump": (24, "center"), "mushaf_hint": (26, "center"),
    "mushaf_header": (22, "center"), "mushaf_body": (30, "center"), "mushaf_footer": (17, "center"),
    "lib_badge": (17, "center"), "lib_heading": (19, "center"),
    "lib_body": (22, "right"), "lib_action": (17, "center"),
    "v_title": (32, "center"), "v_queue": (16, "right"),
    "mushaf_surah": (30, "center"), "mushaf_juz": (19, "center"), "mushaf_page": (84, "center"), "mushaf_state": (16, "center"), "mushaf_tafsir": (20, "right"),
}
# Information texts (left panels, player lines, hints) were too small on a TV: they get a bigger font and the
# plugin shrinks one back step by step only when its text would not fit its box (never below FIT_FLOOR).
BIGGER = {"status": 20, "elapsed": 20, "duration": 20, "p_meta": 19, "p_source": 19, "p_mode": 19, "queue": 19,
          "p_info": 19, "dl_status": 18, "info": 19, "control": 20, "count": 19,
          "bio_born": 18, "bio_died": 18, "bio_heading": 20, "bio_text": 19, "bio_source": 18,
          "bio_recordings": 19, "bio_riwayas": 19, "lib_badge": 19, "lib_heading": 21, "lib_action": 20,
          "mushaf_state": 18, "mushaf_juz": 21}
BIGGER.update({"lib_body": 24, "sub": 20, "mushaf_footer": 19, "v_queue": 18, "mushaf_tafsir": 21})
FIT_FLOOR = dict((name, LABELS[name][0]) for name in BIGGER)
BIO_CHARS = 33      # biography line length in the 416-wide box
LINE_HEIGHT = 1.88  # Cairo's line (ascender + descender) in font sizes
BIO_VIEWS = ("reciter_hub", "editions", "reciter_videos", "shaarawy", "shaarawy_folders")
# long texts with their own paging / scrolling: never cut
NO_FIT = frozenset(("mushaf_body", "lib_body", "mushaf_tafsir", "mushaf_page", "bio_text", "home_ayah2"))
for _name, _size in BIGGER.items():
    LABELS[_name] = (_size, LABELS[_name][1])
LABELS.update({"top_elapsed": (20, "right"), "top_remain": (20, "left")})
LABELS.update({"home_clock": (54, "right"), "home_ayah": (34, "center"), "home_ayah2": (30, "center"), "home_ayah_ref": (18, "center"), "home_resume_cap": (18, "center"),
               "home_resume_title": (25, "center"), "home_resume_sub": (21, "center"), "home_resume_hint": (17, "center"),
               "home_date": (28, "right"), "home_desc": (21, "right")})
for _name, _floor in (("gallery_page", 16), ("home_ayah", 19), ("home_resume_title", 19), ("home_desc", 17), ("home_date", 22), ("home_resume_sub", 17), ("home_resume_hint", 15)):
    FIT_FLOOR[_name] = _floor
LABELS.update({"dlg_title": (28, "center"), "dlg_sub": (19, "center"),
               "dlg_opt0": (22, "center"), "dlg_opt1": (22, "center"), "dlg_opt2": (22, "center")})
LABELS.update({"card%d" % i: (17, "center") for i in range(layout.POSTER_PAGE_SIZE)})
LABELS.update({"ecard_title%d" % i: (22, "center") for i in range(layout.ECARD_PAGE_SIZE)})
LABELS.update({"ecard_meta%d" % i: (17, "center") for i in range(layout.ECARD_PAGE_SIZE)})
LABELS.update({"ecard_num%d" % i: (27, "center") for i in range(layout.ECARD_PAGE_SIZE)})
LABELS.update({"ecard_badge%d" % i: (21, "center") for i in range(layout.ECARD_PAGE_SIZE)})
LABELS.update({"deck_badge%d" % i: (27, "center") for i in range(3)})
LABELS.update({"row%d" % i: (23, "center") for i in range(layout.SURA_PAGE_SIZE)})
LABELS.update({"radio_row%d" % i: (19, "center") for i in range(layout.SURA_PAGE_SIZE)})
LABELS.update({"number%d" % i: (25, "center") for i in range(layout.SURA_PAGE_SIZE)})
LABELS.update({"detail%d" % i: (17, "center") for i in range(layout.SURA_PAGE_SIZE)})
# card names: big, shrunk only as far as needed for the whole name to fit (two lines)
for _prefix, _count, _floor in (("row", layout.SURA_PAGE_SIZE, 18), ("radio_row", layout.SURA_PAGE_SIZE, 16),
                                ("ecard_title", layout.ECARD_PAGE_SIZE, 17)):
    for _i in range(_count):
        FIT_FLOOR["%s%d" % (_prefix, _i)] = _floor
LABELS.update({"radio_row%d" % i: (21, "center") for i in range(layout.SURA_PAGE_SIZE)})
# small card captions one step bigger (shrunk back only when a caption would not fit its capsule)
for _prefix, _count, _big in (("detail", layout.SURA_PAGE_SIZE, 19), ("ecard_meta", layout.ECARD_PAGE_SIZE, 19),
                              ("card", layout.POSTER_PAGE_SIZE, 19)):
    for _i in range(_count):
        _key = "%s%d" % (_prefix, _i)
        FIT_FLOOR[_key] = LABELS[_key][0]
        LABELS[_key] = (_big, LABELS[_key][1])

REGISTERED = False
# calm palette (kept in sync with devtools/gen_art.py)
COLOR_TEXT = "#eee8d6"
COLOR_SOFT = "#9ec6b8"
COLOR_GOLD = "#f4d896"
COLOR_MINT = "#76c4a4"
COLOR_TRACK = "#14302d"
PHOTO_IDS = set()
LIB_PAGE_MS = 16000
SHAARAWY_NAME = u"الشيخ محمد متولي الشعراوي"


TASHKEEL = re.compile(u"[\u0610-\u061a\u064b-\u065f\u0670\u06d6-\u06ed]")


AYAH_ONE_LINE = 42   # up to here one line is bigger (31-34) than two lines would be (26-30)
AYAH_TWO_MAX = 30    # biggest size of a two-line ayah
AYAH_PITCH = 1.42    # distance between the two ayah lines, in font sizes (the font's own 1.88 leaves a hole)


def ayah_lines(text):
    """Ayah of the day: a short ayah stays one line; a longer one is split by us into two balanced, centred lines
    (the first a little longer), because the receiver's own wrapping can leave a single word on the first line."""
    words = (text or u"").split()
    if len(text or u"") <= AYAH_ONE_LINE or len(words) < 2:
        return text
    best = None
    for i in range(1, len(words)):
        first, second = u" ".join(words[:i]), u" ".join(words[i:])
        score = max(len(first), len(second)) + (0.5 if len(first) < len(second) else 0)
        if best is None or score < best[0]:
            best = (score, first, second)
    return best[1] + u"\n" + best[2]


def plain(text):
    """Arabic without harakat: Enigma2 cannot position combining marks (they come out as loose
    glyphs between the letters), so labels it draws itself get clean undecorated text."""
    return TASHKEEL.sub(u"", text or u"")


def collect_media(node):
    """Every downloadable (non-live) audio/video item inside a folder, at any depth."""
    out = []
    stack = [node]
    while stack:
        cur = stack.pop()
        kids = list(cur.get("children") or []) + list(cur.get("folders") or []) + list(cur.get("items") or [])
        if kids:
            stack.extend(reversed(kids))
        elif cur.get("audio") and not cur.get("live") and "qurango.net/radio" not in cur.get("audio", u""):
            out.append(cur)
    return out


def skin(width, height, art_dir=None):
    widgets = []
    for name in IMAGES:
        # background at -4; cards and portraits at 1; the single focus pointer at 2
        z = -5 if name == "backdrop" else -4 if name == "background" else 2 if name == "focus" else 3 if name.startswith("pmark") else 4 if name == "mframe" else 1
        if name.startswith("dlg"):
            z = 28 if name == "dlg_focus" else 27 if name.startswith("dlg_row") else 26
        widgets.append('<widget name="%s" position="0,0" size="1,1" alphatest="blend" zPosition="%d" />' % (name, z))
    for name, (size, alignment) in LABELS.items():
        props = 'transparent="1" foregroundColor="%s"' % COLOR_TEXT
        z = 10
        if name in ("count", "info", "sub", "bio_born", "bio_died", "bio_source", "p_info"):
            props = 'transparent="1" foregroundColor="%s"' % COLOR_SOFT
        if name.startswith(("number", "ecard_num")):
            props = 'transparent="1" foregroundColor="%s"' % COLOR_GOLD
        if name.startswith(("ecard_badge", "deck_badge")) or name in ("lib_heading", "lib_action", "status", "p_reciter", "p_mode"):
            props = 'transparent="1" foregroundColor="%s"' % COLOR_GOLD
        if name.startswith(("detail", "ecard_meta")) or name in ("bio_heading", "dl_status", "p_meta", "p_source", "lib_badge"):
            props = 'transparent="1" foregroundColor="%s"' % COLOR_MINT
        if name in ("notice", "jump"):
            props = 'transparent="0" backgroundColor="#0c2a28" foregroundColor="%s"' % COLOR_GOLD
            z = 30
        if name in ("home_ayah", "home_ayah2", "home_resume_cap", "home_clock", "home_date", "gallery_page"):
            props = 'transparent="1" foregroundColor="%s"' % COLOR_GOLD
        if name in ("home_ayah_ref", "home_resume_sub", "home_desc"):
            props = 'transparent="1" foregroundColor="%s"' % COLOR_MINT
        if name == "home_resume_hint":
            props = 'transparent="1" foregroundColor="%s"' % COLOR_SOFT
        if name.startswith("dlg_"):
            z = 31
            color = COLOR_GOLD if name == "dlg_title" else COLOR_SOFT if name == "dlg_sub" else COLOR_TEXT
            props = 'transparent="1" foregroundColor="%s"' % color
        if name == "mushaf_surah":
            props = 'transparent="1" foregroundColor="%s"' % COLOR_GOLD
        if name == "mushaf_juz":
            props = 'transparent="1" foregroundColor="%s"' % COLOR_MINT
        if name == "mushaf_state":
            props = 'transparent="1" foregroundColor="%s"' % COLOR_SOFT
        if name == "mushaf_tafsir":
            props = 'transparent="1" foregroundColor="#e8e2cc"'
        if name == "mushaf_hint":
            props = 'transparent="1" foregroundColor="#3a5a52"'
            z = 12
        if name == "mushaf_header":
            props = 'transparent="1" foregroundColor="#0c3b2e"'
            z = 12
        if name == "mushaf_body":
            props = 'transparent="1" foregroundColor="#142622"'
            z = 12
        if name == "mushaf_footer":
            props = 'transparent="1" foregroundColor="#5a4628"'
            z = 12
        vertical = "top" if name in ("mushaf_body", "mushaf_tafsir") else "center"
        widgets.append('<widget name="%s" position="0,0" size="1,1" font="UltraQuranUI;%d" '
                       'halign="%s" valign="%s" zPosition="%d" %s />' %
                       (name, max(6, layout.pixel(size, width)), alignment, vertical, z, props))
    # one flat bar: the track colour equals the rail baked into the artwork, so only ONE bar is ever visible
    # The bar is drawn by the plugin itself: a dark track label and a gold fill label whose WIDTH is set from the
    # position. Receivers' own progress widgets ignored the 0..1000 range on some images (bar full at 14 %).
    widgets.append('<widget name="progress" position="0,0" size="1,1" zPosition="15" font="UltraQuranUI;8" '
                   'transparent="0" backgroundColor="%s" foregroundColor="%s" />' % (COLOR_TRACK, COLOR_TRACK))
    # 'laser' fill (Ultra Stalker New 2 style): an image of the whole track, NOT scaled - the widget is only
    # made as wide as the played part, so the left part of the colour run shows
    widgets.append('<widget name="progress_fill" position="0,0" size="1,1" zPosition="16" alphatest="blend" transparent="1" />')
    # now-playing strip in the top bar (other screens): its own track + fill, so it never fights a screen's bar
    widgets.append('<widget name="top_track" position="0,0" size="1,1" zPosition="15" font="UltraQuranUI;8" '
                   'transparent="0" backgroundColor="#2c4c45" foregroundColor="#2c4c45" />')
    widgets.append('<widget name="top_fill" position="0,0" size="1,1" zPosition="16" alphatest="blend" transparent="1" />')
    # #ff000000 is transparent in Enigma2 ARGB so full-screen video plane is visible in 'video' view,
    # while all other views cover (0,0,1920,1080) with the opaque 'background' pixmap.
    return ('<screen name="UltraQuran" position="center,center" size="%d,%d" flags="wfNoBorder" '
            'backgroundColor="#ff000000" title="Ultra Quran">%s</screen>' %
            (width, height, "".join(widgets)))


def find_mushaf(media_root="/media"):
    return find_mushaf_dir(media_root)


def wrap(text, limit, max_lines=None):
    lines = []
    for paragraph in (text or u"").splitlines():
        if not paragraph.strip():
            if lines and lines[-1] != u"":
                lines.append(u"")
        else:
            lines.extend(textwrap.wrap(paragraph, limit, break_long_words=False, break_on_hyphens=False))
    if max_lines is not None and len(lines) > max_lines:
        lines = lines[:max_lines]
    return u"\n".join(lines)


def shorten(text, limit):
    """text cut to at most limit characters: at a " · " part when one ends late enough (no "…" needed, the
    shown part is whole), otherwise at a word with "…"."""
    if len(text) <= limit:
        return text
    head = text[:limit + 1]
    sep = head.rfind(u" · ")
    if sep >= max(4, int(limit * 0.35)):
        return head[:sep].rstrip(u" ·-،,:")
    cut = text[:max(1, limit - 1)]
    space = cut.rfind(u" ")
    if space > max(3, int(len(cut) * 0.4)):
        cut = cut[:space]
    return cut.rstrip(u" ·-،,:") + u"…"


def one_line(text, limit):
    text = u" ".join((text or u"").splitlines()).strip()
    if len(text) <= limit:
        return text
    return text[:limit - 1].rstrip() + u"…"


def card_title(text):
    """Library card title -> (label, shown text, extra) so a title never wraps or gets clipped.

    Long "title · sheikh" strings are split at the dot: the title stays on one line and the
    remainder moves to the meta capsule. Titles over 30 letters use the smaller one-line label."""
    text = u" ".join((text or u"").splitlines()).strip()
    extra = u""
    if len(text) > 30 and u" · " in text:
        text, extra = [part.strip() for part in text.split(u" · ", 1)]
    if len(text) <= 30:
        return "row", text, extra
    return "radio_row", one_line(text, 44), extra


def balanced_wrap(text, per_line=52):
    """Wrap a short paragraph into evenly filled lines (no lonely last word)."""
    text = u" ".join((text or u"").split())
    count = max(1, -(-len(text) // per_line))
    limit = -(-len(text) // count) + 4
    return textwrap.wrap(text, limit, break_long_words=False, break_on_hyphens=False) or [u""]


def grid_step(index, count, cols, direction):
    """Circular cursor movement for RTL grids (left = next, right = previous, down = next row).

    * left on the last item wraps to the first, right on the first wraps to the last;
    * down from the last row goes back to the first row (the last item goes straight to the first);
    * up from the first row goes to the last row / last item;
    * when the last row is incomplete, down from the row above lands on the last item.
    """
    if count <= 0:
        return 0
    last = count - 1
    if direction == "left":
        return 0 if index >= last else index + 1
    if direction == "right":
        return last if index <= 0 else index - 1
    if direction == "down":
        target = index + cols
        if target <= last:
            return target
        if index == last or index // cols == last // cols:
            return 0 if index == last else index % cols
        return last
    if direction == "up":
        target = index - cols
        if target >= 0:
            return target
        wrapped = (last // cols) * cols + index % cols
        return wrapped if wrapped <= last else last
    return index


class Route(object):
    def __init__(self, name, items=(), key=None, index=0, folder_title=None):
        self.name, self.items, self.key, self.index = name, items, key, index
        self.folder_title = folder_title
        self.scroll = 0
        self.question_index = 0
        self.score = 0
        self.answered = None
        self.filter_mode = "all"
        self.owner_name = None
        self.all_items = list(items) if name == "shaarawy" else None


class UltraQuran(Screen):
    def createSummary(self):
        from .frontpanel import UltraQuranFrontSummary
        return UltraQuranFrontSummary

    def __init__(self, session):
        global REGISTERED
        desktop = getDesktop(0).size()
        self.width, self.height = next(
            ((w, h) for w, h in layout.SIZES if desktop.width() >= w and desktop.height() >= h),
            layout.SIZES[-1])
        if not REGISTERED:
            path = os.path.join(ROOT, "fonts", "Cairo-SemiBold.ttf")
            try:
                addFont(native(path), "UltraQuranUI", 100, 0, 0)
            except TypeError:
                addFont(native(path), "UltraQuranUI", 100, 0)
            REGISTERED = True
        wanted_width = self.width
        if art_ready(self.width) is None:
            # e.g. a 4K (3840) skin: prepare its artwork in the background and open now at the
            # nearest shipped size, so the receiver never freezes on first launch
            wanted = self.width
            worker = threading.Thread(target=ensure_art_for_width, args=(wanted,))
            worker.daemon = True
            worker.start()
            self.width, self.height = next(((w, h) for w, h in layout.SIZES if w <= wanted and art_ready(w)), (1920, 1080))
        self.art = ensure_art_for_width(self.width)
        try:
            from .portraits import remember_width
            remember_width(wanted_width)
        except Exception:
            pass
        self.skin = skin(self.width, self.height, self.art)
        Screen.__init__(self, session)
        self.scale_art = False
        self.catalog = Catalog()
        self.favorites = load_favorites(self.catalog)
        self.stack = [Route("home")]
        self.mushaf_page = 1
        self.mushaf_subpage = 0
        self.tafsir_sub = 0
        self.mushaf_subpages = 1
        self.mushaf_mode = "image"
        self.mushaf_half = 0
        self.tafsir_sub = 0
        self.repeat = False
        self.jump_buffer = None
        self.tasbih_counts = {}
        self.measured_durations = {}
        self.playing_items = None
        self.playing_index = None
        self.video_osd_visible = True
        self._shown_widgets = set()
        self._widget_cache = {}
        self.notice = Timer(self.hide_notice)
        self.jump_timer = Timer(self.commit_jump)
        self.portrait_timer = Timer(self.refresh_portraits)
        self.warm_timer = Timer(self.warm_portraits)
        self.download_timer = Timer(self.refresh_downloads)
        self.sync_timer = Timer(self.periodic_sync)
        self.video_osd_timer = Timer(self.auto_hide_video_osd)
        self.lib_timer = Timer(lambda: self.lib_turn(1, True))
        self.lib_page = 0
        self.lib_pages = 1
        self.lib_page_key = None
        self.portraits = PortraitManager(self.width, on_ready=self.schedule_portrait_refresh)
        names = dict((entry[0], entry[1]) for entry in self.catalog.all_figures)
        names[999] = SHAARAWY_NAME
        self.portraits.names = names
        self.video_timer = Timer(self.refresh_videos)
        self.catalog.video_finder = VideoFinder(on_ready=self.schedule_video_refresh)
        self.downloader = DownloadManager(self.catalog, on_update=self.schedule_download_refresh)
        self.mushaf_timer = Timer(self.refresh_mushaf)
        self.update_timer = Timer(self.poll_update)
        self.mushaf = MushafManager(on_update=self.schedule_mushaf_refresh)
        self.mushaf.display_width = self.width
        self.audio = None
        self.dialog = None
        self._mini_hint_owner = False
        self.lib_durations = {}
        self.lib_route = None
        self.lib_indices = []
        self.bio_scroll = BioScroller(self, "bio_text")
        self.bio_open = False
        self.bio_timer = Timer(self.refresh_bio)
        self.wiki_bios = WikiBios(on_ready=self.schedule_bio_refresh)

        for name in IMAGES:
            self[name] = Pixmap()
        for name in LABELS:
            self[name] = Label()
        self["progress"] = Label("")
        self["progress_fill"] = Pixmap()
        self["top_track"] = Label("")
        self["top_fill"] = Pixmap()
        self._progress_value = 0.0
        self._progress_box = None

        actions = {
            "left": lambda: self.move("left"), "right": lambda: self.move("right"),
            "up": lambda: self.move("up"), "down": lambda: self.move("down"),
            "ok": self.accept, "cancel": self.back,
            "red": self.red, "yellow": self.yellow, "green": self.green, "blue": self.blue,
            "chplus": lambda: self.page_step(1), "chminus": lambda: self.page_step(-1),
            "nextBouquet": lambda: self.page_step(1), "prevBouquet": lambda: self.page_step(-1),
            "bouquet_up": lambda: self.page_step(1), "bouquet_down": lambda: self.page_step(-1),
            "pageUp": lambda: self.page_step(-1), "pageDown": lambda: self.page_step(1),
            "moveDown": lambda: self.page_step(1), "moveUp": lambda: self.page_step(-1),
        }
        for digit in range(10):
            actions[str(digit)] = lambda digit=digit: self.number(digit)
        self["navigation"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions", "NumberActions", "ChannelSelectBaseActions"],
            {key: self.guard(fn, key) for key, fn in actions.items()}, -3)
        self["media"] = ActionMap(["InfobarSeekActions"], {
            "playpauseService": self.guard(self.play_control),
            "pauseService": self.guard(self.play_control),
        }, -2)
        self["media"].setEnabled(False)
        self["bio_keys"] = ActionMap(["EPGSelectActions", "InfobarEPGActions", "InfobarActions"], {
            "info": self.guard(self.toggle_bio), "showEventInfo": self.guard(self.toggle_bio),
            "showEventInfoPlugin": self.guard(self.toggle_bio), "epg": self.guard(self.toggle_bio),
        }, -2)
        self.onLayoutFinish.append(self.layout_finished)
        self.onClose.append(self.cleanup)

    @property
    def route(self):
        return self.stack[-1]

    @property
    def is_playing_view(self):
        return self.route.name in ("surahs", "radios", "favorites", "library", "shaarawy", "shaarawy_folders", "video")

    def guard(self, function, key=None):
        def call():
            try:
                if key is not None and getattr(self, "dialog", None):
                    self.dialog_key(key)
                    return
                function()
            except Exception:
                log_exception("Interface action failed")
                self.flash(u"تعذّر تنفيذ الأمر")
            self._prefetch_focus()
        return call

    def _prefetch_focus(self):
        """Resolve, in the background, the link of the focused recording / video and of the next track, so
        OK (or the automatic next track) starts without waiting for the server's redirect."""
        try:
            route = self.route
            urls = []
            item = None
            items = route.items or []
            if items and 0 <= route.index < len(items):
                item = items[route.index]
                if route.name in ("surahs", "favorites") and isinstance(item, tuple) and item[0] is not None:
                    urls.append(self.catalog.track(item)[3])
                elif route.name in ("shaarawy", "library", "reciter_videos") and isinstance(item, dict):
                    urls.append(item.get("audio"))
                elif route.name == "video" and route.index + 1 < len(items):
                    urls.append(items[route.index + 1].get("audio"))
            playing = self.playing_items
            if playing and self.playing_index is not None and self.playing_index + 1 < len(playing):
                following = playing[self.playing_index + 1]
                if following[0] is not None:
                    urls.append(self.catalog.track(following)[3])
            for url in urls:
                if url and not (isinstance(item, dict) and item.get("live")):
                    fastlink.prefetch(url)
        except Exception:
            pass

    def schedule_portrait_refresh(self):
        try:
            self.portrait_timer.start(150, True)
        except Exception:
            pass

    def refresh_portraits(self):
        ready = self.portraits.pop_ready()
        if ready and self.route.name in ("gallery", "editions", "shaarawy", "shaarawy_folders", "video", "surahs", "favorites",
                                          "reciter_hub", "reciter_videos"):
            self.render()

    def schedule_bio_refresh(self):
        try:
            self.bio_timer.start(200, True)
        except Exception:
            pass

    def refresh_bio(self):
        if self.route.name in BIO_VIEWS:
            self.render()

    def reciter_bio(self, reciter_id, name=None, shipped=None):
        """The shipped biography, replaced by the full Arabic Wikipedia one once the receiver has fetched it."""
        if shipped is None:
            shipped = self.catalog.bios.get(reciter_id)
        wiki = self.wiki_bios
        if wiki is None:
            return shipped
        if shipped and (shipped.get("nowiki") or len(shipped.get("summary") or u"") >= 300):
            return shipped      # verified full biography: a look-alike Wikipedia article must never replace it
        if name is None:
            name = self.catalog.reciter[reciter_id][1] if reciter_id in self.catalog.reciter else u""
        cached = wiki.get(reciter_id)
        if cached is None:
            wiki.request(reciter_id, name, shipped)
            return shipped
        merged = dict(shipped or {})
        for key in ("summary", "source", "url", "born"):
            if cached.get(key):
                merged[key] = cached[key]
        died, known = cached.get("died"), merged.get("died", u"")
        generic = (not known) or known.startswith((u"معتمد", u"حفظه"))
        if died and (died != u"حفظه الله" or generic):
            merged["died"] = died           # Wikidata has no death date: never overwrite a known one with "alive"
        return merged

    def schedule_video_refresh(self):
        try:
            self.video_timer.start(200, True)
        except Exception:
            pass

    def refresh_videos(self):
        """Background video discovery finished: refresh the hub / video list if the sheikh is on screen."""
        finder = self.catalog.video_finder
        ready = finder.pop_ready() if finder is not None else []
        route = self.route
        if not ready or route.name not in ("reciter_hub", "reciter_videos") or route.key not in ready:
            return
        if route.name == "reciter_hub":
            route.items = self.catalog.reciter_hub_folders(route.key)
        else:
            route.items = self.catalog.reciter_videos(route.key)
            route.index = max(0, min(route.index, len(route.items) - 1))
        self.render()

    def schedule_download_refresh(self):
        try:
            self.download_timer.start(150, True)
        except Exception:
            pass

    def refresh_downloads(self):
        self.downloader.pop_updated()
        if self.route.name == "favorites":
            self.route.items = self.offline_and_favorites_list()
            self.route.index = max(0, min(self.route.index, max(0, len(self.route.items) - 1)))
        if self.route.name in ("editions", "surahs", "favorites", "shaarawy", "library", "reciter_videos", "reciter_hub", "gallery"):
            self.render()

    def schedule_mushaf_refresh(self):
        try:
            self.mushaf_timer.start(180, True)
        except Exception:
            pass

    def refresh_mushaf(self):
        self.mushaf.pop_updated()
        if self.route.name == "mushaf":
            self.render()

    def offline_and_favorites_list(self):
        combined = list(self.favorites)
        seen = set(combined)
        for item in self.downloader.all_downloaded_entries():
            if item not in seen:
                seen.add(item)
                combined.append(item)
        return combined

    def periodic_sync(self):
        """Main-thread periodic check so background portrait/MP3/Mushaf downloads always update the OSD."""
        try:
            self.refresh_videos()
            ready = self.portraits.pop_ready()
            dl_updated = self.downloader.pop_updated()
            mushaf_updated = self.mushaf.pop_updated()
            if dl_updated and self.route.name == "favorites":
                self.route.items = self.offline_and_favorites_list()
                self.route.index = max(0, min(self.route.index, max(0, len(self.route.items) - 1)))
            if (ready and self.route.name in ("gallery", "editions", "shaarawy", "shaarawy_folders", "video", "surahs", "favorites",
                                              "reciter_hub", "reciter_videos")) or (
                dl_updated and self.route.name in ("editions", "surahs", "favorites", "shaarawy", "library", "reciter_videos", "reciter_hub", "gallery")
            ) or (mushaf_updated and self.route.name == "mushaf"):
                self.render()
            elif self.route.name == "home" and getattr(self, "dialog", None) is None:
                self.render_home_hero()            # the clock in the date capsule
        except Exception:
            pass
        finally:
            try:
                self.sync_timer.start(1200, True)
            except Exception:
                pass

    WARM_IDS = [999, 950, 951, 952, 953, 954, 955, 956, 957, 958, 959, 960, 961, 962, 963, 964, 51, 112, 118, 241, 125, 121, 106, 9, 901, 902, 903, 904, 905, 906, 907, 908, 909, 910, 911, 912, 913, 914, 915, 916, 74, 54, 31, 102, 123, 30]

    def warm_portraits(self):
        """Prepare the first posters a moment after the screen is up (all disk / image work runs in a thread)."""
        try:
            self.portraits.request(self.WARM_IDS, background=True)
        except Exception:
            log_exception("Cannot warm the poster cache")

    def layout_finished(self):
        try:
            self._widget_cache.clear()
            self._shown_widgets.clear()
            self.warm_timer.start(2500, True)
            self.render()
            if self.audio is None:
                self.audio = Audio(self.session.nav, self.update_player, self.track_ended)
            self.sync_timer.start(1200, True)
            from .updater import UPDATER, configured
            if configured() and UPDATER.state == "idle":
                UPDATER.check(manual=False)            # quiet check once per session
                self.update_timer.start(1000, False)
        except Exception:
            log_exception("Cannot initialize the Ultra Quran screen")
            self.close()

    def place(self, name, box):
        position = layout.scaled(box, self.width)
        if name in IMAGE_SET:
            # artwork is pre-scaled from its own size, so the widget must match it pixel for pixel
            position = position[:2] + layout.scaled((0, 0, box[2], box[3]), self.width)[2:]
        if self._widget_cache.get((name, "box")) != position:
            x, y, w, h = position
            self[name].instance.move(ePoint(x, y))
            self[name].instance.resize(eSize(w, h))
            self._widget_cache[(name, "box")] = position
        if name not in self._shown_widgets:
            self[name].show()
            self._shown_widgets.add(name)
        if name == "progress":
            self._progress_box = box
            self._place_fill()

    def hide_widget(self, name):
        if name in self._shown_widgets:
            self[name].hide()
            self._shown_widgets.remove(name)
        if name == "progress":
            self.hide_widget("progress_fill")

    def hide(self, name=None):
        """Enigma2 Screen.doClose() calls self.hide() with 0 args; widget hiding passes name."""
        if name is None:
            return Screen.hide(self)
        self.hide_widget(name)

    def text(self, name, value, box):
        # Enigma2 cannot place Arabic combining marks (harakat come out loose between the letters):
        # every label it draws gets the plain letters
        value = plain(value) if name != "mushaf_body" else value
        changed = self._widget_cache.get((name, "value")) != value
        if changed:
            self[name].setText(native(value))
            self._widget_cache[(name, "value")] = value
        if name in LABELS and name not in NO_FIT:
            box = self._tall_enough(name, box)
        self.place(name, box)
        if name in LABELS and name not in NO_FIT:
            self._fit(name, value, box)

    @staticmethod
    def _tall_enough(name, box):
        """A label lower than one line of its font is grown evenly up and down: the receiver draws a line that
        is taller than its label from the label's top (so it sat low and lost its bottom), not centred."""
        x, y, w, h = box
        line = int(LABELS[name][0] * LINE_HEIGHT + 0.999) + 2
        if h >= line:
            return box
        grow = line - h
        return (x, y - grow // 2, w, h + grow)

    def _fit(self, name, value, box):
        """Largest font (from the bigger size down to the old size) whose text fits the label's box; when even
        the smallest size would wrap past the box (the TV then shows half a line or nothing), the text is cut
        at a word with "…" so every label always shows whole, readable lines."""
        key = (value, tuple(box))
        if self._widget_cache.get((name, "fit")) == key:
            return
        self._widget_cache[(name, "fit")] = key
        try:
            instance = self[name].instance
            if instance is None or not value:
                return
            w, h = layout.scaled(box, self.width)[2:]
            big = LABELS[name][0]
            floor = FIT_FLOOR.get(name, big)
            fits = None
            for size in range(big, floor - 1, -1):
                if gFont is not None and floor != big:
                    instance.setFont(gFont("UltraQuranUI", layout.pixel(size, self.width)))
                fits = self._fits_box(name, value, w, h)
                if fits:
                    break
            if not fits:
                shown = self._cut_to_box(name, value, w, h)
                if shown != value:
                    self[name].setText(native(shown))
        except Exception:
            pass

    def bio_text(self, value, box):
        """Sheikh biography box: the whole text, wrapped to the box; when it is longer than the box it rolls
        up slowly by itself (hold at the top, roll, hold at the end, back to the top), like Poster Grid 3."""
        source = plain(value or u"")
        key = (source, tuple(box))
        if self._widget_cache.get(("bio_text", "wrapped_for")) != key:
            self._widget_cache[("bio_text", "wrapped")] = self.bio_scroll.wrap(source, box, BIO_CHARS)
            self._widget_cache[("bio_text", "wrapped_for")] = key
            self._widget_cache.pop(("bio_text", "value"), None)     # measuring changed the label's text
        lines = self._widget_cache[("bio_text", "wrapped")]
        self.text("bio_text", lines, box)
        self.bio_scroll.show(lines, box)

    def _fits_box(self, name, value, w, h):
        """True when the label's current text (value) wraps inside w x h with its current font."""
        widget = self[name]
        instance = widget.instance
        widget.setText(native(u"ا"))
        line = instance.calculateSize().height()
        widget.setText(native(value))
        need = instance.calculateSize()
        wide = need.width() + (text_width_pad(LABELS[name][0] * self.width // 1920) if need.width() else 0)
        return wide <= w + 1 and need.height() <= max(h, line) + 1

    def _cut_to_box(self, name, value, w, h):
        lines = value.split(u"\n")
        for _ in range(len(lines)):
            text = u"\n".join(lines)
            if self._fits_box(name, text, w, h):
                return text
            longest = max(range(len(lines)), key=lambda i: len(lines[i]))
            source = lines[longest]
            lo, hi = 0, len(source) - 1
            while lo < hi:
                mid = (lo + hi + 1) // 2
                lines[longest] = shorten(source, mid)
                if self._fits_box(name, u"\n".join(lines), w, h):
                    lo = mid
                else:
                    hi = mid - 1
            lines[longest] = shorten(source, lo) if lo else u""
            lines = [line for line in lines if line] or [u"…"]
        text = u"\n".join(lines)
        self._fits_box(name, text, w, h)
        return text

    def play_marks(self, label, rect):
        """Two big gold chevrons on the card's bottom bar, hugging its text, for the item that is playing."""
        x, y, w, h = rect
        text_w = 90.0
        try:
            size = self[label].instance.calculateSize()
            measured = size.width() * 1920.0 / self.width
            if 4 < measured:
                text_w = min(w - 160, measured)
        except Exception:
            pass
        mw, mh, gap = layout.PMARK
        cx = x + w / 2.0
        right = int(min(cx + text_w / 2.0 + gap, x + w - mw - 34))
        left = int(max(cx - text_w / 2.0 - gap - mw, x + 34))
        top = int(y + (h - mh) / 2.0)
        self.image("pmark_r", "pmark-r", (right, top, mw, mh))
        self.image("pmark_l", "pmark-l", (left, top, mw, mh))
        self._pmark_owner = label

    def align_label(self, name, mode):
        """Runtime horizontal alignment of a label: 0 left, 1 centre, 2 right (ignored on images without setHAlign)."""
        if self._widget_cache.get((name, "halign")) == mode:
            return
        try:
            self[name].instance.setHAlign(mode)
            self._widget_cache[(name, "halign")] = mode
        except Exception:
            pass

    def image(self, name, key, box, external=False):
        path = key if external else os.path.join(self.art, key + ".png")
        self.place(name, box)
        if self._widget_cache.get((name, "value")) != path:
            instance = self[name].instance
            for method in ("setPixmapScale", "setScale"):
                scale = getattr(instance, method, None)
                if scale is not None:
                    try:
                        scale(1)
                        break
                    except Exception:
                        pass
            instance.setPixmapFromFile(native(path))
            self._widget_cache[(name, "value")] = path

    def reciter_card_image(self, widget_name, reciter_id, box):
        cached = self.portraits.cached_card_path(reciter_id)
        if cached:
            self.image(widget_name, cached, box, external=True)
            return
        self.portraits.request([reciter_id])
        fallback = self.portraits.fallback_card_path(reciter_id)
        if fallback:
            self.image(widget_name, fallback, box, external=True)
        else:
            self.image(widget_name, "grid3-reciter-default", box)

    def reciter_portrait_image(self, widget_name, reciter_id, box):
        cached = self.portraits.cached_portrait_path(reciter_id)
        if cached:
            self.image(widget_name, cached, box, external=True)
            return
        self.portraits.request([reciter_id])
        fallback = self.portraits.fallback_portrait_path(reciter_id)
        if fallback:
            self.image(widget_name, fallback, box, external=True)
        else:
            self.image(widget_name, "poster-default", box)

    def highlight(self, box, style, reciter_id=None):
        """The ONE focus pointer used everywhere: a thin warm-gold rounded outline (no glow, no colour changes)."""
        x, y, w, h = box
        m = layout.FOCUS_MARGIN
        self.image("focus", "focus-" + style, (x - m, y - m, w + 2 * m, h + 2 * m))

    def flash(self, value):
        self.text("notice", value, (480, 932, 960, 62))
        self.notice.start(3200)

    def hide_notice(self):
        self.hide_widget("notice")

    def open(self, route):
        self.cancel_jump()
        self.bio_open = False
        self.stack.append(route)
        self.render()

    def render(self):
        route = self.route
        if not self._shown_widgets:
            for key in IMAGES + tuple(LABELS) + ("progress", "progress_fill", "top_track", "top_fill"):
                self[key].hide()
        previous = self._shown_widgets.copy()
        self._shown_widgets.clear()
        view = route.name
        self["media"].setEnabled(self.is_playing_view or self.mini_player_active())

        if view == "video":
            self.render_video()
            for key in previous - self._shown_widgets:
                self[key].hide()
            self.bio_scroll.stop()
            return

        if view in ("home", "gallery", "editions", "shaarawy", "mushaf"):
            background = view
        elif view == "main_folders":
            background = "portal"
        elif view == "reciter_hub":
            background = "hub"
        elif view == "reciter_videos":
            background = "reciter"
        elif view == "shaarawy_folders":
            background = "hub-sh" if (self.shaarawy_root() or self.shaarawy_audio_root()) else "shaarawy"
        elif view == "library":
            background = "library"
        elif view == "quiz":
            background = "quiz"
        else:
            background = "list"
        self.image("backdrop", "bg", (0, 0, 1920, 1080))      # one shared page backdrop under every screen
        self.image("background", background, (0, 0, 1920, 1080))
        if view == "home":
            self.highlight(layout.HOME[route.index], "home")
            self._update_home_footer()
        elif view == "main_folders":
            self.render_main_folders()
        elif view == "gallery":
            self.gallery()
        elif view == "reciter_hub":
            self.render_reciter_hub()
        elif view == "editions":
            self.render_editions()
        elif view == "reciter_videos":
            self.render_reciter_videos()
        elif view == "shaarawy_folders":
            self.render_shaarawy_folders()
        elif view == "shaarawy":
            self.render_shaarawy()
        elif view in ("library", "quiz"):
            self.render_library()
        elif view == "mushaf":
            self.render_mushaf()
        else:
            self.render_list()
        if self.jump_buffer is not None:
            self.jump_label()
        if getattr(self, "dialog", None):
            self.draw_dialog()
        self.top_strip()
        for key in previous - self._shown_widgets:
            self[key].hide()
        if "bio_text" not in self._shown_widgets:
            self.bio_scroll.stop()

    # ------------------------------------------------------------------ choice dialog
    DLG_WIDGETS = ("dlg", "dlg_row0", "dlg_row1", "dlg_row2", "dlg_focus", "dlg_title", "dlg_sub",
                   "dlg_opt0", "dlg_opt1", "dlg_opt2")

    def open_choice(self, title, sub, options):
        """Centred choice dialog. options: [(label, callback or None)]; a last 'cancel' row is added."""
        options = list(options)[:2] + [(u"إلغاء", None)]
        self.dialog = {"title": title, "sub": sub, "options": options, "index": 0}
        self.draw_dialog()

    def draw_dialog(self):
        d = self.dialog
        if not d:
            return
        rows = len(d["options"])
        g = layout.dlg_geometry(rows)
        self.image("dlg", "dlg-%d" % rows, g["panel"])
        self.text("dlg_title", one_line(plain(d["title"]), 40), g["title"])
        if d["sub"]:
            self.text("dlg_sub", one_line(plain(d["sub"]), 64), g["sub"])
        else:
            self.hide_widget("dlg_sub")
        for i in range(3):
            if i < rows:
                self.image("dlg_row%d" % i, "dlg-row", g["rows"][i])
                self.text("dlg_opt%d" % i, one_line(plain(d["options"][i][0]), 48), g["rows"][i])
            else:
                self.hide_widget("dlg_row%d" % i)
                self.hide_widget("dlg_opt%d" % i)
        x, y, w, h = g["rows"][d["index"]]
        m = layout.FOCUS_MARGIN
        self.image("dlg_focus", "focus-dlg", (x - m, y - m, w + 2 * m, h + 2 * m))

    def close_dialog(self):
        self.dialog = None
        for name in self.DLG_WIDGETS:
            self.hide_widget(name)

    def dialog_key(self, key):
        d = self.dialog
        rows = len(d["options"])
        if key in ("up", "left"):
            d["index"] = (d["index"] - 1) % rows
            self.draw_dialog()
        elif key in ("down", "right"):
            d["index"] = (d["index"] + 1) % rows
            self.draw_dialog()
        elif key in ("ok", "1", "2", "3"):
            index = d["index"] if key == "ok" else int(key) - 1
            if index >= rows:
                return
            callback = d["options"][index][1]
            self.close_dialog()
            if callback is not None:
                callback()
        elif key in ("cancel", "red", "0"):
            self.close_dialog()

    def _update_home_footer(self):
        """The footer bar carries only the colour-key legend (no running text); the hero is live."""
        self.hide_widget("gallery_page")
        self.render_home_hero()

    AYAT = None
    WEEKDAYS = (u"الاثنين", u"الثلاثاء", u"الأربعاء", u"الخميس", u"الجمعة", u"السبت", u"الأحد")

    def ayah_of_day(self):
        if UltraQuran.AYAT is None:
            try:
                from .support import data_json
                UltraQuran.AYAT = data_json("ayat.json")
            except Exception:
                UltraQuran.AYAT = [[u"إن هذا القرآن يهدي للتي هي أقوم", u"الإسراء", 9]]
        import datetime
        ayat = UltraQuran.AYAT
        now = datetime.datetime.now()
        # a new ayah every two hours (12 a day), never the same one two slots in a row
        return ayat[(now.date().toordinal() * 12 + now.hour // 2) % len(ayat)]

    def draw_ayah(self, text):
        """Short ayah: one big line. Longer ayah: two balanced lines, each its own label, both the same size,
        closer together than the font's own line height, centred between the caption and the surah line."""
        lines = ayah_lines(text).split(u"\n")
        box = layout.HOME_AYAH
        if len(lines) == 1 or gFont is None:
            self.hide_widget("home_ayah2")
            self.text("home_ayah", u"\n".join(lines), box)
            return
        x, y, w, h = box
        names = ("home_ayah", "home_ayah2")
        size = self._ayah_size(lines, box)
        line_h = int(size * LINE_HEIGHT + 0.999) + 2
        pitch = size * AYAH_PITCH
        mid = y + h / 2.0
        for i, name in enumerate(names):
            top = int(round(mid + (i - 0.5) * pitch - line_h / 2.0))
            value = lines[i]
            if self._widget_cache.get((name, "value")) != value or self._widget_cache.get((name, "size")) != size:
                try:
                    self[name].instance.setFont(gFont("UltraQuranUI", layout.pixel(size, self.width)))
                except Exception:
                    pass
                self[name].setText(native(plain(value)))
                self._widget_cache[(name, "value")] = value
                self._widget_cache[(name, "size")] = size
                self._widget_cache.pop((name, "fit"), None)
            self.place(name, (x, top, w, line_h))

    def _ayah_size(self, lines, box):
        """Largest size (AYAH_TWO_MAX down to the floor) at which BOTH lines stay on one line in the box width."""
        key = (tuple(lines), self.width)
        if self._widget_cache.get(("ayah_size", "for")) == key:
            return self._widget_cache[("ayah_size", "value")]
        floor = FIT_FLOOR.get("home_ayah", 19)
        size = floor
        try:
            name = "home_ayah2"
            w = layout.scaled(box, self.width)[2]
            self.place(name, (box[0], box[1], box[2], int(AYAH_TWO_MAX * LINE_HEIGHT) + 2))
            for candidate in range(AYAH_TWO_MAX, floor - 1, -1):
                self[name].instance.setFont(gFont("UltraQuranUI", layout.pixel(candidate, self.width)))
                if all(self._fits_box(name, plain(line), w, 0) for line in lines):
                    size = candidate
                    break
        except Exception:
            pass
        self._widget_cache.pop(("home_ayah2", "value"), None)      # measuring changed the label
        self._widget_cache[("ayah_size", "for")] = key
        self._widget_cache[("ayah_size", "value")] = size
        return size

    def render_home_hero(self):
        """Ayah of the day, continue listening, Hijri date + clock, and a line about the focused section."""
        if self.route.name != "home":
            return
        import datetime
        text, surah, number = self.ayah_of_day()
        # no ornate brackets: the receiver mirrors them to the wrong end of an Arabic line
        self.draw_ayah(text)
        self.text("home_ayah_ref", u"سورة %s  ·  الآية %d" % (surah, number), layout.HOME_AYAH_REF)
        now = datetime.datetime.now()
        try:
            from .catalog import hijri_today
            hijri = hijri_today()
        except Exception:
            hijri = u""
        self.text("home_clock", u"%02d:%02d" % (now.hour, now.minute), layout.HOME_CLOCK)
        self.text("home_date", u"%s  %s" % (self.WEEKDAYS[now.weekday()], hijri), layout.HOME_DATE)
        index = max(0, min(len(layout.HOME_TILES_DESC) - 1, self.route.index))
        self.text("home_desc", layout.HOME_TILES_DESC[index], layout.HOME_DESC)
        audio = self.audio
        if self.mini_player_active():
            entry = self.playing_items[self.playing_index]
            title = self.catalog.track(entry)[0]
            self.text("home_resume_cap", u"يُشغَّل الآن", layout.HOME_RESUME_CAP)
            self.text("home_resume_title", plain(strip_duration(title)), layout.HOME_RESUME_TITLE)
            total = audio.total()
            when = u"%s / %s" % (self.duration(audio.shown_position()), self.duration(total)) if total > 0 else u"بث مباشر" if audio.live else u""
            who = plain(self.playing_who(entry))
            self.text("home_resume_sub", who or when, layout.HOME_RESUME_SUB)
            hint = u"زر التشغيل: إيقاف واستئناف"
            self.text("home_resume_hint", (when + u"  ·  " + hint) if (who and when) else hint, layout.HOME_RESUME_HINT)
            return
        last = None
        try:
            from .player import RESUME
            last = RESUME.latest()
        except Exception:
            last = None
        if last:
            url, seconds, title, total, who = last
            self.text("home_resume_cap", u"كمّل الاستماع", layout.HOME_RESUME_CAP)
            self.text("home_resume_title", plain(strip_duration(title)), layout.HOME_RESUME_TITLE)
            at = self.duration(int(seconds * PTS))
            when = (u"توقفت عند %s من %s" % (at, self.duration(int(total * PTS)))) if total else u"توقفت عند %s" % at
            if who:
                self.text("home_resume_sub", plain(who), layout.HOME_RESUME_SUB)
                self.text("home_resume_hint", when + u"  ·  الأخضر للاستكمال", layout.HOME_RESUME_HINT)
            else:
                self.text("home_resume_sub", when, layout.HOME_RESUME_SUB)
                self.text("home_resume_hint", u"الزر الأخضر: كمّل من حيث توقفت", layout.HOME_RESUME_HINT)
        else:
            self.text("home_resume_cap", u"ابدأ الاستماع", layout.HOME_RESUME_CAP)
            self.text("home_resume_title", u"اختر قسماً وابدأ", layout.HOME_RESUME_TITLE)
            self.text("home_resume_sub", u"كل ما تسمعه يُحفظ مكانه", layout.HOME_RESUME_SUB)
            self.hide_widget("home_resume_hint")

    def playing_who(self, entry):
        """Who is heard: the reciter / munshid for Quran editions, the folder or section for library media."""
        try:
            if entry[0] is None:
                return u"إذاعة القرآن الكريم"
            who = self.catalog.track(entry)[1] or u""
            if isinstance(entry[0], int) and who and not who.startswith((u"الشيخ", u"القارئ", u"فضيلة", u"د.")):
                who = u"الشيخ " + who
            return who
        except Exception:
            return u""

    def resume_last(self):
        """Green on home: continue the most recent unfinished recording where it stopped."""
        try:
            from .player import RESUME
            last = RESUME.latest()
        except Exception:
            last = None
        if not last:
            self.flash(u"لا يوجد شيء لاستكماله بعد")
            return
        url, seconds, title, total, who = last
        play_url = self.downloader.local_media_path(url, is_video=False) or url
        self.playing_items = [("lib", (title, who or u"استكمال الاستماع", u"صوتي", url))]
        self.playing_index = 0
        self.lib_durations = {url: total}
        self.lib_route = None
        self.lib_indices = []
        self.audio.play(title, play_url, False, total, who=who)
        self.render()

    def render_main_folders(self):
        """Quran portal: four tall folder cards (everything is baked into the card art)."""
        route = self.route
        folders = route.items or self.catalog.main_portal_folders()
        route.items = folders
        for i, folder in enumerate(folders[:4]):
            self.image("ecard%d" % i, "portal-%d" % i, layout.PORTAL_CARDS[i])
        if folders:
            self.highlight(layout.PORTAL_CARDS[min(route.index, 3)], "portal")

    def _update_gallery_footer(self):
        """Right end of the footer: which page, and which sheikh of how many."""
        route = self.route
        size = layout.POSTER_PAGE_SIZE
        pages = max(1, (len(route.items) + size - 1) // size)
        self.text("gallery_page", u"صفحة %d من %d  ·  %d من %d" % (route.index // size + 1, pages, route.index + 1,
                                                                   len(route.items)), layout.GALLERY_PAGE)

    def gallery(self):
        route = self.route
        page_size = layout.POSTER_PAGE_SIZE
        start = (route.index // page_size) * page_size
        page_items = route.items[start:start + page_size]
        visible_ids = []
        for i, (reciter_id, name, _) in enumerate(page_items):
            x, y, w, h = layout.POSTERS[i]
            self.reciter_card_image("poster%d" % i, reciter_id, (x, y, w, h))
            self.text("card%d" % i, wrap(name, 22, max_lines=2), (x + 8, y + h - layout.POSTER_PLATE + 4, w - 16, layout.POSTER_PLATE - 8))
            visible_ids.append(reciter_id)
        self.portraits.request(visible_ids)
        focused = route.items[route.index][0]
        self.highlight(layout.POSTERS[route.index - start], "poster", reciter_id=focused)
        self._update_gallery_footer()

    def _update_reciter_bio_panel(self, reciter_id):
        bio = self.reciter_bio(reciter_id)
        if self.bio_open:
            name = self.catalog.reciter[reciter_id][1] if reciter_id in self.catalog.reciter else u""
            self.draw_bio_full(name, bio or {}, living_label=u"الحالة / الوفاة")
            return
        if reciter_id == 950:
            heading = u"السيرة الذاتية لفارس المنابر"
        elif 951 <= reciter_id <= 965:
            heading = u"السيرة الذاتية للمبتهل"
        else:
            heading = u"السيرة الذاتية للقارئ"
        self.text("bio_heading", heading, layout.EDITIONS_BIO_HEADING)
        if bio:
            self.text("bio_born", u"الميلاد والنشأة\n" + bio.get("born", u"—"), layout.EDITIONS_BIO_BORN)
            if bio.get("died"):
                self.text("bio_died", u"الحالة / الوفاة\n" + bio["died"], layout.EDITIONS_BIO_DIED)
            else:
                self.text("bio_died", u"الحالة\nأطال الله في عمره", layout.EDITIONS_BIO_DIED)
            self.bio_text(bio.get("summary", u""), layout.EDITIONS_BIO_TEXT)
            self.text("bio_source", one_line(u"المصدر · " + bio.get("source", u"الهيئة العامة للاستعلامات"), 44), layout.EDITIONS_BIO_SOURCE)

    def render_reciter_hub(self):
        """Sheikh / Mubtahil / Preacher Home Portal: 2 Grand Luxury Folders (MP3 Audio vs Rare Video)."""
        route = self.route
        reciter_id = route.key
        reciter = self.catalog.reciter[reciter_id]
        reciter_name = reciter[1]
        recordings = reciter[2]
        self.catalog.request_reciter_videos(reciter_id)
        videos = self.catalog.reciter_videos(reciter_id)
        folders = self.catalog.reciter_hub_folders(reciter_id)
        route.items = folders

        px, py, pw, ph = layout.EDITIONS_POSTER
        self.reciter_card_image("poster0", reciter_id, layout.EDITIONS_POSTER)
        self.text("card0", wrap(reciter_name, 22, max_lines=2), (px + 8, py + ph - 76, pw - 16, 73))
        self.portraits.request([reciter_id])

        state = self.catalog.reciter_videos_state(reciter_id)
        total = sum(len(ed[3]) for ed in recordings)
        if reciter_id == 950:
            kind = "kishk"
            self.text("bio_recordings", u"%d خطبة صوتية" % total, layout.EDITIONS_BADGE_REC)
            self.text("bio_riwayas", u"%d خطبة مرئية" % len(videos) if videos else u"الخطب المصورة", layout.EDITIONS_BADGE_RIW)
            hub_title = u"فارس المنابر  ·  " + reciter_name
            hub_sub = u"اختر المكتبة  ·  الخطب الصوتية أو الخطب المصوّرة"
            audio_badge = u"الخطب: %d" % total
        elif 951 <= reciter_id <= 965:
            kind = "mub"
            self.text("bio_recordings", u"%d ابتهال صوتي" % total, layout.EDITIONS_BADGE_REC)
            self.text("bio_riwayas", u"%d فيديو" % len(videos) if videos else u"المكتبة المرئية", layout.EDITIONS_BADGE_RIW)
            hub_title = u"فضيلة المبتهل  ·  " + reciter_name
            hub_sub = u"اختر المكتبة  ·  الابتهالات والتواشيح الصوتية أو الحفلات المرئية"
            audio_badge = u"الابتهالات: %d" % total
        else:
            kind = "rec"
            self.text("bio_recordings", u"%d تسجيل صوتي" % len(recordings), layout.EDITIONS_BADGE_REC)
            self.text("bio_riwayas", u"%d فيديو" % len(videos) if videos else u"المكتبة المرئية", layout.EDITIONS_BADGE_RIW)
            hub_title = (u"فضيلة " if reciter_name.startswith(u"الشيخ") else u"فضيلة الشيخ ") + reciter_name
            hub_sub = u"اختر المكتبة  ·  المكتبة الصوتية أو المكتبة المرئية"
            audio_badge = u"المصاحف والتسجيلات: %d" % len(recordings)
        if state == "ready":
            video_badge = u"الفيديوهات: %d" % len(videos)
        elif state == "searching":
            video_badge = u"جارٍ البحث…"
        elif state == "offline":
            video_badge = u"تعذّر الاتصال"
        else:
            video_badge = u"لا توجد فيديوهات بعد"
        self._update_reciter_bio_panel(reciter_id)
        self.render_deck(hub_title, hub_sub, ["deck-%s-audio" % kind, "deck-%s-video" % kind], [audio_badge, video_badge])

    def deck_size(self):
        """Number of tall folder cards when the current screen is a folder deck, else 0."""
        route = self.route
        if route.name == "reciter_hub":
            return 2
        if route.name == "shaarawy_folders":
            if self.shaarawy_root():
                return 2
            if self.shaarawy_audio_root():
                return min(4, len(route.items))
        return 0

    def deck_window(self, n):
        """First visible card index: the focused card always stays inside the three visible slots."""
        route = self.route
        visible = min(layout.DECK_VISIBLE, n)
        start = getattr(route, "deck_start", 0)
        if route.index < start:
            start = route.index
        elif route.index >= start + visible:
            start = route.index - visible + 1
        start = max(0, min(start, n - visible))
        route.deck_start = start
        return start, visible

    def render_deck(self, title, sub, arts, badges):
        """Tall glass folder cards beside the poster / biography tower (3 visible, the rest slide in)."""
        route = self.route
        n = len(arts)
        route.index = max(0, min(route.index, n - 1))
        start, visible = self.deck_window(n)
        boxes = layout.deck_cards(visible)
        if n > visible:
            hidden = n - visible
            sub = u"%s  ·  %s" % (sub, u"بالسهم لعرض فولدر آخر" if hidden == 1 else u"بالسهم لعرض %d فولدرات أخرى" % hidden)
        self.text("title", one_line(title, 48), layout.EDITIONS_TITLE)
        self.text("sub", one_line(sub, 92), layout.EDITIONS_SUB)
        bx, by, bw, bh = layout.DECK_BADGE
        for slot in range(visible):
            i = start + slot
            x, y, w, h = boxes[slot]
            self.image("ecard%d" % slot, arts[i], boxes[slot])
            if badges[i]:
                self.text("deck_badge%d" % slot, one_line(badges[i], 28), (x + bx, y + by, bw, bh))
        self.highlight(boxes[route.index - start], "deck")

    def render_reciter_videos(self):
        """Rare Video Recitations Library for the Sheikh."""
        route = self.route
        reciter_id = route.key
        reciter = self.catalog.reciter[reciter_id]
        reciter_name = reciter[1]
        videos = route.items
        state = self.catalog.reciter_videos_state(reciter_id)

        px, py, pw, ph = layout.EDITIONS_POSTER
        self.reciter_card_image("poster0", reciter_id, layout.EDITIONS_POSTER)
        self.text("card0", wrap(reciter_name, 22, max_lines=2), (px + 8, py + ph - 76, pw - 16, 73))
        self.portraits.request([reciter_id])

        self.text("bio_recordings", u"%d فيديو" % len(videos), layout.EDITIONS_BADGE_REC)
        self.text("bio_riwayas", u"أرشيف الإنترنت", layout.EDITIONS_BADGE_RIW)
        self._update_reciter_bio_panel(reciter_id)

        self.text("title", one_line(u"المكتبة المرئية  ·  " + reciter_name, 48), layout.EDITIONS_TITLE)
        page_size = layout.ECARD_PAGE_SIZE
        start = (route.index // page_size) * page_size
        total_pages = max(1, (len(videos) + page_size - 1) // page_size)
        self.text("sub", u"صفحة %d من %d  ·  %d فيديو مرئي  ·  الأحمر أو رجوع: العودة" % (
            start // page_size + 1, total_pages, len(videos)
        ), layout.EDITIONS_SUB)
        if not videos:
            messages = {
                "searching": (u"جارٍ البحث عن فيديوهات الشيخ…", u"البحث في أرشيف الإنترنت · انتظر لحظات"),
                "offline": (u"تعذّر الاتصال بأرشيف الإنترنت", u"تحقق من الشبكة ثم ارجع وافتح المكتبة مرة أخرى"),
                "empty": (u"لا توجد فيديوهات موثّقة للشيخ حالياً", u"تُضاف أولاً بأول مع تحديثات البلجن"),
            }
            title, hint = messages.get(state, messages["empty"])
            x, y, w, h = layout.ECARDS[0]
            parts = layout.card_parts("ecard", (x, y, w, h))
            self.image("ecard0", "ecard-bg", (x, y, w, h))
            self.text("ecard_num0", u"—", parts["num"])
            self.text("ecard_title0", title, parts["title"])
            self.text("ecard_meta0", hint, parts["meta"])
            return

        visible = videos[start:start + page_size]
        for i, item in enumerate(visible):
            x, y, w, h = layout.ECARDS[i]
            parts = layout.card_parts("ecard", (x, y, w, h))
            idx = start + i
            self.image("ecard%d" % i, "ecard-bg", (x, y, w, h))
            self.text("ecard_num%d" % i, "%02d" % (idx + 1), parts["num"])
            self.text("ecard_title%d" % i, one_line(item["title"], 42), parts["title"])
            meta = item.get("badge", u"فيديو مرئي")
            if item.get("duration"):
                meta += u"  ·  %s" % item["duration"]
            if self.downloader.is_media_downloaded(item.get("audio"), is_video=True):
                meta = u"• محمّل بدون نت  ·  " + meta
            elif self.downloader.is_media_queued(item.get("audio")):
                meta = u"• جارٍ التحميل  ·  " + meta
            self.text("ecard_meta%d" % i, one_line(meta, 38), parts["meta"])
        if videos:
            self.highlight(layout.ECARDS[route.index - start], "ecard")

    def render_editions(self):
        route = self.route
        reciter_id = route.key
        reciter_name = self.catalog.reciter[reciter_id][1]
        recordings = route.items

        px, py, pw, ph = layout.EDITIONS_POSTER
        self.reciter_card_image("poster0", reciter_id, layout.EDITIONS_POSTER)
        self.text("card0", wrap(reciter_name, 22, max_lines=2), (px + 8, py + ph - 76, pw - 16, 73))
        self.portraits.request([reciter_id])

        total_items = sum(len(e[3]) for e in recordings)
        if reciter_id == 950:
            self.text("bio_recordings", u"%d مصنفات" % len(recordings), layout.EDITIONS_BADGE_REC)
            self.text("bio_riwayas", u"%d خطبة" % total_items, layout.EDITIONS_BADGE_RIW)
            ed_heading = u"فولدرات ومصنفات خطب الشيخ عبد الحميد كشك"
            sub_line = u"%s  ·  %d مصنفات تضم %d خطبة ومحاضرة صوتية" % (reciter_name, len(recordings), total_items)
            item_unit = u"خطبة"
        elif 951 <= reciter_id <= 965:
            self.text("bio_recordings", u"%d مصنفات" % len(recordings), layout.EDITIONS_BADGE_REC)
            self.text("bio_riwayas", u"%d ابتهال" % total_items, layout.EDITIONS_BADGE_RIW)
            ed_heading = u"فولدرات الابتهالات والتواشيح الصوتية"
            sub_line = u"%s  ·  %d مصنفات تضم %d ابتهالاً وتوشيحاً" % (reciter_name, len(recordings), total_items)
            item_unit = u"ابتهال"
        else:
            self.text("bio_recordings", u"%d تسجيل" % len(recordings), layout.EDITIONS_BADGE_REC)
            self.text("bio_riwayas", u"%d رواية" % self.catalog.riwayas(recordings), layout.EDITIONS_BADGE_RIW)
            ed_heading = u"الروايات والتسجيلات"
            sub_line = u"%s  ·  %d رواية ومصدر صوتي" % (reciter_name, len(recordings))
            item_unit = u"سورة"

        self._update_reciter_bio_panel(reciter_id)
        self.text("title", ed_heading, layout.EDITIONS_TITLE)
        dl_msg = self.downloader.status_text()
        if dl_msg:
            sub_line += u"   ·   " + dl_msg
        self.text("sub", one_line(sub_line, 96), layout.EDITIONS_SUB)

        page_size = layout.ECARD_PAGE_SIZE
        start = (route.index // page_size) * page_size
        visible = recordings[start:start + page_size]
        for i, edition in enumerate(visible):
            x, y, w, h = layout.ECARDS[i]
            parts = layout.card_parts("ecard", (x, y, w, h))
            ed_id = edition[0]
            self.image("ecard%d" % i, "ecard-bg", (x, y, w, h))
            self.text("ecard_num%d" % i, "%02d" % (start + i + 1), parts["num"])
            self.text("ecard_title%d" % i, one_line(edition[1], 42), parts["title"])
            src_name = self.catalog.source_label(edition[2])
            dl_cnt = self.downloader.downloaded_count(ed_id)
            unit_txt = item_unit
            if item_unit == u"سورة" and self.catalog.is_custom_edition(ed_id):
                unit_txt = u"تلاوة"
            meta_txt = u"%d %s  ·  %s" % (len(edition[3]), unit_txt, src_name)
            if dl_cnt > 0:
                meta_txt += u"  ·  %d محمّلة" % dl_cnt
            self.text("ecard_meta%d" % i, one_line(meta_txt, 38), parts["meta"])
        self.highlight(layout.ECARDS[route.index - start], "ecard")

    def _update_shaarawy_folders_bio_panel(self):
        """Left panel while browsing the Sheikh's folder tree (audio / video / surahs / programs)."""
        route = self.route
        section = self.catalog.libraries[1]
        bio = section.get("bio", {})
        if self.bio_open:
            self.draw_bio_full(u"الإمام محمد متولي الشعراوي", self.reciter_bio(999, u"محمد متولي الشعراوي", self.catalog.bios.get(999) or bio) or bio,
                               living_label=u"الوفاة واللقب")
            return
        folders = route.items or section.get("folders", [])
        folder = folders[route.index] if folders else {}
        poster_id = folder.get("poster_id", 999)
        poster_name = folder.get("poster_name", u"محمد متولي الشعراوي")

        px, py, pw, ph = layout.EDITIONS_POSTER
        self.reciter_card_image("poster0", poster_id, layout.EDITIONS_POSTER)
        self.text("card0", wrap(poster_name, 22, max_lines=2), (px + 8, py + ph - 76, pw - 16, 73))

        self.text("bio_recordings", folder.get("count_label", u""), layout.EDITIONS_BADGE_REC)
        self.text("bio_riwayas", folder.get("riwayas_label", u""), layout.EDITIONS_BADGE_RIW)
        born_txt = folder.get("born") or bio.get("born", u"15 أبريل 1911م")
        died_txt = folder.get("died") or bio.get("died", u"17 يونيو 1998م")
        self.text("bio_born", u"الميلاد والنشأة\n" + born_txt, layout.EDITIONS_BIO_BORN)
        self.text("bio_died", u"الوفاة واللقب\n" + died_txt, layout.EDITIONS_BIO_DIED)
        self.text("bio_heading", one_line(folder.get("subtitle") or u"موسوعة الشيخ الشعراوي", 44), layout.EDITIONS_BIO_HEADING)
        summary = folder.get("summary") or bio.get("summary", u"")
        if self.mini_player_active():
            self.bio_text(summary, layout.EDITIONS_BIO_TEXT_SHORT)
            self.mini_player(layout.EDITIONS_MINI, "bio_source", 44)
        else:
            self.bio_text(summary, layout.EDITIONS_BIO_TEXT)
            self.text("bio_source", u"اضغط زر الموافقة لفتح الفولدر  ·  رجوع للعودة", layout.EDITIONS_BIO_SOURCE)

    def draw_bio_full(self, name, bio, living_label=u"الحالة / الوفاة"):
        """The whole left tower becomes the biography: name, birth, death, the full text (rolling when it is
        longer than the box) and its source. Back, OK or yellow / INFO again bring the photo card back."""
        for widget in ("poster0", "card0", "bio_recordings", "bio_riwayas", "elapsed", "duration", "status", "progress"):
            self.hide_widget(widget)
        self.image("page", "bio-full", layout.BIO_FULL_PANEL)
        self.text("bio_heading", u"السيرة الذاتية  ·  " + plain(name or u""), layout.BIO_FULL_HEADING)
        self.text("bio_born", u"الميلاد والنشأة\n" + (bio.get("born") or u"—"), layout.BIO_FULL_BORN)
        if bio.get("died"):
            self.text("bio_died", living_label + u"\n" + bio["died"], layout.BIO_FULL_DIED)
        else:
            self.text("bio_died", u"الحالة\nأطال الله في عمره", layout.BIO_FULL_DIED)
        self.bio_text(bio.get("summary", u"") or u"لا توجد سيرة مفصلة بعد", layout.BIO_FULL_TEXT)
        source = bio.get("source") or u"الهيئة العامة للاستعلامات"
        self.text("bio_source", u"المصدر · %s  ·  رجوع للإغلاق" % source, layout.BIO_FULL_SOURCE)

    def toggle_bio(self):
        if self.route.name not in BIO_VIEWS:
            return False
        if self.route.name == "reciter_hub" or self.route.name == "editions" or self.route.name == "reciter_videos":
            if self.route.key not in self.catalog.reciter:
                return False
        self.bio_open = not self.bio_open
        self.render()
        return True

    def close_bio(self):
        """True when the full biography was open (it is closed now and the screen redrawn)."""
        if not self.bio_open:
            return False
        self.bio_open = False
        self.render()
        return True

    def shaarawy_root(self):
        """True on the first screen of the Sheikh's encyclopedia (the two big folders: audio | video)."""
        route = self.route
        return route.name == "shaarawy_folders" and route.items is self.catalog.libraries[1].get("folders")

    def shaarawy_audio_root(self):
        """True inside the Sheikh's audio folder (tafsir | programs | sermons | clips)."""
        route = self.route
        folders = self.catalog.libraries[1].get("folders") or []
        return route.name == "shaarawy_folders" and bool(folders) and route.items is folders[0].get("folders")

    def render_shaarawy_root(self):
        folders = self.route.items
        self.portraits.request([999])
        badges = [f.get("count_label") or f.get("badge", u"") for f in folders[:2]]
        self.render_deck(u"فضيلة الإمام الشيخ محمد متولي الشعراوي", u"اختر المكتبة  ·  الصوتيات أو الفيديو",
                         ["deck-sh-audio", "deck-sh-video"], badges)
        self._update_shaarawy_folders_bio_panel()

    def render_shaarawy_audio_root(self):
        folders = self.route.items[:4]
        self.portraits.request([999])
        badges = [f.get("count_label") or f.get("badge", u"") for f in folders]
        self.render_deck(u"صوتيات الإمام الشعراوي", u"التفسير · البرامج · الخطب · المقتطفات",
                         ["deck-sha-%d" % i for i in range(len(folders))], badges)
        self._update_shaarawy_folders_bio_panel()

    def render_shaarawy_folders(self):
        """Folder levels of the Sheikh's encyclopedia: root (audio | video) -> surahs / programs -> items."""
        route = self.route
        section = self.catalog.libraries[1]
        folders = route.items or section.get("folders", [])
        if self.shaarawy_root():
            self.render_shaarawy_root()
            return
        if self.shaarawy_audio_root():
            self.render_shaarawy_audio_root()
            return
        self.portraits.request([999])

        self.text("title", one_line(route.folder_title or section.get("title") or u"موسوعة الشيخ الشعراوي", 48), layout.EDITIONS_TITLE)
        page_size = layout.ECARD_PAGE_SIZE
        start = (route.index // page_size) * page_size
        total_pages = max(1, (len(folders) + page_size - 1) // page_size)
        if total_pages > 1:
            sub_line = u"صفحة %d من %d  ·  %d فولدراً  ·  الموافقة: فتح الفولدر  ·  رجوع: العودة" % (start // page_size + 1, total_pages, len(folders))
        else:
            sub_line = u"اختر الفولدر المطلوب  ·  %d فولدرات  ·  الموافقة: فتح  ·  رجوع: العودة" % len(folders) if len(folders) > 2 else u"اختر القسم المطلوب  ·  الصوتيات أو الفيديو  ·  الموافقة: فتح  ·  رجوع: العودة"
        self.text("sub", one_line(sub_line, 96), layout.EDITIONS_SUB)

        for i, folder in enumerate(folders[start:start + page_size]):
            x, y, w, h = layout.ECARDS[i]
            parts = layout.card_parts("ecard", (x, y, w, h))
            self.image("ecard%d" % i, "ecard-bg", (x, y, w, h))
            self.text("ecard_num%d" % i, "%02d" % (start + i + 1), parts["num"])
            self.text("ecard_title%d" % i, one_line(folder["title"], 42), parts["title"])
            self.text("ecard_meta%d" % i, one_line(folder.get("badge", u""), 38), parts["meta"])
        if folders:
            self.highlight(layout.ECARDS[route.index - start], "ecard")
        self._update_shaarawy_folders_bio_panel()

    def _update_shaarawy_bio_panel(self):
        route = self.route
        section = self.catalog.libraries[1]
        bio = section.get("bio", {})
        if self.bio_open:
            self.draw_bio_full(u"الإمام محمد متولي الشعراوي", self.reciter_bio(999, u"محمد متولي الشعراوي", self.catalog.bios.get(999) or bio) or bio,
                               living_label=u"الوفاة واللقب")
            return
        current = route.items[route.index] if route.items else {}

        self.text("bio_born", u"الميلاد والنشأة\n" + bio.get("born", u"15 أبريل 1911م"), layout.EDITIONS_BIO_BORN)
        self.text("bio_died", u"الوفاة واللقب\n" + bio.get("died", u"17 يونيو 1998م"), layout.EDITIONS_BIO_DIED)

        self.text("bio_heading", one_line(current.get("subtitle") or route.folder_title or u"خواطر الشيخ الشعراوي", 44), layout.EDITIONS_BIO_HEADING)
        body_clean = current.get("body") or bio.get("summary", u"")
        if self.mini_player_active():
            self.bio_text(body_clean, layout.EDITIONS_BIO_TEXT_SHORT)
            self.mini_player(layout.EDITIONS_MINI, "bio_source", 44)
        else:
            self.bio_text(body_clean, layout.EDITIONS_BIO_TEXT)
        if self.mini_player_active():
            pass
        elif current.get("video"):
            self.text("bio_source", u"اضغط زر الموافقة لمشاهدة الفيديو بالعرض الكامل", layout.EDITIONS_BIO_SOURCE)
        else:
            self.text("bio_source", u"اضغط زر الموافقة للاستماع · رجوع لقائمة الفولدرات", layout.EDITIONS_BIO_SOURCE)

    def render_shaarawy(self):
        route = self.route
        section = self.catalog.libraries[1]

        px, py, pw, ph = layout.EDITIONS_POSTER
        self.reciter_card_image("poster0", 999, layout.EDITIONS_POSTER)
        self.text("card0", u"محمد متولي الشعراوي", (px + 8, py + ph - 76, pw - 16, 73))
        self.portraits.request([999])

        all_items = route.all_items or route.items
        vid_count = sum(1 for item in all_items if item.get("video"))
        if vid_count > 0:
            self.text("bio_recordings", u"%d حلقة مرئية" % vid_count, layout.EDITIONS_BADGE_REC)
        else:
            self.text("bio_recordings", u"%d تسجيلاً صوتياً" % len(route.items), layout.EDITIONS_BADGE_REC)
        total_secs = sum(self.clock_seconds(item.get("duration")) for item in route.items)
        self.text("bio_riwayas", (u"%.1f ساعة" % (total_secs / 3600.0)) if total_secs else u"%d مادة" % len(route.items), layout.EDITIONS_BADGE_RIW)

        header_title = route.folder_title or u"موسوعة الشيخ محمد متولي الشعراوي"
        self.text("title", one_line(header_title, 48), layout.EDITIONS_TITLE)
        page_size = layout.ECARD_PAGE_SIZE
        start = (route.index // page_size) * page_size
        total_pages = max(1, (len(route.items) + page_size - 1) // page_size)
        sub_line = u"صفحة %d من %d  ·  %d مادة بالفولدر  ·  الأحمر: تحميل للهارد  ·  رجوع: العودة" % (
            start // page_size + 1, total_pages, len(route.items)
        )
        self.text("sub", one_line(sub_line, 96), layout.EDITIONS_SUB)

        active_url = None
        if self.playing_items and self.playing_index is not None and 0 <= self.playing_index < len(self.playing_items):
            active_url = self.catalog.track(self.playing_items[self.playing_index])[3]

        visible = route.items[start:start + page_size]
        for i, item in enumerate(visible):
            x, y, w, h = layout.ECARDS[i]
            parts = layout.card_parts("ecard", (x, y, w, h))
            idx = start + i
            title_txt = item.get("short") or item["title"]
            playing = bool(active_url and item.get("audio") == active_url and self.audio is not None
                           and self.audio.state in ("connecting", "playing", "paused"))
            self.image("ecard%d" % i, "ecard-bg", (x, y, w, h))
            self.text("ecard_num%d" % i, "%03d" % (idx + 1), parts["num"])
            self.text("ecard_title%d" % i, one_line(title_txt, 42), parts["title"])

            meta_txt = item.get("badge") or item.get("subtitle") or u"خواطر الشعراوي"
            if self.downloader.is_media_downloaded(item.get("audio"), is_video=bool(item.get("video"))):
                meta_txt = u"• محمّل بدون نت  ·  " + meta_txt
            elif self.downloader.is_media_queued(item.get("audio")):
                meta_txt = u"• جارٍ التحميل  ·  " + meta_txt
            self.text("ecard_meta%d" % i, one_line(meta_txt, 38), parts["meta"])
            if playing:
                self.play_marks("ecard_meta%d" % i, parts["meta"])
        if route.items:
            self.highlight(layout.ECARDS[route.index - start], "ecard")
        self._update_shaarawy_bio_panel()

    def show_video_osd(self, auto_hide=True):
        self.video_osd_visible = True
        if auto_hide:
            self.video_osd_timer.start(6000, True)
        if self.route.name == "video":
            self.render()

    def auto_hide_video_osd(self):
        if self.route.name == "video" and self.audio is not None and self.audio.state == "playing":
            self.video_osd_visible = False
            self.render()

    def render_video(self):
        """Ultra Stalker Floating Islands Full-Screen Video Player (`livebar2` architecture)."""
        route = self.route
        if not route.items:
            return
        if not self.video_osd_visible:
            return

        item = route.items[route.index]
        owner_id, owner_name = self.video_owner()
        shaarawy = owner_id == 999
        self.image("background", "video-bar", layout.VIDEO_BAR)
        self.reciter_card_image("poster0", owner_id, layout.VIDEO_POSTER)
        self.text("card0", wrap(owner_name.replace(u"الشيخ ", u"", 1), 22, max_lines=2), layout.VIDEO_POSTER_NAME)

        is_local_vid = self.downloader.is_media_downloaded(item.get("audio"), is_video=True)
        self.text("p_source", u"• فيديو من الهارد" if is_local_vid else u"• فيديو مرئي", layout.VIDEO_BADGE_1)
        self.text("p_mode", u"جودة فائقة HD" if shaarawy else u"أرشيف الإنترنت", layout.VIDEO_BADGE_2)
        video_title = one_line(item["title"], 78)
        self.text("v_title", video_title, layout.VIDEO_TITLE)
        # short titles sit in the middle of the plaque, long ones start from the right edge
        self.align_label("v_title", 2 if len(video_title) > 62 else 1)
        self.text("p_reciter", one_line(owner_name, 34), layout.VIDEO_RECITER)
        for centred in ("v_queue", "p_reciter", "p_info", "dl_status"):
            self.align_label(centred, 1)

        if route.index + 1 < len(route.items):
            next_title = route.items[route.index + 1]["title"]
            self.text("v_queue", u"التالي:  " + one_line(next_title, 120), layout.VIDEO_QUEUE_TEXT)
        elif shaarawy:
            self.text("v_queue", u"نهاية حلقات الفولدر الحالي  ·  موسوعة الشيخ محمد متولي الشعراوي", layout.VIDEO_QUEUE_TEXT)
        else:
            self.text("v_queue", u"آخر فيديو في المكتبة المرئية  ·  " + one_line(owner_name, 40), layout.VIDEO_QUEUE_TEXT)

        self.text("p_info", (u"الحلقة %d من %d" if shaarawy else u"الفيديو %d من %d") % (route.index + 1, len(route.items)), layout.VIDEO_INFO)
        self.text("dl_status", u"التقديم والترجيع بأزرار الأرقام\nزر ١ و ٣ عشر ثوانٍ  ·  ٤ و ٦ دقيقة  ·  ٧ و ٩ خمس دقائق", layout.VIDEO_HINT)
        self.update_video_player()

    def video_owner(self):
        """(id, name) of the sheikh whose video is playing (Shaarawy keeps his own encyclopedia)."""
        route = self.route
        if route.key in self.catalog.reciter and route.key != 999:
            return route.key, self.catalog.reciter[route.key][1]
        return 999, SHAARAWY_NAME

    def update_video_player(self):
        if self.route.name != "video" or not self.video_osd_visible or not self.route.items:
            return
        item = self.route.items[self.route.index]
        state = self.audio.state if self.audio is not None else "idle"
        status_map = {
            "connecting": u"جارٍ الاتصال ببث الفيديو المرئي…",
            "playing": u"قيد العرض المرئي الآن",
            "paused": u"الفيديو متوقف مؤقتاً",
            "finished": u"انتهى عرض الحلقة المرئية",
            "error": u"تعذّر تشغيل الفيديو · اضغط الأخضر للإعادة",
            "idle": u"جاهز للتشغيل المرئي",
        }
        if self.audio is not None and state in ("playing", "paused", "connecting", "finished"):
            position = self.audio.shown_position()
            total_pts = self.audio.total()
            if total_pts <= 0:
                dur_str = item.get("duration") or u"45:00"
                parts = [int(p) for p in dur_str.split(":") if p.isdigit()]
                if len(parts) == 3:
                    est_sec = parts[0] * 3600 + parts[1] * 60 + parts[2]
                elif len(parts) == 2:
                    est_sec = parts[0] * 60 + parts[1]
                else:
                    est_sec = 2700
                total_pts = int(est_sec * PTS)
                total_str = dur_str
            else:
                total_str = self.duration(total_pts)
            self.text("elapsed", self.duration(position), layout.VIDEO_ELAPSED)
            self.text("duration", total_str, layout.VIDEO_DURATION)
            value = self.progress_value(position, total_pts)
            rem_pts = max(0, total_pts - position) if total_pts else 0
            status_line = status_map.get(state, u"قيد العرض")
            note = self.audio.status_note()
            if total_pts > 0 and state in ("playing", "paused"):
                status_line += u"  ·  %d%%  ·  المتبقي %s" % (int(value), self.duration(rem_pts))
            if note and state in ("playing", "paused", "connecting"):
                status_line += u"  ·  " + note
            self.text("status", status_line, layout.VIDEO_STATUS)
            self.set_progress(value)
            self.place("progress", layout.VIDEO_PROGRESS)
        else:
            self.text("elapsed", u"00:00", layout.VIDEO_ELAPSED)
            self.text("duration", item.get("duration") or u"45:00", layout.VIDEO_DURATION)
            self.text("status", status_map.get(state, u"قيد العرض"), layout.VIDEO_STATUS)
            self.set_progress(0)
            self.place("progress", layout.VIDEO_PROGRESS)

    def _update_library_reader(self):
        route = self.route
        section = self.catalog.libraries[route.key]
        title = section["title"]
        current = route.items[route.index]
        lines = wrap(current.get("body", u""), 42).split(u"\n")
        per_page = 12
        pages = max(1, (len(lines) + per_page - 1) // per_page) if len(lines) > 12 else 1
        key = (route.key, id(route), route.index)
        if self.lib_page_key != key:
            self.lib_page_key = key
            self.lib_page = 0
            self.lib_timer.stop()
            if pages > 1:
                self.lib_timer.start(LIB_PAGE_MS, True)
        self.lib_pages = pages
        self.lib_page %= pages
        badge = current.get("badge") or title
        if pages > 1:
            badge = u"صفحة %d من %d  ·  زر ٢ و ٨ لتقليب النص" % (self.lib_page + 1, pages)
            shown = lines[self.lib_page * per_page:(self.lib_page + 1) * per_page]
            while shown and not shown[0].strip():
                shown = shown[1:]
        else:
            shown = lines[:12]
        self.text("lib_badge", one_line(badge, 44), layout.LIB_BADGE)
        self.text("lib_heading", wrap(one_line(current.get("subtitle", current["title"]), 72), 34, max_lines=2), layout.LIB_HEADING)
        body_raw = current.get("body", u"")
        # the reading text always sits in the middle of its box (both directions)
        self.align_label("lib_body", 1)
        balanced = balanced_wrap(body_raw.strip(), 44) if (pages == 1 and u"\n" not in body_raw.strip()) else []
        if 0 < len(balanced) <= 12:
            self.text("lib_body", u"\n".join(balanced), layout.LIB_BODY)
        else:
            self.text("lib_body", u"\n".join(shown), layout.LIB_BODY)
        if self.mini_player(layout.LIB_MINI, "lib_action", 40):
            pass
        elif current.get("counter"):
            target = current["counter"]
            val = self.tasbih_counts.get((route.key, route.index), 0)
            self.text("lib_action", u"المسبحة التفاعلية: %d من %d  ·  اضغط زر الموافقة للتسبيح" % (val, target), layout.LIB_ACTION)
        elif current.get("children"):
            self.text("lib_action", u"اضغط زر الموافقة لفتح الفولدر  ·  رجوع للعودة", layout.LIB_ACTION)
        elif current.get("edition"):
            self.text("lib_action", u"اضغط زر الموافقة لفتح سور المصحف المعلم · 114 سورة", layout.LIB_ACTION)
        elif current.get("audio"):
            self.text("lib_action", u"اضغط زر الموافقة أو الزر الأخضر للاستماع الصوتي المباشر", layout.LIB_ACTION)
        else:
            self.text("lib_action", u"تنقّل بالأسهم بين الصناديق · العنصر %d من %d" % (route.index + 1, len(route.items)), layout.LIB_ACTION)

    def lib_turn(self, step, auto=False):
        """Flip the reading panel page (auto every few seconds, or with keys 2 / 8)."""
        if self.route.name != "library" or self.lib_pages <= 1:
            self.lib_timer.stop()
            if self.route.name != "library":
                self.lib_page_key = None
            return
        self.lib_page = (self.lib_page + step) % self.lib_pages
        self._update_library_reader()
        self.lib_timer.start(LIB_PAGE_MS if auto else LIB_PAGE_MS * 2, True)

    def render_library(self):
        route = self.route
        section = self.catalog.libraries[route.key]
        title = section["title"]
        sub = section["sub"]
        if route.key == 13:
            sub = u"التاريخ الهجري اليوم: %s  ·  %s" % (hijri_today(), sub)
        if route.folder_title:
            sub = u"%s  ·  %s" % (title, sub)
            title = route.folder_title
        self.text("title", one_line(title, 44), layout.LIST_TITLE)
        self.text("sub", one_line(sub, 68), layout.LIST_SUB)

        if route.name == "quiz":
            q_list = route.items
            q_idx = route.question_index % len(q_list)
            q_obj = q_list[q_idx]
            self.text("count", u"السؤال %d من %d  ·  النتيجة: %d" % (q_idx + 1, len(q_list), route.score), layout.LIST_COUNT)
            self.text("lib_badge", u"المسابقة الإسلامية التفاعلية  ·  النقاط: %d" % route.score, layout.LIB_BADGE)
            self.text("lib_heading", u"السؤال %d من %d" % (q_idx + 1, len(q_list)), layout.LIB_HEADING)
            body_text = q_obj["q"]
            if route.answered is not None:
                correct = (route.answered == q_obj["answer"])
                verdict = u"• إجابة صحيحة! أحسنت" if correct else (u"• الإجابة الصحيحة: " + q_obj["options"][q_obj["answer"]])
                body_text += u"\n\n" + verdict + u"\n\nالشرح والفائدة:\n" + q_obj["explanation"]
            self.align_label("lib_body", 1)
            self.text("lib_body", wrap(body_text, 42, max_lines=12), layout.LIB_BODY)
            action_hint = u"اضغط زر الموافقة أو الأصفر للسؤال التالي" if route.answered is not None else u"اختر الصندوق الصحيح بالأسهم ثم اضغط زر الموافقة"
            self.text("lib_action", action_hint, layout.LIB_ACTION)

            letters = (u"أ", u"ب", u"ج", u"د")
            for i, option_text in enumerate(q_obj["options"][:4]):
                x, y, w, h = layout.LCARDS[i]
                parts = layout.card_parts("lcard", (x, y, w, h))
                badge = u"اضغط زر الموافقة لاختيار هذه الإجابة"
                if route.answered is not None:
                    if i == q_obj["answer"]:
                        badge = u"• الإجابة الصحيحة"
                    elif i == route.answered:
                        badge = u"• اختيارك"
                self.image("lcard%d" % i, "lcard-bg", (x, y, w, h))
                self.text("number%d" % i, letters[i], parts["num"])
                kind = "row" if len(option_text) <= 30 else "radio_row"
                self.text("%s%d" % (kind, i), one_line(option_text, 70), parts["title"])
                self.text("detail%d" % i, badge, parts["meta"])
            self.highlight(layout.LCARDS[route.index], "lib")
            return

        page_size = layout.LIB_PAGE_SIZE
        start = (route.index // page_size) * page_size
        total_pages = max(1, (len(route.items) + page_size - 1) // page_size)
        self.text("count", u"صفحة %d من %d  ·  %d مادة" % (start // page_size + 1, total_pages, len(route.items)), layout.LIST_COUNT)

        active_url = None
        if self.mini_player_active():
            try:
                active_url = self.catalog.track(self.playing_items[self.playing_index])[3]
            except Exception:
                active_url = None
        mark = None
        visible = route.items[start:start + page_size]
        for i, item in enumerate(visible):
            x, y, w, h = layout.LCARDS[i]
            parts = layout.card_parts("lcard", (x, y, w, h))
            idx = start + i
            self.image("lcard%d" % i, "lcard-bg", (x, y, w, h))
            self.text("number%d" % i, "%03d" % (idx + 1), parts["num"])
            kind, shown_title, extra = card_title(item["title"])
            if item.get("counter"):
                extra = u""          # the count is already shown in the capsule below
            self.text("%s%d" % (kind, i), shown_title, parts["title"])
            badge_text = item.get("badge") or item.get("subtitle") or title
            if extra:
                badge_text = u"%s  ·  %s" % (extra, badge_text)
            if item.get("counter"):
                val = self.tasbih_counts.get((route.key, idx), 0)
                badge_text = u"%s  ·  العدّاد: %d من %d" % (badge_text, val, item["counter"])
            elif item.get("audio"):
                dl_prefix = u"• محمّل بدون نت  ·  " if self.downloader.is_media_downloaded(item.get("audio")) else (
                    u"• جارٍ التحميل  ·  " if self.downloader.is_media_queued(item.get("audio")) else (
                        u"• صوت ونص مكتوب  ·  " if len(item.get("body", u"")) > 200 else u"• صوتي  ·  "
                    )
                )
                badge_text = dl_prefix + badge_text
            self.text("detail%d" % i, one_line(badge_text, 60), parts["meta"])
            if active_url and item.get("audio") and (item.get("audio") == active_url or
                                                     self.downloader.local_media_path(item["audio"], is_video=False) == active_url):
                mark = ("detail%d" % i, parts["meta"])
        if mark:
            self.play_marks(*mark)
        self.highlight(layout.LCARDS[route.index - start], "lib")
        self._update_library_reader()

    def render_list(self):
        route = self.route
        unit = u"سورة"
        if route.name == "surahs":
            reciter, recording = self.catalog.edition[route.key]
            rec_id = reciter[0]
            if rec_id == 950:
                title = u"خطب الشيخ عبد الحميد كشك"
                unit = u"خطبة"
            elif 951 <= rec_id <= 965:
                title = u"الابتهالات والتواشيح الدينية"
                unit = u"ابتهال"
            elif self.catalog.is_custom_edition(route.key):
                title = u"تلاوات وحفلات نادرة مختارة"
                unit = u"تلاوة"
            else:
                title = u"سور القرآن الكريم"
                unit = u"سورة"
            sub = reciter[1] + u"  ·  " + recording[1]
        elif route.name == "radios":
            title, sub = u"إذاعات القرآن الكريم", u"البث المباشر  ·  %d إذاعة قرآنية وإسلامية" % len(route.items)
            unit = u"إذاعة"
        else:
            title, sub = u"المفضلة ومكتبة الهارد (بدون نت)", u"التلاوات والصوتيات المحمّلة على الهارد والمحفوظة في المفضلة"
            unit = u"مادة"

        page_size = layout.SURA_PAGE_SIZE
        start = (route.index // page_size) * page_size
        total_pages = max(1, (len(route.items) + page_size - 1) // page_size)

        self.text("title", title, layout.LIST_TITLE)
        self.text("sub", one_line(sub, 68), layout.LIST_SUB)
        self.text("count", u"صفحة %d من %d  ·  %d %s" % (start // page_size + 1, total_pages, len(route.items), unit), layout.LIST_COUNT)

        if not route.items:
            self.text("panel", u"القائمة فارغة", layout.SURA_PLAYER_TITLE)
            self.text("status", u"اضغط الزر الأزرق لحفظ السور في المفضلة", layout.SURA_PLAYER_STATUS)
            return

        active_entry = self.playing_items[self.playing_index] if (self.playing_items and self.playing_index is not None) else None
        visible_items = route.items[start:start + page_size]
        is_custom = (route.name == "surahs" and self.catalog.is_custom_edition(route.key))

        for i, entry in enumerate(visible_items):
            x, y, w, h = layout.SURA_CARDS[i]
            parts = layout.card_parts("scard", (x, y, w, h))
            index = start + i
            name, dur_text, number = self.list_item(route.name, entry, index)
            playing = active_entry == entry and self.audio is not None and self.audio.state in ("connecting", "playing", "paused")
            self.image("scard%d" % i, "scard-bg", (x, y, w, h))
            self.text("number%d" % i, "%03d" % number, parts["num"])
            if route.name == "radios" or is_custom:
                label = "radio_row%d" % i
                self.text(label, one_line(name, 90), parts["title"])
            else:
                label = "row%d" % i
                self.text(label, one_line(name, 90), parts["title"])
            if dur_text:
                self.text("detail%d" % i, dur_text, parts["meta"])
                if playing:
                    self.play_marks("detail%d" % i, parts["meta"])

        self.highlight(layout.SURA_CARDS[route.index - start], "sura")
        self.render_integrated_player()

    def _refresh_sura_card_title(self, item_index):
        route = self.route
        if route.name not in ("surahs", "radios", "favorites") or not (0 <= item_index < len(route.items)):
            return
        page_size = layout.SURA_PAGE_SIZE
        start = (route.index // page_size) * page_size
        if not (start <= item_index < start + page_size):
            return
        slot = item_index - start
        x, y, w, h = layout.SURA_CARDS[slot]
        parts = layout.card_parts("scard", (x, y, w, h))
        entry = route.items[item_index]
        name, _, _ = self.list_item(route.name, entry, item_index)
        active_entry = self.playing_items[self.playing_index] if (self.playing_items and self.playing_index is not None) else None
        playing = active_entry == entry and self.audio is not None and self.audio.state in ("connecting", "playing", "paused")
        is_custom = (route.name == "surahs" and self.catalog.is_custom_edition(route.key))
        if route.name == "radios" or is_custom:
            label = "radio_row%d" % slot
            self.text(label, one_line(name, 90), parts["title"])
        else:
            label = "row%d" % slot
            self.text(label, one_line(name, 90), parts["title"])
        label = "detail%d" % slot
        if playing:
            self.play_marks(label, parts["meta"])
        elif getattr(self, "_pmark_owner", None) == label:
            self.hide_widget("pmark_r")
            self.hide_widget("pmark_l")
            self._pmark_owner = None

    def list_item(self, view, entry, index):
        if view == "radios":
            return self.catalog.radio[entry[1]][1], u"• بث مباشر 24 ساعة", index + 1
        if entry[0] == "lib":
            title, sub, detail, _ = entry[1]
            return title, u"%s  ·  • محمّلة" % sub, index + 1
        edition_id, chapter = entry
        sura_title = self.catalog.track_title(edition_id, chapter)
        if view == "favorites" and edition_id in self.catalog.edition:
            rec_name = self.catalog.edition[edition_id][0][1].replace(u"الشيخ ", u"", 1)
            sura_title = u"%s · %s" % (sura_title, rec_name)
        if entry in self.favorites:
            sura_title += u" •"
        if entry in self.measured_durations:
            dur_str = format_seconds(self.measured_durations[entry])
        else:
            dur_str = self.catalog.surah_duration_str(edition_id, chapter)
        if self.downloader.is_downloaded(edition_id, chapter):
            dur_str += u"  ·  • محمّلة"
        elif self.downloader.is_queued(edition_id, chapter):
            dur_str += u"  ·  • تحميل"
        return sura_title, dur_str, (index + 1 if view == "favorites" else chapter)

    def render_integrated_player(self):
        route = self.route
        if not route.items:
            return
        if self.playing_items and self.playing_index is not None and 0 <= self.playing_index < len(self.playing_items):
            items = self.playing_items
            idx = self.playing_index
            is_active_track = True
        else:
            items = route.items
            idx = route.index
            is_active_track = False

        entry = items[idx]
        name, reciter, edition, url, reciter_id = self.catalog.track(entry)
        if reciter_id is not None:
            self.reciter_portrait_image("portrait", reciter_id, layout.SURA_PLAYER_PORTRAIT)
        elif entry[0] is None:
            self.image("portrait", "radio-art", layout.SURA_PLAYER_PORTRAIT)
        elif u"الشعراوي" in (reciter or u""):
            self.reciter_portrait_image("portrait", 999, layout.SURA_PLAYER_PORTRAIT)
        else:
            self.image("portrait", "poster-default", layout.SURA_PLAYER_PORTRAIT)

        if entry[0] is None:
            source_badge = u"• بث إذاعي مباشر"
            meta_line = u"إذاعة قرآنية مباشرة  ·  بث متواصل 24 ساعة"
            riwaya_line = edition
        elif isinstance(entry[0], int):
            ed_id, chapter = entry
            is_local = self.downloader.is_downloaded(ed_id, chapter)
            source_badge = u"• تشغيل من الهارد (بدون نت)" if is_local else u"• بث سحابي فائق النقاء"
            meta_line = self.catalog.surah_meta_str(chapter, edition_id=ed_id)
            src_label = self.catalog.source_label(url)
            if len(edition) > 28 or src_label in edition:
                riwaya_line = one_line(edition, 52)
            else:
                riwaya_line = one_line(edition + u"  ·  " + src_label, 52)
        else:
            is_local_media = self.downloader.is_media_downloaded(url)
            source_badge = u"• تشغيل من الهارد (بدون نت)" if is_local_media else u"• صوتيات إسلامية"
            meta_line = edition
            riwaya_line = reciter

        mode_badge = u"التكرار: سورة واحدة" if self.repeat else u"التشغيل: تسلسلي تلقائي"
        self.text("p_source", source_badge, layout.SURA_PLAYER_SOURCE)
        self.text("p_mode", mode_badge, layout.SURA_PLAYER_MODE)

        self.text("panel", one_line(name, 38), layout.SURA_PLAYER_TITLE)
        self.text("p_meta", meta_line, layout.SURA_PLAYER_META)
        self.text("p_reciter", one_line(reciter, 34), layout.SURA_PLAYER_RECITER)
        self.text("info", riwaya_line, layout.SURA_PLAYER_RIWAYA)

        self.align_label("queue", 1)
        if idx + 1 < len(items):
            next_entry = items[idx + 1]
            following = self.catalog.track(next_entry)[0]
            if isinstance(next_entry[0], int):
                next_dur = self.catalog.surah_duration_str(next_entry[0], next_entry[1])
                if self.catalog.is_custom_edition(next_entry[0]):
                    self.text("queue", u"التالي  ·  %s  ·  %s" % (following, next_dur) if next_dur else u"التالي  ·  " + following, layout.SURA_PLAYER_QUEUE)
                else:
                    self.text("queue", u"التالي في المصحف  ·  %s (%03d)  ·  %s" % (following, next_entry[1], next_dur), layout.SURA_PLAYER_QUEUE)
            else:
                self.text("queue", u"التالي  ·  " + one_line(following, 48), layout.SURA_PLAYER_QUEUE)
        else:
            self.text("queue", u"نهاية القائمة الحالية  ·  اكتملت السور", layout.SURA_PLAYER_QUEUE)

        self.text(
            "p_info",
            u"زر ١ و ٣ عشر ثوانٍ  ·  ٤ و ٦ دقيقة  ·  ٧ و ٩ خمس دقائق" if (is_active_track and self.audio is not None and not self.audio.live) else u"العنصر %d من %d  ·  موافقة: تشغيل/إيقاف  ·  القنوات: تغيير الصفحة" % (route.index + 1, len(route.items)),
            layout.SURA_PLAYER_INFO
        )

        dl_msg = self.downloader.status_text()
        if route.name == "surahs":
            dl_cnt = self.downloader.downloaded_count(route.key)
            if dl_msg:
                full_dl = dl_msg + u"\nمكتبة الهارد: محمّل %d من %d سورة" % (dl_cnt, len(route.items))
            else:
                full_dl = u"مكتبة الهارد: محمّل %d من %d سورة · يعمل بدون نت\nالأحمر: ضغطة لتحميل السورة · ضغطة ثانية لتحميل الفولدر كامل" % (dl_cnt, len(route.items))
            self.text("dl_status", full_dl, layout.SURA_PLAYER_DL)
        elif route.name == "favorites":
            self.text("dl_status", dl_msg or u"الأزرق: إضافة أو إزالة من المفضلة  ·  الأحمر: تحميل السورة للهارد", layout.SURA_PLAYER_DL)
        else:
            self.text("dl_status", u"بث إذاعي قرآني مباشر فائق النقاء على مدار الساعة", layout.SURA_PLAYER_DL)

        self.update_player(preview_entry=None if is_active_track else entry)

    def mini_player_active(self):
        audio = self.audio
        return bool(audio is not None and self.playing_items and self.playing_index is not None
                    and audio.state in ("connecting", "playing", "paused"))

    def _hide_mini(self):
        for name in ("elapsed", "duration", "status", "progress"):
            self.hide_widget(name)
        if self._mini_hint_owner:
            self.hide_widget("p_info")
            self._mini_hint_owner = False

    def mini_player(self, rects, title_label, title_chars):
        """Small now-playing block (title, gold bar, elapsed / remaining / total, key hint) for screens
        that list audio but have no big player.  Returns False (and hides itself) when nothing plays."""
        if not self.mini_player_active():
            self._hide_mini()
            return False
        audio = self.audio
        try:
            p_title = self.catalog.track(self.playing_items[self.playing_index])[0]
        except Exception:
            p_title = u""
        # only the name of what is playing, centred, using the whole line (the font shrinks to fit)
        self.text(title_label, one_line(plain(p_title), title_chars + 20), rects["title"])
        if audio.live:
            self.text("elapsed", u"بث مباشر", rects["elapsed"])
            self.hide_widget("duration")
            self.hide_widget("status")
            self.hide_widget("progress")
        else:
            position = audio.shown_position()
            total = audio.total()
            # only the two times on the bar's line: played on the left, still to go on the right
            self.text("elapsed", self.duration(position), rects["elapsed"])
            self.hide_widget("status")
            if total > 0:
                self.text("duration", self.duration(max(0, total - position)), rects["total"])
                self.set_progress(self.progress_value(position, total))
            else:
                self.text("duration", u"\u2014", rects["total"])
                self.set_progress(0)
            self.place("progress", rects["bar"])
        if "hint" in rects:
            hint = u"موافقة: إيقاف واستئناف  ·  أزرار الأرقام: تقديم وترجيع" if not audio.live else u"موافقة: إيقاف واستئناف"
            self.text("p_info", hint, rects["hint"])
            self._mini_hint_owner = True
        return True

    def _refresh_library_mini(self):
        if self.route.name != "library" or not self.route.items:
            return
        if not self.mini_player(layout.LIB_MINI, "lib_action", 40):
            self._update_library_reader()      # playback ended: the box shows its normal hint again

    def _refresh_folders_mini(self):
        route = self.route
        if route.name != "shaarawy_folders" or not route.items:
            return
        self._update_shaarawy_folders_bio_panel()

    TOP_STRIP_HIDDEN = ("surahs", "radios", "favorites", "video", "library", "shaarawy", "shaarawy_folders")

    def top_strip(self):
        """While sound plays and the screen has no player of its own: elapsed | gold bar | remaining in the
        middle of the top bar."""
        names = ("top_elapsed", "top_remain", "top_track", "top_fill")
        if self.route.name in self.TOP_STRIP_HIDDEN or not self.mini_player_active():
            for name in names:
                self.hide_widget(name)
            return
        audio = self.audio
        ex, ey, ew, eh = layout.TOP_ELAPSED
        track = layout.TOP_TRACK
        if audio.live:
            self.text("top_elapsed", u"بث مباشر", (ex - 60, ey, ew + 60, eh))
            self.hide_widget("top_remain")
            self.hide_widget("top_fill")
            self.place("top_track", track)
            return
        position = audio.shown_position()
        total = audio.total()
        self.text("top_elapsed", self.duration(position), layout.TOP_ELAPSED)
        self.place("top_track", track)
        if total > 0:
            self.text("top_remain", self.duration(max(0, total - position)), layout.TOP_REMAIN)
            self.laser("top_fill", track, self.progress_value(position, total))
        else:
            self.hide_widget("top_remain")
            self.hide_widget("top_fill")

    def update_player(self, preview_entry=None):
        self.top_strip()
        if self.route.name == "home":
            self.render_home_hero()
        if self.downloader.pop_updated() and self.route.name in ("surahs", "favorites", "editions"):
            self.render()
            return
        if self.route.name == "video":
            self.update_video_player()
            return
        if self.route.name == "shaarawy":
            self._update_shaarawy_bio_panel()
            return
        if self.route.name == "library":
            self._refresh_library_mini()
            return
        if self.route.name == "shaarawy_folders":
            self._refresh_folders_mini()
            return
        if self.route.name not in ("surahs", "radios", "favorites") or self.audio is None:
            return
        state = self.audio.state if (self.playing_items and preview_entry is None) else "idle"
        status_map = {
            "connecting": u"جارٍ الاتصال بالمصدر الصوتي…",
            "playing": u"قيد التشغيل الآن",
            "paused": u"متوقف مؤقتًا",
            "finished": u"انتهت التلاوة",
            "error": u"تعذّر التشغيل · اضغط موافقة لإعادة المحاولة",
            "idle": u"اضغط زر الموافقة لتشغيل السورة في المشغّل الاحترافي",
        }
        controls_map = {
            "connecting": u"اتصال",
            "playing": u"إيقاف مؤقت",
            "paused": u"استئناف",
            "finished": u"إعادة",
            "error": u"إعادة",
            "idle": u"تشغيل",
        }
        self.text("control", controls_map[state], layout.SURA_PLAYER_CONTROL)
        self.text("p_mode", u"التكرار: سورة واحدة" if self.repeat else u"التشغيل: تسلسلي تلقائي", layout.SURA_PLAYER_MODE)

        active_entry = preview_entry
        if active_entry is None and self.playing_items and self.playing_index is not None:
            active_entry = self.playing_items[self.playing_index]

        if active_entry and active_entry[0] is None:
            self.text("status", status_map[state] + u"  ·  بث إذاعي مباشر", layout.SURA_PLAYER_STATUS)
            self.text("elapsed", u"بث مباشر", layout.SURA_PLAYER_ELAPSED)
            self.text("duration", u"24 ساعة", layout.SURA_PLAYER_DURATION)
            self.hide_widget("progress")
            return

        if state in ("playing", "paused", "connecting", "finished") and not self.audio.live:
            if self.audio.length > 0 and active_entry and isinstance(active_entry[0], int):
                measured_sec = int(self.audio.length // PTS)
                if measured_sec > 2 and self.measured_durations.get(active_entry) != measured_sec:
                    self.measured_durations[active_entry] = measured_sec
            position = self.audio.shown_position()
            total_pts = self.audio.total()
            if total_pts > 0:
                total_str = self.duration(total_pts)
            else:
                total_str = u"\u2014"
            self.text("elapsed", self.duration(position), layout.SURA_PLAYER_ELAPSED)
            self.text("duration", total_str, layout.SURA_PLAYER_DURATION)
            value = self.progress_value(position, total_pts)
            rem_pts = max(0, total_pts - position) if total_pts else 0
            status_line = status_map[state]
            note = self.audio.status_note()
            if total_pts > 0 and state in ("playing", "paused"):
                status_line += u"  ·  %d%%  ·  المتبقي %s" % (int(value), self.duration(rem_pts))
            if note and state in ("playing", "paused", "connecting"):
                status_line += u"  ·  " + note
            self.text("status", status_line, layout.SURA_PLAYER_STATUS)
            self.set_progress(value)
            self.place("progress", layout.SURA_PLAYER_PROGRESS)
        else:
            self.text("status", status_map[state], layout.SURA_PLAYER_STATUS)
            self.text("elapsed", u"00:00", layout.SURA_PLAYER_ELAPSED)
            if active_entry and isinstance(active_entry[0], int):
                total_str = self.catalog.surah_duration_str(active_entry[0], active_entry[1])
            else:
                total_str = u"—"
            self.text("duration", total_str, layout.SURA_PLAYER_DURATION)
            self.set_progress(0)
            self.place("progress", layout.SURA_PLAYER_PROGRESS)

    @staticmethod
    def progress_value(position, total):
        """Percent as a float (the bar uses tenths of a percent; texts show int())."""
        if not total or total <= 0:
            return 0
        return min(100.0, max(0.0, position * 100.0 / total))

    def set_progress(self, value):
        """Percent 0..100 (float). The gold fill is resized to exactly that share of the track."""
        self._progress_value = max(0.0, min(100.0, float(value or 0)))
        self._place_fill()

    def _place_fill(self):
        box = self._progress_box
        if box is None or "progress" not in self._shown_widgets:
            self.hide_widget("progress_fill")
            return
        self.laser("progress_fill", box, self._progress_value)

    def laser(self, name, box, percent):
        """Show `percent` of the track `box` with its laser image (cut, never squeezed)."""
        x, y, w, h = box
        px, py, pw, ph = layout.scaled(box, self.width)
        fill = int(round(pw * max(0.0, min(100.0, percent)) / 100.0))
        if fill < 2:
            self.hide_widget(name)
            return
        path = os.path.join(self.art, "laser-%dx%d.png" % (w, h))
        instance = self[name].instance
        if self._widget_cache.get((name, "value")) != path:
            if not os.path.isfile(path):
                path = os.path.join(self.art, "laser-368x12.png")
            instance.setPixmapFromFile(native(path))
            self._widget_cache[(name, "value")] = path
        position = (px, py, min(pw, fill), ph)
        if self._widget_cache.get((name, "box")) != position:
            instance.move(ePoint(px, py))
            instance.resize(eSize(min(pw, fill), ph))
            self._widget_cache[(name, "box")] = position
        if name not in self._shown_widgets:
            self[name].show()
            self._shown_widgets.add(name)

    @staticmethod
    def duration(pts):
        seconds = max(0, int(pts // PTS))
        hours, seconds = divmod(seconds, 3600)
        minutes, seconds = divmod(seconds, 60)
        return u"%d:%02d:%02d" % (hours, minutes, seconds) if hours else u"%02d:%02d" % (minutes, seconds)

    def render_mushaf(self):
        self.image("mframe", "mushaf-frame", layout.MUSHAF_FRAME)
        page = self.mushaf_page
        self.mushaf.request_page(page, full_download=True)
        pdata = self.mushaf.page_data(page)
        has_img = self.mushaf.has_image(page)
        juz_num = (pdata or {}).get("juz") or ((page - 1) // 20 + 1)
        surahs_str = u" · ".join((pdata or {}).get("surahs") or [u"القرآن الكريم"])
        self.text("mushaf_surah", one_line(plain(surahs_str), 30), layout.MUSHAF_SURAH)
        self.text("mushaf_juz", u"الجزء %d  ·  صفحة %d من 604" % (juz_num, page), layout.MUSHAF_JUZ)
        rows = self.mushaf.tafsir(page)
        lines = []
        last_surah = None
        for surah_name, ayah_no, body in rows:
            if surah_name != last_surah and (last_surah is not None or ayah_no == 1):
                lines.append(u"﴿ سورة %s ﴾" % surah_name)
            last_surah = surah_name
            lines.extend(textwrap.wrap(u"(%d) %s" % (ayah_no, body), 38, break_long_words=False, break_on_hyphens=False))
            lines.append(u"")
        while lines and not lines[-1]:
            lines.pop()
        per = 16
        subs = max(1, (len(lines) + per - 1) // per)
        self.tafsir_subs = subs
        self.tafsir_sub %= subs
        shown = lines[self.tafsir_sub * per:(self.tafsir_sub + 1) * per]
        self.text("mushaf_tafsir", plain(u"\n".join(shown)) if shown else u"التفسير الميسر غير متوفر لهذه الصفحة", layout.MUSHAF_TAFSIR)
        bulk = self.mushaf.bulk_state()
        if bulk["saved"] >= 604:
            second = u"المصحف محفوظ كاملاً على الهارد · 604 صفحة"
        elif bulk["running"]:
            second = u"جارٍ تحميل المصحف كامل  ·  %d / 604 صفحة" % bulk["saved"]
        elif bulk["error"]:
            second = u"توقّف التحميل (تحقق من الإنترنت)  ·  %d / 604  ·  الأزرق للمتابعة" % bulk["saved"]
        else:
            second = u"محفوظ %d / 604 صفحة  ·  الأزرق لتحميل المصحف كامل" % bulk["saved"]
        self.text("mushaf_state", plain(u"%s  ·  التفسير %d/%d\n%s" % (self.mushaf.riwaya_name(), self.tafsir_sub + 1, subs, second)), layout.MUSHAF_STATE)
        self.set_progress(page * 100.0 / 604)
        self.place("progress", layout.MUSHAF_PROGRESS)

        if has_img and self.mushaf_mode == "large":
            halves = self.mushaf.page_halves(page)
            self.mushaf_half = min(self.mushaf_half, halves - 1)
            path = self.mushaf.page_image_path(page, half=self.mushaf_half)
            if path:
                self.image("page", path, layout.MUSHAF_IMG, external=True)
                if halves > 1:
                    self.text("mushaf_juz", u"الجزء %d  ·  صفحة %d  ·  %s" % (
                        juz_num, page, u"النصف الأول" if self.mushaf_half == 0 else u"النصف الثاني"), layout.MUSHAF_JUZ)
                return
        if has_img and self.mushaf_mode in ("auto", "image", "large"):
            path = self.mushaf.page_image_path(page)
            if path:
                self.image("page", path, layout.MUSHAF_IMG, external=True)
                return
        if pdata and self.mushaf_mode == "text" and self.mushaf.riwaya == "hafs":
            tx, ty, tw, th = layout.MUSHAF_TEXT_BODY
            max_l = 10
            self.text("mushaf_header", one_line(u"%s   ·   صفحة %d" % (surahs_str, page), 50), layout.MUSHAF_TEXT_HEAD)
            raw_lines = wrap(pdata.get("text", u""), 32).split(u"\n")
            non_empty = [ln for ln in raw_lines if ln.strip()]
            subpages = max(1, (len(non_empty) + max_l - 1) // max_l)
            self.mushaf_subpages = subpages
            self.mushaf_subpage %= subpages
            shown = non_empty[self.mushaf_subpage * max_l:(self.mushaf_subpage + 1) * max_l]
            self.text("mushaf_body", u"\n".join(shown), layout.MUSHAF_TEXT_BODY)
            if subpages > 1:
                self.text("mushaf_footer", u"الجزء %d من %d  ·  زر ٢ و ٨ لتقليب آيات الصفحة" % (self.mushaf_subpage + 1, subpages), layout.MUSHAF_TEXT_FOOT)
            return
        if self.mushaf.page_failed(page) or self.mushaf.bulk_state()["error"]:
            hint = u"تعذّر تحميل صفحة %d\nتحقق من الإنترنت ثم اضغط الزر الأزرق\nلتحميل المصحف كامل وحفظه على الهارد" % page
        else:
            hint = u"جارٍ تحميل صفحة %d\nمصحف %s\nتُحفظ الصفحة على الهارد للتصفح بدون إنترنت" % (page, self.mushaf.riwaya_name())
        self.text("mushaf_hint", plain(hint), layout.MUSHAF_IMG)

    def move(self, direction):
        """Cursor navigation. Always circular: the last item + down goes back to the first."""
        route = self.route
        if self.jump_buffer is not None:
            return
        if route.name == "video":
            self.show_video_osd(auto_hide=True)
            if direction == "up":
                self.skip_video(-1)
            elif direction == "down":
                self.skip_video(1)
            return
        if route.name == "mushaf":
            if direction in ("up", "down"):
                self.tafsir_sub = (self.tafsir_sub + (1 if direction == "down" else -1)) % max(1, getattr(self, "tafsir_subs", 1))
                self.render()
            else:
                self.mushaf_turn(1 if direction == "left" else -1)
            return
        old_idx = route.index
        if route.name == "home":
            route.index = grid_step(route.index, 15, 5, direction)
            if route.index != old_idx:
                self.highlight(layout.HOME[route.index], "home")
                self._update_home_footer()
            return
        deck = self.deck_size()
        if deck:
            if direction in ("left", "right"):
                route.index = (route.index + (1 if direction == "left" else -1)) % deck
                self.render()
            return
        if route.name == "quiz":
            route.index = grid_step(route.index, 4, 2, direction)
            if route.index != old_idx:
                self.highlight(layout.LCARDS[route.index], "lib")
            return
        if route.name == "gallery":
            cols, page_size = layout.POSTER_COLS, layout.POSTER_PAGE_SIZE
            if not route.items:
                return
            route.index = grid_step(route.index, len(route.items), cols, direction)
            if route.index != old_idx and (old_idx // page_size) == (route.index // page_size):
                start = (route.index // page_size) * page_size
                self.highlight(layout.POSTERS[route.index - start], "poster")
                self._update_gallery_footer()
                return
        elif route.name in ("main_folders", "editions", "shaarawy", "shaarawy_folders", "reciter_videos"):
            if not route.items:
                return
            if route.name == "main_folders":
                route.index = grid_step(route.index, len(route.items), 4, direction)
                if route.index != old_idx:
                    self.highlight(layout.PORTAL_CARDS[route.index], "portal")
                return
            route.index = grid_step(route.index, len(route.items), layout.ECARD_COLS, direction)
            if route.index == old_idx:
                return
            page_size = layout.ECARD_PAGE_SIZE
            if (old_idx // page_size) == (route.index // page_size):
                start = (route.index // page_size) * page_size
                self.highlight(layout.ECARDS[route.index - start], "ecard")
                if route.name == "shaarawy_folders":
                    self._update_shaarawy_folders_bio_panel()
                elif route.name == "shaarawy":
                    self._update_shaarawy_bio_panel()
                return
        elif route.name == "library" and route.items:
            route.index = grid_step(route.index, len(route.items), layout.LIB_COLS, direction)
            if route.index == old_idx:
                return
            page_size = layout.LIB_PAGE_SIZE
            if (old_idx // page_size) == (route.index // page_size):
                start = (route.index // page_size) * page_size
                self.highlight(layout.LCARDS[route.index - start], "lib")
                self._update_library_reader()
                return
        elif route.name in ("surahs", "radios", "favorites") and route.items:
            route.index = grid_step(route.index, len(route.items), layout.SURA_COLS, direction)
            if route.index == old_idx:
                return
            page_size = layout.SURA_PAGE_SIZE
            if (old_idx // page_size) == (route.index // page_size):
                start = (route.index // page_size) * page_size
                self.highlight(layout.SURA_CARDS[route.index - start], "sura")
                self.render_integrated_player()
                return
        self.render()

    def mushaf_turn(self, direction):
        """Left / right in large print walks the halves: top half -> bottom half -> next page."""
        if self.mushaf_mode == "large" and self.mushaf.has_image(self.mushaf_page):
            halves = self.mushaf.page_halves(self.mushaf_page)
            target = self.mushaf_half + direction
            if 0 <= target < halves:
                self.mushaf_half = target
                self.render()
                return
            self.page_step(direction)
            if direction < 0 and self.mushaf.has_image(self.mushaf_page):
                self.mushaf_half = self.mushaf.page_halves(self.mushaf_page) - 1
                self.render()
            return
        self.page_step(direction)

    def page_step(self, direction):
        """Page up / down (CH+/CH-). Circular too: past the last page goes to the first, and back."""
        route = self.route
        if route.name == "video":
            self.skip_video(direction)
            return
        if route.name == "mushaf":
            self.mushaf_page = (self.mushaf_page - 1 + direction) % 604 + 1
            self.mushaf_subpage = 0
            self.mushaf_half = 0
            self.tafsir_sub = 0
        elif route.name == "quiz":
            route.question_index = (route.question_index + direction) % len(route.items)
            route.answered = None
            route.index = 0
        else:
            sizes = {
                "gallery": layout.POSTER_PAGE_SIZE, "main_folders": layout.ECARD_PAGE_SIZE,
                "editions": layout.ECARD_PAGE_SIZE,
                "shaarawy": layout.ECARD_PAGE_SIZE, "shaarawy_folders": layout.ECARD_PAGE_SIZE,
                "reciter_videos": layout.ECARD_PAGE_SIZE, "library": layout.LIB_PAGE_SIZE,
                "surahs": layout.SURA_PAGE_SIZE, "radios": layout.SURA_PAGE_SIZE,
                "favorites": layout.SURA_PAGE_SIZE,
            }
            size = sizes.get(route.name)
            if not size or not route.items:
                return
            pages = (len(route.items) + size - 1) // size
            page = ((route.index // size) + direction) % pages
            # keep the same slot on the new page when it exists, otherwise land on the page's last item
            route.index = min(len(route.items) - 1, page * size + route.index % size)
        self.render()

    def _open_shaarawy_item(self, item, owner_id=999):
        route = self.route
        if item.get("video"):
            video_items = [it for it in route.items if it.get("video")] or [item]
            try:
                vid_idx = video_items.index(item)
            except ValueError:
                vid_idx = 0
            self.video_osd_visible = True
            self.open(Route("video", video_items, key=owner_id, index=vid_idx))
            self._start_video_episode()
        elif item.get("audio"):
            self.play_library_item(item, u"الشيخ محمد متولي الشعراوي")
            self.render()

    def _start_video_episode(self):
        route = self.route
        if route.name != "video" or not route.items:
            return
        item = route.items[route.index]
        url = item["audio"]
        play_url = self.downloader.local_media_path(url, is_video=True) or url
        track_entry = ("lib", (item["title"], self.video_owner()[1], item.get("badge", u"فيديو مرئي"), play_url))
        self.playing_items = [track_entry]
        self.playing_index = 0
        if self.audio is not None:
            self.audio.play(item["title"], play_url, False, self.clock_seconds(item.get("duration")), video=True)
        self.show_video_osd(auto_hide=True)

    @staticmethod
    def clock_seconds(text):
        try:
            parts = [int(p) for p in (text or u"").split(":") if p.strip().isdigit()]
        except Exception:
            return 0
        total = 0
        for part in parts[-3:]:
            total = total * 60 + part
        return total if len(parts) >= 2 else 0

    def skip_video(self, step):
        route = self.route
        if route.name != "video" or not route.items:
            return
        route.index = (route.index + step) % len(route.items)
        self._start_video_episode()

    def accept(self):
        if self.bio_open:
            self.bio_open = False          # entering anything closes the full biography first
        route = self.route
        if self.jump_buffer is not None:
            self.commit_jump()
        elif route.name == "video":
            self.video_osd_visible = not self.video_osd_visible
            if self.video_osd_visible:
                self.video_osd_timer.start(6000, True)
            else:
                self.video_osd_timer.stop()
            self.render()
        elif route.name == "home":
            if route.index == 0:
                self.open(Route("main_folders", self.catalog.main_portal_folders(), key="main"))
            elif route.index == 1:
                self.open(Route("shaarawy_folders", self.catalog.libraries[1]["folders"], key=1,
                                folder_title=self.catalog.libraries[1].get("title")))
            elif route.index == 10:
                self.open(Route("radios", [(None, radio[0]) for radio in self.catalog.radios]))
            elif route.index == 14:
                self.open(Route("quiz", self.catalog.libraries[14]["questions"], key=14))
            elif route.index in self.catalog.libraries:
                self.open(Route("library", self.catalog.libraries[route.index]["items"], key=route.index))
            else:
                self.flash(u"القسم قيد الإعداد")
        elif route.name == "gallery":
            key, _, editions = route.items[route.index]
            self.open(Route("reciter_hub", self.catalog.reciter_hub_folders(key), key))
        elif route.name == "reciter_hub":
            reciter_id = route.key
            if route.index == 0:
                editions = self.catalog.reciter[reciter_id][2]
                self.open(Route("editions", editions, reciter_id))
            else:
                self.catalog.request_reciter_videos(reciter_id, retry=True)
                videos = self.catalog.reciter_videos(reciter_id)
                self.open(Route("reciter_videos", videos, reciter_id))
        elif route.name == "reciter_videos":
            if route.items:
                self._open_shaarawy_item(route.items[route.index], owner_id=route.key)
        elif route.name == "editions":
            key = route.items[route.index][0]
            self.open(Route("surahs", self.catalog.tracks(key), key))
        elif route.name in ("main_folders", "shaarawy_folders") and route.items:
            folder = route.items[route.index]
            action = folder.get("action")
            if action == "reciters_gallery":
                self.open(Route("gallery", self.catalog.reciters, key="reciters", folder_title=u"قراء القرآن الكريم"))
            elif action == "mubtahileen_gallery":
                self.open(Route("gallery", self.catalog.mubtahileen, key="mubtahileen", folder_title=u"موسوعة الابتهالات وكبار المبتهلين"))
            elif action == "kishk_hub":
                self.open(Route("reciter_hub", self.catalog.reciter_hub_folders(950), 950))
            elif action == "mushaf_viewer":
                self.mushaf.request_page(self.mushaf_page, full_download=True)
                self.open(Route("mushaf", key=self.mushaf.base_dir))
            elif folder.get("folders"):
                self.open(Route("shaarawy_folders", folder["folders"], key=route.key, folder_title=folder["title"]))
            else:
                self.open(Route("shaarawy", folder["items"], key=route.index, folder_title=folder["title"]))
        elif route.name == "shaarawy" and route.items:
            self._open_shaarawy_item(route.items[route.index])
        elif route.name == "library":
            item = route.items[route.index]
            if item.get("children"):
                self.open(Route("library", item["children"], key=route.key, folder_title=item["title"]))
            elif item.get("counter"):
                target = item["counter"]
                k = (route.key, route.index)
                val = self.tasbih_counts.get(k, 0) + 1
                completed = val >= target
                self.tasbih_counts[k] = 0 if completed else val
                self.render()
                if completed:
                    self.flash(u"تقبّل الله! أتممت الورد · %d مرة" % target)
            elif item.get("edition") and item["edition"] in self.catalog.edition:
                ed_key = item["edition"]
                self.open(Route("surahs", self.catalog.tracks(ed_key), ed_key))
            elif item.get("audio"):
                self.play_library_item(item, self.catalog.libraries[route.key]["title"])
            else:
                if route.index + 1 < len(route.items):
                    route.index += 1
                    self.render()
        elif route.name == "quiz":
            q_obj = route.items[route.question_index % len(route.items)]
            if route.answered is None:
                route.answered = route.index
                correct = (route.index == q_obj["answer"])
                if correct:
                    route.score += 1
                self.render()
                if correct:
                    self.flash(u"إجابة صحيحة! أحسنت")
                else:
                    self.flash(u"الإجابة الصحيحة: " + q_obj["options"][q_obj["answer"]])
            else:
                route.question_index = (route.question_index + 1) % len(route.items)
                route.answered = None
                route.index = 0
                self.render()
        elif route.name == "mushaf":
            modes = ("image", "large")         # the typed-text view is gone: the page is always the real mushaf
            labels = {
                "image": u"وضع العرض: الصفحة كاملة",
                "large": u"وضع العرض: خط كبير (نصف صفحة)",
                "text": u"وضع العرض: النص القرآني المكتوب",
            }
            self.mushaf_half = 0
            cur = modes.index(self.mushaf_mode) if self.mushaf_mode in modes else 0
            self.mushaf_mode = modes[(cur + 1) % len(modes)]
            self.mushaf.request_page(self.mushaf_page, full_download=True)
            self.render()
            self.flash(labels[self.mushaf_mode])
        elif route.name in ("surahs", "radios", "favorites") and route.items:
            selected = route.items[route.index]
            current_playing = (
                self.playing_items[self.playing_index]
                if (self.playing_items and self.playing_index is not None and 0 <= self.playing_index < len(self.playing_items))
                else None
            )
            if current_playing == selected and self.audio is not None and self.audio.state in ("playing", "paused", "error", "finished"):
                self.play_control()
            else:
                prev_idx = self.playing_index if self.playing_items == route.items else None
                self.playing_items = list(route.items)
                self.playing_index = route.index
                self.start_track(prev_index=prev_idx)

    @staticmethod
    def _playlist_item(item):
        return bool(item.get("audio")) and not item.get("video") and not item.get("children") and not item.get("live") \
            and "qurango.net/radio" not in item.get("audio", "")

    def play_library_item(self, item, section_title):
        """Plays the item and queues the folder's other recordings after it (auto-continue, keys 2 / 8)."""
        url = item["audio"]
        play_url = self.downloader.local_media_path(url, is_video=False) or url
        is_live = False if play_url.startswith("/") else bool(item.get("live", "qurango.net/radio" in url))
        current = None
        if self.playing_items and self.playing_index is not None and 0 <= self.playing_index < len(self.playing_items):
            current = self.playing_items[self.playing_index]
        if (current is not None and current[0] == "lib" and current[1][3] in (url, play_url)
                and self.audio is not None and self.audio.state in ("playing", "paused")):
            self.play_control()
            return
        route = self.route
        items = route.items if (route.items and item in route.items) else [item]
        entries, indices = [], []
        self.lib_durations = {}
        if is_live or not self._playlist_item(item):
            entries = [("lib", (item["title"], section_title, item.get("badge", u"صوتيات إسلامية"), play_url))]
            indices = [route.items.index(item) if item in (route.items or []) else None]
        else:
            for i, it in enumerate(items):
                if it is item or self._playlist_item(it):
                    entries.append(("lib", (it["title"], section_title, it.get("badge", u"صوتيات إسلامية"), it["audio"])))
                    indices.append(i if items is route.items else None)
                    self.lib_durations[it["audio"]] = self.clock_seconds(it.get("duration"))
        self.playing_items = entries
        self.playing_index = next(n for n, e in enumerate(entries) if e[1][3] in (url, play_url))
        self.lib_route = route
        self.lib_indices = indices
        self.audio.play(item["title"], play_url, is_live, 0 if is_live else self.clock_seconds(item.get("duration")),
                        who=self.playing_who(self.playing_items[self.playing_index]))
        if self.route.name == "library":
            self._update_library_reader()
        elif self.route.name == "shaarawy":
            self._update_shaarawy_bio_panel()

    def start_track(self, prev_index=None):
        """Instant Surah start without redundant full-screen redraws."""
        if not self.playing_items or self.playing_index is None:
            return
        entry = self.playing_items[self.playing_index]
        title, _, _, url, _ = self.catalog.track(entry)
        if isinstance(entry[0], int) and self.downloader.is_downloaded(entry[0], entry[1]):
            url = self.downloader.surah_path(entry[0], entry[1])
        elif entry[0] == "lib":
            url = self.downloader.local_media_path(url, is_video=False) or url
        is_live = (entry[0] is None) or (entry[0] == "lib" and "qurango.net/radio" in url)
        expected = 0
        if entry[0] == "lib":
            expected = getattr(self, "lib_durations", {}).get(entry[1][3], 0)
            indices = getattr(self, "lib_indices", None) or []
            if (getattr(self, "lib_route", None) is self.route and self.playing_index < len(indices)
                    and indices[self.playing_index] is not None):
                self.route.index = indices[self.playing_index]      # the focus follows the playing recording
        if isinstance(entry[0], int):
            try:
                expected = self.catalog.surah_duration_seconds(entry[0], entry[1])
            except Exception:
                expected = 0
        self.audio.play(title, url, is_live, expected, who=self.playing_who(entry))
        self._prefetch_focus()
        if self.route.name in ("surahs", "radios", "favorites"):
            if prev_index is not None and prev_index != self.playing_index:
                self._refresh_sura_card_title(prev_index)
            self._refresh_sura_card_title(self.playing_index)
            self.render_integrated_player()
        else:
            self.render()

    def play_control(self):
        if self.route.name == "video":
            self.show_video_osd(auto_hide=True)
            if self.audio is not None and self.audio.state in ("idle", "error", "finished"):
                self._start_video_episode()
            elif self.audio is not None and self.audio.state != "connecting":
                self.audio.toggle()
                self.update_video_player()
            return
        if not self.playing_items or self.audio is None:
            if self.route.name in ("surahs", "radios", "favorites") and self.route.items:
                self.playing_items = list(self.route.items)
                self.playing_index = self.route.index
                self.start_track()
            return
        if self.audio.state in ("idle", "error", "finished"):
            self.start_track()
        elif self.audio.state != "connecting" and not self.audio.toggle():
            self.flash(u"الإيقاف المؤقت غير متاح لهذا البث")
        elif self.route.name in ("surahs", "radios", "favorites"):
            self.update_player()
        else:
            self.render()

    def seek(self, direction):
        self.seek_by(10 * direction)

    def can_seek_keys(self):
        """Digits seek while a track is on; otherwise they keep their navigation meaning."""
        audio = self.audio
        return bool(self.playing_items and audio is not None and self.route.name in
                    ("surahs", "radios", "favorites", "library", "shaarawy", "video")
                    and audio.state in ("playing", "paused", "connecting"))

    def seek_by(self, seconds):
        audio = self.audio
        if not self.playing_items or audio is None:
            return
        if audio.live:
            self.flash(u"بث مباشر · لا يوجد تقديم أو ترجيع")
        elif audio.state == "connecting":
            return
        elif not audio.seek_seconds(seconds):
            self.flash(u"التقديم والترجيع غير متاحين الآن")
        if self.route.name == "video":
            self.show_video_osd(auto_hide=True)

    def skip(self, step):
        if self.route.name == "video":
            self.skip_video(step)
            return
        if not self.playing_items or self.playing_index is None:
            return
        target = self.playing_index + step
        if 0 <= target < len(self.playing_items):
            prev_idx = self.playing_index
            self.playing_index = target
            old_page = self.route.index // layout.SURA_PAGE_SIZE
            if self.route.name in ("surahs", "radios", "favorites") and self.route.items == self.playing_items:
                self.route.index = target
            new_page = self.route.index // layout.SURA_PAGE_SIZE
            if old_page != new_page:
                self.start_track(prev_index=prev_idx)
                self.render()
            else:
                if self.route.name in ("surahs", "radios", "favorites"):
                    start = new_page * layout.SURA_PAGE_SIZE
                    self.highlight(layout.SURA_CARDS[self.route.index - start], "sura")
                self.start_track(prev_index=prev_idx)
        else:
            self.flash(u"وصلت إلى طرف القائمة")

    def track_ended(self):
        if self.route.name == "video":
            if self.route.index + 1 < len(self.route.items):
                self.skip_video(1)
            elif self.audio is not None:
                self.audio.finished()
                self.show_video_osd(auto_hide=False)
            return
        if not self.playing_items or self.audio is None:
            return
        if self.repeat:
            self.start_track()
        elif self.playing_index + 1 < len(self.playing_items):
            self.skip(1)
        else:
            self.audio.finished()

    def back(self):
        if self.jump_buffer is not None:
            self.cancel_jump()
            return
        if self.close_bio():
            return
        if len(self.stack) == 1:
            self.close()
            return
        route = self.stack.pop()
        if route.name == "video":
            self.video_osd_timer.stop()
        # sound keeps playing wherever you go inside the plugin (it stops when the plugin closes);
        # only a video stops when its full-screen view is left, because the picture needs that screen
        if route.name == "video" and self.audio is not None and self.playing_items:
            self.audio.release()
            self.playing_items = None
            self.playing_index = None
            self.repeat = False
        self.render()

    # ------------------------------------------------------------------ online update (red key on home)
    def check_update(self):
        from .updater import UPDATER
        if UPDATER.state in ("available",):
            self._offer_update()
            return
        if UPDATER.state == "done":
            self._offer_restart()
            return
        if UPDATER.check(manual=True):
            self.flash(u"جار البحث عن تحديث…")
        self.update_timer.start(1000, False)

    def poll_update(self):
        from .updater import UPDATER
        state = UPDATER.state
        manual = UPDATER.manual
        if state == "checking":
            return
        if state == "downloading":
            self.flash(u"جار تحميل التحديث  ·  %d%%" % UPDATER.progress)
            return
        if state == "installing":
            self.flash(u"جار تثبيت التحديث…")
            return
        self.update_timer.stop()
        if state == "available":
            if manual:
                self._offer_update()
            elif self.route.name == "home":
                self.flash(u"يوجد تحديث جديد %s  ·  اضغط الزر الأحمر للتثبيت" % UPDATER.info.get("version", u""))
        elif state == "latest" and manual:
            from . import VERSION
            self.flash(u"أنت على آخر إصدار  ·  %s" % VERSION)
        elif state == "error" and manual:
            self.flash(UPDATER.message or u"تعذر التحديث")
        elif state == "done":
            self._offer_restart()

    def _offer_update(self):
        from .updater import UPDATER
        info = UPDATER.info
        from .updater import notes
        self.open_choice(u"تحديث جديد  ·  %s" % info.get("version", u""), notes(info) or u"Ultra Quran",
                         [(u"تحميل وتثبيت التحديث الآن", self._start_install)])

    def _start_install(self):
        from .updater import UPDATER
        if UPDATER.install():
            self.flash(u"جار تحميل التحديث…")
            self.update_timer.start(1000, False)

    def _offer_restart(self):
        self.open_choice(u"تم تثبيت التحديث", u"يلزم إعادة تشغيل الواجهة لتفعيل الإصدار الجديد",
                         [(u"إعادة تشغيل الواجهة الآن", self._restart_gui)])

    def _restart_gui(self):
        try:
            from Screens.Standby import TryQuitMainloop
            self.session.open(TryQuitMainloop, 3)
        except Exception:
            log_exception("GUI restart failed")
            self.flash(u"أعد تشغيل الجهاز لتفعيل التحديث")

    def red(self):
        route = self.route
        if route.name == "home":
            self.check_update()
            return
        if route.name == "video":
            self.skip_video(-1)
        elif route.name == "mushaf":
            self.mushaf.toggle_riwaya()
            self.mushaf_half = 0
            if self.mushaf.riwaya != "hafs" and self.mushaf_mode == "text":
                self.mushaf_mode = "image"
            self.mushaf.request_page(self.mushaf_page, full_download=True)
            self.render()
            self.flash(u"الرواية: %s" % self.mushaf.riwaya_name())
        elif route.name == "shaarawy" and route.items:
            item = route.items[route.index]
            if item.get("audio") and not item.get("live"):
                self.choose_download(item, collect_media({"items": route.items}), SHAARAWY_NAME,
                                     route.folder_title or SHAARAWY_NAME)
            else:
                self.back()
        elif route.name == "shaarawy_folders" and self.shaarawy_root():
            self.back()
        elif route.name == "shaarawy_folders" and route.items:
            folder = route.items[route.index]
            self.choose_download(None, collect_media(folder), SHAARAWY_NAME, folder.get("title", u""))
        elif route.name == "reciter_videos" and route.items:
            item = route.items[route.index]
            reciter_name = self.catalog.reciter.get(route.key, (0, u"القرآن الكريم"))[1]
            self.choose_download(item, collect_media({"items": route.items}), reciter_name,
                                 u"فيديوهات " + reciter_name, video=True)
        elif route.name == "reciter_hub":
            self.back()
        elif route.name == "library" and route.items:
            item = route.items[route.index]
            sec_title = self.catalog.libraries[route.key]["title"]
            if item.get("children"):
                self.choose_download(None, collect_media(item), sec_title, item["title"])
            elif item.get("audio") and not item.get("live") and "qurango.net/radio" not in item.get("audio", ""):
                self.choose_download(item, collect_media({"items": route.items}), sec_title,
                                     route.folder_title or sec_title)
            else:
                self.page_step(-1)
        elif route.name in ("gallery", "radios"):
            self.page_step(-1)
        elif route.name == "editions" and route.items:
            ed_id = route.items[route.index][0]
            count = self.downloader.enqueue_edition(ed_id)
            self.render()
            if count > 0:
                self.flash(u"بدأ تحميل فولدر الرواية بالكامل · %d سورة على الهارد" % count)
            else:
                self.flash(u"فولدر الرواية محمّل بالكامل على الهارد")
        elif route.name in ("surahs", "favorites") and route.items:
            entry = route.items[route.index]
            if not isinstance(entry[0], int):
                return
            ed_id, chapter = entry
            self.choose_surah_download(ed_id, chapter)

    def choose_download(self, item, folder_items, section_title, folder_title, video=False):
        """Red key: ask 'this item only' or 'the whole folder' (or just confirm a folder)."""
        kind = u"الفيديو" if video else u"المادة"
        options = []
        if item is not None:
            if self.downloader.is_media_downloaded(item.get("audio"), is_video=bool(item.get("video"))):
                label = u"%s محمّلة بالفعل على الهارد" % kind if not video else u"الفيديو محمّل بالفعل على الهارد"
            else:
                label = u"تحميل هذه %s فقط" % kind if not video else u"تحميل هذا الفيديو فقط"
            options.append((label, lambda: self._download_one(item, section_title, video)))
        if folder_items:
            options.append((u"تحميل الفولدر كامل  ·  %d مادة" % len(folder_items),
                            lambda: self._download_folder(folder_items, section_title, folder_title)))
        if not options:
            self.flash(u"هذا الفولدر بث مباشر أو نصوص للقراءة · لا يحتاج تحميل")
            return
        sub = one_line(item.get("title", u""), 60) if item is not None else one_line(folder_title, 60)
        self.open_choice(u"التحميل على الهارد", sub, options)

    def _download_one(self, item, section_title, video=False):
        if self.downloader.enqueue_media(item, section_title):
            self.render()
            self.flash(u"بدأ حفظ الفيديو على الهارد للمشاهدة بدون إنترنت" if video else
                       u"بدأ حفظ المادة على الهارد للتشغيل بدون إنترنت")
        else:
            self.flash(u"محمّل بالفعل على الهارد أو قيد التحميل")

    def choose_surah_download(self, ed_id, chapter):
        name = self.catalog.track_title(ed_id, chapter)
        total = len(self.catalog.edition[ed_id][1][3]) if ed_id in self.catalog.edition else 0
        if self.downloader.is_downloaded(ed_id, chapter):
            one = u"%s محمّلة بالفعل" % plain(name)
        elif self.downloader.is_queued(ed_id, chapter):
            one = u"%s قيد التحميل" % plain(name)
        else:
            one = u"تحميل %s فقط" % plain(name)

        def surah():
            if self.downloader.enqueue_surah(ed_id, chapter):
                self.render()
                self.flash(u"بدأ تحميل %s على الهارد" % plain(name))
            else:
                self.flash(u"%s محمّلة أو قيد التحميل على الهارد" % plain(name))

        def edition():
            count = self.downloader.enqueue_edition(ed_id)
            self.render()
            if count > 0:
                self.flash(u"بدأ تحميل فولدر الشيخ بالكامل · %d سورة على الهارد" % count)
            else:
                self.flash(u"جميع سور هذا المصحف محمّلة أو قيد التحميل على الهارد")

        reciter = u""
        try:
            reciter = self.catalog.edition[ed_id][0][1]
        except Exception:
            pass
        self.open_choice(u"التحميل على الهارد", reciter,
                         [(one, surah), (u"تحميل فولدر الشيخ كامل  ·  %d سورة" % total, edition)])

    def _download_folder(self, items, section_title, folder_title):
        if not items:
            self.flash(u"هذا الفولدر بث مباشر أو نصوص للقراءة · لا يحتاج تحميل")
            return
        count = self.downloader.enqueue_media_many(items, section_title)
        self.render()
        if count > 0:
            self.flash(u"بدأ تحميل الفولدر كامل على الهارد · %d مادة" % count)
        else:
            self.flash(u"فولدر «%s» محمّل بالكامل أو قيد التحميل" % one_line(folder_title, 30))

    def yellow(self):
        route = self.route
        if route.name in BIO_VIEWS and self.toggle_bio():
            return
        if route.name == "video":
            self.accept()
        elif route.name == "home":
            self.mushaf.request_page(self.mushaf_page, full_download=True)
            self.open(Route("mushaf", key=self.mushaf.base_dir))
        elif route.name == "gallery":
            self.page_step(1)
        elif route.name == "quiz":
            route.question_index = (route.question_index + 1) % len(route.items)
            route.answered = None
            route.index = 0
            self.render()
        elif route.name in ("surahs", "favorites") and self.playing_items and self.audio is not None and not self.audio.live and self.audio.state in ("playing", "paused", "connecting"):
            self.repeat = not self.repeat
            self.update_player()
        elif route.name in ("mushaf", "main_folders", "surahs", "editions", "shaarawy", "shaarawy_folders", "radios", "favorites", "library"):
            self.jump_buffer = ""
            self.jump_label()

    def green(self):
        route = self.route
        if route.name == "video":
            self.play_control()
        elif route.name == "home":
            self.resume_last()
        elif route.name in ("main_folders", "shaarawy_folders", "reciter_videos", "reciter_hub") and route.items:
            self.accept()
        elif route.name == "shaarawy" and route.items:
            self._open_shaarawy_item(route.items[route.index])
        elif route.name in ("surahs", "radios", "favorites"):
            self.play_control()
        elif route.name == "editions" and route.items:
            ed_id = route.items[route.index][0]
            count = self.downloader.enqueue_edition(ed_id)
            self.render()
            if count > 0:
                self.flash(u"بدأ تحميل فولدر الرواية بالكامل · %d سورة على الهارد" % count)
            else:
                self.flash(u"فولدر الرواية محمّل بالكامل على الهارد")
        elif route.name in ("gallery", "reciter_hub"):
            self.mushaf.request_page(self.mushaf_page, full_download=True)
            self.open(Route("mushaf", key=self.mushaf.base_dir))
        elif route.name == "library":
            item = route.items[route.index]
            if item.get("children"):
                self.accept()
            elif item.get("audio"):
                self.play_library_item(item, self.catalog.libraries[route.key]["title"])
            elif item.get("edition") and item["edition"] in self.catalog.edition:
                ed_key = item["edition"]
                self.open(Route("surahs", self.catalog.tracks(ed_key), ed_key))
            else:
                self.flash(u"هذه المادة للقراءة والتدبر")
        elif route.name == "mushaf":
            if len(self.stack) > 1 and self.stack[-2].name in ("gallery", "reciter_hub"):
                self.back()
            else:
                self.open(Route("gallery", self.catalog.reciters))

    def blue(self):
        route = self.route
        if route.name == "video":
            self.skip_video(1)
            return
        if route.name == "mushaf":
            state = self.mushaf.bulk_state()
            name = self.mushaf.riwaya_name()
            if state["saved"] >= 604:
                self.flash(u"مصحف %s محفوظ بالكامل على الهارد · 604 صفحة" % name)
            elif state["running"]:
                self.flash(u"التحميل شغال: %d / 604 صفحة (مصحف %s)" % (state["saved"], name))
            else:
                self.mushaf.start_full_download()
                self.flash(u"بدأ تحميل مصحف %s كامل على الهارد · %d / 604" % (name, state["saved"]))
            self.render()
            return
        if route.name in ("home", "main_folders", "gallery", "reciter_hub", "editions", "shaarawy", "shaarawy_folders", "radios", "library", "quiz"):
            self.open(Route("favorites", self.offline_and_favorites_list()))
            return
        if route.name not in ("surahs", "favorites") or not route.items:
            return
        entry = route.items[route.index]
        if entry[0] is None or entry[0] == "lib":
            self.flash(u"هذه المادة محفوظة في مكتبة الهارد للاستماع بدون نت")
            return
        if entry in self.favorites:
            updated = [item for item in self.favorites if item != entry]
            message = u"تمت الإزالة من المفضلة"
        elif len(self.favorites) < 200:
            updated = self.favorites + [entry]
            message = u"تم الحفظ في المفضلة"
        else:
            self.flash(u"المفضلة ممتلئة")
            return
        try:
            save_favorites(updated)
        except (IOError, OSError):
            log_exception("Could not save favorites")
            self.flash(u"تعذّر حفظ المفضلة")
            return
        self.favorites = updated
        if route.name == "favorites":
            route.items = self.offline_and_favorites_list()
            route.index = min(route.index, max(0, len(route.items) - 1))
        self.render()
        self.flash(message)

    def jump_label(self):
        self.text("jump", u"اكتب الرقم ثم اضغط موافقة   ·   " + (self.jump_buffer or u"___"), (550, 932, 820, 60))

    def cancel_jump(self):
        self.jump_buffer = None
        self.jump_timer.stop()
        self.hide_widget("jump")

    SEEK_KEYS = {1: -10, 3: 10, 4: -60, 6: 60, 7: -300, 9: 300}

    def number(self, digit):
        if self.jump_buffer is None and self.route.name == "library" and self.lib_pages > 1 and digit in (2, 8):
            self.lib_turn(-1 if digit == 2 else 1)
            return
        if self.jump_buffer is None and self.route.name == "mushaf" and self.mushaf_subpages > 1 and digit in (2, 8):
            self.mushaf_subpage = (self.mushaf_subpage + (-1 if digit == 2 else 1)) % self.mushaf_subpages
            self.render()
            return
        if self.jump_buffer is None and self.can_seek_keys():
            if digit in self.SEEK_KEYS:
                self.seek_by(self.SEEK_KEYS[digit])
                return
            if digit == 5:
                self.play_control()
                return
            if digit == 2:
                self.skip(-1)
                return
            if digit == 8:
                self.skip(1)
                return
            if digit == 0 and self.route.name in ("surahs", "favorites", "radios", "library", "shaarawy"):
                self.jump_buffer = ""
                self.jump_label()
                return
        if self.route.name == "home" and 1 <= digit <= 9:
            self.route.index = digit - 1
            self.highlight(layout.HOME[self.route.index], "home")
            self._update_home_footer()
            return
        if self.route.name == "gallery" and self.jump_buffer is None and digit == 0:
            if self.route.key == "mubtahileen":
                self.route.items = self.catalog.reciters
                self.route.key = "reciters"
                self.route.index = 0
                self.render()
                self.flash(u"تم التبديل إلى معرض قراء القرآن الكريم (%d قارئ)" % len(self.catalog.reciters))
            else:
                self.route.items = self.catalog.mubtahileen
                self.route.key = "mubtahileen"
                self.route.index = 0
                self.render()
                self.flash(u"تم التبديل إلى معرض كبار المبتهلين (%d مبتهل)" % len(self.catalog.mubtahileen))
            return
        if self.route.name not in ("gallery", "main_folders", "surahs", "mushaf", "editions", "shaarawy", "shaarawy_folders", "radios", "favorites", "library"):
            return
        self.jump_buffer = (self.jump_buffer or "") + str(digit)
        if len(self.jump_buffer) == 3:
            self.commit_jump()
        else:
            self.jump_label()
            self.jump_timer.start(2400)

    def commit_jump(self):
        value = self.jump_buffer
        self.cancel_jump()
        if not value:
            return
        number = int(value)
        route = self.route
        if route.name == "mushaf" and 1 <= number <= 604:
            self.mushaf_page = number
            self.mushaf_subpage = 0
            self.mushaf_half = 0
            self.tafsir_sub = 0
        elif route.name == "surahs" and (route.key, number) in route.items:
            route.index = route.items.index((route.key, number))
        elif route.name in ("gallery", "main_folders", "editions", "shaarawy", "shaarawy_folders", "radios", "favorites", "library") and 1 <= number <= len(route.items):
            route.index = number - 1
        else:
            self.flash(u"الرقم غير متاح في القائمة الحالية")
            return
        self.render()

    def cleanup(self):
        self.bio_scroll.close()
        self.bio_timer.close()
        self.jump_timer.close()
        self.notice.close()
        self.portrait_timer.close()
        self.warm_timer.close()
        self.download_timer.close()
        self.mushaf_timer.close()
        self.sync_timer.close()
        self.video_osd_timer.close()
        self.lib_timer.close()
        self.update_timer.close()
        if self.audio is not None:
            self.audio.close()
