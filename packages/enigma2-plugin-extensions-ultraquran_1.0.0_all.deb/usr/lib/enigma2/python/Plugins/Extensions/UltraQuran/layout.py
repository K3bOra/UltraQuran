# -*- coding: utf-8 -*-
"""1080p master coordinates (0.5.0 "Royal Emerald" design), shared by the art builder and Enigma2.

Every screen is a full-bleed 1920x1080 composition: top bar (y 18..75), content (y 92..984), footer (y 1001..1063).
"""
MASTER = (1920, 1080)
SIZES = ((3840, 2160), (2560, 1440), (1920, 1080), (1280, 720), (720, 405))

TOPBAR = (53, 18, 1814, 57)
# now-playing strip inside the top bar (between the breadcrumb capsule and the title)
TOP_ELAPSED = (676, 27, 96, 34)
TOP_TRACK = (782, 43, 396, 8)
TOP_REMAIN = (1190, 27, 100, 34)
FOOTER = (53, 1001, 1814, 62)

# ---- Home: hero strip + 5x3 section tiles --------------------------------------------------------
HOME_HERO = (53, 90, 1814, 172)
HOME_TILE = (350, 224)
GALLERY_PAGE = (1566, 1008, 282, 48)        # page / sheikh counter at the right end of the gallery footer
# premium hero: ayah of the day (left), continue-listening card (middle), date + focused-section line (right)
HOME_AYAH_BOX = (77, 106, 600, 140)
HOME_AYAH = (93, 125, 568, 102)         # centred between the caption and the surah line; two lines of 27 fit (2 x 1.88 x 27 < 102)
HOME_AYAH_REF = (95, 220, 564, 24)
HOME_RESUME_BOX = (700, 106, 560, 140)
HOME_RESUME_CAP = (720, 112, 520, 32)
HOME_RESUME_TITLE = (720, 144, 520, 40)
HOME_RESUME_SUB = (720, 184, 520, 30)
HOME_RESUME_HINT = (720, 212, 520, 28)
HOME_CLOCK = (1652, 90, 186, 64)          # big gold clock, right end of the hero
HOME_DATE = (1290, 102, 340, 52)           # day + Hijri date next to it
HOME_DESC = (1290, 218, 548, 36)
HOME = [(1517 - (i % 5) * 366, 278 + (i // 5) * 238, 350, 224) for i in range(15)]
HOME_TILES_META = (
    (u"القرآن الكريم", u"260 قارئ · تلاوات ومصحف"),
    (u"الشيخ الشعراوي", u"2776 مادة · صوتيات وفيديو"),
    (u"التفسير وعلومه", u"الطبري وابن كثير · 1155 درساً"),
    (u"الحديث الشريف", u"شروح صوتية كاملة · 681 مادة"),
    (u"السنة والشمائل", u"الشمائل والطب النبوي · 206 مادة"),
    (u"السيرة النبوية", u"العوضي والرحيق · 167 حلقة"),
    (u"قصص الأنبياء", u"العوضي والشعراوي · 108 حلقة"),
    (u"العقيدة والفقه", u"التوحيد وفقه العبادات · 97 درساً"),
    (u"الأذكار والرقية", u"حصن المسلم والرقية والمسبحة"),
    (u"أسماء الله الحسنى", u"الأسماء الـ 99 ومعانيها الكاملة"),
    (u"إذاعات القرآن", u"173 إذاعة قرآنية وإسلامية"),
    (u"المكتبة الإسلامية", u"زاد المعاد والمتون · 111 مادة"),
    (u"عالم الأطفال", u"المصحف المعلم وجزء عمّ والآداب"),
    (u"التقويم الإسلامي", u"التاريخ الهجري والمواسم الفاضلة"),
    (u"المسابقات", u"70 سؤالاً تفاعلياً بالنتيجة"),
)
HOME_TILES_DESC = (
    u"المصاحف المرتلة لـ 260 قارئاً مع المصحف المصور والتفسير",
    u"خواطر الإمام الشعراوي في التفسير صوتاً وصورة",
    u"دروس التفسير الكاملة وعلوم القرآن وإذاعات التفسير",
    u"شروح كتب الحديث بأصوات كبار العلماء",
    u"الشمائل المحمدية وهدي النبي في يومه",
    u"سيرة النبي صلى الله عليه وسلم من المولد إلى الوفاة",
    u"قصص الأنبياء والمرسلين كما وردت في القرآن",
    u"أصول العقيدة وأحكام العبادات بأسلوب ميسر",
    u"أذكار الصباح والمساء والرقية الشرعية والمسبحة",
    u"أسماء الله الحسنى التسعة والتسعون ومعانيها",
    u"إذاعات القرآن الكريم والأذكار بثاً مباشراً",
    u"أمهات الكتب الإسلامية والمتون مقروءة ومسموعة",
    u"المصحف المعلم وجزء عم وقصص الأطفال والآداب",
    u"التاريخ الهجري والأيام والمواسم الفاضلة",
    u"اختبر معلوماتك في القرآن والسيرة والفقه",
)

# ---- Reciter gallery: 7 x 2 posters ----------------------------------------------------------------
POSTER_COLS = 7
POSTER_PAGE_SIZE = 14
POSTER_SIZE = (246, 438)
POSTER_PLATE = 76          # name plate height at the bottom of every poster
POSTERS = [(1621 - column * 261, top, 246, 438)
           for top in (92, 546) for column in range(POSTER_COLS)]
POSTER_FOCUS_MARGIN = 9
FOCUS_MARGIN = 14
GRID_PAGE = (1060, 1011, 780, 42)

# ---- Reciter / editions / Shaarawy: spotlight tower (left) + header deck + 3x4 cards -----------------
EDITIONS_TOWER = (53, 92, 470, 892)
EDITIONS_POSTER = (159, 108, 258, 459)
EDITIONS_BADGE_REC = (70, 582, 206, 40)
EDITIONS_BADGE_RIW = (300, 582, 206, 40)
EDITIONS_BIO_PANEL = (69, 632, 438, 340)
EDITIONS_BIO_HEADING = (79, 638, 418, 38)
EDITIONS_BIO_BORN = (83, 682, 200, 64)
EDITIONS_BIO_DIED = (293, 682, 200, 64)
EDITIONS_BIO_TEXT = (78, 754, 420, 166)
EDITIONS_BIO_SOURCE = (79, 928, 418, 38)

EDITIONS_HEADER = (541, 92, 1326, 128)
EDITIONS_TITLE = (570, 92, 1250, 72)
EDITIONS_SUB = (570, 162, 1250, 46)
ECARD_COLS = 3
ECARD_ROWS = 4
ECARD_PAGE_SIZE = 12
ECARD_SIZE = (430, 174)
ECARDS = [(1437 - col * 448, 236 + row * 188, 430, 174)
          for row in range(ECARD_ROWS) for col in range(ECARD_COLS)]

# ---- Surahs / radios / favorites: studio player (left) + header deck + 3x5 cards ----------------------
LIST_HEADER = (708, 92, 1159, 132)
LIST_TITLE = (736, 92, 1100, 72)
LIST_SUB = (1000, 162, 836, 46)
LIST_COUNT = (736, 162, 250, 46)
SURA_COLS = 3
SURA_ROWS_COUNT = 5
SURA_PAGE_SIZE = 15
SURA_SIZE = (377, 136)
SURA_CARDS = [(1490 - col * 391, 240 + row * 148, 377, 136)
              for row in range(SURA_ROWS_COUNT) for col in range(SURA_COLS)]

# ---- Libraries & quiz: reader tower (left) + header deck + 2x5 cards -----------------------------------
LIB_COLS = 2
LIB_ROWS_COUNT = 5
LIB_PAGE_SIZE = 10
LIB_SIZE = (572, 136)
LCARDS = [(1295 - col * 587, 240 + row * 148, 572, 136)
          for row in range(LIB_ROWS_COUNT) for col in range(LIB_COLS)]
ROWS = LCARDS

# parts inside a card (so the art builder and screen.py agree): num chip, title, meta chip
def card_parts(kind, box):
    """Glass card anatomy: gear ornament (top-left), large number plate (top-right), CENTERED title, meta capsule.

    The title uses all the room between the ornament and the number plate, two lines tall, so a long name is
    shown whole instead of a few words with "…".
    """
    x, y, w, h = box
    if kind == "ecard":
        return {"num": (x + w - 106, y + 14, 92, 48), "title": (x + 58, y + 8, w - 174, 90),
                "meta": (x + 16, y + h - 66, w - 32, 50)}
    return {"num": (x + w - 104, y + 12, 90, 44), "title": (x + 56, y + 4, w - 166, 72),
            "meta": (x + 16, y + h - 58, w - 32, 44)}


# ---- Studio player tower (left side of surahs / radios / favorites)
SURA_PLAYER_PANEL = (56, 92, 628, 892)
SURA_PLAYER_SOURCE = (376, 106, 286, 40)
SURA_PLAYER_MODE = (78, 106, 282, 40)
SURA_PLAYER_PORTRAIT = (270, 156, 200, 210)
SURA_PLAYER_TITLE = (78, 374, 584, 54)
SURA_PLAYER_META = (104, 432, 532, 38)
SURA_PLAYER_RECITER = (78, 474, 584, 42)
SURA_PLAYER_RIWAYA = (74, 518, 592, 36)
SURA_PLAYER_STATUS = (88, 558, 564, 40)
SURA_PLAYER_PROGRESS = (186, 643, 368, 12)
SURA_PLAYER_ELAPSED = (82, 629, 96, 34)
SURA_PLAYER_DURATION = (562, 629, 96, 34)
SURA_PLAYER_BTNS = [
    (86, 696, 130, 50),
    (226, 696, 164, 50),
    (400, 696, 122, 50),
    (532, 696, 122, 50),
]
SURA_PLAYER_CONTROL = (232, 700, 152, 42)
SURA_PLAYER_QUEUE = (82, 756, 576, 44)
SURA_PLAYER_INFO = (82, 806, 576, 36)
SURA_PLAYER_DL = (82, 848, 576, 112)


# ---- Library reader tower
LIB_PANEL = (56, 92, 628, 892)
LIB_BADGE = (108, 110, 524, 42)
LIB_HEADING = (84, 160, 572, 82)
LIB_BODY = (86, 254, 568, 548)
LIB_ACTION = (84, 814, 572, 142)
# mini player inside the library action box (title line, gold bar, times row, key hint)
LIB_MINI = {"title": (100, 820, 540, 42), "bar": (188, 870, 364, 10), "elapsed": (92, 855, 90, 34),
            "total": (558, 855, 90, 34), "hint": (100, 900, 540, 34)}
# mini player inside the Sheikh's bio panel (editions-style screens)
EDITIONS_BIO_TEXT_SHORT = (78, 752, 420, 104)
# full biography (yellow / INFO on a sheikh's pages): it takes the whole left tower instead of the photo card
BIO_FULL_PANEL = EDITIONS_TOWER
BIO_FULL_HEADING = (97, 106, 382, 48)
BIO_FULL_BORN = (77, 166, 206, 66)
BIO_FULL_DIED = (293, 166, 206, 66)
BIO_FULL_TEXT_BOX = (71, 244, 434, 676)
BIO_FULL_TEXT = (79, 252, 418, 660)
BIO_FULL_SOURCE = (97, 926, 382, 40)
EDITIONS_MINI = {"bar": (160, 878, 256, 10), "elapsed": (80, 863, 74, 34), "total": (422, 863, 74, 34), "title": (79, 928, 418, 38)}

# Ultra Stalker Floating Islands VOD Player (livebar2 architecture — zero background scrim/shadow!)
# Islands and footer bars end level with the poster plate (y=1068); 6px between islands and footer bars.
# Left Poster stands cleanly at x=28..264; Center VOD Island starts at x=284..1496; Right Island at x=1512..1880
VIDEO_BAR = (0, 620, 1920, 460)
VIDEO_POSTER = (28, 624, 246, 438)
VIDEO_POSTER_NAME = (36, 992, 230, 62)
VIDEO_BADGE_1 = (1700, 1020, 170, 40)
VIDEO_BADGE_2 = (1522, 1020, 170, 40)
VIDEO_TITLE = (324, 802, 1132, 62)
VIDEO_PROGRESS = (420, 878, 940, 12)
VIDEO_ELAPSED = (304, 864, 108, 34)
VIDEO_STATUS = (312, 898, 1156, 38)
VIDEO_DURATION = (1368, 864, 108, 34)
VIDEO_QUEUE = (312, 944, 1156, 46)
VIDEO_QUEUE_TEXT = (336, 944, 1108, 46)
VIDEO_RECITER = (1528, 808, 336, 44)
VIDEO_INFO = (1528, 864, 336, 38)
VIDEO_HINT = (1528, 912, 336, 78)

MUSHAF = (129, 170, 1662, 765)
# ---- Mushaf stage: help panel (left) | gilded page frame | info panel (right) --------------------
MUSHAF_PANEL_L = (53, 92, 505, 892)
MUSHAF_FRAME = (578, 92, 764, 892)
MUSHAF_IMG = (608, 122, 704, 832)
MUSHAF_FRAME_WINDOW = 42        # the overlay frame covers the page up to this inset (page edges hidden)
MUSHAF_PANEL_R = (1362, 92, 505, 892)
MUSHAF_SURAH = (1382, 176, 465, 44)
MUSHAF_JUZ = (1382, 220, 465, 32)
MUSHAF_TAFSIR = (1398, 296, 435, 548)
MUSHAF_PROGRESS = (1402, 868, 425, 10)
MUSHAF_STATE = (1382, 886, 465, 80)
MUSHAF_TEXT_HEAD = (620, 134, 680, 44)
MUSHAF_TEXT_BODY = (624, 188, 672, 690)
MUSHAF_TEXT_FOOT = (620, 884, 680, 56)

# ---- Quran portal: four tall folder cards (right -> left) --------------------------------------
PORTAL_CARDS = [(1427 - i * 458, 176, 440, 808) for i in range(4)]

# ---- Folder decks: poster + biography tower on the left, up to three tall glass cards beside it ------
# (a fourth folder slides in with the arrows; two cards are centred in the free area)
PMARK = (30, 26, 12)        # gold 'now playing' chevrons: w, h, gap to the text
DECK_CARD = (426, 748)
DECK_VISIBLE = 3
DECK_BADGE = (40, 590, 346, 64)   # the count capsule, relative to a deck card
DECK_AREA = (541, 236, 1326, 748)


def deck_cards(n):
    """Slot rectangles (right-to-left) for n visible deck cards (1..3), centred in the deck area."""
    n = max(1, min(DECK_VISIBLE, n))
    w, h = DECK_CARD
    gap = 24
    total = n * w + (n - 1) * gap
    x0 = DECK_AREA[0] + (DECK_AREA[2] - total) // 2
    return [(x0 + total - w - i * (w + gap), DECK_AREA[1], w, h) for i in range(n)]



def pixel(value, width):
    return (value * width + 960) // 1920


def scaled(rect, width):
    x, y, w, h = rect
    left, top = pixel(x, width), pixel(y, width)
    return (left, top, pixel(x + w, width) - left, pixel(y + h, width) - top)


# ---------------------------------------------------------------- choice dialog (download: this item / whole folder)
DLG_W = 820
DLG_ROW = (680, 74)
DLG_PITCH = 90


def dlg_geometry(rows):
    """Rectangles of the centred choice dialog with `rows` option buttons (2 or 3)."""
    h = 196 + rows * DLG_PITCH + 62
    x = (1920 - DLG_W) // 2
    y = (1080 - h) // 2 - 20
    return {
        "panel": (x, y, DLG_W, h),
        "title": (x + 50, y + 28, DLG_W - 100, 56),
        "sub": (x + 50, y + 98, DLG_W - 100, 44),
        "rows": [(x + (DLG_W - DLG_ROW[0]) // 2, y + 164 + i * DLG_PITCH, DLG_ROW[0], DLG_ROW[1]) for i in range(rows)],
    }
